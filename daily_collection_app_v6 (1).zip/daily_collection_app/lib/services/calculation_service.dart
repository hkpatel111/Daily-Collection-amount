class CalcResult {
  final int totalDays;
  final double profit;
  final double dailyInterestRate;
  final double monthlyInterestRate;
  final double yearlyInterestRate;
  final String endDate;
  final double lastDayAdjustedAmount;

  CalcResult({
    required this.totalDays, required this.profit, required this.dailyInterestRate,
    required this.monthlyInterestRate, required this.yearlyInterestRate,
    required this.endDate, required this.lastDayAdjustedAmount,
  });
}

class CalculationService {
  static String today() {
    final now = DateTime.now();
    return '${now.year}-${now.month.toString().padLeft(2, '0')}-${now.day.toString().padLeft(2, '0')}';
  }

  static String now() {
    final now = DateTime.now();
    return '${now.year}-${now.month.toString().padLeft(2, '0')}-${now.day.toString().padLeft(2, '0')} '
           '${now.hour.toString().padLeft(2, '0')}:${now.minute.toString().padLeft(2, '0')}:${now.second.toString().padLeft(2, '0')}';
  }

  static String formatDate(String date) {
    if (date.length < 10) return date;
    final parts = date.substring(0, 10).split('-');
    if (parts.length != 3) return date;
    return '${parts[2]}/${parts[1]}/${parts[0]}';
  }

  static String formatDateTime(String dt) {
    if (dt.length < 10) return dt;
    final datePart = dt.substring(0, 10);
    final timePart = dt.length > 10 ? dt.substring(11) : '';
    return '${formatDate(datePart)} $timePart';
  }

  static String formatCurrency(double amount) {
    bool isNegative = amount < 0;
    amount = amount.abs();
    int rupees = amount.toInt();
    String rupeeStr = rupees.toString();
    if (rupeeStr.length > 3) {
      final sb = StringBuffer();
      int count = 0;
      for (int i = rupeeStr.length - 1; i >= 0; i--) {
        if (count == 3) { sb.write(','); count = 1; }
        else if (count > 0 && count % 2 == 0) { sb.write(','); }
        sb.write(rupeeStr[i]);
        count++;
      }
      rupeeStr = sb.toString().split('').reversed.join();
    }
    return 'Rs $rupeeStr${isNegative ? ' (Dr)' : ''}';
  }

  static int daysBetween(String startDate, String endDate) {
    final start = DateTime.parse(startDate);
    final end = DateTime.parse(endDate);
    return end.difference(start).inDays;
  }

  static CalcResult calculateLoan({
    required double principal, required double returnAmount,
    required double dailyInstallment, required String startDate,
  }) {
    if (principal <= 0 || returnAmount <= principal || dailyInstallment <= 0) {
      return CalcResult(totalDays: 0, profit: 0, dailyInterestRate: 0,
        monthlyInterestRate: 0, yearlyInterestRate: 0, endDate: startDate, lastDayAdjustedAmount: 0);
    }
    final profit = returnAmount - principal;
    final exactDays = returnAmount / dailyInstallment;
    final totalDays = exactDays.ceil();
    final lastDayAdjustedAmount = (returnAmount - (dailyInstallment * (totalDays - 1))).roundToDouble();
    final dailyInterestRate = (profit / (principal * totalDays)) * 100;
    final monthlyInterestRate = dailyInterestRate * 30;
    final yearlyInterestRate = dailyInterestRate * 365;
    final start = DateTime.parse(startDate);
    final end = start.add(Duration(days: totalDays - 1));
    final endDate = '${end.year}-${end.month.toString().padLeft(2, '0')}-${end.day.toString().padLeft(2, '0')}';
    return CalcResult(totalDays: totalDays, profit: profit, dailyInterestRate: dailyInterestRate,
      monthlyInterestRate: monthlyInterestRate, yearlyInterestRate: yearlyInterestRate,
      endDate: endDate, lastDayAdjustedAmount: lastDayAdjustedAmount);
  }

  static double calculateOverdueInterest({
    required double overduePrincipal, required double dailyInterestRate,
    required int daysOverdue, required int gracePeriodDays,
  }) {
    if (daysOverdue <= gracePeriodDays || overduePrincipal <= 0) return 0.0;
    final effectiveDays = daysOverdue - gracePeriodDays;
    return (overduePrincipal * dailyInterestRate / 100) * effectiveDays;
  }

  static double calculateLateFee({
    required int daysMissed, required double lateFeePerDay, required bool isEnabled,
  }) {
    if (!isEnabled || daysMissed <= 0) return 0.0;
    return daysMissed * lateFeePerDay;
  }

  // ===== CALCULATORS =====

  static Map<String, double> calculateEMI(double principal, double annualRate, int months) {
    if (principal <= 0 || months <= 0) return {'emi': 0, 'total': 0, 'interest': 0};
    final monthlyRate = annualRate / 12 / 100;
    if (monthlyRate == 0) {
      final emi = principal / months;
      return {'emi': emi, 'total': emi * months, 'interest': 0};
    }
    final emi = principal * monthlyRate * pow(1 + monthlyRate, months) / (pow(1 + monthlyRate, months) - 1);
    return {'emi': emi, 'total': emi * months, 'interest': emi * months - principal};
  }

  static double pow(double base, int exp) {
    double result = 1;
    for (int i = 0; i < exp; i++) result *= base;
    return result;
  }

  static Map<String, double> calculateSIP(double monthlyInvestment, double annualRate, int years) {
    if (monthlyInvestment <= 0 || years <= 0) return {'maturity': 0, 'invested': 0, 'gain': 0};
    final monthlyRate = annualRate / 12 / 100;
    final months = years * 12;
    if (monthlyRate == 0) {
      return {'maturity': monthlyInvestment * months, 'invested': monthlyInvestment * months, 'gain': 0};
    }
    final maturity = monthlyInvestment * ((pow(1 + monthlyRate, months) - 1) / monthlyRate) * (1 + monthlyRate);
    return {'maturity': maturity, 'invested': monthlyInvestment * months, 'gain': maturity - monthlyInvestment * months};
  }

  static Map<String, double> calculateFutureValue(double presentValue, double annualRate, int years) {
    if (presentValue <= 0 || years <= 0) return {'future': presentValue, 'gain': 0};
    final future = presentValue * pow(1 + annualRate / 100, years);
    return {'future': future, 'gain': future - presentValue};
  }

  static double calculateRateOfReturn(double invested, double currentValue, int years) {
    if (invested <= 0 || years <= 0) return 0;
    return (pow(currentValue / invested, 1.0 / years) - 1) * 100;
  }

  static Map<String, double> calculateSimpleInterest(double principal, double rate, int years) {
    final interest = principal * rate * years / 100;
    return {'interest': interest, 'total': principal + interest};
  }

  static Map<String, double> calculateCompoundInterest(double principal, double rate, int years, int freqPerYear) {
    if (freqPerYear <= 0) freqPerYear = 1;
    final amount = principal * pow(1 + rate / (100 * freqPerYear), years * freqPerYear);
    return {'amount': amount, 'interest': amount - principal};
  }

  static Map<String, double> calculateProfitMargin(double cost, double sellingPrice) {
    final profit = sellingPrice - cost;
    final margin = cost > 0 ? (profit / cost) * 100 : 0.0;
    return {'profit': profit, 'margin': margin};
  }

  static String getCreditScoreLabel(int score) {
    if (score >= 80) return 'Good';
    if (score >= 50) return 'Average';
    return 'Poor';
  }

  static int calculateCreditScore({
    required int totalLoans, required int completedLoans,
    required int overdueCount, required int missedPayments,
  }) {
    if (totalLoans == 0) return 50;
    int score = 50;
    score += (completedLoans * 10);
    score -= (overdueCount * 15);
    score -= (missedPayments * 5);
    if (score > 100) score = 100;
    if (score < 0) score = 0;
    return score;
  }
}
