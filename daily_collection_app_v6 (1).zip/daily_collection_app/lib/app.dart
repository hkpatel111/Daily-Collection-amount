import 'package:flutter/material.dart';
import 'screens/dashboard_screen.dart';
import 'screens/customer_list_screen.dart';
import 'screens/daily_collection_screen.dart';
import 'screens/settings_screen.dart';
import 'screens/loan_detail_screen.dart';
import 'screens/transaction_log_screen.dart';
import 'screens/search_screen.dart';
import 'screens/calculators_screen.dart';
import 'screens/app_lock_screen.dart';
import 'screens/sms_history_screen.dart';
import 'utils/constants.dart';
import 'database/dao/settings_dao.dart';

class DailyCollectionApp extends StatefulWidget {
  const DailyCollectionApp({super.key});

  @override
  State<DailyCollectionApp> createState() => _DailyCollectionAppState();
}

class _DailyCollectionAppState extends State<DailyCollectionApp> with WidgetsBindingObserver {
  bool _darkMode = false;
  Color _themeColor = AppColors.primary;
  bool _unlocked = false;
  bool _appLockEnabled = false;
  String _appPin = '';

  @override
  void initState() {
    super.initState();
    WidgetsBinding.instance.addObserver(this);
    _loadTheme();
  }

  @override
  void dispose() {
    WidgetsBinding.instance.removeObserver(this);
    super.dispose();
  }

  @override
  void didChangeAppLifecycleState(AppLifecycleState state) {
    if (state == AppLifecycleState.resumed) {
      _loadTheme();
      if (_appLockEnabled) setState(() => _unlocked = false);
    }
  }

  Future<void> _loadTheme() async {
    try {
      final settingsDao = SettingsDao();
      final settings = await settingsDao.getSettings();
      if (mounted) {
        setState(() {
          _darkMode = settings.darkMode;
          _themeColor = ThemeColors.getColor(settings.themeColor);
          _appLockEnabled = settings.appLockEnabled;
          _appPin = settings.appPin;
          if (!_appLockEnabled) _unlocked = true;
        });
      }
    } catch (_) {}
  }

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      title: 'Daily Collection',
      debugShowCheckedModeBanner: false,
      theme: _darkMode ? _darkTheme() : _lightTheme(),
      home: _appLockEnabled && !_unlocked
        ? AppLockScreen(correctPin: _appPin, onUnlock: () => setState(() => _unlocked = true))
        : const DashboardScreen(),
      routes: {
        '/customers': (ctx) => const CustomerListScreen(),
        '/daily_collection': (ctx) => const DailyCollectionScreen(),
        '/settings': (ctx) => const SettingsScreen(),
        '/loan_detail': (ctx) => LoanDetailRoute(),
        '/transaction_log': (ctx) => const TransactionLogScreen(),
        '/search': (ctx) => const SearchScreen(),
        '/calculators': (ctx) => const CalculatorsScreen(),
        '/sms_history': (ctx) => const SmsHistoryScreen(),
      },
    );
  }

  ThemeData _lightTheme() {
    return ThemeData(
      colorScheme: ColorScheme.fromSeed(seedColor: _themeColor, primary: _themeColor, brightness: Brightness.light),
      appBarTheme: AppBarTheme(backgroundColor: _themeColor, foregroundColor: Colors.white, elevation: 2),
      elevatedButtonTheme: ElevatedButtonThemeData(
        style: ElevatedButton.styleFrom(backgroundColor: _themeColor, foregroundColor: Colors.white,
          shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(AppConstants.buttonRadius)),
        ),
      ),
      cardTheme: CardThemeData(elevation: 2, shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(AppConstants.cardRadius))),
      scaffoldBackgroundColor: AppColors.background,
      useMaterial3: true,
    );
  }

  ThemeData _darkTheme() {
    return ThemeData(
      colorScheme: ColorScheme.fromSeed(seedColor: _themeColor, primary: _themeColor, brightness: Brightness.dark),
      appBarTheme: AppBarTheme(backgroundColor: _themeColor.withOpacity(0.8), foregroundColor: Colors.white, elevation: 2),
      elevatedButtonTheme: ElevatedButtonThemeData(
        style: ElevatedButton.styleFrom(backgroundColor: _themeColor, foregroundColor: Colors.white,
          shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(AppConstants.buttonRadius)),
        ),
      ),
      cardTheme: CardThemeData(elevation: 2, shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(AppConstants.cardRadius))),
      scaffoldBackgroundColor: DarkColors.background,
      useMaterial3: true,
    );
  }
}

class LoanDetailRoute extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    final loanId = ModalRoute.of(context)!.settings.arguments as int;
    return LoanDetailScreen(loanId: loanId);
  }
}
