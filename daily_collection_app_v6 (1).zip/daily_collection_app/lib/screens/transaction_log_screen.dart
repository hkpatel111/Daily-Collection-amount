import 'package:flutter/material.dart';
import 'package:share_plus/share_plus.dart';
import '../utils/constants.dart';
import '../database/dao/transaction_log_dao.dart';
import '../services/calculation_service.dart';
import '../services/backup_service.dart';

class TransactionLogScreen extends StatefulWidget {
  const TransactionLogScreen({super.key});

  @override
  State<TransactionLogScreen> createState() => _TransactionLogScreenState();
}

class _TransactionLogScreenState extends State<TransactionLogScreen> {
  final TransactionLogDao _logDao = TransactionLogDao();
  final BackupService _backupService = BackupService();
  List<Map<String, dynamic>> _logs = [];
  bool _isLoading = true;
  String _searchQuery = '';
  String _filterType = 'all';

  @override
  void initState() { super.initState(); _loadData(); }

  Future<void> _loadData() async {
    setState(() => _isLoading = true);
    _logs = await _logDao.getAllWithCustomerName(limit: 500, searchQuery: _searchQuery.isNotEmpty ? _searchQuery : null);
    if (_filterType != 'all') {
      _logs = _logs.where((l) => l['action_type'] == _filterType).toList();
    }
    setState(() => _isLoading = false);
  }

  Future<void> _exportLog() async {
    final result = await _backupService.exportTransactionLog(searchQuery: _searchQuery.isNotEmpty ? _searchQuery : null);
    if (result.success && result.filePath != null) {
      await Share.shareXFiles([XFile(result.filePath!)], subject: 'Transaction Log');
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text('Transaction Log'),
        actions: [
          IconButton(icon: const Icon(Icons.share), onPressed: _exportLog),
        ],
      ),
      body: Column(children: [
        Padding(padding: const EdgeInsets.all(AppConstants.padding),
          child: Column(children: [
            TextField(
              decoration: const InputDecoration(labelText: 'Search by name, mobile, amount, loan ID', prefixIcon: Icon(Icons.search), border: OutlineInputBorder()),
              onChanged: (v) { _searchQuery = v; _loadData(); },
            ),
            const SizedBox(height: 8),
            SingleChildScrollView(scrollDirection: Axis.horizontal, child: Row(children: [
              _filterChip('All', 'all'), const SizedBox(width: 6),
              _filterChip('Collection', 'collection'), const SizedBox(width: 6),
              _filterChip('Edit', 'edit_collection'), const SizedBox(width: 6),
              _filterChip('Delete', 'delete_collection'), const SizedBox(width: 6),
              _filterChip('Completed', 'loan_completed'), const SizedBox(width: 6),
              _filterChip('Pre-Close', 'pre_close'), const SizedBox(width: 6),
              _filterChip('Cancel', 'cancel_loan'),
            ])),
          ]),
        ),
        Expanded(
          child: _isLoading
            ? const Center(child: CircularProgressIndicator())
            : _logs.isEmpty
              ? Center(child: Text('No transactions found', style: TextStyle(color: AppColors.textSecondary)))
              : ListView.builder(
                  itemCount: _logs.length,
                  itemBuilder: (context, index) {
                    final log = _logs[index];
                    final actionType = log['action_type'] as String;
                    IconData icon; Color color;
                    switch (actionType) {
                      case 'collection': icon = Icons.payment; color = AppColors.success; break;
                      case 'edit_collection': icon = Icons.edit; color = AppColors.warning; break;
                      case 'delete_collection': icon = Icons.delete; color = AppColors.error; break;
                      case 'loan_completed': icon = Icons.check_circle; color = AppColors.completed; break;
                      case 'pre_close': icon = Icons.close; color = AppColors.warning; break;
                      case 'cancel_loan': icon = Icons.cancel; color = AppColors.cancelled; break;
                      case 'schedule_generated': icon = Icons.calendar_today; color = AppColors.primary; break;
                      default: icon = Icons.info; color = AppColors.textSecondary;
                    }
                    return Card(margin: const EdgeInsets.symmetric(horizontal: 8, vertical: 4),
                      child: ListTile(
                        leading: Icon(icon, color: color, size: 24),
                        title: Text(log['description'] as String, style: const TextStyle(fontSize: 14)),
                        subtitle: Text('${log['customer_name'] != null ? log['customer_name'] + ' | ' : ''}${CalculationService.formatDateTime(log['created_at'] as String)}', style: const TextStyle(fontSize: 12)),
                        trailing: log['amount'] != null ? Text(CalculationService.formatCurrency((log['amount'] as num).toDouble()), style: const TextStyle(fontSize: 13, fontWeight: FontWeight.bold)) : null,
                      ),
                    );
                  },
                ),
        ),
      ]),
    );
  }

  Widget _filterChip(String label, String value) {
    return ChoiceChip(
      label: Text(label),
      selected: _filterType == value,
      onSelected: (_) { setState(() => _filterType = value); _loadData(); },
      selectedColor: AppColors.primary.withOpacity(0.2),
    );
  }
}
