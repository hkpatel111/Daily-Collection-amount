import 'package:flutter/material.dart';
import '../database/dao/settings_dao.dart';
import '../models/settings.dart';
import '../services/backup_service.dart';
import '../services/notification_service.dart';
import '../utils/constants.dart';
import '../utils/validators.dart';
import 'package:file_picker/file_picker.dart';

class SettingsScreen extends StatefulWidget {
  const SettingsScreen({super.key});

  @override
  State<SettingsScreen> createState() => _SettingsScreenState();
}

class _SettingsScreenState extends State<SettingsScreen> {
  final SettingsDao _settingsDao = SettingsDao();
  final BackupService _backupService = BackupService();
  final NotificationService _notifService = NotificationService();

  AppSettings? _settings;

  @override
  void initState() {
    super.initState();
    _loadSettings();
  }

  Future<void> _loadSettings() async {
    final settings = await _settingsDao.getSettings();
    setState(() => _settings = settings);
  }

  Future<void> _save() async {
    if (_settings != null) {
      await _settingsDao.update(_settings!);
    }
  }

  @override
  Widget build(BuildContext context) {
    if (_settings == null) return Scaffold(appBar: AppBar(), body: const Center(child: CircularProgressIndicator()));

    return Scaffold(
      appBar: AppBar(title: const Text('Settings')),
      body: ListView(
        padding: const EdgeInsets.all(16),
        children: [
          // Appearance
          const Text('Appearance', style: TextStyle(fontSize: 18, fontWeight: FontWeight.bold)),
          SwitchListTile(
            title: const Text('Dark Mode'),
            value: _settings!.isDarkMode,
            onChanged: (v) { setState(() => _settings = _settings!.copyWith(isDarkMode: v)); _save(); },
          ),
          ListTile(
            title: const Text('Theme Color'),
            trailing: DropdownButton<int>(
              value: _settings!.themeColorIndex,
              items: List.generate(ThemeColors.colors.length, (i) => DropdownMenuItem(value: i, child: Row(children: [CircleAvatar(backgroundColor: ThemeColors.colors[i], radius: 10), const SizedBox(width: 8), Text(ThemeColors.colorNames[i])]))),
              onChanged: (v) { setState(() => _settings = _settings!.copyWith(themeColorIndex: v!)); _save(); },
            ),
          ),
          ListTile(
            title: const Text('Interest Display'),
            trailing: DropdownButton<InterestDisplayMode>(
              value: _settings!.interestDisplayMode,
              items: const [
                DropdownMenuItem(value: InterestDisplayMode.monthly, child: Text('Monthly (default)')),
                DropdownMenuItem(value: InterestDisplayMode.yearly, child: Text('Yearly')),
                DropdownMenuItem(value: InterestDisplayMode.daily, child: Text('Daily')),
              ],
              onChanged: (v) { setState(() => _settings = _settings!.copyWith(interestDisplayMode: v!)); _save(); },
            ),
          ),
          const Divider(),

          // Security
          const Text('Security', style: TextStyle(fontSize: 18, fontWeight: FontWeight.bold)),
          SwitchListTile(
            title: const Text('App Lock (PIN)'),
            value: _settings!.appLockEnabled,
            onChanged: (v) {
              if (v) {
                _showSetPinDialog();
              } else {
                setState(() => _settings = _settings!.copyWith(appLockEnabled: false, appPin: null));
                _save();
              }
            },
          ),
          if (_settings!.appLockEnabled)
            ListTile(
              title: const Text('Set Security Question'),
              trailing: const Icon(Icons.chevron_right),
              onTap: _showSecurityQuestionDialog,
            ),
          const Divider(),

          // Backup & Restore
          const Text('Backup & Restore', style: TextStyle(fontSize: 18, fontWeight: FontWeight.bold)),
          SwitchListTile(
            title: const Text('Auto Backup'),
            subtitle: Text('Every ${_settings!.autoBackupIntervalDays} days'),
            value: _settings!.autoBackupEnabled,
            onChanged: (v) { setState(() => _settings = _settings!.copyWith(autoBackupEnabled: v)); _save(); },
          ),
          if (_settings!.autoBackupEnabled) ...[
            ListTile(
              title: const Text('Backup Interval (days)'),
              trailing: SizedBox(width: 60, child: TextFormField(
                initialValue: '${_settings!.autoBackupIntervalDays}',
                decoration: const InputDecoration(border: OutlineInputBorder()),
                keyboardType: TextInputType.number,
                onChanged: (v) { final n = int.tryParse(v) ?? 7; _settings = _settings!.copyWith(autoBackupIntervalDays: n); _save(); },
              )),
            ),
            ListTile(
              title: const Text('Backup Path'),
              subtitle: Text(_settings!.backupPath ?? 'Not set'),
              trailing: const Icon(Icons.folder),
              onTap: () async {
                final path = await _backupService.pickBackupDirectory();
                if (path != null) {
                  setState(() => _settings = _settings!.copyWith(backupPath: path));
                  _save();
                }
              },
            ),
          ],
          ListTile(
            leading: const Icon(Icons.backup),
            title: const Text('Backup Now (JSON)'),
            onTap: () async {
              final path = await _backupService.exportJson();
              if (mounted) ScaffoldMessenger.of(context).showSnackBar(SnackBar(content: Text('Backup saved: $path')));
            },
          ),
          ListTile(
            leading: const Icon(Icons.restore),
            title: const Text('Restore from JSON'),
            onTap: () async {
              final result = await FilePicker.platform.pickFiles(type: FileType.custom, allowedExtensions: ['json']);
              if (result != null && result.files.single.path != null) {
                final success = await _backupService.importJson(result.files.single.path!);
                if (mounted) ScaffoldMessenger.of(context).showSnackBar(SnackBar(content: Text(success ? 'Restored successfully' : 'Restore failed')));
              }
            },
          ),
          ListTile(
            leading: const Icon(Icons.file_download),
            title: const Text('Export CSV (Loans)'),
            onTap: () async {
              final path = await _backupService.exportCsv('loans');
              if (mounted) ScaffoldMessenger.of(context).showSnackBar(SnackBar(content: Text('CSV exported: $path')));
            },
          ),
          ListTile(
            leading: const Icon(Icons.file_download),
            title: const Text('Export CSV (Customers)'),
            onTap: () async {
              final path = await _backupService.exportCsv('customers');
              if (mounted) ScaffoldMessenger.of(context).showSnackBar(SnackBar(content: Text('CSV exported: $path')));
            },
          ),
          ListTile(
            leading: const Icon(Icons.file_download),
            title: const Text('Export CSV (Collections)'),
            onTap: () async {
              final path = await _backupService.exportCsv('collections');
              if (mounted) ScaffoldMessenger.of(context).showSnackBar(SnackBar(content: Text('CSV exported: $path')));
            },
          ),
          const Divider(),

          // Notifications
          const Text('Notifications', style: TextStyle(fontSize: 18, fontWeight: FontWeight.bold)),
          SwitchListTile(
            title: const Text('Daily Reminder Notification'),
            value: _settings!.notificationEnabled,
            onChanged: (v) {
              setState(() => _settings = _settings!.copyWith(notificationEnabled: v));
              _save();
              if (v) _notifService.scheduleDailyReminder();
              else _notifService.cancelDailyReminder();
            },
          ),
          if (_settings!.notificationEnabled)
            ListTile(
              title: const Text('Notification Time'),
              trailing: Text(_settings!.notificationTime),
              onTap: () async {
                final parts = _settings!.notificationTime.split(':');
                final time = await showTimePicker(context: context, initialTime: TimeOfDay(hour: int.parse(parts[0]), minute: int.parse(parts[1])));
                if (time != null) {
                  final timeStr = '${time.hour.toString().padLeft(2, '0')}:${time.minute.toString().padLeft(2, '0')}';
                  setState(() => _settings = _settings!.copyWith(notificationTime: timeStr));
                  _save();
                  _notifService.scheduleDailyReminder();
                }
              },
            ),
          const Divider(),

          // SMS Settings
          const Text('SMS', style: TextStyle(fontSize: 18, fontWeight: FontWeight.bold)),
          SwitchListTile(
            title: const Text('Auto Reminder SMS'),
            value: _settings!.reminderSmsEnabled,
            onChanged: (v) { setState(() => _settings = _settings!.copyWith(reminderSmsEnabled: v)); _save(); },
          ),
          if (_settings!.reminderSmsEnabled)
            ListTile(
              title: const Text('Reminder Days Before'),
              trailing: DropdownButton<int>(
                value: _settings!.reminderSmsDays,
                items: [1, 2, 3, 5, 7].map((d) => DropdownMenuItem(value: d, child: Text('$d day(s)'))).toList(),
                onChanged: (v) { setState(() => _settings = _settings!.copyWith(reminderSmsDays: v!)); _save(); },
              ),
            ),
          const Divider(),

          // Default Loan Settings
          const Text('Default Loan Settings', style: TextStyle(fontSize: 18, fontWeight: FontWeight.bold)),
          ListTile(
            title: const Text('Default Grace Period'),
            trailing: Text('${_settings!.defaultGracePeriod} days'),
          ),
          SwitchListTile(
            title: const Text('Skip Sundays (default)'),
            value: _settings!.sundayHolidayDefault,
            onChanged: (v) { setState(() => _settings = _settings!.copyWith(sundayHolidayDefault: v)); _save(); },
          ),
          const Divider(),

          // About
          const Text('About', style: TextStyle(fontSize: 18, fontWeight: FontWeight.bold)),
          ListTile(title: const Text('App Name'), trailing: Text(AppConstants.appName)),
          ListTile(title: const Text('Version'), trailing: Text(AppConstants.appVersion)),
          ListTile(title: const Text('Developer'), trailing: Text(AppConstants.developerName)),
          const SizedBox(height: 20),
          Center(child: Text(AppConstants.createdBy, style: TextStyle(fontSize: 14, color: Colors.grey[500], fontStyle: FontStyle.italic))),
        ],
      ),
    );
  }

  void _showSetPinDialog() {
    final pinController = TextEditingController();
    showDialog(
      context: context,
      barrierDismissible: false,
      builder: (ctx) => AlertDialog(
        title: const Text('Set PIN'),
        content: TextField(
          controller: pinController,
          decoration: const InputDecoration(labelText: '4-digit PIN', border: OutlineInputBorder()),
          keyboardType: TextInputType.number,
          maxLength: 4,
          obscureText: true,
          validator: Validators.validatePin,
        ),
        actions: [
          FilledButton(
            onPressed: () {
              if (Validators.validatePin(pinController.text) == null) {
                setState(() => _settings = _settings!.copyWith(appLockEnabled: true, appPin: pinController.text));
                _save();
                Navigator.pop(ctx);
              }
            },
            child: const Text('Set PIN'),
          ),
        ],
      ),
    );
  }

  void _showSecurityQuestionDialog() {
    String? selectedQuestion = _settings?.securityQuestion;
    final answerController = TextEditingController(text: _settings?.securityAnswer ?? '');

    showDialog(
      context: context,
      builder: (ctx) => AlertDialog(
        title: const Text('Security Question'),
        content: Column(
          mainAxisSize: MainAxisSize.min,
          children: [
            DropdownButtonFormField<String>(
              value: selectedQuestion,
              decoration: const InputDecoration(labelText: 'Question', border: OutlineInputBorder()),
              items: AppConstants.securityQuestions.map((q) => DropdownMenuItem(value: q, child: Text(q))).toList(),
              onChanged: (v) => selectedQuestion = v,
            ),
            const SizedBox(height: 12),
            TextField(
              controller: answerController,
              decoration: const InputDecoration(labelText: 'Answer', border: OutlineInputBorder()),
              validator: Validators.validateSecurityAnswer,
            ),
          ],
        ),
        actions: [
          TextButton(onPressed: () => Navigator.pop(ctx), child: const Text('Cancel')),
          FilledButton(
            onPressed: () {
              setState(() {
                _settings = _settings!.copyWith(securityQuestion: selectedQuestion, securityAnswer: answerController.text);
              });
              _save();
              Navigator.pop(ctx);
            },
            child: const Text('Save'),
          ),
        ],
      ),
    );
  }
}
