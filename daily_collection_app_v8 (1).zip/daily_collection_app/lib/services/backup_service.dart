import 'dart:io';
import 'dart:convert';
import 'package:pdf/pdf.dart';
import 'package:pdf/widgets.dart' as pw;
import 'package:share_plus/share_plus.dart';
import 'package:path_provider/path_provider.dart';
import 'package:file_picker/file_picker.dart';
import '../models/loan.dart';
import '../models/customer.dart';
import '../models/settings.dart';
import '../database/database_helper.dart';
import '../database/dao/customer_dao.dart';
import '../database/dao/loan_dao.dart';
import '../database/dao/schedule_dao.dart';
import '../database/dao/collection_dao.dart';
import '../database/dao/settings_dao.dart';
import '../database/dao/transaction_log_dao.dart';
import 'calculation_service.dart';

class BackupService {
  final DatabaseHelper _dbHelper = DatabaseHelper();
  final CustomerDao _customerDao = CustomerDao();
  final LoanDao _loanDao = LoanDao();
  final ScheduleDao _scheduleDao = ScheduleDao();
  final CollectionDao _collectionDao = CollectionDao();
  final SettingsDao _settingsDao = SettingsDao();
  final TransactionLogDao _logDao = TransactionLogDao();

  // ===== JSON BACKUP / RESTORE =====

  Future<String> exportJson() async {
    final db = await _dbHelper.database;
    final data = <String, dynamic>{};

    for (final table in ['customers', 'loans', 'schedule_entries', 'collection_entries', 'settings', 'transaction_logs', 'sms_logs', 'edit_history', 'loan_templates']) {
      data[table] = await db.query(table);
    }

    final jsonStr = const JsonEncoder.withIndent('  ').convert(data);
    final dir = await getApplicationDocumentsDirectory();
    final file = File('${dir.path}/backup_${DateTime.now().millisecondsSinceEpoch}.json');
    await file.writeAsString(jsonStr);
    return file.path;
  }

  Future<bool> importJson(String filePath) async {
    try {
      final file = File(filePath);
      final jsonStr = await file.readAsString();
      final data = jsonDecode(jsonStr) as Map<String, dynamic>;

      final db = await _dbHelper.database;
      await db.transaction((txn) async {
        for (final table in ['edit_history', 'sms_logs', 'transaction_logs', 'collection_entries', 'schedule_entries', 'loans', 'customers', 'loan_templates']) {
          await txn.delete(table);
        }
        for (final table in data.keys) {
          final rows = data[table] as List;
          for (final row in rows) {
            await txn.insert(table, row as Map<String, Object?>);
          }
        }
      });
      return true;
    } catch (e) {
      return false;
    }
  }

  // ===== CUSTOM PATH BACKUP =====

  Future<String?> backupToCustomPath(String customPath) async {
    final jsonPath = await exportJson();
    final timestamp = DateTime.now().millisecondsSinceEpoch;
    final destPath = '$customPath/daily_collection_backup_$timestamp.json';
    await File(jsonPath).copy(destPath);
    return destPath;
  }

  Future<String?> pickBackupDirectory() async {
    final result = await FilePicker.platform.getDirectoryPath();
    return result;
  }

  Future<List<FileSystemEntity>> findBackupsInPath(String path) async {
    final dir = Directory(path);
    if (!await dir.exists()) return [];
    return dir.listSync().where((e) => e.path.endsWith('.json') && e.path.contains('daily_collection_backup')).toList()
      ..sort((a, b) => b.path.compareTo(a.path));
  }

  // ===== CSV EXPORT =====

  Future<String> exportCsv(String type, {int? loanId, int? customerId}) async {
    final sb = StringBuffer();

    switch (type) {
      case 'loans':
        sb.writeln('ID,Customer,Principal,Return Amount,Daily Installment,Start Date,Total Days,Status,Profit,Monthly Rate');
        final loans = await _loanDao.getAllWithCustomer();
        for (final l in loans) {
          final loan = Loan.fromMap(l);
          final dailyRate = CalculationService.calcDailyInterestRate(loan.profit, loan.principal, loan.totalDays);
          sb.writeln('${loan.id},${l['customer_name']},${loan.principal},${loan.returnAmount},${loan.dailyInstallment},${CalculationService.formatDate(loan.startDate)},${loan.totalDays},${loan.status.name},${loan.profit},${CalculationService.calcMonthlyRate(dailyRate).toStringAsFixed(2)}');
        }
        break;
      case 'collections':
        sb.writeln('ID,Date,Customer,Loan ID,Amount,Payment Mode,Schedule Date,Day Number');
        final collections = await _collectionDao.getAllWithDetails();
        for (final c in collections) {
          sb.writeln('${c['id']},${c['collected_date']},${c['customer_name']},${c['loan_id']},${c['amount']},${c['payment_mode']},${c['schedule_date'] ?? ''},${c['day_number'] ?? ''}');
        }
        break;
      case 'customers':
        sb.writeln('ID,Name,Mobile,Nickname,Active,Created At');
        final customers = await _customerDao.getAll();
        for (final c in customers) {
          sb.writeln('${c.id},${c.name},${c.mobile},${c.nickname ?? ''},${c.isActive},${c.createdAt.toIso8601String()}');
        }
        break;
    }

    final dir = await getApplicationDocumentsDirectory();
    final file = File('${dir.path}/${type}_export_${DateTime.now().millisecondsSinceEpoch}.csv');
    await file.writeAsString(sb.toString());
    return file.path;
  }

  // ===== PDF HELPERS =====

  Future<String> _savePdfToFile(pw.Document pdf, String filename) async {
    final dir = await getTemporaryDirectory();
    final filePath = '${dir.path}/$filename';
    final file = File(filePath);
    await file.writeAsBytes(await pdf.save());
    return filePath;
  }

  Future<void> _sharePdfFile(String filePath, String filename) async {
    await Share.shareXFiles([XFile(filePath)], subject: filename);
  }

  pw.Widget _pdfRow(String label, String value) {
    return pw.Padding(
      padding: const pw.EdgeInsets.symmetric(vertical: 3),
      child: pw.Row(
        mainAxisAlignment: pw.MainAxisAlignment.spaceBetween,
        children: [
          pw.Text(label, style: pw.TextStyle(fontSize: 11, color: PdfColors.grey700)),
          pw.Text(value, style: const pw.TextStyle(fontSize: 11)),
        ],
      ),
    );
  }

  // ===== PDF GENERATION =====

  Future<void> sharePdfReceipt({
    required Customer customer,
    required Loan loan,
    required double amount,
    required int dayNumber,
    required double totalCollected,
    required double remaining,
    String? paymentMode,
  }) async {
    final pdf = pw.Document();

    pdf.addPage(
      pw.Page(
        pageFormat: PdfPageFormat.a5,
        build: (pw.Context context) {
          return pw.Container(
            padding: const pw.EdgeInsets.all(20),
            child: pw.Column(
              crossAxisAlignment: pw.CrossAxisAlignment.start,
              children: [
                pw.Center(
                  child: pw.Text('Payment Receipt',
                    style: pw.TextStyle(fontSize: 20, fontWeight: pw.FontWeight.bold),
                  ),
                ),
                pw.SizedBox(height: 10),
                pw.Center(child: pw.Text('Created by Harish', style: pw.TextStyle(fontSize: 10, color: PdfColors.grey))),
                pw.Divider(),
                pw.SizedBox(height: 10),
                _pdfRow('Date', CalculationService.formatDateTime(DateTime.now())),
                _pdfRow('Customer', customer.name),
                _pdfRow('Mobile', customer.mobile),
                _pdfRow('Loan ID', '#${loan.id}'),
                if (loan.accountName.isNotEmpty) _pdfRow('Account', loan.accountName),
                pw.Divider(),
                pw.SizedBox(height: 10),
                _pdfRow('Day', '$dayNumber / ${loan.totalDays}'),
                _pdfRow('Amount Paid', CalculationService.formatCurrency(amount)),
                if (paymentMode != null) _pdfRow('Payment Mode', paymentMode.toUpperCase()),
                pw.Divider(),
                pw.SizedBox(height: 10),
                _pdfRow('Total Collected', CalculationService.formatCurrency(totalCollected)),
                _pdfRow('Remaining', CalculationService.formatCurrency(remaining)),
                _pdfRow('Return Amount', CalculationService.formatCurrency(loan.returnAmount)),
                _pdfRow('Principal', CalculationService.formatCurrency(loan.principal)),
                pw.SizedBox(height: 20),
                pw.Divider(),
                pw.SizedBox(height: 5),
                pw.Center(child: pw.Text('Thank You!', style: pw.TextStyle(fontSize: 14, fontWeight: pw.FontWeight.bold))),
                pw.SizedBox(height: 5),
                pw.Center(child: pw.Text('Daily Collection App', style: pw.TextStyle(fontSize: 10, color: PdfColors.grey))),
              ],
            ),
          );
        },
      ),
    );

    final filePath = await _savePdfToFile(pdf, 'receipt_loan_${loan.id}_day_$dayNumber.pdf');
    await _sharePdfFile(filePath, 'receipt_loan_${loan.id}_day_$dayNumber.pdf');
  }

  Future<void> sharePdfLoanSummary({
    required Customer customer,
    required Loan loan,
    required double totalCollected,
    required int paidDays,
  }) async {
    final pdf = pw.Document();

    pdf.addPage(
      pw.Page(
        pageFormat: PdfPageFormat.a4,
        build: (pw.Context context) {
          return pw.Container(
            padding: const pw.EdgeInsets.all(20),
            child: pw.Column(
              crossAxisAlignment: pw.CrossAxisAlignment.start,
              children: [
                pw.Center(child: pw.Text('Loan Summary', style: pw.TextStyle(fontSize: 22, fontWeight: pw.FontWeight.bold))),
                pw.Center(child: pw.Text('Created by Harish', style: pw.TextStyle(fontSize: 10, color: PdfColors.grey))),
                pw.Divider(),
                pw.SizedBox(height: 15),
                pw.Text('Customer Details', style: pw.TextStyle(fontSize: 16, fontWeight: pw.FontWeight.bold)),
                pw.SizedBox(height: 5),
                _pdfRow('Name', customer.name),
                _pdfRow('Mobile', customer.mobile),
                if (customer.nickname != null) _pdfRow('Nickname', customer.nickname!),
                pw.SizedBox(height: 15),
                pw.Text('Loan Details', style: pw.TextStyle(fontSize: 16, fontWeight: pw.FontWeight.bold)),
                pw.SizedBox(height: 5),
                _pdfRow('Loan ID', '#${loan.id}'),
                if (loan.accountName.isNotEmpty) _pdfRow('Account', loan.accountName),
                _pdfRow('Principal', CalculationService.formatCurrency(loan.principal)),
                _pdfRow('Return Amount', CalculationService.formatCurrency(loan.returnAmount)),
                _pdfRow('Profit', CalculationService.formatCurrency(loan.profit)),
                _pdfRow('Daily Installment', CalculationService.formatCurrency(loan.dailyInstallment)),
                _pdfRow('Start Date', CalculationService.formatDate(loan.startDate)),
                _pdfRow('Total Days', '${loan.totalDays}'),
                _pdfRow('Status', loan.status.name),
                pw.SizedBox(height: 15),
                pw.Text('Interest Rates', style: pw.TextStyle(fontSize: 16, fontWeight: pw.FontWeight.bold)),
                pw.SizedBox(height: 5),
                _pdfRow('Monthly Rate', '${CalculationService.calcMonthlyRate(CalculationService.calcDailyInterestRate(loan.profit, loan.principal, loan.totalDays)).toStringAsFixed(2)}%'),
                _pdfRow('Yearly Rate', '${CalculationService.calcYearlyRate(CalculationService.calcDailyInterestRate(loan.profit, loan.principal, loan.totalDays)).toStringAsFixed(2)}%'),
                pw.SizedBox(height: 15),
                pw.Text('Collection Progress', style: pw.TextStyle(fontSize: 16, fontWeight: pw.FontWeight.bold)),
                pw.SizedBox(height: 5),
                _pdfRow('Paid Days', '$paidDays / ${loan.totalDays}'),
                _pdfRow('Total Collected', CalculationService.formatCurrency(totalCollected)),
                _pdfRow('Remaining', CalculationService.formatCurrency(loan.returnAmount - totalCollected)),
                _pdfRow('Completion', '${(paidDays / loan.totalDays * 100).toStringAsFixed(1)}%'),
                pw.SizedBox(height: 20),
                pw.Divider(),
                pw.Center(child: pw.Text('Daily Collection App', style: pw.TextStyle(fontSize: 10, color: PdfColors.grey))),
              ],
            ),
          );
        },
      ),
    );

    final filePath = await _savePdfToFile(pdf, 'loan_summary_${loan.id}.pdf');
    await _sharePdfFile(filePath, 'loan_summary_${loan.id}.pdf');
  }

  Future<void> sharePdfOutstandingSnapshot({
    required Customer customer,
    required Loan loan,
    required double totalCollected,
    required double outstanding,
    required double outstandingWithInterest,
    required DateTime asOfDate,
  }) async {
    final pdf = pw.Document();

    pdf.addPage(
      pw.Page(
        pageFormat: PdfPageFormat.a5,
        build: (pw.Context context) {
          return pw.Container(
            padding: const pw.EdgeInsets.all(20),
            child: pw.Column(
              crossAxisAlignment: pw.CrossAxisAlignment.start,
              children: [
                pw.Center(child: pw.Text('Outstanding Snapshot', style: pw.TextStyle(fontSize: 20, fontWeight: pw.FontWeight.bold))),
                pw.Center(child: pw.Text('Created by Harish', style: pw.TextStyle(fontSize: 10, color: PdfColors.grey))),
                pw.Divider(),
                pw.SizedBox(height: 10),
                _pdfRow('Date', CalculationService.formatDate(asOfDate)),
                _pdfRow('Customer', customer.name),
                _pdfRow('Loan ID', '#${loan.id}'),
                pw.Divider(),
                pw.SizedBox(height: 10),
                _pdfRow('Return Amount', CalculationService.formatCurrency(loan.returnAmount)),
                _pdfRow('Total Collected', CalculationService.formatCurrency(totalCollected)),
                _pdfRow('Base Outstanding', CalculationService.formatCurrency(outstanding)),
                pw.Divider(),
                pw.SizedBox(height: 5),
                _pdfRow('Outstanding + Interest', CalculationService.formatCurrency(outstandingWithInterest)),
                pw.SizedBox(height: 20),
                pw.Divider(),
                pw.Center(child: pw.Text('Daily Collection App', style: pw.TextStyle(fontSize: 10, color: PdfColors.grey))),
              ],
            ),
          );
        },
      ),
    );

    final filePath = await _savePdfToFile(pdf, 'outstanding_loan_${loan.id}.pdf');
    await _sharePdfFile(filePath, 'outstanding_loan_${loan.id}.pdf');
  }

  Future<void> sharePdfTransactionLog(List<Map<String, dynamic>> logs) async {
    final pdf = pw.Document();

    pdf.addPage(
      pw.Page(
        pageFormat: PdfPageFormat.a4,
        build: (pw.Context context) {
          return pw.Container(
            padding: const pw.EdgeInsets.all(20),
            child: pw.Column(
              crossAxisAlignment: pw.CrossAxisAlignment.start,
              children: [
                pw.Center(child: pw.Text('Transaction Log', style: pw.TextStyle(fontSize: 22, fontWeight: pw.FontWeight.bold))),
                pw.Center(child: pw.Text('Created by Harish', style: pw.TextStyle(fontSize: 10, color: PdfColors.grey))),
                pw.Divider(),
                pw.SizedBox(height: 10),
                pw.Table.fromTextArray(
                  headers: ['Date', 'Customer', 'Action', 'Description'],
                  data: logs.map((l) => [
                    CalculationService.formatDateTime(DateTime.parse(l['timestamp'])),
                    l['customer_name'] ?? '-',
                    l['action'] ?? '',
                    l['description'] ?? '',
                  ]).toList(),
                  cellAlignment: pw.Alignment.centerLeft,
                  headerStyle: pw.TextStyle(fontWeight: pw.FontWeight.bold),
                  headerDecoration: const pw.BoxDecoration(color: PdfColors.grey300),
                ),
                pw.SizedBox(height: 10),
                pw.Divider(),
                pw.Center(child: pw.Text('Daily Collection App', style: pw.TextStyle(fontSize: 10, color: PdfColors.grey))),
              ],
            ),
          );
        },
      ),
    );

    final filePath = await _savePdfToFile(pdf, 'transaction_log_${DateTime.now().millisecondsSinceEpoch}.pdf');
    await _sharePdfFile(filePath, 'transaction_log_${DateTime.now().millisecondsSinceEpoch}.pdf');
  }

  Future<void> sharePdfDailySummary({
    required DateTime date,
    required double totalCollected,
    required List<Map<String, dynamic>> collections,
  }) async {
    final pdf = pw.Document();

    pdf.addPage(
      pw.Page(
        pageFormat: PdfPageFormat.a5,
        build: (pw.Context context) {
          return pw.Container(
            padding: const pw.EdgeInsets.all(20),
            child: pw.Column(
              crossAxisAlignment: pw.CrossAxisAlignment.start,
              children: [
                pw.Center(child: pw.Text('Daily Collection Summary', style: pw.TextStyle(fontSize: 18, fontWeight: pw.FontWeight.bold))),
                pw.Center(child: pw.Text('Created by Harish', style: pw.TextStyle(fontSize: 10, color: PdfColors.grey))),
                pw.Divider(),
                pw.SizedBox(height: 10),
                _pdfRow('Date', CalculationService.formatDate(date)),
                _pdfRow('Total Collected', CalculationService.formatCurrency(totalCollected)),
                _pdfRow('Total Entries', '${collections.length}'),
                pw.Divider(),
                pw.SizedBox(height: 10),
                pw.Table.fromTextArray(
                  headers: ['Customer', 'Amount'],
                  data: collections.map((c) => [
                    c['customer_name'] ?? '-',
                    CalculationService.formatCurrency((c['amount'] as num).toDouble()),
                  ]).toList(),
                  cellAlignment: pw.Alignment.centerLeft,
                  headerStyle: pw.TextStyle(fontWeight: pw.FontWeight.bold),
                ),
                pw.SizedBox(height: 20),
                pw.Divider(),
                pw.Center(child: pw.Text('Daily Collection App', style: pw.TextStyle(fontSize: 10, color: PdfColors.grey))),
              ],
            ),
          );
        },
      ),
    );

    final filePath = await _savePdfToFile(pdf, 'daily_summary_${date.millisecondsSinceEpoch}.pdf');
    await _sharePdfFile(filePath, 'daily_summary_${date.millisecondsSinceEpoch}.pdf');
  }

  // ===== WHATSAPP / SHARE =====

  Future<void> shareToWhatsApp(String message) async {
    await Share.share(message);
  }

  // ===== MONTHLY REPORT =====

  Future<Map<String, dynamic>> generateMonthlyReport(int year, int month) async {
    final db = await _dbHelper.database;
    final startDate = DateTime(year, month, 1);
    final endDate = DateTime(year, month + 1, 1);

    final collections = await db.rawQuery('''
      SELECT ce.*, c.name as customer_name
      FROM collection_entries ce
      INNER JOIN customers c ON ce.customer_id = c.id
      WHERE ce.collected_date >= ? AND ce.collected_date < ?
      ORDER BY ce.collected_date DESC
    ''', [startDate.toIso8601String(), endDate.toIso8601String()]);

    double totalCollected = 0;
    for (final c in collections) {
      totalCollected += (c['amount'] as num).toDouble();
    }

    final newLoans = await db.rawQuery('''
      SELECT COUNT(*) as count FROM loans
      WHERE created_at >= ? AND created_at < ?
    ''', [startDate.toIso8601String(), endDate.toIso8601String()]);

    return {
      'collections': collections,
      'totalCollected': totalCollected,
      'collectionCount': collections.length,
      'newLoans': newLoans.first['count'],
    };
  }

  // ===== YEARLY TAX SUMMARY =====

  Future<Map<String, dynamic>> generateYearlyTaxSummary(int year) async {
    final db = await _dbHelper.database;
    final startDate = DateTime(year, 1, 1);
    final endDate = DateTime(year + 1, 1, 1);

    final loans = await db.rawQuery('''
      SELECT * FROM loans
      WHERE created_at >= ? AND created_at < ?
    ''', [startDate.toIso8601String(), endDate.toIso8601String()]);

    double totalPrincipal = 0;
    double totalProfit = 0;
    for (final l in loans) {
      totalPrincipal += (l['principal'] as num).toDouble();
      totalProfit += ((l['return_amount'] as num).toDouble() - (l['principal'] as num).toDouble());
    }

    final collections = await db.rawQuery('''
      SELECT COALESCE(SUM(amount), 0) as total FROM collection_entries
      WHERE collected_date >= ? AND collected_date < ?
    ''', [startDate.toIso8601String(), endDate.toIso8601String()]);

    return {
      'totalPrincipal': totalPrincipal,
      'totalProfit': totalProfit,
      'totalCollected': (collections.first['total'] as num).toDouble(),
      'loanCount': loans.length,
    };
  }
}
