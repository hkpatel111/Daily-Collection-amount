import '../database/dao/loan_dao.dart';
import '../database/dao/schedule_dao.dart';
import '../models/loan.dart';
import '../models/schedule_entry.dart';

class NotificationService {
  final LoanDao _loanDao = LoanDao();
  final ScheduleDao _scheduleDao = ScheduleDao();

  Future<void> init() async {
    // No-op: native notifications removed for build compatibility
  }

  Future<void> scheduleDailyReminder() async {
    // No-op: handled in-app
  }

  Future<void> cancelDailyReminder() async {
    // No-op
  }

  Future<void> showNotification({required String title, required String body, int id = 0}) async {
    // No-op: alerts shown in-app on dashboard
  }

  // ===== DASHBOARD ALERTS =====

  Future<List<Map<String, dynamic>>> getDashboardAlerts() async {
    final alerts = <Map<String, dynamic>>[];
    final loans = await _loanDao.getAll();
    final today = DateTime.now();
    final todayDate = DateTime(today.year, today.month, today.day);

    int overdueCount = 0;
    int missedCount = 0;
    int pendingTodayCount = 0;
    int completedCount = 0;
    int defaultedCount = 0;

    for (final loan in loans) {
      switch (loan.status) {
        case LoanStatus.overdue:
          overdueCount++;
          break;
        case LoanStatus.completed:
          completedCount++;
          break;
        case LoanStatus.defaulted:
          defaultedCount++;
          break;
        case LoanStatus.cancelled:
        case LoanStatus.preClosed:
          break;
        case LoanStatus.active:
          break;
      }
    }

    final pendingEntries = await _scheduleDao.getPendingForDate(todayDate);
    pendingTodayCount = pendingEntries.where((e) => e.status == ScheduleEntryStatus.pending && !e.isSunday).length;

    for (final loan in loans) {
      if (loan.status == LoanStatus.active || loan.status == LoanStatus.overdue) {
        final overdueEntries = await _scheduleDao.getOverdueEntries(loan.id!, todayDate);
        for (final entry in overdueEntries) {
          if (entry.status == ScheduleEntryStatus.overdue) {
            missedCount++;
          }
        }
      }
    }

    if (overdueCount > 0) {
      alerts.add({
        'type': 'overdue',
        'title': 'Overdue Loans',
        'count': overdueCount,
        'color': 0xFFE53935,
        'icon': 'warning',
      });
    }

    if (missedCount > 0) {
      alerts.add({
        'type': 'missed',
        'title': 'Missed Collections',
        'count': missedCount,
        'color': 0xFFFF9800,
        'icon': 'error',
      });
    }

    if (pendingTodayCount > 0) {
      alerts.add({
        'type': 'pending_today',
        'title': 'Pending Today',
        'count': pendingTodayCount,
        'color': 0xFF2196F3,
        'icon': 'schedule',
      });
    }

    if (completedCount > 0) {
      alerts.add({
        'type': 'completed',
        'title': 'Completed Loans',
        'count': completedCount,
        'color': 0xFF4CAF50,
        'icon': 'check_circle',
      });
    }

    if (defaultedCount > 0) {
      alerts.add({
        'type': 'defaulted',
        'title': 'Defaulted Loans',
        'count': defaultedCount,
        'color': 0xFF9E9E9E,
        'icon': 'cancel',
      });
    }

    return alerts;
  }
}
