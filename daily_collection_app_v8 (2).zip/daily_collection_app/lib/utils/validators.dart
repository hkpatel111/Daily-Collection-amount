class Validators {
  static String? validateName(String? value) {
    if (value == null || value.trim().isEmpty) {
      return 'Naam daalo';
    }
    if (value.trim().length < 2) {
      return 'Naam kam se kam 2 letters ka hona chahiye';
    }
    return null;
  }

  static String? validateMobile(String? value) {
    if (value == null || value.trim().isEmpty) {
      return 'Mobile number daalo';
    }
    final cleaned = value.replaceAll(RegExp(r'[^0-9]'), '');
    if (cleaned.length < 10) {
      return 'Sahi mobile number daalo (10 digits)';
    }
    if (cleaned.length > 12) {
      return 'Mobile number galat hai';
    }
    return null;
  }

  static String? validateAmount(String? value) {
    if (value == null || value.trim().isEmpty) {
      return 'Amount daalo';
    }
    final amount = double.tryParse(value.trim());
    if (amount == null) {
      return 'Sahi amount daalo';
    }
    if (amount <= 0) {
      return 'Amount zero se zyada hona chahiye';
    }
    return null;
  }

  static String? validateReturnAmount(String? value, double principal) {
    if (value == null || value.trim().isEmpty) {
      return 'Return amount daalo';
    }
    final amount = double.tryParse(value.trim());
    if (amount == null) {
      return 'Sahi amount daalo';
    }
    if (amount <= 0) {
      return 'Amount zero se zyada hona chahiye';
    }
    if (amount < principal) {
      return 'Return amount principal se kam nahi ho sakta';
    }
    return null;
  }

  static String? validateDailyInstallment(String? value, double returnAmount, int totalDays) {
    if (value == null || value.trim().isEmpty) {
      return 'Daily installment daalo';
    }
    final amount = double.tryParse(value.trim());
    if (amount == null) {
      return 'Sahi amount daalo';
    }
    if (amount <= 0) {
      return 'Daily installment zero se zyada hona chahiye';
    }
    if (totalDays > 0 && (amount * totalDays) < returnAmount) {
      return 'Daily installment x total days return amount se kam hai';
    }
    return null;
  }

  static String? validatePin(String? value) {
    if (value == null || value.trim().isEmpty) {
      return 'PIN daalo';
    }
    if (value.length != 4) {
      return 'PIN 4 digits ka hona chahiye';
    }
    if (!RegExp(r'^[0-9]+$').hasMatch(value)) {
      return 'PIN mein sirf numbers hone chahiye';
    }
    return null;
  }

  static String formatCurrency(double amount, {String symbol = 'Rs'}) {
    final intPart = amount.toInt();
    final formatted = _formatIndianNumber(intPart);
    final decimalPart = ((amount - intPart).abs() * 100).round().toString().padLeft(2, '0');
    final prefix = amount < 0 ? '-' : '';
    return '$prefix$symbol $formatted.$decimalPart';
  }

  static String formatCurrencySimple(double amount, {String symbol = 'Rs'}) {
    final intPart = amount.round().abs();
    final prefix = amount < 0 ? '-' : '';
    final formatted = _formatIndianNumber(intPart);
    return '$prefix$symbol $formatted';
  }

  static String _formatIndianNumber(int number) {
    if (number == 0) return '0';
    final str = number.toString();
    if (str.length <= 3) return str;
    final last3 = str.substring(str.length - 3);
    final rest = str.substring(0, str.length - 3);
    final buffer = StringBuffer();
    int i = 0;
    for (final char in rest.split('').reversed) {
      if (i == 2 && buffer.isNotEmpty) {
        buffer.write(',');
        i = 0;
      }
      buffer.write(char);
      i++;
    }
    final reversed = buffer.toString().split('').reversed.join();
    return '$reversed,$last3';
  }
}
