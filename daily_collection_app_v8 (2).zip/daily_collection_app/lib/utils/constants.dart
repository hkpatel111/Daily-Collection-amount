import 'package:flutter/material.dart';

class AppColors {
  static const Color primary = Color(0xFF1565C0);
  static const Color primaryDark = Color(0xFF0D47A1);
  static const Color accent = Color(0xFFFF8F00);
  static const Color background = Color(0xFFF5F5F5);
  static const Color surface = Colors.white;
  static const Color error = Color(0xFFD32F2F);
  static const Color success = Color(0xFF388E3C);
  static const Color warning = Color(0xFFF57C00);
  static const Color textPrimary = Color(0xFF212121);
  static const Color textSecondary = Color(0xFF757575);
  static const Color divider = Color(0xFFBDBDBD);
  static const Color overdue = Color(0xFFD32F2F);
  static const Color paid = Color(0xFF388E3C);
  static const Color pending = Color(0xFFF57C00);
}

class DarkColors {
  static const Color primary = Color(0xFF42A5F5);
  static const Color primaryDark = Color(0xFF1976D2);
  static const Color accent = Color(0xFFFFB74D);
  static const Color background = Color(0xFF121212);
  static const Color surface = Color(0xFF1E1E1E);
  static const Color error = Color(0xFFEF5350);
  static const Color success = Color(0xFF66BB6A);
  static const Color warning = Color(0xFFFFA726);
  static const Color textPrimary = Color(0xFFE0E0E0);
  static const Color textSecondary = Color(0xFF9E9E9E);
  static const Color divider = Color(0xFF424242);
  static const Color overdue = Color(0xFFEF5350);
  static const Color paid = Color(0xFF66BB6A);
  static const Color pending = Color(0xFFFFA726);
}

class ThemeColors {
  static Color get primary => AppColors.primary;
  static Color get accent => AppColors.accent;
  static Color get background => AppColors.background;
  static Color get surface => AppColors.surface;
  static Color get textPrimary => AppColors.textPrimary;
  static Color get textSecondary => AppColors.textSecondary;
}

class AppConstants {
  static const String appName = 'Daily Collection';
  static const String appVersion = '3.0.0';
  static const String createdBy = 'Created by Harish';
  static const String developerName = 'Harish K Patidar';
  static const String currencySymbol = 'Rs';
  static const double defaultPrincipal = 10000;
  static const double defaultReturnAmount = 12000;
  static const double defaultDailyInstallment = 100;
  static const int defaultTotalDays = 120;
  static const int defaultPinLength = 4;
  static const String backupFileName = 'daily_collection_backup';
  static const String dbFileName = 'daily_collection.db';
}
