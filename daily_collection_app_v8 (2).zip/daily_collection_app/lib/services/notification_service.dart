import 'package:flutter/material.dart';

class NotificationService {
  static final NotificationService _instance = NotificationService._internal();
  factory NotificationService() => _instance;
  NotificationService._internal();

  final List<AppAlert> _alerts = [];

  List<AppAlert> get alerts => List.unmodifiable(_alerts);

  void addAlert(AppAlert alert) {
    _alerts.insert(0, alert);
    if (_alerts.length > 50) {
      _alerts.removeLast();
    }
  }

  void clearAlerts() {
    _alerts.clear();
  }

  void removeAlert(int index) {
    if (index >= 0 && index < _alerts.length) {
      _alerts.removeAt(index);
    }
  }

  // Generate dashboard alerts from data
  void generateAlerts({
    int overdueCount = 0,
    int pendingTodayCount = 0,
    int activeLoansCount = 0,
    double totalOutstanding = 0,
    int expiringLoansCount = 0,
  }) {
    clearAlerts();

    if (overdueCount > 0) {
      addAlert(AppAlert(
        type: AlertType.error,
        title: 'Overdue Installments',
        message: '$overdueCount overdue installments hain. Collection follow-up karo.',
        icon: Icons.warning,
      ));
    }

    if (pendingTodayCount > 0) {
      addAlert(AppAlert(
        type: AlertType.warning,
        title: 'Today Collections Pending',
        message: '$pendingTodayCount aaj ke collections pending hain.',
        icon: Icons.today,
      ));
    }

    if (expiringLoansCount > 0) {
      addAlert(AppAlert(
        type: AlertType.info,
        title: 'Loans Expiring Soon',
        message: '$expiringLoansCount loans 7 din mein expire honge.',
        icon: Icons.schedule,
      ));
    }

    if (activeLoansCount > 0 && totalOutstanding > 0) {
      addAlert(AppAlert(
        type: AlertType.info,
        title: 'Total Outstanding',
        message: 'Rs ${totalOutstanding.toStringAsFixed(0)} outstanding hai across $activeLoansCount active loans.',
        icon: Icons.account_balance_wallet,
      ));
    }
  }

  // Initialize notification service
  Future<void> init() async {
    // Dashboard alerts only - in-memory, no package needed
  }
}

enum AlertType { info, warning, error, success }

class AppAlert {
  final AlertType type;
  final String title;
  final String message;
  final IconData icon;

  const AppAlert({
    required this.type,
    required this.title,
    required this.message,
    required this.icon,
  });

  Color get color {
    switch (type) {
      case AlertType.info:
        return const Color(0xFF1565C0);
      case AlertType.warning:
        return const Color(0xFFF57C00);
      case AlertType.error:
        return const Color(0xFFD32F2F);
      case AlertType.success:
        return const Color(0xFF388E3C);
    }
  }
}
