import '../database/database_helper.dart';
import '../database/dao/loan_dao.dart';
import '../database/dao/schedule_dao.dart';
import '../database/dao/collection_dao.dart';
import '../database/dao/transaction_log_dao.dart';
import '../models/loan.dart';
import '../models/schedule_entry.dart';
import '../models/collection_entry.dart';
import '../models/transaction_log.dart';
import 'calculation_service.dart';

class ScheduleService {
  final DatabaseHelper _dbHelper;
  late final LoanDao _loanDao;
  late final ScheduleDao _scheduleDao;
  late final CollectionDao _collectionDao;
  late final TransactionLogDao _logDao;

  ScheduleService(this._dbHelper) {
    _loanDao = LoanDao(_dbHelper);
    _scheduleDao = ScheduleDao(_dbHelper);
    _collectionDao = CollectionDao(_dbHelper);
    _logDao = TransactionLogDao(_dbHelper);
  }

  // Generate schedule entries for a loan
  Future<List<ScheduleEntry>> generateSchedule(Loan loan) async {
    final entries = <ScheduleEntry>[];
    final dailyInstallment = loan.dailyInstallment;
    var remainingReturn = loan.returnAmount;
    final now = DateTime.now();
    final today = DateTime(now.year, now.month, now.day);

    for (int i = 1; i <= loan.totalDays; i++) {
      double expectedAmount = dailyInstallment;
      if (i == loan.totalDays) {
        // Last installment - adjust for rounding
        expectedAmount = remainingReturn;
      } else {
        remainingReturn -= dailyInstallment;
      }
      final dueDate = loan.startDate.add(Duration(days: i - 1));
      entries.add(ScheduleEntry(
        loanId: loan.id!,
        dueDate: dueDate,
        expectedAmount: expectedAmount,
        installmentNumber: i,
        status: dueDate.isBefore(today) ? ScheduleEntryStatus.overdue : ScheduleEntryStatus.pending,
      ));
    }

    if (loan.id != null) {
      await _scheduleDao.insertAll(entries);
    }
    return entries;
  }

  // Record a collection
  Future<int> recordCollection({
    required int loanId,
    required int scheduleEntryId,
    required double amount,
    required DateTime collectedDate,
    PaymentMode paymentMode = PaymentMode.cash,
    String collectedBy = 'Owner',
    String notes = '',
  }) async {
    final entry = await _scheduleDao.getById(scheduleEntryId);
    if (entry == null) throw Exception('Schedule entry not found');

    final collection = CollectionEntry(
      loanId: loanId,
      scheduleEntryId: scheduleEntryId,
      amount: amount,
      collectedDate: collectedDate,
      paymentMode: paymentMode,
      collectedBy: collectedBy,
      notes: notes,
    );

    final collectionId = await _collectionDao.insert(collection);

    // Update schedule entry
    final updatedEntry = entry.copyWith(
      collectedAmount: entry.collectedAmount + amount,
      status: ScheduleEntryStatus.paid,
      collectedDate: collectedDate,
    );
    await _scheduleDao.update(updatedEntry);

    // Check if loan is completed
    await _checkLoanCompletion(loanId);

    // Log transaction
    await _logDao.insert(TransactionLog(
      type: TransactionType.collect,
      entity: 'collection',
      entityId: collectionId,
      description: 'Collection of ${CalculationService.formatCurrencySimple(amount)} recorded',
      timestamp: DateTime.now(),
      details: 'Loan ID: $loanId, Schedule Entry: $scheduleEntryId',
    ));

    return collectionId;
  }

  // Edit a collection
  Future<void> editCollection({
    required int collectionId,
    required double newAmount,
    required DateTime newDate,
    PaymentMode? paymentMode,
    String? notes,
  }) async {
    final collection = await _collectionDao.getById(collectionId);
    if (collection == null) throw Exception('Collection not found');

    final oldAmount = collection.amount;
    final entry = await _scheduleDao.getById(collection.scheduleEntryId);
    if (entry == null) throw Exception('Schedule entry not found');

    // Update collection
    final updatedCollection = collection.copyWith(
      amount: newAmount,
      collectedDate: newDate,
      paymentMode: paymentMode ?? collection.paymentMode,
      notes: notes ?? collection.notes,
    );
    await _collectionDao.update(updatedCollection);

    // Update schedule entry
    final newCollectedAmount = entry.collectedAmount - oldAmount + newAmount;
    final updatedEntry = entry.copyWith(
      collectedAmount: newCollectedAmount,
      collectedDate: newDate,
      status: newCollectedAmount >= entry.expectedAmount ? ScheduleEntryStatus.paid : ScheduleEntryStatus.pending,
    );
    await _scheduleDao.update(updatedEntry);

    // Log transaction
    await _logDao.insert(TransactionLog(
      type: TransactionType.update,
      entity: 'collection',
      entityId: collectionId,
      description: 'Collection edited from ${CalculationService.formatCurrencySimple(oldAmount)} to ${CalculationService.formatCurrencySimple(newAmount)}',
      timestamp: DateTime.now(),
    ));
  }

  // Delete a collection
  Future<void> deleteCollection(int collectionId) async {
    final collection = await _collectionDao.getById(collectionId);
    if (collection == null) throw Exception('Collection not found');

    final entry = await _scheduleDao.getById(collection.scheduleEntryId);
    if (entry != null) {
      final newCollectedAmount = entry.collectedAmount - collection.amount;
      final updatedEntry = entry.copyWith(
        collectedAmount: newCollectedAmount,
        status: newCollectedAmount >= entry.expectedAmount ? ScheduleEntryStatus.paid : ScheduleEntryStatus.pending,
        collectedDate: newCollectedAmount > 0 ? entry.collectedDate : null,
      );
      await _scheduleDao.update(updatedEntry);
    }

    await _collectionDao.delete(collectionId);

    // Log transaction
    await _logDao.insert(TransactionLog(
      type: TransactionType.delete,
      entity: 'collection',
      entityId: collectionId,
      description: 'Collection of ${CalculationService.formatCurrencySimple(collection.amount)} deleted',
      timestamp: DateTime.now(),
    ));
  }

  // Bulk mark paid for today's entries
  Future<int> bulkMarkPaid(int loanId, DateTime date) async {
    final entries = await _scheduleDao.getByDate(date);
    int count = 0;
    for (final entry in entries) {
      if (entry.loanId == loanId && entry.status != ScheduleEntryStatus.paid) {
        await recordCollection(
          loanId: loanId,
          scheduleEntryId: entry.id!,
          amount: entry.expectedAmount,
          collectedDate: DateTime.now(),
        );
        count++;
      }
    }
    return count;
  }

  Future<int> bulkMarkAllPaid(DateTime date) async {
    final entries = await _scheduleDao.getByDate(date);
    int count = 0;
    for (final entry in entries) {
      if (entry.status != ScheduleEntryStatus.paid) {
        await recordCollection(
          loanId: entry.loanId,
          scheduleEntryId: entry.id!,
          amount: entry.expectedAmount,
          collectedDate: DateTime.now(),
        );
        count++;
      }
    }
    return count;
  }

  // Pre-close a loan
  Future<void> preCloseLoan(int loanId, double preCloseAmount, double discount) async {
    final loan = await _loanDao.getById(loanId);
    if (loan == null) throw Exception('Loan not found');

    final pendingEntries = await _scheduleDao.getPendingByLoanId(loanId);
    for (final entry in pendingEntries) {
      final updatedEntry = entry.copyWith(
        status: ScheduleEntryStatus.skipped,
        notes: 'Pre-closed',
      );
      await _scheduleDao.update(updatedEntry);
    }

    final updatedLoan = loan.copyWith(
      status: LoanStatus.preclosed,
      updatedAt: DateTime.now(),
    );
    await _loanDao.update(updatedLoan);

    await _logDao.insert(TransactionLog(
      type: TransactionType.preclose,
      entity: 'loan',
      entityId: loanId,
      description: 'Loan pre-closed with ${CalculationService.formatCurrencySimple(preCloseAmount)} (discount: ${CalculationService.formatCurrencySimple(discount)})',
      timestamp: DateTime.now(),
    ));
  }

  // Cancel a loan
  Future<void> cancelLoan(int loanId, String reason) async {
    final loan = await _loanDao.getById(loanId);
    if (loan == null) throw Exception('Loan not found');

    final pendingEntries = await _scheduleDao.getPendingByLoanId(loanId);
    for (final entry in pendingEntries) {
      final updatedEntry = entry.copyWith(
        status: ScheduleEntryStatus.skipped,
        notes: 'Loan cancelled',
      );
      await _scheduleDao.update(updatedEntry);
    }

    final updatedLoan = loan.copyWith(
      status: LoanStatus.cancelled,
      notes: '${loan.notes}\nCancelled: $reason',
      updatedAt: DateTime.now(),
    );
    await _loanDao.update(updatedLoan);

    await _logDao.insert(TransactionLog(
      type: TransactionType.cancel,
      entity: 'loan',
      entityId: loanId,
      description: 'Loan cancelled: $reason',
      timestamp: DateTime.now(),
    ));
  }

  // Renew a loan
  Future<int> renewLoan(int oldLoanId, Loan newLoanData) async {
    final oldLoan = await _loanDao.getById(oldLoanId);
    if (oldLoan == null) throw Exception('Old loan not found');

    final collectedTotal = await _scheduleDao.getCollectedTotal(oldLoanId);
    final outstanding = oldLoan.returnAmount - collectedTotal;

    // Mark old loan as completed
    final updatedOldLoan = oldLoan.copyWith(
      status: LoanStatus.completed,
      updatedAt: DateTime.now(),
    );
    await _loanDao.update(updatedOldLoan);

    // Create new loan with renewedFrom set
    final newLoan = newLoanData.copyWith(
      renewedFrom: oldLoanId,
      createdAt: DateTime.now(),
      updatedAt: DateTime.now(),
    );
    final newLoanId = await _loanDao.insert(newLoan);

    // Generate schedule for new loan
    final loanWithId = newLoan.copyWith(id: newLoanId);
    await generateSchedule(loanWithId);

    await _logDao.insert(TransactionLog(
      type: TransactionType.renew,
      entity: 'loan',
      entityId: newLoanId,
      description: 'Loan renewed from loan #$oldLoanId. Outstanding was ${CalculationService.formatCurrencySimple(outstanding)}',
      timestamp: DateTime.now(),
    ));

    return newLoanId;
  }

  // Check if loan is completed
  Future<void> _checkLoanCompletion(int loanId) async {
    final loan = await _loanDao.getById(loanId);
    if (loan == null) return;

    final paidCount = await _scheduleDao.getPaidCount(loanId);
    if (paidCount >= loan.totalDays) {
      final updatedLoan = loan.copyWith(
        status: LoanStatus.completed,
        updatedAt: DateTime.now(),
      );
      await _loanDao.update(updatedLoan);

      await _logDao.insert(TransactionLog(
        type: TransactionType.update,
        entity: 'loan',
        entityId: loanId,
        description: 'Loan completed - all installments paid',
        timestamp: DateTime.now(),
      ));
    }
  }

  // Get loan progress
  Future<Map<String, dynamic>> getLoanProgress(int loanId) async {
    final loan = await _loanDao.getById(loanId);
    if (loan == null) throw Exception('Loan not found');

    final allEntries = await _scheduleDao.getByLoanId(loanId);
    final paidEntries = allEntries.where((e) => e.isPaid).toList();
    final pendingEntries = allEntries.where((e) => e.isPending).toList();
    final overdueEntries = allEntries.where((e) => e.isOverdue).toList();

    final collectedTotal = paidEntries.fold<double>(0, (sum, e) => sum + e.collectedAmount);
    final outstanding = loan.returnAmount - collectedTotal;
    final completionPercent = CalculationService.calculateCompletion(collectedTotal, loan.returnAmount);

    return {
      'totalEntries': allEntries.length,
      'paidCount': paidEntries.length,
      'pendingCount': pendingEntries.length,
      'overdueCount': overdueEntries.length,
      'collectedTotal': collectedTotal,
      'outstanding': outstanding,
      'completionPercent': completionPercent,
      'loan': loan,
    };
  }

  // Mark overdue entries
  Future<void> markOverdue() async {
    await _scheduleDao.markOverdue();
  }
}
