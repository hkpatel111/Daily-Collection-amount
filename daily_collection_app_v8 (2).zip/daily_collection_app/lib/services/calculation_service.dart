class CalculationService {
  // Custom power function for integer exponents
  static double pow(double base, int exp) {
    double result = 1;
    for (int i = 0; i < exp; i++) {
      result *= base;
    }
    return result;
  }

  // Power function for double exponents
  static double powDouble(double base, double exponent) {
    return pow(base, exponent.round());
  }

  // Fixed Return calculation
  static double calculateFixedReturn(double principal, double returnAmount, int totalDays) {
    if (totalDays <= 0) return 0;
    return returnAmount / totalDays;
  }

  // Flat Monthly interest calculation
  static double calculateFlatMonthlyReturn(double principal, double monthlyRate, int totalDays) {
    final months = totalDays / 30.0;
    final interest = principal * (monthlyRate / 100) * months;
    final totalReturn = principal + interest;
    return totalReturn / totalDays;
  }

  // Reducing Balance EMI calculation
  static double calculateEMI(double principal, double monthlyRate, int totalDays) {
    final months = totalDays / 30.0;
    final n = months;
    final r = monthlyRate / 100 / 30;
    if (r == 0) return principal / totalDays;
    // EMI formula: P * r * (1+r)^n / ((1+r)^n - 1)
    // n is double here, use powDouble
    final powVal = powDouble(1 + r, n);
    final emi = principal * r * powVal / (powVal - 1);
    return emi;
  }

  // Total return amount for fixed return mode
  static double calculateTotalReturn(double principal, double dailyInstallment, int totalDays) {
    return dailyInstallment * totalDays;
  }

  // Profit calculation
  static double calculateProfit(double principal, double returnAmount) {
    return returnAmount - principal;
  }

  // Outstanding amount for a loan
  static double calculateOutstanding(double returnAmount, double collectedAmount) {
    return returnAmount - collectedAmount;
  }

  // Completion percentage
  static double calculateCompletion(double collectedAmount, double returnAmount) {
    if (returnAmount <= 0) return 0;
    return (collectedAmount / returnAmount) * 100;
  }

  // Days remaining
  static int calculateDaysRemaining(DateTime endDate) {
    final now = DateTime.now();
    final diff = endDate.difference(now).inDays;
    return diff > 0 ? diff : 0;
  }

  // Days overdue
  static int calculateDaysOverdue(DateTime dueDate) {
    final now = DateTime.now();
    if (dueDate.isAfter(now)) return 0;
    return now.difference(dueDate).inDays;
  }

  // Interest amount for flat monthly
  static double calculateFlatMonthlyInterest(double principal, double monthlyRate, int totalDays) {
    final months = totalDays / 30.0;
    return principal * (monthlyRate / 100) * months;
  }

  // Total interest for reducing balance
  static double calculateReducingBalanceInterest(double principal, double monthlyRate, int totalDays) {
    final emi = calculateEMI(principal, monthlyRate, totalDays);
    return (emi * totalDays) - principal;
  }

  // Format currency with Indian numbering
  static String formatCurrency(double amount, {String symbol = 'Rs'}) {
    final intPart = amount.toInt().abs();
    final isNegative = amount < 0;
    final formatted = _formatIndianNumber(intPart);
    final decimalPart = ((amount.abs() - intPart) * 100).round().toString().padLeft(2, '0');
    final prefix = isNegative ? '-' : '';
    return '$prefix$symbol $formatted.$decimalPart';
  }

  static String formatCurrencySimple(double amount, {String symbol = 'Rs'}) {
    final intPart = amount.round().abs();
    final isNegative = amount < 0;
    final formatted = _formatIndianNumber(intPart);
    final prefix = isNegative ? '-' : '';
    return '$prefix$symbol $formatted';
  }

  static String _formatIndianNumber(int number) {
    if (number == 0) return '0';
    final str = number.toString();
    if (str.length <= 3) return str;
    final last3 = str.substring(str.length - 3);
    final rest = str.substring(0, str.length - 3);
    final buffer = StringBuffer();
    int i = 0;
    for (final char in rest.split('').reversed) {
      if (i == 2 && buffer.isNotEmpty) {
        buffer.write(',');
        i = 0;
      }
      buffer.write(char);
      i++;
    }
    final reversed = buffer.toString().split('').reversed.join();
    return '$reversed,$last3';
  }

  // 10 Calculator methods

  // 1. Fixed Return Calculator
  static Map<String, double> fixedReturnCalc(double principal, double returnAmount, int totalDays) {
    final dailyInstallment = calculateFixedReturn(principal, returnAmount, totalDays);
    final profit = calculateProfit(principal, returnAmount);
    return {
      'dailyInstallment': dailyInstallment,
      'profit': profit,
      'totalReturn': returnAmount,
      'profitPercent': principal > 0 ? (profit / principal) * 100 : 0,
    };
  }

  // 2. Flat Monthly Interest Calculator
  static Map<String, double> flatMonthlyCalc(double principal, double monthlyRate, int totalDays) {
    final dailyInstallment = calculateFlatMonthlyReturn(principal, monthlyRate, totalDays);
    final interest = calculateFlatMonthlyInterest(principal, monthlyRate, totalDays);
    final totalReturn = principal + interest;
    final profit = interest;
    return {
      'dailyInstallment': dailyInstallment,
      'interest': interest,
      'totalReturn': totalReturn,
      'profit': profit,
      'profitPercent': principal > 0 ? (profit / principal) * 100 : 0,
    };
  }

  // 3. Reducing Balance EMI Calculator
  static Map<String, double> reducingBalanceCalc(double principal, double monthlyRate, int totalDays) {
    final emi = calculateEMI(principal, monthlyRate, totalDays);
    final totalReturn = emi * totalDays;
    final interest = totalReturn - principal;
    final profit = interest;
    return {
      'emi': emi,
      'totalReturn': totalReturn,
      'interest': interest,
      'profit': profit,
      'profitPercent': principal > 0 ? (profit / principal) * 100 : 0,
    };
  }

  // 4. Interest Rate Calculator
  static Map<String, double> interestRateCalc(double principal, double returnAmount, int totalDays) {
    final profit = returnAmount - principal;
    final months = totalDays / 30.0;
    final monthlyRate = principal > 0 && months > 0 ? (profit / principal) / months * 100 : 0;
    final yearlyRate = monthlyRate * 12;
    return {
      'profit': profit,
      'monthlyRate': monthlyRate,
      'yearlyRate': yearlyRate,
      'profitPercent': principal > 0 ? (profit / principal) * 100 : 0,
    };
  }

  // 5. Loan Tenure Calculator
  static Map<String, double> loanTenureCalc(double principal, double dailyInstallment, double returnAmount) {
    if (dailyInstallment <= 0) return {'totalDays': 0, 'totalMonths': 0};
    final totalDays = (returnAmount / dailyInstallment).ceil().toDouble();
    return {
      'totalDays': totalDays,
      'totalMonths': totalDays / 30,
      'profit': returnAmount - principal,
    };
  }

  // 6. Daily Installment Calculator
  static Map<String, double> dailyInstallmentCalc(double principal, double returnAmount, int totalDays) {
    final daily = calculateFixedReturn(principal, returnAmount, totalDays);
    return {
      'dailyInstallment': daily,
      'profit': returnAmount - principal,
      'profitPercent': principal > 0 ? ((returnAmount - principal) / principal) * 100 : 0,
    };
  }

  // 7. Principal Calculator (from return and daily installment)
  static Map<String, double> principalCalc(double returnAmount, double dailyInstallment, int totalDays) {
    if (dailyInstallment <= 0 || totalDays <= 0) return {};
    final totalReturn = dailyInstallment * totalDays;
    final principal = returnAmount;
    return {
      'principal': principal,
      'totalReturn': totalReturn,
      'profit': totalReturn - principal,
    };
  }

  // 8. Return Amount Calculator (from principal, rate, days)
  static Map<String, double> returnAmountCalc(double principal, double monthlyRate, int totalDays, String mode) {
    double totalReturn = 0;
    double profit = 0;
    if (mode == 'flat') {
      profit = calculateFlatMonthlyInterest(principal, monthlyRate, totalDays);
      totalReturn = principal + profit;
    } else {
      final emi = calculateEMI(principal, monthlyRate, totalDays);
      totalReturn = emi * totalDays;
      profit = totalReturn - principal;
    }
    return {
      'totalReturn': totalReturn,
      'profit': profit,
      'profitPercent': principal > 0 ? (profit / principal) * 100 : 0,
    };
  }

  // 9. Pre-close Calculator
  static Map<String, double> preCloseCalc(double returnAmount, double collectedAmount, double discountPercent) {
    final outstanding = returnAmount - collectedAmount;
    final discount = outstanding * (discountPercent / 100);
    final preCloseAmount = outstanding - discount;
    return {
      'outstanding': outstanding,
      'discount': discount,
      'preCloseAmount': preCloseAmount,
      'totalCollected': collectedAmount + preCloseAmount,
    };
  }

  // 10. Renewal Calculator
  static Map<String, double> renewalCalc(double oldPrincipal, double oldOutstanding, double newPrincipal, double newReturnAmount, int newTotalDays) {
    final netDisbursement = newPrincipal - oldOutstanding;
    final newDailyInstallment = calculateFixedReturn(newPrincipal, newReturnAmount, newTotalDays);
    return {
      'oldOutstanding': oldOutstanding,
      'newPrincipal': newPrincipal,
      'netDisbursement': netDisbursement,
      'newDailyInstallment': newDailyInstallment,
      'newProfit': newReturnAmount - newPrincipal,
    };
  }
}
