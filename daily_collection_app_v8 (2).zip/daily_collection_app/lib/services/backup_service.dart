import 'dart:convert';
import 'dart:io';
import 'package:path/path.dart';
import 'package:path_provider/path_provider.dart';
import 'package:share_plus/share_plus.dart';
import 'package:pdf/pdf.dart';
import 'package:pdf/widgets.dart' as pw;
import '../database/database_helper.dart';
import '../database/dao/customer_dao.dart';
import '../database/dao/loan_dao.dart';
import '../database/dao/schedule_dao.dart';
import '../database/dao/collection_dao.dart';
import '../models/customer.dart';
import '../models/loan.dart';
import '../models/schedule_entry.dart';
import '../models/collection_entry.dart';

class BackupService {
  final DatabaseHelper _dbHelper;
  late final CustomerDao _customerDao;
  late final LoanDao _loanDao;
  late final ScheduleDao _scheduleDao;
  late final CollectionDao _collectionDao;

  BackupService(this._dbHelper) {
    _customerDao = CustomerDao(_dbHelper);
    _loanDao = LoanDao(_dbHelper);
    _scheduleDao = ScheduleDao(_dbHelper);
    _collectionDao = CollectionDao(_dbHelper);
  }

  // JSON Backup
  Future<String> createBackup() async {
    final customers = await _customerDao.getAll();
    final loans = await _loanDao.getAll();
    final collections = await _collectionDao.getAll();

    final List<Map<String, dynamic>> schedules = [];
    for (final loan in loans) {
      final entries = await _scheduleDao.getByLoanId(loan.id!);
      for (final entry in entries) {
        schedules.add(entry.toMap());
      }
    }

    final backupData = {
      'version': '3.0.0',
      'timestamp': DateTime.now().toIso8601String(),
      'createdBy': 'Harish K Patidar',
      'customers': customers.map((c) => c.toMap()).toList(),
      'loans': loans.map((l) => l.toMap()).toList(),
      'schedules': schedules,
      'collections': collections.map((c) => c.toMap()).toList(),
    };

    final jsonStr = jsonEncode(backupData);
    final dir = await getApplicationDocumentsDirectory();
    final timestamp = DateTime.now().toIso8601String().replaceAll(':', '-').split('.')[0];
    final filePath = join(dir.path, 'daily_collection_backup_$timestamp.json');
    final file = File(filePath);
    await file.writeAsString(jsonStr);
    return filePath;
  }

  // Restore from JSON
  Future<bool> restoreBackup(String jsonStr) async {
    try {
      final data = jsonDecode(jsonStr) as Map<String, dynamic>;
      final db = await _dbHelper.database;

      // Clear existing data
      await db.delete('collections', where: '1 = 1');
      await db.delete('schedule_entries', where: '1 = 1');
      await db.delete('loans', where: '1 = 1');
      await db.delete('customers', where: '1 = 1');

      // Restore customers
      final customers = data['customers'] as List? ?? [];
      for (final c in customers) {
        await db.insert('customers', c as Map<String, dynamic>);
      }

      // Restore loans
      final loans = data['loans'] as List? ?? [];
      for (final l in loans) {
        await db.insert('loans', l as Map<String, dynamic>);
      }

      // Restore schedules
      final schedules = data['schedules'] as List? ?? [];
      for (final s in schedules) {
        await db.insert('schedule_entries', s as Map<String, dynamic>);
      }

      // Restore collections
      final collections = data['collections'] as List? ?? [];
      for (final c in collections) {
        await db.insert('collections', c as Map<String, dynamic>);
      }

      return true;
    } catch (e) {
      return false;
    }
  }

  // CSV Export - Customers
  Future<String> exportCustomersCSV() async {
    final customers = await _customerDao.getAll();
    final buffer = StringBuffer();
    buffer.writeln('ID,Name,Mobile,Nickname,Active,IDNumber,CreatedAt');
    for (final c in customers) {
      buffer.writeln('${c.id},${c.name},${c.mobile},${c.nickname},${c.isActive ? 'Yes' : 'No'},${c.idNumber},${c.createdAt.toIso8601String()}');
    }
    return buffer.toString();
  }

  // CSV Export - Loans
  Future<String> exportLoansCSV() async {
    final loans = await _loanDao.getAll();
    final buffer = StringBuffer();
    buffer.writeln('ID,CustomerID,Principal,ReturnAmount,DailyInstallment,TotalDays,StartDate,EndDate,Status,InterestMode,InterestRate');
    for (final l in loans) {
      buffer.writeln('${l.id},${l.customerId},${l.principal},${l.returnAmount},${l.dailyInstallment},${l.totalDays},${l.startDate.toIso8601String()},${l.endDate.toIso8601String()},${l.status.name},${l.interestMode.name},${l.interestRate}');
    }
    return buffer.toString();
  }

  // CSV Export - Collections
  Future<String> exportCollectionsCSV() async {
    final collections = await _collectionDao.getAll();
    final buffer = StringBuffer();
    buffer.writeln('ID,LoanID,ScheduleEntryID,Amount,CollectedDate,PaymentMode,CollectedBy,Notes');
    for (final c in collections) {
      buffer.writeln('${c.id},${c.loanId},${c.scheduleEntryId},${c.amount},${c.collectedDate.toIso8601String()},${c.paymentMode.name},${c.collectedBy},${c.notes}');
    }
    return buffer.toString();
  }

  // Save CSV file and share
  Future<void> saveAndShareCSV(String csvContent, String fileName) async {
    final dir = await getTemporaryDirectory();
    final filePath = join(dir.path, fileName);
    final file = File(filePath);
    await file.writeAsString(csvContent);
    await Share.shareXFiles([XFile(filePath)]);
  }

  // Generate PDF Receipt
  Future<String> generatePdfReceipt({
    required Customer customer,
    required Loan loan,
    required CollectionEntry collection,
    required double outstanding,
  }) async {
    final pdf = pw.Document();

    pdf.addPage(
      pw.Page(
        pageFormat: PdfPageFormat.a5,
        build: (pw.Context context) {
          return pw.Column(
            crossAxisAlignment: pw.CrossAxisAlignment.start,
            children: [
              pw.Center(
                child: pw.Text(
                  'Daily Collection Receipt',
                  style: pw.TextStyle(fontSize: 18, fontWeight: pw.FontWeight.bold),
                ),
              ),
              pw.SizedBox(height: 10),
              pw.Divider(),
              pw.SizedBox(height: 10),
              pw.Text('Customer: ${customer.name}'),
              pw.Text('Mobile: ${customer.mobile}'),
              pw.SizedBox(height: 8),
              pw.Text('Loan ID: #${loan.id}'),
              pw.Text('Principal: Rs ${loan.principal.toStringAsFixed(0)}'),
              pw.Text('Return Amount: Rs ${loan.returnAmount.toStringAsFixed(0)}'),
              pw.SizedBox(height: 8),
              pw.Text('Collection Amount: Rs ${collection.amount.toStringAsFixed(0)}'),
              pw.Text('Payment Mode: ${collection.paymentMode.name}'),
              pw.Text('Date: ${collection.collectedDate.toLocal().toString().substring(0, 16)}'),
              pw.SizedBox(height: 8),
              pw.Text('Outstanding: Rs ${outstanding.toStringAsFixed(0)}'),
              pw.SizedBox(height: 20),
              pw.Divider(),
              pw.SizedBox(height: 10),
              pw.Center(
                child: pw.Text(
                  'Created by Harish',
                  style: pw.TextStyle(fontSize: 10, color: PdfColors.grey600),
                ),
              ),
              pw.Center(
                child: pw.Text(
                  'Harish K Patidar',
                  style: pw.TextStyle(fontSize: 8, color: PdfColors.grey600),
                ),
              ),
            ],
          );
        },
      ),
    );

    final dir = await getTemporaryDirectory();
    final timestamp = DateTime.now().millisecondsSinceEpoch;
    final filePath = join(dir.path, 'receipt_$timestamp.pdf');
    final file = File(filePath);
    await file.writeAsBytes(await pdf.save());
    return filePath;
  }

  // Share PDF Receipt
  Future<void> sharePdfReceipt(String filePath) async {
    await Share.shareXFiles([XFile(filePath)]);
  }

  // Generate Loan Summary PDF
  Future<String> generateLoanSummaryPdf({
    required Customer customer,
    required Loan loan,
    required List<ScheduleEntry> schedule,
    required double collectedTotal,
  }) async {
    final pdf = pw.Document();

    pdf.addPage(
      pw.MultiPage(
        pageFormat: PdfPageFormat.a4,
        build: (pw.Context context) {
          final outstanding = loan.returnAmount - collectedTotal;
          final completionPercent = (collectedTotal / loan.returnAmount * 100).toStringAsFixed(1);

          return [
            pw.Center(
              child: pw.Text(
                'Loan Summary Report',
                style: pw.TextStyle(fontSize: 20, fontWeight: pw.FontWeight.bold),
              ),
            ),
            pw.SizedBox(height: 10),
            pw.Divider(),
            pw.SizedBox(height: 10),
            pw.Text('Customer: ${customer.name}'),
            pw.Text('Mobile: ${customer.mobile}'),
            pw.SizedBox(height: 8),
            pw.Text('Loan ID: #${loan.id}'),
            pw.Text('Principal: Rs ${loan.principal.toStringAsFixed(0)}'),
            pw.Text('Return Amount: Rs ${loan.returnAmount.toStringAsFixed(0)}'),
            pw.Text('Daily Installment: Rs ${loan.dailyInstallment.toStringAsFixed(0)}'),
            pw.Text('Total Days: ${loan.totalDays}'),
            pw.Text('Start Date: ${loan.startDate.toLocal().toString().substring(0, 10)}'),
            pw.Text('End Date: ${loan.endDate.toLocal().toString().substring(0, 10)}'),
            pw.Text('Interest Mode: ${loan.interestMode.name}'),
            pw.SizedBox(height: 8),
            pw.Text('Collected Total: Rs ${collectedTotal.toStringAsFixed(0)}'),
            pw.Text('Outstanding: Rs ${outstanding.toStringAsFixed(0)}'),
            pw.Text('Completion: $completionPercent%'),
            pw.SizedBox(height: 20),
            pw.Text('Schedule:', style: pw.TextStyle(fontWeight: pw.FontWeight.bold)),
            pw.SizedBox(height: 5),
            pw.Table.fromTextArray(
              headers: ['No', 'Due Date', 'Expected', 'Collected', 'Status'],
              data: schedule.map((e) => [
                e.installmentNumber.toString(),
                e.dueDate.toLocal().toString().substring(0, 10),
                'Rs ${e.expectedAmount.toStringAsFixed(0)}',
                'Rs ${e.collectedAmount.toStringAsFixed(0)}',
                e.status.name,
              ]).toList(),
            ),
            pw.SizedBox(height: 20),
            pw.Center(
              child: pw.Text(
                'Created by Harish | Harish K Patidar',
                style: pw.TextStyle(fontSize: 10, color: PdfColors.grey600),
              ),
            ),
          ];
        },
      ),
    );

    final dir = await getTemporaryDirectory();
    final timestamp = DateTime.now().millisecondsSinceEpoch;
    final filePath = join(dir.path, 'loan_summary_$timestamp.pdf');
    final file = File(filePath);
    await file.writeAsBytes(await pdf.save());
    return filePath;
  }
}
