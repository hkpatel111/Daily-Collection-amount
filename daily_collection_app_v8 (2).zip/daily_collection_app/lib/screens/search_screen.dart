import 'package:flutter/material.dart';
import '../database/database_helper.dart';
import '../database/dao/customer_dao.dart';
import '../database/dao/loan_dao.dart';
import '../models/customer.dart';
import '../models/loan.dart';
import '../services/calculation_service.dart';
import '../utils/constants.dart';

class SearchScreen extends StatefulWidget {
  const SearchScreen({super.key});

  @override
  State<SearchScreen> createState() => _SearchScreenState();
}

class _SearchScreenState extends State<SearchScreen> {
  final _dbHelper = DatabaseHelper();
  late final CustomerDao _customerDao;
  late final LoanDao _loanDao;
  List<Customer> _customers = [];
  List<Loan> _loans = [];
  final _searchController = TextEditingController();
  bool _hasSearched = false;

  @override
  void initState() {
    super.initState();
    _customerDao = CustomerDao(_dbHelper);
    _loanDao = LoanDao(_dbHelper);
  }

  void _search(String query) async {
    if (query.trim().isEmpty) {
      setState(() {
        _customers = [];
        _loans = [];
        _hasSearched = false;
      });
      return;
    }
    final customers = await _customerDao.search(query);
    final loans = await _loanDao.search(query);
    setState(() {
      _customers = customers;
      _loans = loans;
      _hasSearched = true;
    });
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: const Text('Search')),
      body: Column(
        children: [
          Padding(
            padding: const EdgeInsets.all(12),
            child: TextField(
              controller: _searchController,
              keyboardType: TextInputType.text,
              autofocus: true,
              decoration: InputDecoration(
                hintText: 'Search customers, loans, mobile...',
                prefixIcon: const Icon(Icons.search),
                border: OutlineInputBorder(borderRadius: BorderRadius.circular(8)),
              ),
              onChanged: _search,
            ),
          ),
          Expanded(
            child: _hasSearched && _customers.isEmpty && _loans.isEmpty
                ? const Center(child: Text('Kuch nahi mila'))
                : ListView(
                    children: [
                      if (_customers.isNotEmpty) ...[
                        const Padding(
                          padding: EdgeInsets.symmetric(horizontal: 16, vertical: 8),
                          child: Text('Customers', style: TextStyle(fontSize: 16, fontWeight: FontWeight.bold)),
                        ),
                        ..._customers.map((c) => Card(
                              margin: const EdgeInsets.symmetric(horizontal: 8, vertical: 4),
                              child: ListTile(
                                leading: CircleAvatar(backgroundColor: AppColors.primary.withOpacity(0.15), child: const Icon(Icons.person, color: AppColors.primary)),
                                title: Text(c.name),
                                subtitle: Text(c.mobile),
                                onTap: () => Navigator.pushNamed(context, '/customer_detail', arguments: c.id),
                              ),
                            )),
                      ],
                      if (_loans.isNotEmpty) ...[
                        const Padding(
                          padding: EdgeInsets.symmetric(horizontal: 16, vertical: 8),
                          child: Text('Loans', style: TextStyle(fontSize: 16, fontWeight: FontWeight.bold)),
                        ),
                        ..._loans.map((l) => Card(
                              margin: const EdgeInsets.symmetric(horizontal: 8, vertical: 4),
                              child: ListTile(
                                leading: const CircleAvatar(child: Icon(Icons.account_balance)),
                                title: Text('Loan #${l.id} - ${CalculationService.formatCurrencySimple(l.principal)}'),
                                subtitle: Text('Status: ${l.status.name}'),
                                onTap: () => Navigator.pushNamed(context, '/loan_detail', arguments: l.id),
                              ),
                            )),
                      ],
                    ],
                  ),
          ),
        ],
      ),
    );
  }

  @override
  void dispose() {
    _searchController.dispose();
    super.dispose();
  }
}
