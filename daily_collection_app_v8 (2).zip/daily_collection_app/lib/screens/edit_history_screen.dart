import 'package:flutter/material.dart';
import 'package:intl/intl.dart';
import '../database/database_helper.dart';
import '../database/dao/edit_history_dao.dart';
import '../models/edit_history.dart';
import '../utils/constants.dart';

class EditHistoryScreen extends StatefulWidget {
  const EditHistoryScreen({super.key});

  @override
  State<EditHistoryScreen> createState() => _EditHistoryScreenState();
}

class _EditHistoryScreenState extends State<EditHistoryScreen> {
  final _dbHelper = DatabaseHelper();
  late final EditHistoryDao _editHistoryDao;
  List<EditHistory> _history = [];
  bool _isLoading = true;

  @override
  void initState() {
    super.initState();
    _editHistoryDao = EditHistoryDao(_dbHelper);
    _loadData();
  }

  Future<void> _loadData() async {
    setState(() => _isLoading = true);
    final history = await _editHistoryDao.getAll();
    setState(() {
      _history = history;
      _isLoading = false;
    });
  }

  @override
  Widget build(BuildContext context) {
    final dateFormat = DateFormat('dd MMM yyyy HH:mm');
    return Scaffold(
      appBar: AppBar(title: const Text('Edit History')),
      body: _isLoading
          ? const Center(child: CircularProgressIndicator())
          : _history.isEmpty
              ? const Center(child: Text('Koi edit history nahi hai'))
              : ListView.builder(
                  itemCount: _history.length,
                  itemBuilder: (context, index) {
                    final h = _history[index];
                    return Card(
                      margin: const EdgeInsets.symmetric(horizontal: 8, vertical: 4),
                      child: ListTile(
                        leading: const CircleAvatar(
                          backgroundColor: AppColors.primary,
                          child: Icon(Icons.edit, color: Colors.white),
                        ),
                        title: Text('${h.entityType.name} #${h.entityId}: ${h.fieldName}'),
                        subtitle: Column(
                          crossAxisAlignment: CrossAxisAlignment.start,
                          children: [
                            Text('Old: ${h.oldValue}'),
                            Text('New: ${h.newValue}'),
                            Text('${dateFormat.format(h.editedAt)} | by ${h.editedBy}'),
                          ],
                        ),
                      ),
                    );
                  },
                ),
    );
  }
}
