import 'package:flutter/material.dart';
import 'package:intl/intl.dart';
import '../database/database_helper.dart';
import '../database/dao/collection_dao.dart';
import '../models/collection_entry.dart';
import '../services/calculation_service.dart';
import '../services/schedule_service.dart';
import '../utils/constants.dart';

class CollectionListScreen extends StatefulWidget {
  const CollectionListScreen({super.key});

  @override
  State<CollectionListScreen> createState() => _CollectionListScreenState();
}

class _CollectionListScreenState extends State<CollectionListScreen> {
  final _dbHelper = DatabaseHelper();
  late final CollectionDao _collectionDao;
  late final ScheduleService _scheduleService;
  List<CollectionEntry> _collections = [];
  bool _isLoading = true;
  final _searchController = TextEditingController();

  @override
  void initState() {
    super.initState();
    _collectionDao = CollectionDao(_dbHelper);
    _scheduleService = ScheduleService(_dbHelper);
    _loadData();
  }

  Future<void> _loadData() async {
    setState(() => _isLoading = true);
    final collections = await _collectionDao.getAll();
    setState(() {
      _collections = collections;
      _isLoading = false;
    });
  }

  Future<void> _editCollection(CollectionEntry collection) async {
    final amountController = TextEditingController(text: collection.amount.toString());
    final result = await showDialog<Map<String, dynamic>>(
      context: context,
      builder: (ctx) => AlertDialog(
        title: const Text('Edit Collection'),
        content: TextField(
          controller: amountController,
          keyboardType: TextInputType.number,
          decoration: const InputDecoration(labelText: 'Amount'),
        ),
        actions: [
          TextButton(onPressed: () => Navigator.pop(ctx), child: const Text('Cancel')),
          TextButton(
            onPressed: () {
              Navigator.pop(ctx, {
                'amount': double.tryParse(amountController.text) ?? collection.amount,
                'date': DateTime.now(),
              });
            },
            child: const Text('Save'),
          ),
        ],
      ),
    );

    if (result != null) {
      await _scheduleService.editCollection(
        collectionId: collection.id!,
        newAmount: result['amount'] as double,
        newDate: result['date'] as DateTime,
      );
      _loadData();
    }
  }

  Future<void> _deleteCollection(CollectionEntry collection) async {
    final confirmed = await showDialog<bool>(
      context: context,
      builder: (ctx) => AlertDialog(
        title: const Text('Delete Collection'),
        content: Text('Delete ${CalculationService.formatCurrencySimple(collection.amount)}?'),
        actions: [
          TextButton(onPressed: () => Navigator.pop(ctx, false), child: const Text('Cancel')),
          TextButton(onPressed: () => Navigator.pop(ctx, true), child: const Text('Delete', style: TextStyle(color: Colors.red))),
        ],
      ),
    );

    if (confirmed == true) {
      await _scheduleService.deleteCollection(collection.id!);
      _loadData();
    }
  }

  @override
  Widget build(BuildContext context) {
    final dateFormat = DateFormat('dd MMM yyyy HH:mm');
    return Scaffold(
      appBar: AppBar(title: const Text('Collections')),
      body: _isLoading
          ? const Center(child: CircularProgressIndicator())
          : _collections.isEmpty
              ? const Center(child: Text('Koi collection nahi hai'))
              : ListView.builder(
                  itemCount: _collections.length,
                  itemBuilder: (context, index) {
                    final c = _collections[index];
                    return Card(
                      margin: const EdgeInsets.symmetric(horizontal: 8, vertical: 4),
                      child: ListTile(
                        leading: const CircleAvatar(
                          backgroundColor: AppColors.success,
                          child: Icon(Icons.payments, color: Colors.white),
                        ),
                        title: Text(CalculationService.formatCurrencySimple(c.amount), style: const TextStyle(fontWeight: FontWeight.w600)),
                        subtitle: Column(
                          crossAxisAlignment: CrossAxisAlignment.start,
                          children: [
                            Text('Loan #${c.loanId} | ${c.paymentMode.name}'),
                            Text(dateFormat.format(c.collectedDate)),
                          ],
                        ),
                        trailing: PopupMenuButton(
                          itemBuilder: (ctx) => [
                            const PopupMenuItem(value: 'edit', child: Text('Edit')),
                            const PopupMenuItem(value: 'delete', child: Text('Delete')),
                          ],
                          onSelected: (value) {
                            if (value == 'edit') _editCollection(c);
                            if (value == 'delete') _deleteCollection(c);
                          },
                        ),
                      ),
                    );
                  },
                ),
    );
  }

  @override
  void dispose() {
    _searchController.dispose();
    super.dispose();
  }
}
