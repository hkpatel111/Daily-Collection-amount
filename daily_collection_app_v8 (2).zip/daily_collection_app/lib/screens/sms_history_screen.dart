import 'package:flutter/material.dart';
import 'package:intl/intl.dart';
import '../database/database_helper.dart';
import '../database/dao/sms_log_dao.dart';
import '../models/sms_log.dart';
import '../utils/constants.dart';

class SmsHistoryScreen extends StatefulWidget {
  const SmsHistoryScreen({super.key});

  @override
  State<SmsHistoryScreen> createState() => _SmsHistoryScreenState();
}

class _SmsHistoryScreenState extends State<SmsHistoryScreen> {
  final _dbHelper = DatabaseHelper();
  late final SmsLogDao _smsLogDao;
  List<SmsLog> _logs = [];
  bool _isLoading = true;

  @override
  void initState() {
    super.initState();
    _smsLogDao = SmsLogDao(_dbHelper);
    _loadLogs();
  }

  Future<void> _loadLogs() async {
    setState(() => _isLoading = true);
    final logs = await _smsLogDao.getAll();
    setState(() {
      _logs = logs;
      _isLoading = false;
    });
  }

  @override
  Widget build(BuildContext context) {
    final dateFormat = DateFormat('dd MMM yyyy HH:mm');
    return Scaffold(
      appBar: AppBar(title: const Text('SMS History')),
      body: _isLoading
          ? const Center(child: CircularProgressIndicator())
          : _logs.isEmpty
              ? const Center(child: Text('Koi SMS history nahi hai'))
              : ListView.builder(
                  itemCount: _logs.length,
                  itemBuilder: (context, index) {
                    final log = _logs[index];
                    return Card(
                      margin: const EdgeInsets.symmetric(horizontal: 8, vertical: 4),
                      child: ListTile(
                        leading: CircleAvatar(
                          backgroundColor: log.status == SmsStatus.sent
                              ? AppColors.success.withOpacity(0.15)
                              : AppColors.overdue.withOpacity(0.15),
                          child: Icon(
                            log.status == SmsStatus.sent ? Icons.check : Icons.error,
                            color: log.status == SmsStatus.sent ? AppColors.success : AppColors.overdue,
                          ),
                        ),
                        title: Text(log.recipient, style: const TextStyle(fontWeight: FontWeight.w600)),
                        subtitle: Column(
                          crossAxisAlignment: CrossAxisAlignment.start,
                          children: [
                            Text(log.message, maxLines: 2, overflow: TextOverflow.ellipsis),
                            Text(dateFormat.format(log.sentAt)),
                            if (log.errorMessage.isNotEmpty)
                              Text('Error: ${log.errorMessage}', style: const TextStyle(color: AppColors.overdue, fontSize: 12)),
                          ],
                        ),
                        trailing: log.loanId != null ? Text('#${log.loanId}') : null,
                      ),
                    );
                  },
                ),
    );
  }
}
