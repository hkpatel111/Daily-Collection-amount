import 'package:flutter/material.dart';
import '../services/calculation_service.dart';
import '../utils/constants.dart';

class CalculatorsScreen extends StatefulWidget {
  const CalculatorsScreen({super.key});

  @override
  State<CalculatorsScreen> createState() => _CalculatorsScreenState();
}

class _CalculatorsScreenState extends State<CalculatorsScreen> {
  int _selectedCalcIndex = 0;
  bool _isMonthly = true;

  final _input1Controller = TextEditingController(text: '10000');
  final _input2Controller = TextEditingController(text: '12000');
  final _input3Controller = TextEditingController(text: '120');

  static const _calculatorNames = [
    'Fixed Return',
    'Flat Monthly',
    'Reducing EMI',
    'Interest Rate',
    'Loan Tenure',
    'Daily Installment',
    'Principal',
    'Return Amount',
    'Pre-Close',
    'Renewal',
  ];

  static const _input1Labels = [
    'Principal',
    'Principal',
    'Principal',
    'Principal',
    'Principal',
    'Principal',
    'Return Amount',
    'Principal',
    'Return Amount',
    'Old Principal',
  ];

  static const _input2Labels = [
    'Return Amount',
    'Monthly Rate %',
    'Monthly Rate %',
    'Return Amount',
    'Daily Installment',
    'Return Amount',
    'Daily Installment',
    'Monthly Rate %',
    'Collected Amount',
    'Old Outstanding',
  ];

  static const _input3Labels = [
    'Total Days',
    'Total Days',
    'Total Days',
    'Total Days',
    'Return Amount',
    'Total Days',
    'Total Days',
    'Total Days',
    'Discount %',
    'New Principal',
  ];

  Map<String, double> _results = {};

  @override
  void initState() {
    super.initState();
    _calculate();
  }

  void _calculate() {
    final v1 = double.tryParse(_input1Controller.text) ?? 0;
    final v2 = double.tryParse(_input2Controller.text) ?? 0;
    final v3 = double.tryParse(_input3Controller.text) ?? 0;
    final v3Int = int.tryParse(_input3Controller.text) ?? 0;

    Map<String, double> results = {};

    switch (_selectedCalcIndex) {
      case 0:
        results = CalculationService.fixedReturnCalc(v1, v2, v3Int);
        break;
      case 1:
        results = CalculationService.flatMonthlyCalc(v1, v2, v3Int);
        if (!_isMonthly) {
          // Convert monthly rate to yearly for display
          final yearlyRate = v2 * 12;
          results = CalculationService.flatMonthlyCalc(v1, yearlyRate / 12, v3Int);
        }
        break;
      case 2:
        results = CalculationService.reducingBalanceCalc(v1, v2, v3Int);
        break;
      case 3:
        results = CalculationService.interestRateCalc(v1, v2, v3Int);
        break;
      case 4:
        results = CalculationService.loanTenureCalc(v1, v2, v3);
        break;
      case 5:
        results = CalculationService.dailyInstallmentCalc(v1, v2, v3Int);
        break;
      case 6:
        final result = CalculationService.principalCalc(v1, v2, v3Int);
        results = result;
        break;
      case 7:
        final mode = _isMonthly ? 'flat' : 'flat';
        results = CalculationService.returnAmountCalc(v1, v2, v3Int, mode);
        break;
      case 8:
        results = CalculationService.preCloseCalc(v1, v2, v3);
        break;
      case 9:
        // Need more inputs for renewal - use available
        results = CalculationService.renewalCalc(v1, v2, v1, v1 * 1.2, v3Int);
        break;
    }

    setState(() => _results = results);
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: const Text('Calculators')),
      body: Column(
        children: [
          // Calculator selector
          SingleChildScrollView(
            scrollDirection: Axis.horizontal,
            padding: const EdgeInsets.all(8),
            child: Row(
              children: List.generate(_calculatorNames.length, (i) {
                return Padding(
                  padding: const EdgeInsets.only(right: 8),
                  child: ChoiceChip(
                    label: Text(_calculatorNames[i], style: const TextStyle(fontSize: 12)),
                    selected: _selectedCalcIndex == i,
                    onSelected: (_) {
                      setState(() => _selectedCalcIndex = i);
                      _calculate();
                    },
                  ),
                );
              }),
            ),
          ),
          // Monthly/Yearly toggle
          if (_selectedCalcIndex == 1 || _selectedCalcIndex == 2 || _selectedCalcIndex == 7)
            Padding(
              padding: const EdgeInsets.symmetric(horizontal: 16),
              child: SegmentedButton<bool>(
                segments: const [
                  ButtonSegment(value: true, label: Text('Monthly Rate')),
                  ButtonSegment(value: false, label: Text('Yearly Rate')),
                ],
                selected: {_isMonthly},
                onSelectionChanged: (s) {
                  setState(() {
                    _isMonthly = s.first;
                    if (!s.first) {
                      _input2Controller.text = (double.tryParse(_input2Controller.text) ?? 0 * 12).toString();
                    } else {
                      final v = double.tryParse(_input2Controller.text) ?? 0;
                      _input2Controller.text = (v / 12).toStringAsFixed(2);
                    }
                  });
                  _calculate();
                },
              ),
            ),
          // Inputs
          Padding(
            padding: const EdgeInsets.all(16),
            child: Column(
              children: [
                TextField(
                  controller: _input1Controller,
                  keyboardType: TextInputType.number,
                  decoration: InputDecoration(
                    labelText: _input1Labels[_selectedCalcIndex],
                    border: OutlineInputBorder(borderRadius: BorderRadius.circular(8)),
                  ),
                  onChanged: (_) => _calculate(),
                ),
                const SizedBox(height: 12),
                TextField(
                  controller: _input2Controller,
                  keyboardType: TextInputType.number,
                  decoration: InputDecoration(
                    labelText: _input2Labels[_selectedCalcIndex],
                    border: OutlineInputBorder(borderRadius: BorderRadius.circular(8)),
                  ),
                  onChanged: (_) => _calculate(),
                ),
                const SizedBox(height: 12),
                TextField(
                  controller: _input3Controller,
                  keyboardType: TextInputType.number,
                  decoration: InputDecoration(
                    labelText: _input3Labels[_selectedCalcIndex],
                    border: OutlineInputBorder(borderRadius: BorderRadius.circular(8)),
                  ),
                  onChanged: (_) => _calculate(),
                ),
              ],
            ),
          ),
          const Divider(),
          // Results
          Expanded(
            child: _results.isEmpty
                ? const Center(child: Text('Calculate karne ke liye values daalo'))
                : ListView(
                    padding: const EdgeInsets.all(16),
                    children: [
                      const Text('Results', style: TextStyle(fontSize: 18, fontWeight: FontWeight.bold, color: AppColors.primary)),
                      const SizedBox(height: 12),
                      ..._results.entries.map((e) => Card(
                            margin: const EdgeInsets.only(bottom: 8),
                            child: ListTile(
                              title: Text(_formatLabel(e.key)),
                              trailing: Text(
                                CalculationService.formatCurrencySimple(e.value),
                                style: const TextStyle(fontWeight: FontWeight.bold, fontSize: 16, color: AppColors.primary),
                              ),
                            ),
                          )),
                      const SizedBox(height: 16),
                      const Center(child: Text(AppConstants.createdBy, style: TextStyle(fontSize: 11, color: Colors.grey))),
                    ],
                  ),
          ),
        ],
      ),
    );
  }

  String _formatLabel(String key) {
    final labels = {
      'dailyInstallment': 'Daily Installment',
      'emi': 'EMI (Daily)',
      'profit': 'Profit',
      'totalReturn': 'Total Return Amount',
      'interest': 'Total Interest',
      'profitPercent': 'Profit %',
      'monthlyRate': 'Monthly Rate %',
      'yearlyRate': 'Yearly Rate %',
      'totalDays': 'Total Days',
      'totalMonths': 'Total Months',
      'principal': 'Principal',
      'outstanding': 'Outstanding',
      'discount': 'Discount',
      'preCloseAmount': 'Pre-Close Amount',
      'totalCollected': 'Total Collected',
      'oldOutstanding': 'Old Outstanding',
      'newPrincipal': 'New Principal',
      'netDisbursement': 'Net Disbursement',
      'newDailyInstallment': 'New Daily Installment',
      'newProfit': 'New Profit',
    };
    return labels[key] ?? key;
  }

  @override
  void dispose() {
    _input1Controller.dispose();
    _input2Controller.dispose();
    _input3Controller.dispose();
    super.dispose();
  }
}
