import 'package:flutter/material.dart';
import 'package:intl/intl.dart';
import '../database/database_helper.dart';
import '../database/dao/loan_dao.dart';
import '../database/dao/customer_dao.dart';
import '../database/dao/schedule_dao.dart';
import '../models/loan.dart';
import '../models/customer.dart';
import '../models/schedule_entry.dart';
import '../models/collection_entry.dart';
import '../services/calculation_service.dart';
import '../services/schedule_service.dart';
import '../services/sms_service.dart';
import '../services/backup_service.dart';
import '../utils/constants.dart';
import '../widgets/schedule_entry_tile.dart';
import '../widgets/stat_card.dart';

class LoanDetailScreen extends StatefulWidget {
  final int loanId;
  const LoanDetailScreen({super.key, required this.loanId});

  @override
  State<LoanDetailScreen> createState() => _LoanDetailScreenState();
}

class _LoanDetailScreenState extends State<LoanDetailScreen> {
  final _dbHelper = DatabaseHelper();
  late final LoanDao _loanDao;
  late final CustomerDao _customerDao;
  late final ScheduleDao _scheduleDao;
  late final ScheduleService _scheduleService;
  late final SmsService _smsService;
  late final BackupService _backupService;

  Loan? _loan;
  Customer? _customer;
  List<ScheduleEntry> _schedule = [];
  double _collectedTotal = 0;
  bool _isLoading = true;

  @override
  void initState() {
    super.initState();
    _loanDao = LoanDao(_dbHelper);
    _customerDao = CustomerDao(_dbHelper);
    _scheduleDao = ScheduleDao(_dbHelper);
    _scheduleService = ScheduleService(_dbHelper);
    _smsService = SmsService(_dbHelper);
    _backupService = BackupService(_dbHelper);
    _loadData();
  }

  Future<void> _loadData() async {
    setState(() => _isLoading = true);
    final loan = await _loanDao.getById(widget.loanId);
    Customer? customer;
    List<ScheduleEntry> schedule = [];
    double collected = 0;

    if (loan != null) {
      customer = await _customerDao.getById(loan.customerId);
      schedule = await _scheduleDao.getByLoanId(loan.id!);
      collected = await _scheduleDao.getCollectedTotal(loan.id!);
    }

    setState(() {
      _loan = loan;
      _customer = customer;
      _schedule = schedule;
      _collectedTotal = collected;
      _isLoading = false;
    });
  }

  Future<void> _collectPayment(ScheduleEntry entry) async {
    if (_loan == null) return;
    await _scheduleService.recordCollection(
      loanId: _loan!.id!,
      scheduleEntryId: entry.id!,
      amount: entry.expectedAmount,
      collectedDate: DateTime.now(),
    );
    _loadData();
  }

  Future<void> _sendSms() async {
    if (_loan == null || _customer == null) return;
    await _smsService.requestPermissions();
    final message = _smsService.generateReminderMessage(
      _customer!.name,
      _loan!.dailyInstallment,
      0,
    );
    final success = await _smsService.sendSms(
      recipient: _customer!.mobile,
      message: message,
      loanId: _loan!.id,
      customerId: _customer!.id,
    );
    if (mounted) {
      ScaffoldMessenger.of(context).showSnackBar(
        SnackBar(content: Text(success ? 'SMS bhej diya!' : 'SMS bhejne mein error')),
      );
    }
  }

  Future<void> _shareReceipt() async {
    if (_loan == null || _customer == null) return;
    final collection = CollectionEntry(
      loanId: _loan!.id!,
      scheduleEntryId: 0,
      amount: _collectedTotal,
      collectedDate: DateTime.now(),
    );
    final outstanding = _loan!.returnAmount - _collectedTotal;
    final filePath = await _backupService.generatePdfReceipt(
      customer: _customer!,
      loan: _loan!,
      collection: collection,
      outstanding: outstanding,
    );
    await _backupService.sharePdfReceipt(filePath);
  }

  @override
  Widget build(BuildContext context) {
    if (_isLoading) return Scaffold(appBar: AppBar(), body: const Center(child: CircularProgressIndicator()));

    final loan = _loan;
    if (loan == null) {
      return Scaffold(appBar: AppBar(), body: const Center(child: Text('Loan not found')));
    }

    final outstanding = loan.returnAmount - _collectedTotal;
    final completionPercent = CalculationService.calculateCompletion(_collectedTotal, loan.returnAmount);
    final dateFormat = DateFormat('dd MMM yyyy');

    return Scaffold(
      appBar: AppBar(
        title: Text('Loan #${loan.id}'),
        actions: [
          IconButton(icon: const Icon(Icons.message), onPressed: _sendSms, tooltip: 'Send SMS'),
          IconButton(icon: const Icon(Icons.picture_as_pdf), onPressed: _shareReceipt, tooltip: 'Share Receipt'),
          PopupMenuButton(
            itemBuilder: (ctx) => [
              const PopupMenuItem(value: 'preclose', child: Text('Pre-Close')),
              const PopupMenuItem(value: 'cancel', child: Text('Cancel Loan')),
              const PopupMenuItem(value: 'renew', child: Text('Renew Loan')),
            ],
            onSelected: (value) {
              if (value == 'preclose') Navigator.pushNamed(context, '/pre_close', arguments: loan.id).then((_) => _loadData());
              if (value == 'cancel') {
                showDialog(
                  context: context,
                  builder: (ctx) => AlertDialog(
                    title: const Text('Cancel Loan'),
                    content: const TextField(
                      keyboardType: TextInputType.text,
                      decoration: InputDecoration(hintText: 'Reason for cancellation'),
                    ),
                    actions: [
                      TextButton(onPressed: () => Navigator.pop(ctx), child: const Text('Cancel')),
                      TextButton(
                        onPressed: () async {
                          await _scheduleService.cancelLoan(loan.id!, 'User cancelled');
                          if (mounted) Navigator.pop(ctx);
                          _loadData();
                        },
                        child: const Text('Confirm'),
                      ),
                    ],
                  ),
                );
              }
              if (value == 'renew') {
                Navigator.pushNamed(context, '/add_customer').then((_) => _loadData());
              }
            },
          ),
        ],
      ),
      body: ListView(
        padding: const EdgeInsets.all(16),
        children: [
          // Loan info card
          Card(
            child: Padding(
              padding: const EdgeInsets.all(16),
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  if (_customer != null) ...[
                    Text(_customer!.name, style: const TextStyle(fontSize: 18, fontWeight: FontWeight.bold)),
                    Text(_customer!.mobile, style: TextStyle(color: Colors.grey[600])),
                    const Divider(),
                  ],
                  _infoRow('Principal', CalculationService.formatCurrencySimple(loan.principal)),
                  _infoRow('Return Amount', CalculationService.formatCurrencySimple(loan.returnAmount)),
                  _infoRow('Daily Installment', CalculationService.formatCurrencySimple(loan.dailyInstallment)),
                  _infoRow('Total Days', loan.totalDays.toString()),
                  _infoRow('Start Date', dateFormat.format(loan.startDate)),
                  _infoRow('End Date', dateFormat.format(loan.endDate)),
                  _infoRow('Interest Mode', loan.interestMode.name),
                  if (loan.interestRate > 0) _infoRow('Interest Rate', '${loan.interestRate}% monthly'),
                  _infoRow('Status', loan.status.name),
                  if (loan.renewedFrom != null) _infoRow('Renewed From', '#${loan.renewedFrom}'),
                ],
              ),
            ),
          ),
          const SizedBox(height: 16),
          // Progress card
          Row(
            children: [
              Expanded(child: StatCard(title: 'Collected', value: CalculationService.formatCurrencySimple(_collectedTotal), icon: Icons.check_circle, color: AppColors.success)),
              Expanded(child: StatCard(title: 'Outstanding', value: CalculationService.formatCurrencySimple(outstanding), icon: Icons.warning, color: AppColors.overdue)),
            ],
          ),
          const SizedBox(height: 8),
          LinearProgressIndicator(
            value: completionPercent / 100,
            minHeight: 8,
            backgroundColor: Colors.grey[300],
          ),
          Center(child: Text('${completionPercent.toStringAsFixed(1)}% Complete')),
          const SizedBox(height: 16),
          // Schedule
          const Text('Schedule', style: TextStyle(fontSize: 18, fontWeight: FontWeight.bold)),
          const SizedBox(height: 8),
          ..._schedule.map((entry) => ScheduleEntryTile(
                entry: entry,
                onTap: () => Navigator.pushNamed(context, '/collections').then((_) => _loadData()),
                onCollect: entry.status != ScheduleEntryStatus.paid && entry.status != ScheduleEntryStatus.skipped
                    ? () => _collectPayment(entry)
                    : null,
              )),
        ],
      ),
    );
  }

  Widget _infoRow(String label, String value) {
    return Padding(
      padding: const EdgeInsets.symmetric(vertical: 4),
      child: Row(
        mainAxisAlignment: MainAxisAlignment.spaceBetween,
        children: [
          Text(label, style: TextStyle(color: Colors.grey[600])),
          Text(value, style: const TextStyle(fontWeight: FontWeight.w600)),
        ],
      ),
    );
  }
}
