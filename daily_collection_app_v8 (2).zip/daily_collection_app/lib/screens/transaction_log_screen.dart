import 'package:flutter/material.dart';
import 'package:intl/intl.dart';
import '../database/database_helper.dart';
import '../database/dao/transaction_log_dao.dart';
import '../models/transaction_log.dart';
import '../services/backup_service.dart';
import '../utils/constants.dart';

class TransactionLogScreen extends StatefulWidget {
  const TransactionLogScreen({super.key});

  @override
  State<TransactionLogScreen> createState() => _TransactionLogScreenState();
}

class _TransactionLogScreenState extends State<TransactionLogScreen> {
  final _dbHelper = DatabaseHelper();
  late final TransactionLogDao _logDao;
  late final BackupService _backupService;
  List<TransactionLog> _logs = [];
  List<TransactionLog> _filtered = [];
  TransactionType? _filterType;
  bool _isLoading = true;
  final _searchController = TextEditingController();

  @override
  void initState() {
    super.initState();
    _logDao = TransactionLogDao(_dbHelper);
    _backupService = BackupService(_dbHelper);
    _loadLogs();
  }

  Future<void> _loadLogs() async {
    setState(() => _isLoading = true);
    List<TransactionLog> logs;
    if (_filterType == null) {
      logs = await _logDao.getAll();
    } else {
      logs = await _logDao.getByType(_filterType!);
    }
    setState(() {
      _logs = logs;
      _filtered = logs;
      _isLoading = false;
    });
  }

  void _search(String query) {
    setState(() {
      _filtered = _logs.where((l) {
        final q = query.toLowerCase();
        return l.description.toLowerCase().contains(q) || l.entity.toLowerCase().contains(q);
      }).toList();
    });
  }

  Future<void> _exportPdf() async {
    // Export logs as text via share
    final buffer = StringBuffer();
    buffer.writeln('Transaction Log Export - ${DateTime.now()}');
    buffer.writeln('Created by Harish | Harish K Patidar');
    buffer.writeln('---');
    for (final log in _filtered) {
      buffer.writeln('${log.timestamp.toIso8601String()} | ${log.type.name} | ${log.description}');
    }
    await _backupService.saveAndShareCSV(buffer.toString(), 'transaction_log_export.csv');
  }

  @override
  Widget build(BuildContext context) {
    final dateFormat = DateFormat('dd MMM yyyy HH:mm');
    return Scaffold(
      appBar: AppBar(
        title: const Text('Transaction Log'),
        actions: [
          IconButton(icon: const Icon(Icons.picture_as_pdf), onPressed: _exportPdf, tooltip: 'Export'),
        ],
      ),
      body: Column(
        children: [
          SingleChildScrollView(
            scrollDirection: Axis.horizontal,
            padding: const EdgeInsets.all(8),
            child: Row(
              children: [
                FilterChip(label: const Text('All'), selected: _filterType == null, onSelected: (_) { setState(() => _filterType = null); _loadLogs(); }),
                const SizedBox(width: 8),
                ...TransactionType.values.take(6).map((t) => Padding(
                      padding: const EdgeInsets.only(right: 8),
                      child: FilterChip(label: Text(t.name), selected: _filterType == t, onSelected: (_) { setState(() => _filterType = t); _loadLogs(); }),
                    )),
              ],
            ),
          ),
          Padding(
            padding: const EdgeInsets.symmetric(horizontal: 12),
            child: TextField(
              controller: _searchController,
              keyboardType: TextInputType.text,
              decoration: InputDecoration(
                hintText: 'Search logs...',
                prefixIcon: const Icon(Icons.search),
                border: OutlineInputBorder(borderRadius: BorderRadius.circular(8)),
              ),
              onChanged: _search,
            ),
          ),
          const SizedBox(height: 8),
          Expanded(
            child: _isLoading
                ? const Center(child: CircularProgressIndicator())
                : _filtered.isEmpty
                    ? const Center(child: Text('Koi transaction log nahi hai'))
                    : ListView.builder(
                        itemCount: _filtered.length,
                        itemBuilder: (context, index) {
                          final log = _filtered[index];
                          IconData icon;
                          Color color;
                          switch (log.type) {
                            case TransactionType.create:
                              icon = Icons.add_circle; color = AppColors.success; break;
                            case TransactionType.update:
                              icon = Icons.edit; color = AppColors.primary; break;
                            case TransactionType.delete:
                              icon = Icons.delete; color = AppColors.overdue; break;
                            case TransactionType.collect:
                              icon = Icons.payments; color = AppColors.success; break;
                            case TransactionType.preclose:
                              icon = Icons.check_circle; color = AppColors.pending; break;
                            case TransactionType.cancel:
                              icon = Icons.cancel; color = AppColors.overdue; break;
                            case TransactionType.renew:
                              icon = Icons.autorenew; color = AppColors.primary; break;
                            case TransactionType.backup:
                              icon = Icons.backup; color = Colors.grey; break;
                            case TransactionType.restore:
                              icon = Icons.restore; color = Colors.grey; break;
                          }
                          return Card(
                            margin: const EdgeInsets.symmetric(horizontal: 8, vertical: 4),
                            child: ListTile(
                              leading: CircleAvatar(backgroundColor: color.withOpacity(0.15), child: Icon(icon, color: color)),
                              title: Text(log.description, style: const TextStyle(fontSize: 14)),
                              subtitle: Text('${log.type.name} | ${log.entity} | ${dateFormat.format(log.timestamp)}'),
                            ),
                          );
                        },
                      ),
          ),
        ],
      ),
    );
  }

  @override
  void dispose() {
    _searchController.dispose();
    super.dispose();
  }
}
