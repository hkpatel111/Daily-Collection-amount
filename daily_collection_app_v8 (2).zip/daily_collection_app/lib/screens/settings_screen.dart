import 'package:flutter/material.dart';
import '../database/database_helper.dart';
import '../database/dao/settings_dao.dart';
import '../models/settings.dart';
import '../services/backup_service.dart';
import '../utils/constants.dart';

class SettingsScreen extends StatefulWidget {
  const SettingsScreen({super.key});

  @override
  State<SettingsScreen> createState() => _SettingsScreenState();
}

class _SettingsScreenState extends State<SettingsScreen> {
  final _dbHelper = DatabaseHelper();
  late final SettingsDao _settingsDao;
  late final BackupService _backupService;
  AppSettings _settings = const AppSettings();
  bool _isLoading = true;
  final _pinController = TextEditingController();
  final _pinConfirmController = TextEditingController();
  final _formKey = GlobalKey<FormState>();

  @override
  void initState() {
    super.initState();
    _settingsDao = SettingsDao(_dbHelper);
    _backupService = BackupService(_dbHelper);
    _loadSettings();
  }

  Future<void> _loadSettings() async {
    final settings = await _settingsDao.getSettings();
    setState(() {
      _settings = settings;
      _isLoading = false;
    });
  }

  Future<void> _updateSettings(AppSettings newSettings) async {
    await _settingsDao.update(newSettings);
    setState(() => _settings = newSettings);
  }

  Future<void> _createBackup() async {
    try {
      final path = await _backupService.createBackup();
      if (mounted) {
        ScaffoldMessenger.of(context).showSnackBar(
          SnackBar(content: Text('Backup created: $path')),
        );
      }
    } catch (e) {
      if (mounted) {
        ScaffoldMessenger.of(context).showSnackBar(
          SnackBar(content: Text('Backup error: $e')),
        );
      }
    }
  }

  Future<void> _restoreBackup() async {
    try {
      // For simplicity, show a dialog to paste JSON
      final jsonController = TextEditingController();
      final result = await showDialog<bool>(
        context: context,
        builder: (ctx) => AlertDialog(
          title: const Text('Restore Backup'),
          content: TextField(
            controller: jsonController,
            keyboardType: TextInputType.multiline,
            maxLines: 5,
            decoration: const InputDecoration(hintText: 'Paste backup JSON here...'),
          ),
          actions: [
            TextButton(onPressed: () => Navigator.pop(ctx, false), child: const Text('Cancel')),
            TextButton(onPressed: () => Navigator.pop(ctx, true), child: const Text('Restore')),
          ],
        ),
      );
      if (result == true && jsonController.text.isNotEmpty) {
        final success = await _backupService.restoreBackup(jsonController.text);
        if (mounted) {
          ScaffoldMessenger.of(context).showSnackBar(
            SnackBar(content: Text(success ? 'Restore successful!' : 'Restore failed!')),
          );
        }
      }
    } catch (e) {
      if (mounted) {
        ScaffoldMessenger.of(context).showSnackBar(
          SnackBar(content: Text('Restore error: $e')),
        );
      }
    }
  }

  Future<void> _exportCSV(String type) async {
    try {
      String csv;
      String fileName;
      switch (type) {
        case 'customers':
          csv = await _backupService.exportCustomersCSV();
          fileName = 'customers_export.csv';
          break;
        case 'loans':
          csv = await _backupService.exportLoansCSV();
          fileName = 'loans_export.csv';
          break;
        case 'collections':
          csv = await _backupService.exportCollectionsCSV();
          fileName = 'collections_export.csv';
          break;
        default:
          return;
      }
      await _backupService.saveAndShareCSV(csv, fileName);
    } catch (e) {
      if (mounted) {
        ScaffoldMessenger.of(context).showSnackBar(
          SnackBar(content: Text('Export error: $e')),
        );
      }
    }
  }

  void _setupPin() {
    showDialog(
      context: context,
      builder: (ctx) => AlertDialog(
        title: const Text('Set PIN'),
        content: Form(
          key: _formKey,
          child: Column(
            mainAxisSize: MainAxisSize.min,
            children: [
              // CRITICAL FIX: Use TextFormField not TextField for validator
              TextFormField(
                controller: _pinController,
                keyboardType: TextInputType.number,
                obscureText: true,
                decoration: const InputDecoration(labelText: 'Enter 4-digit PIN'),
                validator: (value) {
                  if (value == null || value.isEmpty) return 'PIN daalo';
                  if (value.length != 4) return 'PIN 4 digit ka hona chahiye';
                  if (!RegExp(r'^[0-9]+$').hasMatch(value)) return 'Sirf numbers';
                  return null;
                },
              ),
              const SizedBox(height: 12),
              TextFormField(
                controller: _pinConfirmController,
                keyboardType: TextInputType.number,
                obscureText: true,
                decoration: const InputDecoration(labelText: 'Confirm PIN'),
                validator: (value) {
                  if (value != _pinController.text) return 'PIN match nahi hota';
                  return null;
                },
              ),
            ],
          ),
        ),
        actions: [
          TextButton(
            onPressed: () {
              _pinController.clear();
              _pinConfirmController.clear();
              Navigator.pop(ctx);
            },
            child: const Text('Cancel'),
          ),
          TextButton(
            onPressed: () async {
              if (_formKey.currentState!.validate()) {
                await _updateSettings(_settings.copyWith(
                  appLockEnabled: true,
                  pinHash: _pinController.text,
                ));
                _pinController.clear();
                _pinConfirmController.clear();
                if (mounted) Navigator.pop(ctx);
                ScaffoldMessenger.of(context).showSnackBar(
                  const SnackBar(content: Text('PIN set ho gaya!')),
                );
              }
            },
            child: const Text('Save'),
          ),
        ],
      ),
    );
  }

  @override
  Widget build(BuildContext context) {
    if (_isLoading) return Scaffold(appBar: AppBar(), body: const Center(child: CircularProgressIndicator()));

    return Scaffold(
      appBar: AppBar(title: const Text('Settings')),
      body: ListView(
        padding: const EdgeInsets.all(16),
        children: [
          // SMS Settings
          _sectionTitle('SMS Settings'),
          SwitchListTile(
            title: const Text('Enable SMS'),
            subtitle: const Text('Collection reminders bhejne ke liye'),
            value: _settings.smsEnabled,
            onChanged: (v) => _updateSettings(_settings.copyWith(smsEnabled: v)),
          ),
          const Divider(),

          // WhatsApp Settings
          _sectionTitle('Communication'),
          SwitchListTile(
            title: const Text('Enable WhatsApp Sharing'),
            subtitle: const Text('WhatsApp pe collection reminder bhejna'),
            value: _settings.whatsappEnabled,
            onChanged: (v) => _updateSettings(_settings.copyWith(whatsappEnabled: v)),
          ),
          const Divider(),

          // Interest Display
          _sectionTitle('Interest Display'),
          ListTile(
            title: const Text('Interest Rate Display Mode'),
            subtitle: Text(_settings.interestDisplayMode == InterestDisplayMode.monthly ? 'Monthly' : 'Yearly'),
            trailing: SegmentedButton<InterestDisplayMode>(
              segments: const [
                ButtonSegment(value: InterestDisplayMode.monthly, label: Text('Monthly')),
                ButtonSegment(value: InterestDisplayMode.yearly, label: Text('Yearly')),
              ],
              selected: {_settings.interestDisplayMode},
              onSelectionChanged: (s) => _updateSettings(_settings.copyWith(interestDisplayMode: s.first)),
            ),
          ),
          const Divider(),

          // App Lock
          _sectionTitle('Security'),
          SwitchListTile(
            title: const Text('App Lock (PIN)'),
            subtitle: const Text('App ko PIN se lock karein'),
            value: _settings.appLockEnabled,
            onChanged: (v) {
              if (v) {
                _setupPin();
              } else {
                _updateSettings(_settings.copyWith(appLockEnabled: false, pinHash: ''));
              }
            },
          ),
          if (_settings.appLockEnabled)
            ListTile(
              leading: const Icon(Icons.lock_reset),
              title: const Text('Change PIN'),
              onTap: _setupPin,
            ),
          const Divider(),

          // Backup & Restore
          _sectionTitle('Backup & Restore'),
          ListTile(
            leading: const Icon(Icons.backup, color: AppColors.primary),
            title: const Text('Create Backup'),
            subtitle: const Text('JSON backup file banayein'),
            onTap: _createBackup,
          ),
          ListTile(
            leading: const Icon(Icons.restore, color: AppColors.accent),
            title: const Text('Restore Backup'),
            subtitle: const Text('JSON se data restore karein'),
            onTap: _restoreBackup,
          ),
          SwitchListTile(
            title: const Text('Auto Backup'),
            subtitle: const Text('Automatic daily backup'),
            value: _settings.autoBackup,
            onChanged: (v) => _updateSettings(_settings.copyWith(autoBackup: v)),
          ),
          const Divider(),

          // CSV Export
          _sectionTitle('CSV Export'),
          ListTile(
            leading: const Icon(Icons.people, color: AppColors.success),
            title: const Text('Export Customers CSV'),
            onTap: () => _exportCSV('customers'),
          ),
          ListTile(
            leading: const Icon(Icons.account_balance, color: AppColors.success),
            title: const Text('Export Loans CSV'),
            onTap: () => _exportCSV('loans'),
          ),
          ListTile(
            leading: const Icon(Icons.payments, color: AppColors.success),
            title: const Text('Export Collections CSV'),
            onTap: () => _exportCSV('collections'),
          ),
          const Divider(),

          // About
          _sectionTitle('About'),
          ListTile(
            leading: const Icon(Icons.info, color: AppColors.primary),
            title: const Text(AppConstants.appName),
            subtitle: Text('Version ${AppConstants.appVersion}'),
          ),
          const ListTile(
            leading: Icon(Icons.person, color: AppColors.accent),
            title: Text(AppConstants.createdBy),
            subtitle: Text('Developer: ${AppConstants.developerName}'),
          ),
          const SizedBox(height: 16),
          const Center(
            child: Text(
              AppConstants.createdBy,
              style: TextStyle(fontSize: 14, fontWeight: FontWeight.w600, color: AppColors.primary),
            ),
          ),
          const SizedBox(height: 8),
        ],
      ),
    );
  }

  Widget _sectionTitle(String title) {
    return Padding(
      padding: const EdgeInsets.symmetric(vertical: 8),
      child: Text(title, style: const TextStyle(fontSize: 16, fontWeight: FontWeight.bold, color: AppColors.primary)),
    );
  }

  @override
  void dispose() {
    _pinController.dispose();
    _pinConfirmController.dispose();
    super.dispose();
  }
}
