import 'package:flutter/material.dart';
import '../database/database_helper.dart';
import '../database/dao/loan_dao.dart';
import '../database/dao/schedule_dao.dart';
import '../services/calculation_service.dart';
import '../services/schedule_service.dart';
import '../utils/constants.dart';

class PreCloseScreen extends StatefulWidget {
  final int loanId;
  const PreCloseScreen({super.key, required this.loanId});

  @override
  State<PreCloseScreen> createState() => _PreCloseScreenState();
}

class _PreCloseScreenState extends State<PreCloseScreen> {
  final _dbHelper = DatabaseHelper();
  late final LoanDao _loanDao;
  late final ScheduleDao _scheduleDao;
  late final ScheduleService _scheduleService;

  double _returnAmount = 0;
  double _collectedAmount = 0;
  double _outstanding = 0;
  double _discountPercent = 0;
  double _preCloseAmount = 0;
  bool _isLoading = true;
  final _discountController = TextEditingController(text: '0');

  @override
  void initState() {
    super.initState();
    _loanDao = LoanDao(_dbHelper);
    _scheduleDao = ScheduleDao(_dbHelper);
    _scheduleService = ScheduleService(_dbHelper);
    _loadData();
  }

  Future<void> _loadData() async {
    final loan = await _loanDao.getById(widget.loanId);
    if (loan != null) {
      final collected = await _scheduleDao.getCollectedTotal(loan.id!);
      setState(() {
        _returnAmount = loan.returnAmount;
        _collectedAmount = collected;
        _outstanding = loan.returnAmount - collected;
        _isLoading = false;
        _recalculate();
      });
    }
  }

  void _recalculate() {
    final discount = _outstanding * (_discountPercent / 100);
    setState(() {
      _preCloseAmount = _outstanding - discount;
    });
  }

  Future<void> _confirmPreClose() async {
    final confirmed = await showDialog<bool>(
      context: context,
      builder: (ctx) => AlertDialog(
        title: const Text('Confirm Pre-Close'),
        content: Text('Pre-close amount: ${CalculationService.formatCurrencySimple(_preCloseAmount)}?'),
        actions: [
          TextButton(onPressed: () => Navigator.pop(ctx, false), child: const Text('Cancel')),
          TextButton(onPressed: () => Navigator.pop(ctx, true), child: const Text('Confirm')),
        ],
      ),
    );

    if (confirmed == true) {
      final discount = _outstanding * (_discountPercent / 100);
      await _scheduleService.preCloseLoan(widget.loanId, _preCloseAmount, discount);
      if (mounted) {
        ScaffoldMessenger.of(context).showSnackBar(
          const SnackBar(content: Text('Loan pre-closed successfully!')),
        );
        Navigator.pop(context);
      }
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: const Text('Pre-Close Loan')),
      body: _isLoading
          ? const Center(child: CircularProgressIndicator())
          : ListView(
              padding: const EdgeInsets.all(16),
              children: [
                Card(
                  child: Padding(
                    padding: const EdgeInsets.all(16),
                    child: Column(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: [
                        const Text('Loan Summary', style: TextStyle(fontSize: 18, fontWeight: FontWeight.bold)),
                        const Divider(),
                        _row('Return Amount', CalculationService.formatCurrencySimple(_returnAmount)),
                        _row('Collected So Far', CalculationService.formatCurrencySimple(_collectedAmount)),
                        _row('Outstanding', CalculationService.formatCurrencySimple(_outstanding), color: AppColors.overdue),
                      ],
                    ),
                  ),
                ),
                const SizedBox(height: 16),
                Card(
                  child: Padding(
                    padding: const EdgeInsets.all(16),
                    child: Column(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: [
                        const Text('Pre-Close Calculation', style: TextStyle(fontSize: 18, fontWeight: FontWeight.bold)),
                        const Divider(),
                        TextField(
                          controller: _discountController,
                          keyboardType: TextInputType.number,
                          decoration: const InputDecoration(
                            labelText: 'Discount %',
                            suffixText: '%',
                          ),
                          onChanged: (value) {
                            _discountPercent = double.tryParse(value) ?? 0;
                            _recalculate();
                          },
                        ),
                        const SizedBox(height: 12),
                        _row('Discount Amount', CalculationService.formatCurrencySimple(_outstanding * (_discountPercent / 100))),
                        _row('Pre-Close Amount', CalculationService.formatCurrencySimple(_preCloseAmount), color: AppColors.success, bold: true),
                        _row('Total After Pre-Close', CalculationService.formatCurrencySimple(_collectedAmount + _preCloseAmount)),
                      ],
                    ),
                  ),
                ),
                const SizedBox(height: 16),
                ElevatedButton(
                  onPressed: _confirmPreClose,
                  child: const Text('Pre-Close Loan'),
                ),
              ],
            ),
    );
  }

  Widget _row(String label, String value, {Color? color, bool bold = false}) {
    return Padding(
      padding: const EdgeInsets.symmetric(vertical: 4),
      child: Row(
        mainAxisAlignment: MainAxisAlignment.spaceBetween,
        children: [
          Text(label, style: TextStyle(color: Colors.grey[600])),
          Text(value, style: TextStyle(fontWeight: bold ? FontWeight.bold : FontWeight.w600, color: color)),
        ],
      ),
    );
  }

  @override
  void dispose() {
    _discountController.dispose();
    super.dispose();
  }
}
