import 'package:flutter/material.dart';
import '../database/database_helper.dart';
import '../database/dao/customer_dao.dart';
import '../database/dao/loan_dao.dart';
import '../models/customer.dart';
import '../models/loan.dart';
import '../utils/constants.dart';
import '../services/calculation_service.dart';

class CustomerDetailScreen extends StatefulWidget {
  final int customerId;
  const CustomerDetailScreen({super.key, required this.customerId});

  @override
  State<CustomerDetailScreen> createState() => _CustomerDetailScreenState();
}

class _CustomerDetailScreenState extends State<CustomerDetailScreen> {
  final _dbHelper = DatabaseHelper();
  late final CustomerDao _customerDao;
  late final LoanDao _loanDao;
  Customer? _customer;
  List<Loan> _loans = [];
  bool _isLoading = true;

  @override
  void initState() {
    super.initState();
    _customerDao = CustomerDao(_dbHelper);
    _loanDao = LoanDao(_dbHelper);
    _loadData();
  }

  Future<void> _loadData() async {
    final customer = await _customerDao.getById(widget.customerId);
    final loans = await _loanDao.getByCustomerId(widget.customerId);
    setState(() {
      _customer = customer;
      _loans = loans;
      _isLoading = false;
    });
  }

  Future<void> _archiveToggle() async {
    if (_customer == null) return;
    if (_customer!.isActive) {
      await _customerDao.archive(_customer!.id!);
    } else {
      await _customerDao.unarchive(_customer!.id!);
    }
    _loadData();
  }

  Future<void> _deleteCustomer() async {
    if (_customer == null) return;
    final confirmed = await showDialog<bool>(
      context: context,
      builder: (ctx) => AlertDialog(
        title: const Text('Delete Customer'),
        content: const Text('Kya aap sure ho? Saare loans aur collections bhi delete ho jayenge.'),
        actions: [
          TextButton(onPressed: () => Navigator.pop(ctx, false), child: const Text('Cancel')),
          TextButton(onPressed: () => Navigator.pop(ctx, true), child: const Text('Delete', style: TextStyle(color: Colors.red))),
        ],
      ),
    );
    if (confirmed == true && _customer != null) {
      await _customerDao.delete(_customer!.id!);
      if (mounted) Navigator.pop(context);
    }
  }

  @override
  Widget build(BuildContext context) {
    if (_isLoading) return Scaffold(appBar: AppBar(), body: const Center(child: CircularProgressIndicator()));

    final customer = _customer;
    if (customer == null) {
      return Scaffold(appBar: AppBar(), body: const Center(child: Text('Customer not found')));
    }

    return Scaffold(
      appBar: AppBar(
        title: Text(customer.displayName),
        actions: [
          IconButton(
            icon: const Icon(Icons.edit),
            onPressed: () {
              // Navigate to edit - for now just show snackbar
              ScaffoldMessenger.of(context).showSnackBar(
                const SnackBar(content: Text('Edit feature - customer update')),
              );
            },
          ),
          PopupMenuButton(
            itemBuilder: (ctx) => [
              PopupMenuItem(value: 'archive', child: Text(customer.isActive ? 'Archive' : 'Unarchive')),
              const PopupMenuItem(value: 'delete', child: Text('Delete')),
            ],
            onSelected: (value) {
              if (value == 'archive') _archiveToggle();
              if (value == 'delete') _deleteCustomer();
            },
          ),
        ],
      ),
      body: ListView(
        padding: const EdgeInsets.all(16),
        children: [
          Card(
            child: Padding(
              padding: const EdgeInsets.all(16),
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Row(
                    children: [
                      CircleAvatar(
                        radius: 30,
                        backgroundColor: AppColors.primary.withOpacity(0.15),
                        child: Text(
                          customer.name.isNotEmpty ? customer.name[0].toUpperCase() : '?',
                          style: const TextStyle(fontSize: 24, color: AppColors.primary, fontWeight: FontWeight.bold),
                        ),
                      ),
                      const SizedBox(width: 16),
                      Expanded(
                        child: Column(
                          crossAxisAlignment: CrossAxisAlignment.start,
                          children: [
                            Text(customer.name, style: const TextStyle(fontSize: 20, fontWeight: FontWeight.bold)),
                            if (customer.nickname.isNotEmpty)
                              Text('aka ${customer.nickname}', style: TextStyle(color: Colors.grey[600])),
                          ],
                        ),
                      ),
                    ],
                  ),
                  const Divider(),
                  _infoRow(Icons.phone, 'Mobile', customer.mobile),
                  if (customer.idNumber.isNotEmpty) _infoRow(Icons.credit_card, 'ID', customer.idNumber),
                  _infoRow(Icons.check_circle, 'Status', customer.isActive ? 'Active' : 'Archived'),
                  _infoRow(Icons.date_range, 'Joined', customer.createdAt.toLocal().toString().substring(0, 10)),
                ],
              ),
            ),
          ),
          const SizedBox(height: 16),
          Row(
            mainAxisAlignment: MainAxisAlignment.spaceBetween,
            children: [
              const Text('Loans', style: TextStyle(fontSize: 18, fontWeight: FontWeight.bold)),
              Text('${_loans.length} total', style: TextStyle(color: Colors.grey[600])),
            ],
          ),
          const SizedBox(height: 8),
          if (_loans.isEmpty)
            const Card(child: ListTile(title: Text('Koi loan nahi hai')))
          else
            ..._loans.map((loan) => Card(
                  child: ListTile(
                    title: Text('Loan #${loan.id} - ${loan.interestMode.name}'),
                    subtitle: Text(
                      'Principal: ${CalculationService.formatCurrencySimple(loan.principal)} | Return: ${CalculationService.formatCurrencySimple(loan.returnAmount)}',
                    ),
                    trailing: Chip(
                      label: Text(loan.status.name, style: const TextStyle(fontSize: 11)),
                      backgroundColor: loan.status == LoanStatus.active
                          ? AppColors.primary.withOpacity(0.15)
                          : loan.status == LoanStatus.completed
                              ? AppColors.paid.withOpacity(0.15)
                              : Colors.grey.withOpacity(0.15),
                    ),
                    onTap: () => Navigator.pushNamed(context, '/loan_detail', arguments: loan.id),
                  ),
                )),
        ],
      ),
      floatingActionButton: FloatingActionButton(
        onPressed: () => Navigator.pushNamed(context, '/add_customer'),
        child: const Icon(Icons.add),
      ),
    );
  }

  Widget _infoRow(IconData icon, String label, String value) {
    return Padding(
      padding: const EdgeInsets.symmetric(vertical: 4),
      child: Row(
        children: [
          Icon(icon, size: 20, color: AppColors.textSecondary),
          const SizedBox(width: 8),
          Text('$label: ', style: TextStyle(color: Colors.grey[600])),
          Expanded(child: Text(value, style: const TextStyle(fontWeight: FontWeight.w500))),
        ],
      ),
    );
  }
}
