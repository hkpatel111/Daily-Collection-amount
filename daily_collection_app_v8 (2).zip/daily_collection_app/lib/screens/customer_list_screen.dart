import 'package:flutter/material.dart';
import '../database/database_helper.dart';
import '../database/dao/customer_dao.dart';
import '../models/customer.dart';
import '../utils/constants.dart';

class CustomerListScreen extends StatefulWidget {
  const CustomerListScreen({super.key});

  @override
  State<CustomerListScreen> createState() => _CustomerListScreenState();
}

class _CustomerListScreenState extends State<CustomerListScreen> {
  final _dbHelper = DatabaseHelper();
  late final CustomerDao _customerDao;
  List<Customer> _customers = [];
  List<Customer> _filtered = [];
  bool _showArchive = false;
  bool _isLoading = true;
  final _searchController = TextEditingController();

  @override
  void initState() {
    super.initState();
    _customerDao = CustomerDao(_dbHelper);
    _loadCustomers();
  }

  Future<void> _loadCustomers() async {
    setState(() => _isLoading = true);
    List<Customer> customers;
    if (_showArchive) {
      customers = await _customerDao.getAll();
    } else {
      customers = await _customerDao.getActive();
    }
    setState(() {
      _customers = customers;
      _filtered = customers;
      _isLoading = false;
    });
  }

  void _filterCustomers(String query) {
    setState(() {
      _filtered = _customers.where((c) {
        final q = query.toLowerCase();
        return c.name.toLowerCase().contains(q) ||
            c.mobile.contains(q) ||
            c.nickname.toLowerCase().contains(q);
      }).toList();
    });
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text('Customers'),
        actions: [
          IconButton(
            icon: Icon(_showArchive ? Icons.people : Icons.archive),
            onPressed: () {
              setState(() => _showArchive = !_showArchive);
              _loadCustomers();
            },
            tooltip: _showArchive ? 'Show Active' : 'Show Archive',
          ),
        ],
      ),
      body: Column(
        children: [
          Padding(
            padding: const EdgeInsets.all(12),
            child: TextField(
              controller: _searchController,
              keyboardType: TextInputType.text,
              decoration: InputDecoration(
                hintText: 'Search by name, mobile, nickname...',
                prefixIcon: const Icon(Icons.search),
                border: OutlineInputBorder(
                  borderRadius: BorderRadius.circular(8),
                ),
              ),
              onChanged: _filterCustomers,
            ),
          ),
          Expanded(
            child: _isLoading
                ? const Center(child: CircularProgressIndicator())
                : _filtered.isEmpty
                    ? const Center(child: Text('Koi customer nahi mila'))
                    : ListView.builder(
                        itemCount: _filtered.length,
                        itemBuilder: (context, index) {
                          final customer = _filtered[index];
                          return Card(
                            margin: const EdgeInsets.symmetric(horizontal: 8, vertical: 4),
                            child: ListTile(
                              leading: CircleAvatar(
                                backgroundColor: AppColors.primary.withOpacity(0.15),
                                child: Text(
                                  customer.name.isNotEmpty ? customer.name[0].toUpperCase() : '?',
                                  style: const TextStyle(color: AppColors.primary, fontWeight: FontWeight.bold),
                                ),
                              ),
                              title: Text(customer.displayName, style: const TextStyle(fontWeight: FontWeight.w600)),
                              subtitle: Text(customer.mobile),
                              trailing: !customer.isActive
                                  ? const Icon(Icons.archive, color: Colors.grey)
                                  : const Icon(Icons.chevron_right),
                              onTap: () {
                                Navigator.pushNamed(context, '/customer_detail', arguments: customer.id);
                              },
                            ),
                          );
                        },
                      ),
          ),
        ],
      ),
      floatingActionButton: FloatingActionButton(
        onPressed: () => Navigator.pushNamed(context, '/add_customer'),
        child: const Icon(Icons.person_add),
      ),
    );
  }

  @override
  void dispose() {
    _searchController.dispose();
    super.dispose();
  }
}
