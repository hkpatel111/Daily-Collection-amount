import 'package:flutter/material.dart';
import '../database/database_helper.dart';
import '../database/dao/loan_dao.dart';
import '../models/loan.dart';
import '../utils/constants.dart';
import '../services/calculation_service.dart';
import '../widgets/stat_card.dart';

class LoanListScreen extends StatefulWidget {
  const LoanListScreen({super.key});

  @override
  State<LoanListScreen> createState() => _LoanListScreenState();
}

class _LoanListScreenState extends State<LoanListScreen> {
  final _dbHelper = DatabaseHelper();
  late final LoanDao _loanDao;
  List<Loan> _loans = [];
  List<Loan> _filtered = [];
  LoanStatus? _filterStatus;
  bool _isLoading = true;
  final _searchController = TextEditingController();

  @override
  void initState() {
    super.initState();
    _loanDao = LoanDao(_dbHelper);
    _loadLoans();
  }

  Future<void> _loadLoans() async {
    setState(() => _isLoading = true);
    List<Loan> loans;
    if (_filterStatus == null) {
      loans = await _loanDao.getAll();
    } else {
      loans = await _loanDao.getByStatus(_filterStatus!);
    }
    setState(() {
      _loans = loans;
      _filtered = loans;
      _isLoading = false;
    });
  }

  void _filterLoans(String query) {
    setState(() {
      _filtered = _loans.where((l) {
        final q = query.toLowerCase();
        return l.notes.toLowerCase().contains(q) ||
            l.id.toString().contains(q) ||
            l.customerId.toString().contains(q);
      }).toList();
    });
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: const Text('Loans')),
      body: Column(
        children: [
          // Filter chips
          SingleChildScrollView(
            scrollDirection: Axis.horizontal,
            padding: const EdgeInsets.all(8),
            child: Row(
              children: [
                FilterChip(
                  label: const Text('All'),
                  selected: _filterStatus == null,
                  onSelected: (_) {
                    setState(() => _filterStatus = null);
                    _loadLoans();
                  },
                ),
                const SizedBox(width: 8),
                ...LoanStatus.values.map((status) => Padding(
                      padding: const EdgeInsets.only(right: 8),
                      child: FilterChip(
                        label: Text(status.name),
                        selected: _filterStatus == status,
                        onSelected: (_) {
                          setState(() => _filterStatus = status);
                          _loadLoans();
                        },
                      ),
                    )),
              ],
            ),
          ),
          Padding(
            padding: const EdgeInsets.symmetric(horizontal: 12),
            child: TextField(
              controller: _searchController,
              keyboardType: TextInputType.text,
              decoration: InputDecoration(
                hintText: 'Search loans...',
                prefixIcon: const Icon(Icons.search),
                border: OutlineInputBorder(borderRadius: BorderRadius.circular(8)),
              ),
              onChanged: _filterLoans,
            ),
          ),
          const SizedBox(height: 8),
          Expanded(
            child: _isLoading
                ? const Center(child: CircularProgressIndicator())
                : _filtered.isEmpty
                    ? const Center(child: Text('Koi loan nahi mila'))
                    : ListView.builder(
                        itemCount: _filtered.length,
                        itemBuilder: (context, index) {
                          final loan = _filtered[index];
                          return Card(
                            margin: const EdgeInsets.symmetric(horizontal: 8, vertical: 4),
                            child: ListTile(
                              title: Text('Loan #${loan.id}', style: const TextStyle(fontWeight: FontWeight.w600)),
                              subtitle: Column(
                                crossAxisAlignment: CrossAxisAlignment.start,
                                children: [
                                  Text('Principal: ${CalculationService.formatCurrencySimple(loan.principal)}'),
                                  Text('Return: ${CalculationService.formatCurrencySimple(loan.returnAmount)}'),
                                  Text('Daily: ${CalculationService.formatCurrencySimple(loan.dailyInstallment)} | Days: ${loan.totalDays}'),
                                ],
                              ),
                              trailing: Column(
                                mainAxisAlignment: MainAxisAlignment.center,
                                children: [
                                  LoanStatusBadge(status: loan.status),
                                  const SizedBox(height: 4),
                                  Text(loan.interestMode.name, style: const TextStyle(fontSize: 10, color: Colors.grey)),
                                ],
                              ),
                              onTap: () => Navigator.pushNamed(context, '/loan_detail', arguments: loan.id),
                            ),
                          );
                        },
                      ),
          ),
        ],
      ),
    );
  }

  @override
  void dispose() {
    _searchController.dispose();
    super.dispose();
  }
}
