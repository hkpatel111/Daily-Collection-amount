import 'package:flutter/material.dart';
import '../database/database_helper.dart';
import '../database/dao/settings_dao.dart';
import '../utils/constants.dart';
import '../utils/validators.dart';

class AppLockScreen extends StatefulWidget {
  final bool isSetup;
  const AppLockScreen({super.key, this.isSetup = false});

  @override
  State<AppLockScreen> createState() => _AppLockScreenState();
}

class _AppLockScreenState extends State<AppLockScreen> {
  final _dbHelper = DatabaseHelper();
  late final SettingsDao _settingsDao;
  String _enteredPin = '';
  String _confirmPin = '';
  bool _isConfirmStep = false;
  String? _errorText;

  @override
  void initState() {
    super.initState();
    _settingsDao = SettingsDao(_dbHelper);
  }

  void _onDigitPressed(String digit) {
    if (_isConfirmStep) {
      if (_confirmPin.length < 4) {
        setState(() {
          _confirmPin += digit;
          _errorText = null;
        });
        if (_confirmPin.length == 4) {
          _verifyPin();
        }
      }
    } else {
      if (_enteredPin.length < 4) {
        setState(() {
          _enteredPin += digit;
          _errorText = null;
        });
        if (widget.isSetup && _enteredPin.length == 4) {
          setState(() => _isConfirmStep = true);
        } else if (!widget.isSetup && _enteredPin.length == 4) {
          _verifyPin();
        }
      }
    }
  }

  void _onBackspace() {
    if (_isConfirmStep) {
      setState(() {
        _confirmPin = _confirmPin.substring(0, _confirmPin.length - 1);
        if (_confirmPin.isEmpty) {
          _isConfirmStep = false;
        }
      });
    } else {
      setState(() {
        _enteredPin = _enteredPin.substring(0, _enteredPin.length - 1);
        _errorText = null;
      });
    }
  }

  Future<void> _verifyPin() async {
    if (widget.isSetup) {
      if (_enteredPin == _confirmPin) {
        final settings = await _settingsDao.getSettings();
        await _settingsDao.update(settings.copyWith(
          appLockEnabled: true,
          pinHash: _enteredPin,
        ));
        if (mounted) {
          ScaffoldMessenger.of(context).showSnackBar(
            const SnackBar(content: Text('PIN set ho gaya!')),
          );
          Navigator.pop(context);
        }
      } else {
        setState(() {
          _errorText = 'PIN match nahi hota. Dobara koshish karein.';
          _confirmPin = '';
          _isConfirmStep = false;
          _enteredPin = '';
        });
      }
    } else {
      final settings = await _settingsDao.getSettings();
      if (_enteredPin == settings.pinHash) {
        if (mounted) Navigator.pop(context);
      } else {
        setState(() {
          _errorText = 'Galat PIN. Dobara koshish karein.';
          _enteredPin = '';
        });
      }
    }
  }

  @override
  Widget build(BuildContext context) {
    final pin = _isConfirmStep ? _confirmPin : _enteredPin;
    return Scaffold(
      appBar: AppBar(
        title: Text(widget.isSetup ? 'Set PIN' : 'Enter PIN'),
        automaticallyImplyLeading: false,
      ),
      body: Padding(
        padding: const EdgeInsets.all(24),
        child: Column(
          mainAxisAlignment: MainAxisAlignment.center,
          children: [
            const Icon(Icons.lock, size: 48, color: AppColors.primary),
            const SizedBox(height: 16),
            Text(
              _isConfirmStep ? 'PIN confirm karein' : (widget.isSetup ? 'Naya PIN set karein' : 'App unlock karne ke liye PIN daalo'),
              style: const TextStyle(fontSize: 18, fontWeight: FontWeight.w600),
            ),
            const SizedBox(height: 24),
            // PIN dots
            Row(
              mainAxisAlignment: MainAxisAlignment.center,
              children: List.generate(4, (index) {
                return Container(
                  margin: const EdgeInsets.symmetric(horizontal: 8),
                  width: 20,
                  height: 20,
                  decoration: BoxDecoration(
                    shape: BoxShape.circle,
                    color: index < pin.length ? AppColors.primary : Colors.transparent,
                    border: Border.all(color: AppColors.primary, width: 2),
                  ),
                );
              }),
            ),
            if (_errorText != null) ...[
              const SizedBox(height: 12),
              Text(_errorText!, style: const TextStyle(color: AppColors.overdue, fontSize: 14)),
            ],
            const SizedBox(height: 32),
            // Number pad
            Expanded(
              child: GridView.count(
                crossAxisCount: 3,
                mainAxisSpacing: 12,
                crossAxisSpacing: 12,
                childAspectRatio: 1.5,
                children: [
                  ...List.generate(9, (i) => _numButton('${i + 1}')),
                  _numButton(''),
                  _numButton('0'),
                  _backspaceButton(),
                ],
              ),
            ),
            const Text(
              AppConstants.createdBy,
              style: TextStyle(fontSize: 11, color: Colors.grey),
            ),
          ],
        ),
      ),
    );
  }

  Widget _numButton(String digit) {
    if (digit.isEmpty) return const SizedBox();
    return ElevatedButton(
      onPressed: () => _onDigitPressed(digit),
      style: ElevatedButton.styleFrom(
        shape: const CircleBorder(),
        padding: const EdgeInsets.all(20),
      ),
      child: Text(digit, style: const TextStyle(fontSize: 24)),
    );
  }

  Widget _backspaceButton() {
    return ElevatedButton(
      onPressed: _onBackspace,
      style: ElevatedButton.styleFrom(
        shape: const CircleBorder(),
        padding: const EdgeInsets.all(20),
        backgroundColor: Colors.grey[200],
        foregroundColor: Colors.grey[700],
        elevation: 0,
      ),
      child: const Icon(Icons.backspace),
    );
  }
}
