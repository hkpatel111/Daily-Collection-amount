import 'package:flutter/material.dart';
import 'package:intl/intl.dart';
import '../database/database_helper.dart';
import '../database/dao/schedule_dao.dart';
import '../database/dao/loan_dao.dart';
import '../models/schedule_entry.dart';
import '../services/calculation_service.dart';
import '../services/schedule_service.dart';
import '../utils/constants.dart';
import '../widgets/schedule_entry_tile.dart';

class DailyCollectionScreen extends StatefulWidget {
  const DailyCollectionScreen({super.key});

  @override
  State<DailyCollectionScreen> createState() => _DailyCollectionScreenState();
}

class _DailyCollectionScreenState extends State<DailyCollectionScreen> {
  final _dbHelper = DatabaseHelper();
  late final ScheduleDao _scheduleDao;
  late final LoanDao _loanDao;
  late final ScheduleService _scheduleService;
  List<ScheduleEntry> _todayEntries = [];
  bool _isLoading = true;
  DateTime _selectedDate = DateTime.now();

  @override
  void initState() {
    super.initState();
    _scheduleDao = ScheduleDao(_dbHelper);
    _loanDao = LoanDao(_dbHelper);
    _scheduleService = ScheduleService(_dbHelper);
    _loadData();
  }

  Future<void> _loadData() async {
    setState(() => _isLoading = true);
    await _scheduleService.markOverdue();
    final entries = await _scheduleDao.getByDate(_selectedDate);
    setState(() {
      _todayEntries = entries;
      _isLoading = false;
    });
  }

  Future<void> _bulkMarkPaid() async {
    final count = await _scheduleService.bulkMarkAllPaid(_selectedDate);
    if (mounted) {
      ScaffoldMessenger.of(context).showSnackBar(
        SnackBar(content: Text('$count collections mark kiye gaye')),
      );
      _loadData();
    }
  }

  Future<void> _collectPayment(ScheduleEntry entry) async {
    await _scheduleService.recordCollection(
      loanId: entry.loanId,
      scheduleEntryId: entry.id!,
      amount: entry.expectedAmount,
      collectedDate: DateTime.now(),
    );
    _loadData();
  }

  @override
  Widget build(BuildContext context) {
    final dateFormat = DateFormat('dd MMM yyyy');
    final pendingCount = _todayEntries.where((e) => e.status != ScheduleEntryStatus.paid && e.status != ScheduleEntryStatus.skipped).length;
    final totalExpected = _todayEntries.fold<double>(0, (sum, e) => e.status != ScheduleEntryStatus.paid && e.status != ScheduleEntryStatus.skipped ? sum + e.expectedAmount : sum);

    return Scaffold(
      appBar: AppBar(title: const Text('Daily Collection')),
      body: _isLoading
          ? const Center(child: CircularProgressIndicator())
          : Column(
              children: [
                // Date selector
                ListTile(
                  title: Text(dateFormat.format(_selectedDate)),
                  subtitle: Text('$pendingCount pending | Total: ${CalculationService.formatCurrencySimple(totalExpected)}'),
                  trailing: Row(
                    mainAxisSize: MainAxisSize.min,
                    children: [
                      IconButton(
                        icon: const Icon(Icons.calendar_today),
                        onPressed: () async {
                          final picked = await showDatePicker(
                            context: context,
                            initialDate: _selectedDate,
                            firstDate: DateTime(2020),
                            lastDate: DateTime(2100),
                          );
                          if (picked != null) {
                            setState(() => _selectedDate = picked);
                            _loadData();
                          }
                        },
                      ),
                      IconButton(
                        icon: const Icon(Icons.check_circle, color: AppColors.success),
                        tooltip: 'Mark All Paid',
                        onPressed: pendingCount > 0 ? _bulkMarkPaid : null,
                      ),
                    ],
                  ),
                ),
                Expanded(
                  child: _todayEntries.isEmpty
                      ? const Center(child: Text('Aaj koi collection pending nahi hai'))
                      : ListView.builder(
                          itemCount: _todayEntries.length,
                          itemBuilder: (context, index) {
                            final entry = _todayEntries[index];
                            return ScheduleEntryTile(
                              entry: entry,
                              onCollect: entry.status != ScheduleEntryStatus.paid && entry.status != ScheduleEntryStatus.skipped
                                  ? () => _collectPayment(entry)
                                  : null,
                            );
                          },
                        ),
                ),
              ],
            ),
    );
  }
}
