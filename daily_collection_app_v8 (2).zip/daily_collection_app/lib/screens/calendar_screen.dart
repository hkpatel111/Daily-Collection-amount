import 'package:flutter/material.dart';
import '../database/database_helper.dart';
import '../database/dao/schedule_dao.dart';
import '../models/schedule_entry.dart';
import '../services/calculation_service.dart';
import '../utils/constants.dart';

class CalendarScreen extends StatefulWidget {
  const CalendarScreen({super.key});

  @override
  State<CalendarScreen> createState() => _CalendarScreenState();
}

class _CalendarScreenState extends State<CalendarScreen> {
  final _dbHelper = DatabaseHelper();
  late final ScheduleDao _scheduleDao;
  DateTime _selectedMonth = DateTime(DateTime.now().year, DateTime.now().month, 1);
  Map<int, List<ScheduleEntry>> _entriesByDay = {};
  int? _selectedDay;

  @override
  void initState() {
    super.initState();
    _scheduleDao = ScheduleDao(_dbHelper);
    _loadMonthData();
  }

  Future<void> _loadMonthData() async {
    final start = _selectedMonth;
    final end = DateTime(_selectedMonth.year, _selectedMonth.month + 1, 0, 23, 59, 59);
    final entries = await _scheduleDao.getByDateRange(start, end);

    final byDay = <int, List<ScheduleEntry>>{};
    for (final entry in entries) {
      final day = entry.dueDate.day;
      byDay.putIfAbsent(day, () => []).add(entry);
    }
    setState(() => _entriesByDay = byDay);
  }

  @override
  Widget build(BuildContext context) {
    final firstDay = DateTime(_selectedMonth.year, _selectedMonth.month, 1);
    final daysInMonth = DateTime(_selectedMonth.year, _selectedMonth.month + 1, 0).day;
    final firstWeekday = firstDay.weekday % 7;

    return Scaffold(
      appBar: AppBar(
        title: Text('${_selectedMonth.year}-${_selectedMonth.month.toString().padLeft(2, '0')}'),
        actions: [
          IconButton(
            icon: const Icon(Icons.chevron_left),
            onPressed: () {
              setState(() {
                _selectedMonth = DateTime(_selectedMonth.year, _selectedMonth.month - 1, 1);
                _selectedDay = null;
              });
              _loadMonthData();
            },
          ),
          IconButton(
            icon: const Icon(Icons.chevron_right),
            onPressed: () {
              setState(() {
                _selectedMonth = DateTime(_selectedMonth.year, _selectedMonth.month + 1, 1);
                _selectedDay = null;
              });
              _loadMonthData();
            },
          ),
        ],
      ),
      body: Column(
        children: [
          // Weekday headers
          Row(
            children: ['Sun', 'Mon', 'Tue', 'Wed', 'Thu', 'Fri', 'Sat']
                .map((d) => Expanded(
                      child: Center(
                        child: Padding(
                          padding: const EdgeInsets.all(8),
                          child: Text(d, style: const TextStyle(fontWeight: FontWeight.bold, color: AppColors.primary)),
                        ),
                      ),
                    ))
                .toList(),
          ),
          // Calendar grid
          GridView.builder(
            shrinkWrap: true,
            physics: const NeverScrollableScrollPhysics(),
            gridDelegate: const SliverGridDelegateWithFixedCrossAxisCount(crossAxisCount: 7),
            itemCount: firstWeekday + daysInMonth,
            itemBuilder: (context, index) {
              if (index < firstWeekday) return const SizedBox();
              final day = index - firstWeekday + 1;
              final entries = _entriesByDay[day] ?? [];
              final hasPending = entries.any((e) => e.status != ScheduleEntryStatus.paid && e.status != ScheduleEntryStatus.skipped);
              final allPaid = entries.isNotEmpty && entries.every((e) => e.status == ScheduleEntryStatus.paid);
              final hasOverdue = entries.any((e) => e.isOverdue);

              Color bgColor;
              if (_selectedDay == day) {
                bgColor = AppColors.primary;
              } else if (hasOverdue) {
                bgColor = AppColors.overdue.withOpacity(0.2);
              } else if (allPaid) {
                bgColor = AppColors.paid.withOpacity(0.15);
              } else if (hasPending) {
                bgColor = AppColors.pending.withOpacity(0.15);
              } else {
                bgColor = Colors.transparent;
              }

              return GestureDetector(
                onTap: entries.isEmpty
                    ? null
                    : () {
                        setState(() => _selectedDay = day);
                      },
                child: Container(
                  margin: const EdgeInsets.all(2),
                  decoration: BoxDecoration(
                    color: bgColor,
                    border: Border.all(color: Colors.grey[300]!),
                    borderRadius: BorderRadius.circular(4),
                  ),
                  child: Column(
                    mainAxisAlignment: MainAxisAlignment.center,
                    children: [
                      Text(day.toString(), style: TextStyle(fontWeight: FontWeight.w500, color: _selectedDay == day ? Colors.white : null)),
                      if (entries.isNotEmpty)
                        Text(
                          CalculationService.formatCurrencySimple(entries.fold<double>(0, (s, e) => s + e.expectedAmount)),
                          style: TextStyle(fontSize: 9, color: _selectedDay == day ? Colors.white70 : Colors.grey),
                        ),
                    ],
                  ),
                ),
              );
            },
          ),
          const Divider(),
          // Selected day entries
          if (_selectedDay != null && _entriesByDay[_selectedDay] != null)
            Expanded(
              child: ListView(
                children: _entriesByDay[_selectedDay]!
                    .map((e) => ListTile(
                          title: Text('Loan #${e.loanId} - ${CalculationService.formatCurrencySimple(e.expectedAmount)}'),
                          subtitle: Text(e.status.name),
                          trailing: Icon(
                            e.status == ScheduleEntryStatus.paid ? Icons.check_circle : Icons.schedule,
                            color: e.status == ScheduleEntryStatus.paid ? AppColors.success : AppColors.pending,
                          ),
                        ))
                    .toList(),
              ),
            )
          else
            const Expanded(child: Center(child: Text('Ek din select karein to see details'))),
        ],
      ),
    );
  }
}
