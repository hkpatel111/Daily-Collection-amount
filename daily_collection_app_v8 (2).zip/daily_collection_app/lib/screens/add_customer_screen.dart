import 'package:flutter/material.dart';
import 'package:intl/intl.dart';
import '../database/database_helper.dart';
import '../database/dao/customer_dao.dart';
import '../database/dao/loan_dao.dart';
import '../database/dao/transaction_log_dao.dart';
import '../models/customer.dart';
import '../models/loan.dart';
import '../models/transaction_log.dart';
import '../services/calculation_service.dart';
import '../services/schedule_service.dart';
import '../services/sms_service.dart';
import '../utils/constants.dart';
import '../utils/validators.dart';

class AddCustomerScreen extends StatefulWidget {
  const AddCustomerScreen({super.key});

  @override
  State<AddCustomerScreen> createState() => _AddCustomerScreenState();
}

class _AddCustomerScreenState extends State<AddCustomerScreen> {
  final _dbHelper = DatabaseHelper();
  final _formKey = GlobalKey<FormState>();

  final _nameController = TextEditingController();
  final _mobileController = TextEditingController();
  final _nicknameController = TextEditingController();
  final _idNumberController = TextEditingController();
  final _principalController = TextEditingController(text: '10000');
  final _returnAmountController = TextEditingController(text: '12000');
  final _dailyInstallmentController = TextEditingController(text: '100');
  final _totalDaysController = TextEditingController(text: '120');
  final _interestRateController = TextEditingController(text: '20');
  final _notesController = TextEditingController();

  InterestMode _interestMode = InterestMode.fixedReturn;
  DateTime _startDate = DateTime.now();
  bool _sendSms = false;
  bool _isSaving = false;

  // Live calculation results
  double _calcDailyInstallment = 100;
  double _calcReturnAmount = 12000;
  double _calcProfit = 2000;
  double _calcProfitPercent = 20;

  @override
  void initState() {
    super.initState();
    _recalculate();
  }

  void _recalculate() {
    final principal = double.tryParse(_principalController.text) ?? 0;
    final returnAmount = double.tryParse(_returnAmountController.text) ?? 0;
    final dailyInstallment = double.tryParse(_dailyInstallmentController.text) ?? 0;
    final totalDays = int.tryParse(_totalDaysController.text) ?? 0;
    final interestRate = double.tryParse(_interestRateController.text) ?? 0;

    double calcDaily = 0;
    double calcReturn = 0;
    double calcProfit = 0;
    double calcProfitPercent = 0;

    switch (_interestMode) {
      case InterestMode.fixedReturn:
        if (totalDays > 0) {
          calcDaily = CalculationService.calculateFixedReturn(principal, returnAmount, totalDays);
          calcReturn = returnAmount;
          calcProfit = returnAmount - principal;
          calcProfitPercent = principal > 0 ? (calcProfit / principal) * 100 : 0;
        }
        break;
      case InterestMode.flatMonthly:
        if (totalDays > 0) {
          final result = CalculationService.flatMonthlyCalc(principal, interestRate, totalDays);
          calcDaily = result['dailyInstallment'] ?? 0;
          calcReturn = result['totalReturn'] ?? 0;
          calcProfit = result['profit'] ?? 0;
          calcProfitPercent = result['profitPercent'] ?? 0;
        }
        break;
      case InterestMode.reducingBalance:
        if (totalDays > 0) {
          final result = CalculationService.reducingBalanceCalc(principal, interestRate, totalDays);
          calcDaily = result['emi'] ?? 0;
          calcReturn = result['totalReturn'] ?? 0;
          calcProfit = result['profit'] ?? 0;
          calcProfitPercent = result['profitPercent'] ?? 0;
        }
        break;
    }

    setState(() {
      _calcDailyInstallment = calcDaily;
      _calcReturnAmount = calcReturn;
      _calcProfit = calcProfit;
      _calcProfitPercent = calcProfitPercent;
    });
  }

  Future<void> _saveCustomer() async {
    if (!_formKey.currentState!.validate()) return;

    setState(() => _isSaving = true);

    try {
      final now = DateTime.now();
      final customerDao = CustomerDao(_dbHelper);
      final loanDao = LoanDao(_dbHelper);
      final logDao = TransactionLogDao(_dbHelper);
      final scheduleService = ScheduleService(_dbHelper);

      // Create customer
      final customer = Customer(
        name: _nameController.text.trim(),
        mobile: _mobileController.text.trim(),
        nickname: _nicknameController.text.trim(),
        idNumber: _idNumberController.text.trim(),
        createdAt: now,
        updatedAt: now,
      );
      final customerId = await customerDao.insert(customer);

      // Create loan
      final principal = double.tryParse(_principalController.text) ?? 0;
      final totalDays = int.tryParse(_totalDaysController.text) ?? 120;
      double returnAmount;
      double dailyInstallment;

      switch (_interestMode) {
        case InterestMode.fixedReturn:
          returnAmount = double.tryParse(_returnAmountController.text) ?? 0;
          dailyInstallment = CalculationService.calculateFixedReturn(principal, returnAmount, totalDays);
          break;
        case InterestMode.flatMonthly:
          final rate = double.tryParse(_interestRateController.text) ?? 0;
          final result = CalculationService.flatMonthlyCalc(principal, rate, totalDays);
          returnAmount = result['totalReturn'] ?? 0;
          dailyInstallment = result['dailyInstallment'] ?? 0;
          break;
        case InterestMode.reducingBalance:
          final rate = double.tryParse(_interestRateController.text) ?? 0;
          final result = CalculationService.reducingBalanceCalc(principal, rate, totalDays);
          returnAmount = result['totalReturn'] ?? 0;
          dailyInstallment = result['emi'] ?? 0;
          break;
      }

      final endDate = _startDate.add(Duration(days: totalDays));

      final loan = Loan(
        customerId: customerId,
        principal: principal,
        returnAmount: returnAmount,
        dailyInstallment: dailyInstallment,
        totalDays: totalDays,
        startDate: _startDate,
        endDate: endDate,
        interestMode: _interestMode,
        interestRate: double.tryParse(_interestRateController.text) ?? 0,
        notes: _notesController.text.trim(),
        createdAt: now,
        updatedAt: now,
      );

      final loanId = await loanDao.insert(loan);

      // CRITICAL FIX: loan.id is final, use copyWith to set id
      final loanWithId = loan.copyWith(id: loanId);

      // Generate schedule
      await scheduleService.generateSchedule(loanWithId);

      // Log transaction
      await logDao.insert(TransactionLog(
        type: TransactionType.create,
        entity: 'loan',
        entityId: loanId,
        description: 'Customer ${customer.name} and Loan created. Principal: ${CalculationService.formatCurrencySimple(principal)}',
        timestamp: now,
      ));

      // Send SMS if enabled
      if (_sendSms && _mobileController.text.isNotEmpty) {
        final smsService = SmsService(_dbHelper);
        await smsService.requestPermissions();
        final message = smsService.generateLoanCreatedMessage(
          customer.name,
          principal,
          returnAmount,
          dailyInstallment,
          totalDays,
        );
        await smsService.sendSms(
          recipient: _mobileController.text,
          message: message,
          loanId: loanId,
          customerId: customerId,
        );
      }

      if (mounted) {
        ScaffoldMessenger.of(context).showSnackBar(
          const SnackBar(content: Text('Customer aur Loan create ho gaya!')),
        );
        Navigator.pop(context, true);
      }
    } catch (e) {
      if (mounted) {
        ScaffoldMessenger.of(context).showSnackBar(
          SnackBar(content: Text('Error: $e')),
        );
      }
    } finally {
      if (mounted) setState(() => _isSaving = false);
    }
  }

  @override
  Widget build(BuildContext context) {
    final dateFormat = DateFormat('dd MMM yyyy');
    return Scaffold(
      appBar: AppBar(title: const Text('Add Customer + Loan')),
      body: Form(
        key: _formKey,
        child: ListView(
          padding: const EdgeInsets.all(16),
          children: [
            // Customer Section
            const Text('Customer Details', style: TextStyle(fontSize: 18, fontWeight: FontWeight.bold)),
            const SizedBox(height: 12),
            TextFormField(
              controller: _nameController,
              keyboardType: TextInputType.name,
              decoration: const InputDecoration(
                labelText: 'Full Name *',
                prefixIcon: Icon(Icons.person),
              ),
              validator: Validators.validateName,
            ),
            const SizedBox(height: 12),
            TextFormField(
              controller: _mobileController,
              keyboardType: TextInputType.phone,
              decoration: const InputDecoration(
                labelText: 'Mobile Number *',
                prefixIcon: Icon(Icons.phone),
              ),
              validator: Validators.validateMobile,
            ),
            const SizedBox(height: 12),
            TextFormField(
              controller: _nicknameController,
              keyboardType: TextInputType.text,
              decoration: const InputDecoration(
                labelText: 'Nickname',
                prefixIcon: Icon(Icons.badge),
              ),
            ),
            const SizedBox(height: 12),
            TextFormField(
              controller: _idNumberController,
              keyboardType: TextInputType.text,
              decoration: const InputDecoration(
                labelText: 'ID Number (Aadhar/PAN)',
                prefixIcon: Icon(Icons.credit_card),
              ),
            ),
            const SizedBox(height: 24),

            // Loan Section
            const Text('Loan Details', style: TextStyle(fontSize: 18, fontWeight: FontWeight.bold)),
            const SizedBox(height: 12),

            // Interest Mode Selector
            SegmentedButton<InterestMode>(
              segments: const [
                ButtonSegment(
                  value: InterestMode.fixedReturn,
                  label: Text('Fixed Return', style: TextStyle(fontSize: 11)),
                ),
                ButtonSegment(
                  value: InterestMode.flatMonthly,
                  label: Text('Flat Monthly', style: TextStyle(fontSize: 11)),
                ),
                ButtonSegment(
                  value: InterestMode.reducingBalance,
                  label: Text('EMI', style: TextStyle(fontSize: 11)),
                ),
              ],
              selected: {_interestMode},
              onSelectionChanged: (selection) {
                setState(() => _interestMode = selection.first);
                _recalculate();
              },
            ),
            const SizedBox(height: 12),

            TextFormField(
              controller: _principalController,
              keyboardType: TextInputType.number,
              decoration: const InputDecoration(
                labelText: 'Principal Amount *',
                prefixIcon: Icon(Icons.currency_rupee),
              ),
              validator: Validators.validateAmount,
              onChanged: (_) => _recalculate(),
            ),
            const SizedBox(height: 12),

            // Show different fields based on interest mode
            if (_interestMode == InterestMode.fixedReturn) ...[
              TextFormField(
                controller: _returnAmountController,
                keyboardType: TextInputType.number,
                decoration: const InputDecoration(
                  labelText: 'Return Amount *',
                  prefixIcon: Icon(Icons.account_balance_wallet),
                ),
                validator: (v) => Validators.validateReturnAmount(v, double.tryParse(_principalController.text) ?? 0),
                onChanged: (_) => _recalculate(),
              ),
            ] else ...[
              TextFormField(
                controller: _interestRateController,
                keyboardType: TextInputType.number,
                decoration: const InputDecoration(
                  labelText: 'Monthly Interest Rate (%)',
                  prefixIcon: Icon(Icons.percent),
                ),
                onChanged: (_) => _recalculate(),
              ),
            ],
            const SizedBox(height: 12),

            TextFormField(
              controller: _totalDaysController,
              keyboardType: TextInputType.number,
              decoration: const InputDecoration(
                labelText: 'Total Days *',
                prefixIcon: Icon(Icons.calendar_today),
              ),
              validator: (v) {
                if (v == null || v.isEmpty) return 'Days daalo';
                final days = int.tryParse(v);
                if (days == null || days <= 0) return 'Sahi days daalo';
                return null;
              },
              onChanged: (_) => _recalculate(),
            ),
            const SizedBox(height: 12),

            // Start Date
            ListTile(
              contentPadding: EdgeInsets.zero,
              title: const Text('Start Date'),
              subtitle: Text(dateFormat.format(_startDate)),
              trailing: const Icon(Icons.calendar_month),
              onTap: () async {
                final picked = await showDatePicker(
                  context: context,
                  initialDate: _startDate,
                  firstDate: DateTime(2020),
                  lastDate: DateTime(2100),
                );
                if (picked != null) {
                  setState(() => _startDate = picked);
                }
              },
            ),
            const SizedBox(height: 12),

            TextFormField(
              controller: _notesController,
              keyboardType: TextInputType.multiline,
              maxLines: 2,
              decoration: const InputDecoration(
                labelText: 'Notes',
                prefixIcon: Icon(Icons.note),
              ),
            ),
            const SizedBox(height: 16),

            // Live Calculation Card
            Card(
              color: AppColors.primary.withOpacity(0.08),
              child: Padding(
                padding: const EdgeInsets.all(16),
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Row(
                      children: const [
                        Icon(Icons.calculate, color: AppColors.primary),
                        SizedBox(width: 8),
                        Text('Live Calculation', style: TextStyle(fontWeight: FontWeight.bold, fontSize: 16, color: AppColors.primary)),
                      ],
                    ),
                    const Divider(),
                    _calcRow('Daily Installment', CalculationService.formatCurrencySimple(_calcDailyInstallment)),
                    _calcRow('Return Amount', CalculationService.formatCurrencySimple(_calcReturnAmount)),
                    _calcRow('Profit', CalculationService.formatCurrencySimple(_calcProfit)),
                    _calcRow('Profit %', '${_calcProfitPercent.toStringAsFixed(2)}%'),
                  ],
                ),
              ),
            ),
            const SizedBox(height: 12),

            // SMS toggle
            SwitchListTile(
              title: const Text('Send SMS on creation'),
              subtitle: const Text('Customer ko loan details SMS karein'),
              value: _sendSms,
              onChanged: (v) => setState(() => _sendSms = v),
            ),
            const SizedBox(height: 16),

            // Save Button
            ElevatedButton(
              onPressed: _isSaving ? null : _saveCustomer,
              child: _isSaving
                  ? const SizedBox(height: 20, width: 20, child: CircularProgressIndicator(strokeWidth: 2))
                  : const Text('Save Customer + Loan', style: TextStyle(fontSize: 16)),
            ),
            const SizedBox(height: 8),
            const Center(
              child: Text(
                AppConstants.createdBy,
                style: TextStyle(fontSize: 11, color: Colors.grey),
              ),
            ),
          ],
        ),
      ),
    );
  }

  Widget _calcRow(String label, String value) {
    return Padding(
      padding: const EdgeInsets.symmetric(vertical: 4),
      child: Row(
        mainAxisAlignment: MainAxisAlignment.spaceBetween,
        children: [
          Text(label, style: const TextStyle(color: Colors.grey)),
          Text(value, style: const TextStyle(fontWeight: FontWeight.w600)),
        ],
      ),
    );
  }

  @override
  void dispose() {
    _nameController.dispose();
    _mobileController.dispose();
    _nicknameController.dispose();
    _idNumberController.dispose();
    _principalController.dispose();
    _returnAmountController.dispose();
    _dailyInstallmentController.dispose();
    _totalDaysController.dispose();
    _interestRateController.dispose();
    _notesController.dispose();
    super.dispose();
  }
}
