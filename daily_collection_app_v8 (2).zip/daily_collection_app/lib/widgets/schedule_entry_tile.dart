import 'package:flutter/material.dart';
import 'package:intl/intl.dart';
import '../models/schedule_entry.dart';
import '../utils/constants.dart';
import '../services/calculation_service.dart';

class ScheduleEntryTile extends StatelessWidget {
  final ScheduleEntry entry;
  final VoidCallback? onTap;
  final VoidCallback? onCollect;

  const ScheduleEntryTile({
    super.key,
    required this.entry,
    this.onTap,
    this.onCollect,
  });

  @override
  Widget build(BuildContext context) {
    final dateFormat = DateFormat('dd MMM yyyy');
    Color statusColor;
    IconData statusIcon;
    String statusLabel;

    switch (entry.status) {
      case ScheduleEntryStatus.paid:
        statusColor = AppColors.paid;
        statusIcon = Icons.check_circle;
        statusLabel = 'Paid';
        break;
      case ScheduleEntryStatus.overdue:
        statusColor = AppColors.overdue;
        statusIcon = Icons.error;
        statusLabel = 'Overdue';
        break;
      case ScheduleEntryStatus.pending:
        statusColor = AppColors.pending;
        statusIcon = Icons.schedule;
        statusLabel = 'Pending';
        break;
      case ScheduleEntryStatus.skipped:
        statusColor = Colors.grey;
        statusIcon = Icons.skip_next;
        statusLabel = 'Skipped';
        break;
    }

    return Card(
      margin: const EdgeInsets.symmetric(horizontal: 8, vertical: 4),
      child: ListTile(
        onTap: onTap,
        leading: CircleAvatar(
          backgroundColor: statusColor.withOpacity(0.15),
          child: Icon(statusIcon, color: statusColor),
        ),
        title: Row(
          children: [
            Text(
              'Installment #${entry.installmentNumber}',
              style: const TextStyle(fontWeight: FontWeight.w600),
            ),
            const SizedBox(width: 8),
            if (entry.isOverdue)
              Container(
                padding: const EdgeInsets.symmetric(horizontal: 6, vertical: 2),
                decoration: BoxDecoration(
                  color: AppColors.overdue.withOpacity(0.15),
                  borderRadius: BorderRadius.circular(8),
                ),
                child: const Text(
                  'OVERDUE',
                  style: TextStyle(
                    color: AppColors.overdue,
                    fontSize: 10,
                    fontWeight: FontWeight.bold,
                  ),
                ),
              ),
          ],
        ),
        subtitle: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Text('Due: ${dateFormat.format(entry.dueDate)}'),
            Text(
              '${CalculationService.formatCurrencySimple(entry.expectedAmount)} | $statusLabel',
              style: TextStyle(color: statusColor, fontSize: 12),
            ),
            if (entry.collectedAmount > 0)
              Text(
                'Collected: ${CalculationService.formatCurrencySimple(entry.collectedAmount)}',
                style: const TextStyle(fontSize: 11, color: Colors.grey),
              ),
          ],
        ),
        trailing: entry.status != ScheduleEntryStatus.paid && entry.status != ScheduleEntryStatus.skipped
            ? IconButton(
                icon: const Icon(Icons.payments, color: AppColors.success),
                onPressed: onCollect,
                tooltip: 'Collect',
              )
            : null,
      ),
    );
  }
}
