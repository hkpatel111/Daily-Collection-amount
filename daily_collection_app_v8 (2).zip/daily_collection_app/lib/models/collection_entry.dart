enum PaymentMode { cash, upi, bankTransfer, cheque, other }

class CollectionEntry {
  final int? id;
  final int loanId;
  final int scheduleEntryId;
  final double amount;
  final DateTime collectedDate;
  final PaymentMode paymentMode;
  final String collectedBy;
  final String notes;

  const CollectionEntry({
    this.id,
    required this.loanId,
    required this.scheduleEntryId,
    required this.amount,
    required this.collectedDate,
    this.paymentMode = PaymentMode.cash,
    this.collectedBy = '',
    this.notes = '',
  });

  Map<String, dynamic> toMap() {
    return {
      'id': id,
      'loan_id': loanId,
      'schedule_entry_id': scheduleEntryId,
      'amount': amount,
      'collected_date': collectedDate.toIso8601String(),
      'payment_mode': paymentMode.index,
      'collected_by': collectedBy,
      'notes': notes,
    };
  }

  factory CollectionEntry.fromMap(Map<String, dynamic> map) {
    return CollectionEntry(
      id: map['id'] as int?,
      loanId: map['loan_id'] as int,
      scheduleEntryId: map['schedule_entry_id'] as int,
      amount: (map['amount'] as num?)?.toDouble() ?? 0,
      collectedDate: DateTime.tryParse(map['collected_date'] as String? ?? '') ?? DateTime.now(),
      paymentMode: PaymentMode.values[map['payment_mode'] as int? ?? 0],
      collectedBy: map['collected_by'] as String? ?? '',
      notes: map['notes'] as String? ?? '',
    );
  }

  CollectionEntry copyWith({
    int? id,
    int? loanId,
    int? scheduleEntryId,
    double? amount,
    DateTime? collectedDate,
    PaymentMode? paymentMode,
    String? collectedBy,
    String? notes,
  }) {
    return CollectionEntry(
      id: id ?? this.id,
      loanId: loanId ?? this.loanId,
      scheduleEntryId: scheduleEntryId ?? this.scheduleEntryId,
      amount: amount ?? this.amount,
      collectedDate: collectedDate ?? this.collectedDate,
      paymentMode: paymentMode ?? this.paymentMode,
      collectedBy: collectedBy ?? this.collectedBy,
      notes: notes ?? this.notes,
    );
  }
}
