import 'dart:convert';

class Customer {
  final int? id;
  final String name;
  final String mobile;
  final String nickname;
  final bool isActive;
  final String photoPath;
  final String idNumber;
  final DateTime createdAt;
  final DateTime updatedAt;

  const Customer({
    this.id,
    required this.name,
    required this.mobile,
    this.nickname = '',
    this.isActive = true,
    this.photoPath = '',
    this.idNumber = '',
    required this.createdAt,
    required this.updatedAt,
  });

  Map<String, dynamic> toMap() {
    return {
      'id': id,
      'name': name,
      'mobile': mobile,
      'nickname': nickname,
      'is_active': isActive ? 1 : 0,
      'photo_path': photoPath,
      'id_number': idNumber,
      'created_at': createdAt.toIso8601String(),
      'updated_at': updatedAt.toIso8601String(),
    };
  }

  factory Customer.fromMap(Map<String, dynamic> map) {
    return Customer(
      id: map['id'] as int?,
      name: map['name'] as String? ?? '',
      mobile: map['mobile'] as String? ?? '',
      nickname: map['nickname'] as String? ?? '',
      isActive: (map['is_active'] as int? ?? 1) == 1,
      photoPath: map['photo_path'] as String? ?? '',
      idNumber: map['id_number'] as String? ?? '',
      createdAt: DateTime.tryParse(map['created_at'] as String? ?? '') ?? DateTime.now(),
      updatedAt: DateTime.tryParse(map['updated_at'] as String? ?? '') ?? DateTime.now(),
    );
  }

  Customer copyWith({
    int? id,
    String? name,
    String? mobile,
    String? nickname,
    bool? isActive,
    String? photoPath,
    String? idNumber,
    DateTime? createdAt,
    DateTime? updatedAt,
  }) {
    return Customer(
      id: id ?? this.id,
      name: name ?? this.name,
      mobile: mobile ?? this.mobile,
      nickname: nickname ?? this.nickname,
      isActive: isActive ?? this.isActive,
      photoPath: photoPath ?? this.photoPath,
      idNumber: idNumber ?? this.idNumber,
      createdAt: createdAt ?? this.createdAt,
      updatedAt: updatedAt ?? this.updatedAt,
    );
  }

  String get displayName => nickname.isNotEmpty ? nickname : name;
}
