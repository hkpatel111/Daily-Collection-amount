enum InterestDisplayMode { monthly, yearly }

class AppSettings {
  final bool smsEnabled;
  final bool autoBackup;
  final String backupPath;
  final String currencySymbol;
  final bool appLockEnabled;
  final String pinHash;
  final InterestDisplayMode interestDisplayMode;
  final bool whatsappEnabled;
  final String ownerName;
  final String businessName;

  const AppSettings({
    this.smsEnabled = false,
    this.autoBackup = false,
    this.backupPath = '',
    this.currencySymbol = 'Rs',
    this.appLockEnabled = false,
    this.pinHash = '',
    this.interestDisplayMode = InterestDisplayMode.monthly,
    this.whatsappEnabled = true,
    this.ownerName = 'Harish K Patidar',
    this.businessName = 'Daily Collection',
  });

  Map<String, dynamic> toMap() {
    return {
      'sms_enabled': smsEnabled ? 1 : 0,
      'auto_backup': autoBackup ? 1 : 0,
      'backup_path': backupPath,
      'currency_symbol': currencySymbol,
      'app_lock_enabled': appLockEnabled ? 1 : 0,
      'pin_hash': pinHash,
      'interest_display_mode': interestDisplayMode.index,
      'whatsapp_enabled': whatsappEnabled ? 1 : 0,
      'owner_name': ownerName,
      'business_name': businessName,
    };
  }

  factory AppSettings.fromMap(Map<String, dynamic> map) {
    return AppSettings(
      smsEnabled: (map['sms_enabled'] as int? ?? 0) == 1,
      autoBackup: (map['auto_backup'] as int? ?? 0) == 1,
      backupPath: map['backup_path'] as String? ?? '',
      currencySymbol: map['currency_symbol'] as String? ?? 'Rs',
      appLockEnabled: (map['app_lock_enabled'] as int? ?? 0) == 1,
      pinHash: map['pin_hash'] as String? ?? '',
      interestDisplayMode: InterestDisplayMode.values[map['interest_display_mode'] as int? ?? 0],
      whatsappEnabled: (map['whatsapp_enabled'] as int? ?? 1) == 1,
      ownerName: map['owner_name'] as String? ?? 'Harish K Patidar',
      businessName: map['business_name'] as String? ?? 'Daily Collection',
    );
  }

  AppSettings copyWith({
    bool? smsEnabled,
    bool? autoBackup,
    String? backupPath,
    String? currencySymbol,
    bool? appLockEnabled,
    String? pinHash,
    InterestDisplayMode? interestDisplayMode,
    bool? whatsappEnabled,
    String? ownerName,
    String? businessName,
  }) {
    return AppSettings(
      smsEnabled: smsEnabled ?? this.smsEnabled,
      autoBackup: autoBackup ?? this.autoBackup,
      backupPath: backupPath ?? this.backupPath,
      currencySymbol: currencySymbol ?? this.currencySymbol,
      appLockEnabled: appLockEnabled ?? this.appLockEnabled,
      pinHash: pinHash ?? this.pinHash,
      interestDisplayMode: interestDisplayMode ?? this.interestDisplayMode,
      whatsappEnabled: whatsappEnabled ?? this.whatsappEnabled,
      ownerName: ownerName ?? this.ownerName,
      businessName: businessName ?? this.businessName,
    );
  }
}
