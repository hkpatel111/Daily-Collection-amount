// SmsStatus enum kept in separate file to avoid conflict with telephony package's SmsStatus
enum SmsStatus { sent, failed }

class SmsLog {
  final int? id;
  final int? loanId;
  final int? customerId;
  final String recipient;
  final String message;
  final SmsStatus status;
  final DateTime sentAt;
  final String errorMessage;

  const SmsLog({
    this.id,
    this.loanId,
    this.customerId,
    required this.recipient,
    required this.message,
    required this.status,
    required this.sentAt,
    this.errorMessage = '',
  });

  Map<String, dynamic> toMap() {
    return {
      'id': id,
      'loan_id': loanId,
      'customer_id': customerId,
      'recipient': recipient,
      'message': message,
      'status': status.index,
      'sent_at': sentAt.toIso8601String(),
      'error_message': errorMessage,
    };
  }

  factory SmsLog.fromMap(Map<String, dynamic> map) {
    return SmsLog(
      id: map['id'] as int?,
      loanId: map['loan_id'] as int?,
      customerId: map['customer_id'] as int?,
      recipient: map['recipient'] as String? ?? '',
      message: map['message'] as String? ?? '',
      status: SmsStatus.values[map['status'] as int? ?? 0],
      sentAt: DateTime.tryParse(map['sent_at'] as String? ?? '') ?? DateTime.now(),
      errorMessage: map['error_message'] as String? ?? '',
    );
  }
}
