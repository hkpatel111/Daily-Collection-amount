enum TransactionType { create, update, delete, collect, preclose, cancel, renew, backup, restore }

class TransactionLog {
  final int? id;
  final TransactionType type;
  final String entity;
  final int? entityId;
  final String description;
  final DateTime timestamp;
  final String details;

  const TransactionLog({
    this.id,
    required this.type,
    required this.entity,
    this.entityId,
    required this.description,
    required this.timestamp,
    this.details = '',
  });

  Map<String, dynamic> toMap() {
    return {
      'id': id,
      'type': type.index,
      'entity': entity,
      'entity_id': entityId,
      'description': description,
      'timestamp': timestamp.toIso8601String(),
      'details': details,
    };
  }

  factory TransactionLog.fromMap(Map<String, dynamic> map) {
    return TransactionLog(
      id: map['id'] as int?,
      type: TransactionType.values[map['type'] as int? ?? 0],
      entity: map['entity'] as String? ?? '',
      entityId: map['entity_id'] as int?,
      description: map['description'] as String? ?? '',
      timestamp: DateTime.tryParse(map['timestamp'] as String? ?? '') ?? DateTime.now(),
      details: map['details'] as String? ?? '',
    );
  }
}
