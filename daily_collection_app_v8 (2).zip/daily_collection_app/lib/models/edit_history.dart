enum EditEntityType { customer, loan, collection, schedule, settings }

class EditHistory {
  final int? id;
  final EditEntityType entityType;
  final int entityId;
  final String fieldName;
  final String oldValue;
  final String newValue;
  final DateTime editedAt;
  final String editedBy;

  const EditHistory({
    this.id,
    required this.entityType,
    required this.entityId,
    required this.fieldName,
    required this.oldValue,
    required this.newValue,
    required this.editedAt,
    this.editedBy = 'Owner',
  });

  Map<String, dynamic> toMap() {
    return {
      'id': id,
      'entity_type': entityType.index,
      'entity_id': entityId,
      'field_name': fieldName,
      'old_value': oldValue,
      'new_value': newValue,
      'edited_at': editedAt.toIso8601String(),
      'edited_by': editedBy,
    };
  }

  factory EditHistory.fromMap(Map<String, dynamic> map) {
    return EditHistory(
      id: map['id'] as int?,
      entityType: EditEntityType.values[map['entity_type'] as int? ?? 0],
      entityId: map['entity_id'] as int? ?? 0,
      fieldName: map['field_name'] as String? ?? '',
      oldValue: map['old_value'] as String? ?? '',
      newValue: map['new_value'] as String? ?? '',
      editedAt: DateTime.tryParse(map['edited_at'] as String? ?? '') ?? DateTime.now(),
      editedBy: map['edited_by'] as String? ?? 'Owner',
    );
  }
}
