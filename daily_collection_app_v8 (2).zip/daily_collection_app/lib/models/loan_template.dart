import '../models/loan.dart';

class LoanTemplate {
  final int? id;
  final String name;
  final double principal;
  final double returnAmount;
  final double dailyInstallment;
  final int totalDays;
  final InterestMode interestMode;
  final double interestRate;

  const LoanTemplate({
    this.id,
    required this.name,
    required this.principal,
    required this.returnAmount,
    required this.dailyInstallment,
    required this.totalDays,
    this.interestMode = InterestMode.fixedReturn,
    this.interestRate = 0,
  });

  Map<String, dynamic> toMap() {
    return {
      'id': id,
      'name': name,
      'principal': principal,
      'return_amount': returnAmount,
      'daily_installment': dailyInstallment,
      'total_days': totalDays,
      'interest_mode': interestMode.index,
      'interest_rate': interestRate,
    };
  }

  factory LoanTemplate.fromMap(Map<String, dynamic> map) {
    return LoanTemplate(
      id: map['id'] as int?,
      name: map['name'] as String? ?? '',
      principal: (map['principal'] as num?)?.toDouble() ?? 0,
      returnAmount: (map['return_amount'] as num?)?.toDouble() ?? 0,
      dailyInstallment: (map['daily_installment'] as num?)?.toDouble() ?? 0,
      totalDays: map['total_days'] as int? ?? 0,
      interestMode: InterestMode.values[map['interest_mode'] as int? ?? 0],
      interestRate: (map['interest_rate'] as num?)?.toDouble() ?? 0,
    );
  }
}
