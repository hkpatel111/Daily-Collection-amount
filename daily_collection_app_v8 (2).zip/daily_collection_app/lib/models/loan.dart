enum LoanStatus { active, completed, preclosed, cancelled }

enum InterestMode { fixedReturn, flatMonthly, reducingBalance }

class Loan {
  final int? id;
  final int customerId;
  final double principal;
  final double returnAmount;
  final double dailyInstallment;
  final int totalDays;
  final DateTime startDate;
  final DateTime endDate;
  final LoanStatus status;
  final InterestMode interestMode;
  final double interestRate;
  final String notes;
  final DateTime createdAt;
  final DateTime updatedAt;
  final int? renewedFrom;

  const Loan({
    this.id,
    required this.customerId,
    required this.principal,
    required this.returnAmount,
    required this.dailyInstallment,
    required this.totalDays,
    required this.startDate,
    required this.endDate,
    this.status = LoanStatus.active,
    this.interestMode = InterestMode.fixedReturn,
    this.interestRate = 0,
    this.notes = '',
    required this.createdAt,
    required this.updatedAt,
    this.renewedFrom,
  });

  double get profit => returnAmount - principal;

  Map<String, dynamic> toMap() {
    return {
      'id': id,
      'customer_id': customerId,
      'principal': principal,
      'return_amount': returnAmount,
      'daily_installment': dailyInstallment,
      'total_days': totalDays,
      'start_date': startDate.toIso8601String(),
      'end_date': endDate.toIso8601String(),
      'status': status.index,
      'interest_mode': interestMode.index,
      'interest_rate': interestRate,
      'notes': notes,
      'created_at': createdAt.toIso8601String(),
      'updated_at': updatedAt.toIso8601String(),
      'renewed_from': renewedFrom,
    };
  }

  factory Loan.fromMap(Map<String, dynamic> map) {
    return Loan(
      id: map['id'] as int?,
      customerId: map['customer_id'] as int,
      principal: (map['principal'] as num?)?.toDouble() ?? 0,
      returnAmount: (map['return_amount'] as num?)?.toDouble() ?? 0,
      dailyInstallment: (map['daily_installment'] as num?)?.toDouble() ?? 0,
      totalDays: map['total_days'] as int? ?? 0,
      startDate: DateTime.tryParse(map['start_date'] as String? ?? '') ?? DateTime.now(),
      endDate: DateTime.tryParse(map['end_date'] as String? ?? '') ?? DateTime.now(),
      status: LoanStatus.values[map['status'] as int? ?? 0],
      interestMode: InterestMode.values[map['interest_mode'] as int? ?? 0],
      interestRate: (map['interest_rate'] as num?)?.toDouble() ?? 0,
      notes: map['notes'] as String? ?? '',
      createdAt: DateTime.tryParse(map['created_at'] as String? ?? '') ?? DateTime.now(),
      updatedAt: DateTime.tryParse(map['updated_at'] as String? ?? '') ?? DateTime.now(),
      renewedFrom: map['renewed_from'] as int?,
    );
  }

  Loan copyWith({
    int? id,
    int? customerId,
    double? principal,
    double? returnAmount,
    double? dailyInstallment,
    int? totalDays,
    DateTime? startDate,
    DateTime? endDate,
    LoanStatus? status,
    InterestMode? interestMode,
    double? interestRate,
    String? notes,
    DateTime? createdAt,
    DateTime? updatedAt,
    int? renewedFrom,
  }) {
    return Loan(
      id: id ?? this.id,
      customerId: customerId ?? this.customerId,
      principal: principal ?? this.principal,
      returnAmount: returnAmount ?? this.returnAmount,
      dailyInstallment: dailyInstallment ?? this.dailyInstallment,
      totalDays: totalDays ?? this.totalDays,
      startDate: startDate ?? this.startDate,
      endDate: endDate ?? this.endDate,
      status: status ?? this.status,
      interestMode: interestMode ?? this.interestMode,
      interestRate: interestRate ?? this.interestRate,
      notes: notes ?? this.notes,
      createdAt: createdAt ?? this.createdAt,
      updatedAt: updatedAt ?? this.updatedAt,
      renewedFrom: renewedFrom ?? this.renewedFrom,
    );
  }
}
