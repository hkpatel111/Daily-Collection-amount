enum ScheduleEntryStatus { pending, paid, overdue, skipped }

enum ScheduleSortOrder { byDate, byAmount, byStatus }

class ScheduleEntry {
  final int? id;
  final int loanId;
  final DateTime dueDate;
  final double expectedAmount;
  final double collectedAmount;
  final ScheduleEntryStatus status;
  final int installmentNumber;
  final DateTime? collectedDate;
  final String notes;

  const ScheduleEntry({
    this.id,
    required this.loanId,
    required this.dueDate,
    required this.expectedAmount,
    this.collectedAmount = 0,
    this.status = ScheduleEntryStatus.pending,
    required this.installmentNumber,
    this.collectedDate,
    this.notes = '',
  });

  bool get isOverdue => status == ScheduleEntryStatus.overdue;

  bool get isPaid => status == ScheduleEntryStatus.paid;

  bool get isPending => status == ScheduleEntryStatus.pending;

  double get remainingAmount => expectedAmount - collectedAmount;

  Map<String, dynamic> toMap() {
    return {
      'id': id,
      'loan_id': loanId,
      'due_date': dueDate.toIso8601String(),
      'expected_amount': expectedAmount,
      'collected_amount': collectedAmount,
      'status': status.index,
      'installment_number': installmentNumber,
      'collected_date': collectedDate?.toIso8601String(),
      'notes': notes,
    };
  }

  factory ScheduleEntry.fromMap(Map<String, dynamic> map) {
    return ScheduleEntry(
      id: map['id'] as int?,
      loanId: map['loan_id'] as int,
      dueDate: DateTime.tryParse(map['due_date'] as String? ?? '') ?? DateTime.now(),
      expectedAmount: (map['expected_amount'] as num?)?.toDouble() ?? 0,
      collectedAmount: (map['collected_amount'] as num?)?.toDouble() ?? 0,
      status: ScheduleEntryStatus.values[map['status'] as int? ?? 0],
      installmentNumber: map['installment_number'] as int? ?? 0,
      collectedDate: map['collected_date'] != null
          ? DateTime.tryParse(map['collected_date'] as String)
          : null,
      notes: map['notes'] as String? ?? '',
    );
  }

  ScheduleEntry copyWith({
    int? id,
    int? loanId,
    DateTime? dueDate,
    double? expectedAmount,
    double? collectedAmount,
    ScheduleEntryStatus? status,
    int? installmentNumber,
    DateTime? collectedDate,
    String? notes,
  }) {
    return ScheduleEntry(
      id: id ?? this.id,
      loanId: loanId ?? this.loanId,
      dueDate: dueDate ?? this.dueDate,
      expectedAmount: expectedAmount ?? this.expectedAmount,
      collectedAmount: collectedAmount ?? this.collectedAmount,
      status: status ?? this.status,
      installmentNumber: installmentNumber ?? this.installmentNumber,
      collectedDate: collectedDate ?? this.collectedDate,
      notes: notes ?? this.notes,
    );
  }
}
