import 'package:flutter/material.dart';
import 'screens/dashboard_screen.dart';
import 'screens/customer_list_screen.dart';
import 'screens/add_customer_screen.dart';
import 'screens/customer_detail_screen.dart';
import 'screens/loan_list_screen.dart';
import 'screens/loan_detail_screen.dart';
import 'screens/daily_collection_screen.dart';
import 'screens/collection_list_screen.dart';
import 'screens/pre_close_screen.dart';
import 'screens/calendar_screen.dart';
import 'screens/transaction_log_screen.dart';
import 'screens/search_screen.dart';
import 'screens/sms_history_screen.dart';
import 'screens/edit_history_screen.dart';
import 'screens/settings_screen.dart';
import 'screens/calculators_screen.dart';
import 'screens/app_lock_screen.dart';
import 'utils/constants.dart';

class DailyCollectionApp extends StatelessWidget {
  const DailyCollectionApp({super.key});

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      title: AppConstants.appName,
      debugShowCheckedModeBanner: false,
      theme: _buildLightTheme(),
      darkTheme: _buildDarkTheme(),
      themeMode: ThemeMode.system,
      initialRoute: '/',
      onGenerateRoute: (settings) {
        switch (settings.name) {
          case '/':
            return MaterialPageRoute(builder: (_) => const DashboardScreen());
          case '/customers':
            return MaterialPageRoute(builder: (_) => const CustomerListScreen());
          case '/add_customer':
            return MaterialPageRoute(builder: (_) => const AddCustomerScreen());
          case '/customer_detail':
            final id = settings.arguments as int? ?? 0;
            return MaterialPageRoute(builder: (_) => CustomerDetailScreen(customerId: id));
          case '/loans':
            return MaterialPageRoute(builder: (_) => const LoanListScreen());
          case '/loan_detail':
            final id = settings.arguments as int? ?? 0;
            return MaterialPageRoute(builder: (_) => LoanDetailScreen(loanId: id));
          case '/daily_collection':
            return MaterialPageRoute(builder: (_) => const DailyCollectionScreen());
          case '/collections':
            return MaterialPageRoute(builder: (_) => const CollectionListScreen());
          case '/pre_close':
            final id = settings.arguments as int? ?? 0;
            return MaterialPageRoute(builder: (_) => PreCloseScreen(loanId: id));
          case '/calendar':
            return MaterialPageRoute(builder: (_) => const CalendarScreen());
          case '/transaction_log':
            return MaterialPageRoute(builder: (_) => const TransactionLogScreen());
          case '/search':
            return MaterialPageRoute(builder: (_) => const SearchScreen());
          case '/sms_history':
            return MaterialPageRoute(builder: (_) => const SmsHistoryScreen());
          case '/edit_history':
            return MaterialPageRoute(builder: (_) => const EditHistoryScreen());
          case '/settings':
            return MaterialPageRoute(builder: (_) => const SettingsScreen());
          case '/calculators':
            return MaterialPageRoute(builder: (_) => const CalculatorsScreen());
          case '/app_lock':
            final isSetup = settings.arguments as bool? ?? false;
            return MaterialPageRoute(builder: (_) => AppLockScreen(isSetup: isSetup));
          default:
            return MaterialPageRoute(builder: (_) => const DashboardScreen());
        }
      },
    );
  }

  ThemeData _buildLightTheme() {
    return ThemeData(
      useMaterial3: true,
      primaryColor: AppColors.primary,
      colorScheme: ColorScheme.fromSeed(
        seedColor: AppColors.primary,
        brightness: Brightness.light,
      ),
      scaffoldBackgroundColor: AppColors.background,
      appBarTheme: const AppBarTheme(
        backgroundColor: AppColors.primary,
        foregroundColor: Colors.white,
        elevation: 2,
      ),
      // Use CardThemeData (NOT CardTheme)
      cardTheme: CardThemeData(
        elevation: 2,
        shape: RoundedRectangleBorder(
          borderRadius: BorderRadius.circular(12),
        ),
        color: Colors.white,
      ),
      elevatedButtonTheme: ElevatedButtonThemeData(
        style: ElevatedButton.styleFrom(
          backgroundColor: AppColors.primary,
          foregroundColor: Colors.white,
          shape: RoundedRectangleBorder(
            borderRadius: BorderRadius.circular(8),
          ),
        ),
      ),
      inputDecorationTheme: InputDecorationTheme(
        border: OutlineInputBorder(
          borderRadius: BorderRadius.circular(8),
        ),
        contentPadding: const EdgeInsets.symmetric(horizontal: 12, vertical: 14),
      ),
      floatingActionButtonTheme: const FloatingActionButtonThemeData(
        backgroundColor: AppColors.accent,
        foregroundColor: Colors.white,
      ),
    );
  }

  ThemeData _buildDarkTheme() {
    return ThemeData(
      useMaterial3: true,
      colorScheme: ColorScheme.fromSeed(
        seedColor: AppColors.primary,
        brightness: Brightness.dark,
      ),
      scaffoldBackgroundColor: DarkColors.background,
      appBarTheme: const AppBarTheme(
        backgroundColor: DarkColors.primary,
        foregroundColor: Colors.white,
        elevation: 2,
      ),
      cardTheme: CardThemeData(
        elevation: 2,
        shape: RoundedRectangleBorder(
          borderRadius: BorderRadius.circular(12),
        ),
        color: DarkColors.surface,
      ),
    );
  }
}
