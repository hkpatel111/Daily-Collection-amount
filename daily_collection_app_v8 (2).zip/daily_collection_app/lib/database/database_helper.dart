import 'package:sqflite/sqflite.dart';
import 'package:path/path.dart';
import 'package:path_provider/path_provider.dart';

class DatabaseHelper {
  static final DatabaseHelper _instance = DatabaseHelper._internal();
  factory DatabaseHelper() => _instance;
  DatabaseHelper._internal();

  static const int _dbVersion = 4;
  static const String _dbName = 'daily_collection.db';

  Database? _database;

  Future<Database> get database async {
    if (_database != null) return _database!;
    _database = await _initDatabase();
    return _database!;
  }

  Future<Database> _initDatabase() async {
    final dir = await getApplicationDocumentsDirectory();
    final path = join(dir.path, _dbName);
    return await openDatabase(
      path,
      version: _dbVersion,
      onCreate: _onCreate,
      onUpgrade: _onUpgrade,
    );
  }

  Future<void> _onCreate(Database db, int version) async {
    await db.execute('''
      CREATE TABLE customers (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        name TEXT NOT NULL,
        mobile TEXT NOT NULL,
        nickname TEXT DEFAULT '',
        is_active INTEGER DEFAULT 1,
        photo_path TEXT DEFAULT '',
        id_number TEXT DEFAULT '',
        created_at TEXT NOT NULL,
        updated_at TEXT NOT NULL
      )
    ''');

    await db.execute('''
      CREATE TABLE loans (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        customer_id INTEGER NOT NULL,
        principal REAL NOT NULL,
        return_amount REAL NOT NULL,
        daily_installment REAL NOT NULL,
        total_days INTEGER NOT NULL,
        start_date TEXT NOT NULL,
        end_date TEXT NOT NULL,
        status INTEGER DEFAULT 0,
        interest_mode INTEGER DEFAULT 0,
        interest_rate REAL DEFAULT 0,
        notes TEXT DEFAULT '',
        created_at TEXT NOT NULL,
        updated_at TEXT NOT NULL,
        renewed_from INTEGER,
        FOREIGN KEY (customer_id) REFERENCES customers(id)
      )
    ''');

    await db.execute('''
      CREATE TABLE schedule_entries (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        loan_id INTEGER NOT NULL,
        due_date TEXT NOT NULL,
        expected_amount REAL NOT NULL,
        collected_amount REAL DEFAULT 0,
        status INTEGER DEFAULT 0,
        installment_number INTEGER NOT NULL,
        collected_date TEXT,
        notes TEXT DEFAULT '',
        FOREIGN KEY (loan_id) REFERENCES loans(id)
      )
    ''');

    await db.execute('''
      CREATE TABLE collections (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        loan_id INTEGER NOT NULL,
        schedule_entry_id INTEGER NOT NULL,
        amount REAL NOT NULL,
        collected_date TEXT NOT NULL,
        payment_mode INTEGER DEFAULT 0,
        collected_by TEXT DEFAULT '',
        notes TEXT DEFAULT '',
        FOREIGN KEY (loan_id) REFERENCES loans(id),
        FOREIGN KEY (schedule_entry_id) REFERENCES schedule_entries(id)
      )
    ''');

    await db.execute('''
      CREATE TABLE settings (
        id INTEGER PRIMARY KEY,
        sms_enabled INTEGER DEFAULT 0,
        auto_backup INTEGER DEFAULT 0,
        backup_path TEXT DEFAULT '',
        currency_symbol TEXT DEFAULT 'Rs',
        app_lock_enabled INTEGER DEFAULT 0,
        pin_hash TEXT DEFAULT '',
        interest_display_mode INTEGER DEFAULT 0,
        whatsapp_enabled INTEGER DEFAULT 1,
        owner_name TEXT DEFAULT 'Harish K Patidar',
        business_name TEXT DEFAULT 'Daily Collection'
      )
    ''');

    await db.execute('''
      CREATE TABLE transaction_logs (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        type INTEGER NOT NULL,
        entity TEXT NOT NULL,
        entity_id INTEGER,
        description TEXT NOT NULL,
        timestamp TEXT NOT NULL,
        details TEXT DEFAULT ''
      )
    ''');

    await db.execute('''
      CREATE TABLE sms_logs (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        loan_id INTEGER,
        customer_id INTEGER,
        recipient TEXT NOT NULL,
        message TEXT NOT NULL,
        status INTEGER NOT NULL,
        sent_at TEXT NOT NULL,
        error_message TEXT DEFAULT ''
      )
    ''');

    await db.execute('''
      CREATE TABLE edit_history (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        entity_type INTEGER NOT NULL,
        entity_id INTEGER NOT NULL,
        field_name TEXT NOT NULL,
        old_value TEXT,
        new_value TEXT,
        edited_at TEXT NOT NULL,
        edited_by TEXT DEFAULT 'Owner'
      )
    ''');

    await db.execute('''
      CREATE TABLE loan_templates (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        name TEXT NOT NULL,
        principal REAL NOT NULL,
        return_amount REAL NOT NULL,
        daily_installment REAL NOT NULL,
        total_days INTEGER NOT NULL,
        interest_mode INTEGER DEFAULT 0,
        interest_rate REAL DEFAULT 0
      )
    ''');

    await db.insert('settings', {
      'id': 1,
      'sms_enabled': 0,
      'auto_backup': 0,
      'backup_path': '',
      'currency_symbol': 'Rs',
      'app_lock_enabled': 0,
      'pin_hash': '',
      'interest_display_mode': 0,
      'whatsapp_enabled': 1,
      'owner_name': 'Harish K Patidar',
      'business_name': 'Daily Collection',
    });
  }

  Future<void> _onUpgrade(Database db, int oldVersion, int newVersion) async {
    if (oldVersion < 2) {
      await db.execute('''
        CREATE TABLE IF NOT EXISTS edit_history (
          id INTEGER PRIMARY KEY AUTOINCREMENT,
          entity_type INTEGER NOT NULL,
          entity_id INTEGER NOT NULL,
          field_name TEXT NOT NULL,
          old_value TEXT,
          new_value TEXT,
          edited_at TEXT NOT NULL,
          edited_by TEXT DEFAULT 'Owner'
        )
      ''');
    }
    if (oldVersion < 3) {
      await db.execute('ALTER TABLE loans ADD COLUMN interest_mode INTEGER DEFAULT 0;');
      await db.execute('ALTER TABLE loans ADD COLUMN interest_rate REAL DEFAULT 0;');
      await db.execute('ALTER TABLE loans ADD COLUMN renewed_from INTEGER;');
    }
    if (oldVersion < 4) {
      await db.execute('CREATE TABLE IF NOT EXISTS loan_templates ('
          'id INTEGER PRIMARY KEY AUTOINCREMENT, '
          'name TEXT NOT NULL, '
          'principal REAL NOT NULL, '
          'return_amount REAL NOT NULL, '
          'daily_installment REAL NOT NULL, '
          'total_days INTEGER NOT NULL, '
          'interest_mode INTEGER DEFAULT 0, '
          'interest_rate REAL DEFAULT 0)');
    }
  }

  Future<void> close() async {
    if (_database != null) {
      await _database!.close();
      _database = null;
    }
  }
}
