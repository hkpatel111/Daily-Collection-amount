import '../database_helper.dart';
import '../../models/edit_history.dart';

class EditHistoryDao {
  final DatabaseHelper _dbHelper;
  EditHistoryDao(this._dbHelper);

  Future<int> insert(EditHistory history) async {
    final db = await _dbHelper.database;
    return await db.insert('edit_history', history.toMap());
  }

  Future<List<EditHistory>> getAll() async {
    final db = await _dbHelper.database;
    final maps = await db.query('edit_history', orderBy: 'edited_at DESC');
    return maps.map((m) => EditHistory.fromMap(m)).toList();
  }

  Future<List<EditHistory>> getByEntity(int entityId, EditEntityType type) async {
    final db = await _dbHelper.database;
    final maps = await db.query('edit_history',
        where: 'entity_id = ? AND entity_type = ?',
        whereArgs: [entityId, type.index],
        orderBy: 'edited_at DESC');
    return maps.map((m) => EditHistory.fromMap(m)).toList();
  }

  Future<List<EditHistory>> getByEntityType(EditEntityType type) async {
    final db = await _dbHelper.database;
    final maps = await db.query('edit_history',
        where: 'entity_type = ?',
        whereArgs: [type.index],
        orderBy: 'edited_at DESC');
    return maps.map((m) => EditHistory.fromMap(m)).toList();
  }

  Future<int> delete(int id) async {
    final db = await _dbHelper.database;
    return await db.delete('edit_history', where: 'id = ?', whereArgs: [id]);
  }
}
