import '../database_helper.dart';
import '../../models/collection_entry.dart';

class CollectionDao {
  final DatabaseHelper _dbHelper;
  CollectionDao(this._dbHelper);

  Future<int> insert(CollectionEntry entry) async {
    final db = await _dbHelper.database;
    return await db.insert('collections', entry.toMap());
  }

  Future<CollectionEntry?> getById(int id) async {
    final db = await _dbHelper.database;
    final maps = await db.query('collections', where: 'id = ?', whereArgs: [id]);
    if (maps.isNotEmpty) return CollectionEntry.fromMap(maps.first);
    return null;
  }

  Future<List<CollectionEntry>> getByLoanId(int loanId) async {
    final db = await _dbHelper.database;
    final maps = await db.query('collections', where: 'loan_id = ?', whereArgs: [loanId], orderBy: 'collected_date DESC');
    return maps.map((m) => CollectionEntry.fromMap(m)).toList();
  }

  Future<List<CollectionEntry>> getByDateRange(DateTime start, DateTime end) async {
    final db = await _dbHelper.database;
    final maps = await db.query('collections',
        where: 'collected_date >= ? AND collected_date <= ?',
        whereArgs: [start.toIso8601String(), end.toIso8601String()],
        orderBy: 'collected_date DESC');
    return maps.map((m) => CollectionEntry.fromMap(m)).toList();
  }

  Future<List<CollectionEntry>> getAll() async {
    final db = await _dbHelper.database;
    final maps = await db.query('collections', orderBy: 'collected_date DESC');
    return maps.map((m) => CollectionEntry.fromMap(m)).toList();
  }

  Future<int> update(CollectionEntry entry) async {
    final db = await _dbHelper.database;
    return await db.update('collections', entry.toMap(), where: 'id = ?', whereArgs: [entry.id]);
  }

  Future<int> delete(int id) async {
    final db = await _dbHelper.database;
    return await db.delete('collections', where: 'id = ?', whereArgs: [id]);
  }

  Future<double> getTotalCollected() async {
    final db = await _dbHelper.database;
    final result = await db.rawQuery('SELECT COALESCE(SUM(amount), 0) as total FROM collections');
    return (result.first['total'] as num?)?.toDouble() ?? 0;
  }

  Future<double> getTodayTotal() async {
    final db = await _dbHelper.database;
    final today = DateTime.now().toIso8601String().substring(0, 10);
    final result = await db.rawQuery('SELECT COALESCE(SUM(amount), 0) as total FROM collections WHERE collected_date LIKE ?', ['$today%']);
    return (result.first['total'] as num?)?.toDouble() ?? 0;
  }
}
