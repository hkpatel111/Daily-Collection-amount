import '../database_helper.dart';
import '../../models/loan_template.dart';

class LoanTemplateDao {
  final DatabaseHelper _dbHelper;
  LoanTemplateDao(this._dbHelper);

  Future<int> insert(LoanTemplate template) async {
    final db = await _dbHelper.database;
    return await db.insert('loan_templates', template.toMap());
  }

  Future<LoanTemplate?> getById(int id) async {
    final db = await _dbHelper.database;
    final maps = await db.query('loan_templates', where: 'id = ?', whereArgs: [id]);
    if (maps.isNotEmpty) return LoanTemplate.fromMap(maps.first);
    return null;
  }

  Future<List<LoanTemplate>> getAll() async {
    final db = await _dbHelper.database;
    final maps = await db.query('loan_templates', orderBy: 'name ASC');
    return maps.map((m) => LoanTemplate.fromMap(m)).toList();
  }

  Future<int> update(LoanTemplate template) async {
    final db = await _dbHelper.database;
    return await db.update('loan_templates', template.toMap(), where: 'id = ?', whereArgs: [template.id]);
  }

  Future<int> delete(int id) async {
    final db = await _dbHelper.database;
    return await db.delete('loan_templates', where: 'id = ?', whereArgs: [id]);
  }
}
