import '../database_helper.dart';
import '../../models/loan.dart';

class LoanDao {
  final DatabaseHelper _dbHelper;
  LoanDao(this._dbHelper);

  Future<int> insert(Loan loan) async {
    final db = await _dbHelper.database;
    return await db.insert('loans', loan.toMap());
  }

  Future<Loan?> getById(int id) async {
    final db = await _dbHelper.database;
    final maps = await db.query('loans', where: 'id = ?', whereArgs: [id]);
    if (maps.isNotEmpty) return Loan.fromMap(maps.first);
    return null;
  }

  Future<List<Loan>> getAll() async {
    final db = await _dbHelper.database;
    final maps = await db.query('loans', orderBy: 'created_at DESC');
    return maps.map((m) => Loan.fromMap(m)).toList();
  }

  Future<List<Loan>> getByCustomerId(int customerId) async {
    final db = await _dbHelper.database;
    final maps = await db.query('loans', where: 'customer_id = ?', whereArgs: [customerId], orderBy: 'created_at DESC');
    return maps.map((m) => Loan.fromMap(m)).toList();
  }

  Future<List<Loan>> getByStatus(LoanStatus status) async {
    final db = await _dbHelper.database;
    final maps = await db.query('loans', where: 'status = ?', whereArgs: [status.index], orderBy: 'created_at DESC');
    return maps.map((m) => Loan.fromMap(m)).toList();
  }

  Future<List<Loan>> getActive() async {
    final db = await _dbHelper.database;
    final maps = await db.query('loans', where: 'status = ?', whereArgs: [LoanStatus.active.index], orderBy: 'created_at DESC');
    return maps.map((m) => Loan.fromMap(m)).toList();
  }

  Future<List<Loan>> search(String query) async {
    final db = await _dbHelper.database;
    final maps = await db.rawQuery('''
      SELECT l.* FROM loans l
      INNER JOIN customers c ON l.customer_id = c.id
      WHERE c.name LIKE ? OR c.mobile LIKE ? OR l.notes LIKE ?
      ORDER BY l.created_at DESC
    ''', ['%$query%', '%$query%', '%$query%']);
    return maps.map((m) => Loan.fromMap(m)).toList();
  }

  Future<int> update(Loan loan) async {
    final db = await _dbHelper.database;
    return await db.update('loans', loan.toMap(), where: 'id = ?', whereArgs: [loan.id]);
  }

  Future<int> delete(int id) async {
    final db = await _dbHelper.database;
    return await db.delete('loans', where: 'id = ?', whereArgs: [id]);
  }

  Future<int> count() async {
    final db = await _dbHelper.database;
    final result = await db.rawQuery('SELECT COUNT(*) as count FROM loans WHERE status = 0');
    return result.first['count'] as int? ?? 0;
  }

  Future<double> getTotalOutstanding() async {
    final db = await _dbHelper.database;
    final result = await db.rawQuery('''
      SELECT COALESCE(SUM(return_amount - (
        SELECT COALESCE(SUM(collected_amount), 0) FROM schedule_entries WHERE loan_id = l.id
      )), 0) as total
      FROM loans l WHERE status = 0
    ''');
    return (result.first['total'] as num?)?.toDouble() ?? 0;
  }
}
