import '../database_helper.dart';
import '../../models/transaction_log.dart';

class TransactionLogDao {
  final DatabaseHelper _dbHelper;
  TransactionLogDao(this._dbHelper);

  Future<int> insert(TransactionLog log) async {
    final db = await _dbHelper.database;
    return await db.insert('transaction_logs', log.toMap());
  }

  Future<List<TransactionLog>> getAll() async {
    final db = await _dbHelper.database;
    final maps = await db.query('transaction_logs', orderBy: 'timestamp DESC');
    return maps.map((m) => TransactionLog.fromMap(m)).toList();
  }

  Future<List<TransactionLog>> getByType(TransactionType type) async {
    final db = await _dbHelper.database;
    final maps = await db.query('transaction_logs', where: 'type = ?', whereArgs: [type.index], orderBy: 'timestamp DESC');
    return maps.map((m) => TransactionLog.fromMap(m)).toList();
  }

  Future<List<TransactionLog>> getByEntity(String entity) async {
    final db = await _dbHelper.database;
    final maps = await db.query('transaction_logs', where: 'entity = ?', whereArgs: [entity], orderBy: 'timestamp DESC');
    return maps.map((m) => TransactionLog.fromMap(m)).toList();
  }

  Future<List<TransactionLog>> search(String query) async {
    final db = await _dbHelper.database;
    final maps = await db.query('transaction_logs',
        where: 'description LIKE ? OR entity LIKE ? OR details LIKE ?',
        whereArgs: ['%$query%', '%$query%', '%$query%'],
        orderBy: 'timestamp DESC');
    return maps.map((m) => TransactionLog.fromMap(m)).toList();
  }

  Future<int> delete(int id) async {
    final db = await _dbHelper.database;
    return await db.delete('transaction_logs', where: 'id = ?', whereArgs: [id]);
  }

  Future<int> clearAll() async {
    final db = await _dbHelper.database;
    return await db.delete('transaction_logs', where: '1 = 1');
  }
}
