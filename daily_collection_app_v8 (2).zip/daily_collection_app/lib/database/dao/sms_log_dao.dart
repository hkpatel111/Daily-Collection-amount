import '../database_helper.dart';
import '../../models/sms_log.dart';

class SmsLogDao {
  final DatabaseHelper _dbHelper;
  SmsLogDao(this._dbHelper);

  Future<int> insert(SmsLog log) async {
    final db = await _dbHelper.database;
    return await db.insert('sms_logs', log.toMap());
  }

  Future<List<SmsLog>> getAll() async {
    final db = await _dbHelper.database;
    final maps = await db.query('sms_logs', orderBy: 'sent_at DESC');
    return maps.map((m) => SmsLog.fromMap(m)).toList();
  }

  Future<List<SmsLog>> getByLoanId(int loanId) async {
    final db = await _dbHelper.database;
    final maps = await db.query('sms_logs', where: 'loan_id = ?', whereArgs: [loanId], orderBy: 'sent_at DESC');
    return maps.map((m) => SmsLog.fromMap(m)).toList();
  }

  Future<List<SmsLog>> getByCustomerId(int customerId) async {
    final db = await _dbHelper.database;
    final maps = await db.query('sms_logs', where: 'customer_id = ?', whereArgs: [customerId], orderBy: 'sent_at DESC');
    return maps.map((m) => SmsLog.fromMap(m)).toList();
  }

  Future<int> delete(int id) async {
    final db = await _dbHelper.database;
    return await db.delete('sms_logs', where: 'id = ?', whereArgs: [id]);
  }
}
