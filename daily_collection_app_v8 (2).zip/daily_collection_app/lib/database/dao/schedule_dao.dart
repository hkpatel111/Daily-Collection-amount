import '../database_helper.dart';
import '../../models/schedule_entry.dart';

class ScheduleDao {
  final DatabaseHelper _dbHelper;
  ScheduleDao(this._dbHelper);

  Future<int> insert(ScheduleEntry entry) async {
    final db = await _dbHelper.database;
    return await db.insert('schedule_entries', entry.toMap());
  }

  Future<int> insertAll(List<ScheduleEntry> entries) async {
    final db = await _dbHelper.database;
    int count = 0;
    for (final entry in entries) {
      await db.insert('schedule_entries', entry.toMap());
      count++;
    }
    return count;
  }

  Future<ScheduleEntry?> getById(int id) async {
    final db = await _dbHelper.database;
    final maps = await db.query('schedule_entries', where: 'id = ?', whereArgs: [id]);
    if (maps.isNotEmpty) return ScheduleEntry.fromMap(maps.first);
    return null;
  }

  Future<List<ScheduleEntry>> getByLoanId(int loanId) async {
    final db = await _dbHelper.database;
    final maps = await db.query('schedule_entries', where: 'loan_id = ?', whereArgs: [loanId], orderBy: 'installment_number ASC');
    return maps.map((m) => ScheduleEntry.fromMap(m)).toList();
  }

  Future<List<ScheduleEntry>> getByDateRange(DateTime start, DateTime end) async {
    final db = await _dbHelper.database;
    final maps = await db.query('schedule_entries',
        where: 'due_date >= ? AND due_date <= ?',
        whereArgs: [start.toIso8601String(), end.toIso8601String()],
        orderBy: 'due_date ASC');
    return maps.map((m) => ScheduleEntry.fromMap(m)).toList();
  }

  Future<List<ScheduleEntry>> getByDate(DateTime date) async {
    final db = await _dbHelper.database;
    final dateStr = date.toIso8601String().substring(0, 10);
    final maps = await db.query('schedule_entries',
        where: 'due_date LIKE ? AND status IN (0, 2)',
        whereArgs: ['$dateStr%'],
        orderBy: 'due_date ASC');
    return maps.map((m) => ScheduleEntry.fromMap(m)).toList();
  }

  Future<List<ScheduleEntry>> getPendingByLoanId(int loanId) async {
    final db = await _dbHelper.database;
    final maps = await db.query('schedule_entries',
        where: 'loan_id = ? AND status IN (0, 2)',
        whereArgs: [loanId],
        orderBy: 'installment_number ASC');
    return maps.map((m) => ScheduleEntry.fromMap(m)).toList();
  }

  Future<List<ScheduleEntry>> getPaidByLoanId(int loanId) async {
    final db = await _dbHelper.database;
    final maps = await db.query('schedule_entries',
        where: 'loan_id = ? AND status = ?',
        whereArgs: [loanId, ScheduleEntryStatus.paid.index],
        orderBy: 'installment_number ASC');
    return maps.map((m) => ScheduleEntry.fromMap(m)).toList();
  }

  Future<int> update(ScheduleEntry entry) async {
    final db = await _dbHelper.database;
    return await db.update('schedule_entries', entry.toMap(), where: 'id = ?', whereArgs: [entry.id]);
  }

  Future<int> delete(int id) async {
    final db = await _dbHelper.database;
    return await db.delete('schedule_entries', where: 'id = ?', whereArgs: [id]);
  }

  Future<int> deleteByLoanId(int loanId) async {
    final db = await _dbHelper.database;
    return await db.delete('schedule_entries', where: 'loan_id = ?', whereArgs: [loanId]);
  }

  Future<double> getCollectedTotal(int loanId) async {
    final db = await _dbHelper.database;
    final result = await db.rawQuery('SELECT COALESCE(SUM(collected_amount), 0) as total FROM schedule_entries WHERE loan_id = ? AND status = ?', [loanId, ScheduleEntryStatus.paid.index]);
    return (result.first['total'] as num?)?.toDouble() ?? 0;
  }

  Future<int> getPaidCount(int loanId) async {
    final db = await _dbHelper.database;
    final result = await db.rawQuery('SELECT COUNT(*) as count FROM schedule_entries WHERE loan_id = ? AND status = ?', [loanId, ScheduleEntryStatus.paid.index]);
    return result.first['count'] as int? ?? 0;
  }

  Future<void> markOverdue() async {
    final db = await _dbHelper.database;
    final now = DateTime.now().toIso8601String();
    await db.rawUpdate('UPDATE schedule_entries SET status = ? WHERE status = ? AND due_date < ?', [ScheduleEntryStatus.overdue.index, ScheduleEntryStatus.pending.index, now]);
  }
}
