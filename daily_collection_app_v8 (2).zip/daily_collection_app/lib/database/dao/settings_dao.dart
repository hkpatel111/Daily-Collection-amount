import '../database_helper.dart';
import '../../models/settings.dart';

class SettingsDao {
  final DatabaseHelper _dbHelper;
  SettingsDao(this._dbHelper);

  Future<AppSettings> getSettings() async {
    final db = await _dbHelper.database;
    final maps = await db.query('settings', where: 'id = ?', whereArgs: [1]);
    if (maps.isNotEmpty) return AppSettings.fromMap(maps.first);
    // Insert default settings if not exists
    final defaults = AppSettings();
    await db.insert('settings', {'id': 1, ...defaults.toMap()});
    return defaults;
  }

  Future<int> update(AppSettings settings) async {
    final db = await _dbHelper.database;
    final map = settings.toMap();
    map['id'] = 1;
    return await db.update('settings', map, where: 'id = ?', whereArgs: [1]);
  }
}
