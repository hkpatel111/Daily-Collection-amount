import 'package:flutter/material.dart';
import 'app.dart';
import 'services/notification_service.dart';

void main() async {
  WidgetsFlutterBinding.ensureInitialized();

  // Initialize notification service (dashboard alerts only)
  await NotificationService().init();

  runApp(const DailyCollectionApp());
}
