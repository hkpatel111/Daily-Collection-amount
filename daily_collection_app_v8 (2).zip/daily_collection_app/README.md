# Daily Collection Loan Tracking App v3.0

**Created by Harish** (Developer: Harish K Patidar)

## Overview

A Flutter app to track money given as loans to customers, collected back in daily installments. Supports three loan modes: Fixed Return, Flat Monthly %, and Reducing Balance (EMI).

## Features

- **3 Loan Modes**: Fixed Return, Flat Monthly %, Reducing Balance (EMI)
- **Customer Management**: Add, edit, archive, delete customers
- **Loan Tracking**: Create loans with live interchangeable calculations
- **Daily Collection**: Mark today's collections, bulk mark paid
- **Schedule Management**: Auto-generated daily installment schedule
- **Pre-Close & Renew**: Pre-close with discount, renew loans
- **SMS Integration**: Send collection reminders via SMS (telephony package)
- **WhatsApp Sharing**: Share collection details via WhatsApp
- **PDF Receipts**: Generate and share PDF receipts
- **CSV Export**: Export customers, loans, collections as CSV
- **JSON Backup/Restore**: Full data backup and restore
- **10 Calculators**: All live with monthly/yearly toggle
- **Calendar View**: Monthly calendar with collection overview
- **Transaction Log**: Full audit trail with search and filter
- **Edit History**: Track all edits to records
- **SMS History**: Log of all SMS sent
- **App Lock**: PIN-based security
- **Global Search**: Search across customers and loans

## Loan Model

- Principal: Rs 10,000
- Return Amount: Rs 12,000 (fixed)
- Daily Installment: Rs 100
- Total Days: 120
- Profit: Rs 2,000

## Tech Stack

- Flutter (Material 3)
- SQLite (sqflite) - 9 tables, DB version 4
- Telephony (SMS)
- PDF generation (pdf package)
- Share Plus (file sharing)
- File Picker (backup path selection)
- URL Launcher (WhatsApp)

## Dependencies

```yaml
sqflite: ^2.4.1
path: ^1.9.0
path_provider: ^2.1.4
telephony: ^0.2.0
intl: ^0.19.0
share_plus: ^10.1.2
file_picker: ^8.1.3
url_launcher: ^6.3.1
pdf: ^3.11.1
```

## Getting Started

1. Ensure Flutter SDK is installed (>= 3.10.0)
2. Run `flutter pub get`
3. Run `flutter run`

## Communication

The app uses Hinglish (Hindi in Latin script) for user-facing messages.

## Developer

**Harish K Patidar**

## Version

3.0.0
