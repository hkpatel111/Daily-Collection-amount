import 'dart:io';
import 'package:flutter/material.dart';
import 'package:share_plus/share_plus.dart';
import '../utils/constants.dart';
import '../models/settings.dart';
import '../database/dao/settings_dao.dart';
import '../database/database_helper.dart';
import '../services/backup_service.dart';
import '../services/local_reminder_service.dart';
import '../services/biometric_service.dart';
import '../services/gdrive_service.dart';

class SettingsScreen extends StatefulWidget {
  const SettingsScreen({super.key});

  @override
  State<SettingsScreen> createState() => _SettingsScreenState();
}

class _SettingsScreenState extends State<SettingsScreen> {
  final SettingsDao _settingsDao = SettingsDao();
  final BackupService _backupService = BackupService();
  AppSettings _settings = AppSettings();
  bool _isLoading = true;
  bool _isExporting = false;
  bool _isDriveUploading = false;
  final BiometricService _biometricService = BiometricService();
  final GDriveService _driveService = GDriveService();
  bool? _biometricAvailable;

  @override
  void initState() { super.initState(); _loadSettings(); }

  Future<void> _loadSettings() async {
    _settings = await _settingsDao.getSettings();
    _biometricAvailable = await _biometricService.isBiometricAvailable();
    setState(() => _isLoading = false);
  }

  Future<void> _saveSettings() async {
    await _settingsDao.updateSettings(_settings);
    if (mounted) ScaffoldMessenger.of(context).showSnackBar(const SnackBar(content: Text('Settings saved')));
  }

  Future<void> _exportData() async {
    setState(() => _isExporting = true);
    final result = await _backupService.exportData(customPath: _settings.customBackupPath);
    setState(() => _isExporting = false);
    if (result.success && result.filePath != null) {
      await Share.shareXFiles([XFile(result.filePath!)], subject: 'Daily Collection Backup');
    }
  }

  /// v9: Import without file_picker — user backup file ka path paste karta hai.
  Future<void> _importData() async {
    final pathCtrl = TextEditingController();
    final confirmed = await showDialog<bool>(
      context: context,
      builder: (ctx) => AlertDialog(
        title: const Text('Import Data (Restore)'),
        content: Column(
          mainAxisSize: MainAxisSize.min,
          children: [
            const Text('Backup JSON file ka full path paste karein. Warning: current data replace ho jayega!',
              style: TextStyle(fontSize: 13)),
            const SizedBox(height: 12),
            TextField(
              controller: pathCtrl,
              decoration: const InputDecoration(
                labelText: 'Backup file path',
                border: OutlineInputBorder(),
                hintText: '/storage/emulated/0/Download/backup_123.json',
              ),
            ),
          ],
        ),
        actions: [
          TextButton(onPressed: () => Navigator.pop(ctx, false), child: const Text('Cancel')),
          ElevatedButton(
            style: ElevatedButton.styleFrom(backgroundColor: AppColors.error),
            onPressed: () => Navigator.pop(ctx, true),
            child: const Text('Restore'),
          ),
        ],
      ),
    );
    if (confirmed != true) return;
    final path = pathCtrl.text.trim();
    if (path.isEmpty) return;

    final result = await _backupService.importData(path);
    if (mounted) {
      ScaffoldMessenger.of(context).showSnackBar(SnackBar(content: Text(result.message)));
    }
  }

  Future<void> _exportExcel() async {
    setState(() => _isExporting = true);
    final result = await _backupService.exportExcel();
    setState(() => _isExporting = false);
    if (result.success && result.filePath != null) {
      await Share.shareXFiles([XFile(result.filePath!)], subject: 'Daily Collection Excel');
    } else if (mounted) {
      ScaffoldMessenger.of(context).showSnackBar(SnackBar(content: Text(result.message)));
    }
  }

  Future<void> _exportCsv() async {
    final result = await _backupService.exportCsv();
    if (result.success && result.filePath != null) {
      await Share.shareXFiles([XFile(result.filePath!)], subject: 'Daily Collection CSV');
    }
  }

  @override
  Widget build(BuildContext context) {
    if (_isLoading) return Scaffold(appBar: AppBar(title: const Text('Settings')), body: const Center(child: CircularProgressIndicator()));
    return Scaffold(
      appBar: AppBar(title: const Text('Settings'),
        actions: [TextButton(onPressed: _saveSettings, child: const Text('Save', style: TextStyle(color: Colors.white)))]),
      body: ListView(padding: const EdgeInsets.all(AppConstants.padding), children: [
        _sectionTitle('OWNER'),
        Card(child: Padding(padding: const EdgeInsets.all(16),
          child: TextField(
            decoration: const InputDecoration(labelText: 'Your Name (shown in SMS)', border: OutlineInputBorder()),
            onChanged: (v) => _settings = _settings.copyWith(ownerName: v),
            controller: TextEditingController(text: _settings.ownerName),
          ))),
        const SizedBox(height: 24),
        _sectionTitle('COLLECTION RULES'),
        Card(child: Column(children: [
          ListTile(title: const Text('Grace Period'), subtitle: const Text('Days before overdue interest'),
            trailing: SizedBox(width: 60,
              child: TextField(decoration: const InputDecoration(border: InputBorder.none), textAlign: TextAlign.center, keyboardType: TextInputType.number,
                controller: TextEditingController(text: _settings.gracePeriodDays.toString()),
                onChanged: (v) { final d = int.tryParse(v); if (d != null) _settings = _settings.copyWith(gracePeriodDays: d); }))),
          const Divider(height: 1),
          ListTile(title: const Text('Defaulted Threshold'), subtitle: const Text('Days before loan is defaulted'),
            trailing: SizedBox(width: 60,
              child: TextField(decoration: const InputDecoration(border: InputBorder.none), textAlign: TextAlign.center, keyboardType: TextInputType.number,
                controller: TextEditingController(text: _settings.defaultedThresholdDays.toString()),
                onChanged: (v) { final d = int.tryParse(v); if (d != null) _settings = _settings.copyWith(defaultedThresholdDays: d); }))),
          const Divider(height: 1),
          SwitchListTile(title: const Text('Skip Sundays'), subtitle: const Text('No collection on Sundays'),
            value: _settings.sundayHolidayEnabled,
            onChanged: (v) => setState(() => _settings = _settings.copyWith(sundayHolidayEnabled: v))),
        ])),
        const SizedBox(height: 24),
        _sectionTitle('LATE FEE'),
        Card(child: Column(children: [
          SwitchListTile(title: const Text('Enable Late Fee'), value: _settings.lateFeeEnabled,
            onChanged: (v) => setState(() => _settings = _settings.copyWith(lateFeeEnabled: v))),
          if (_settings.lateFeeEnabled) ...[
            const Divider(height: 1),
            ListTile(title: const Text('Late Fee Per Day (Rs)'),
              trailing: SizedBox(width: 80,
                child: TextField(decoration: const InputDecoration(border: InputBorder.none), textAlign: TextAlign.center, keyboardType: TextInputType.number,
                  controller: TextEditingController(text: _settings.lateFeePerDay.toStringAsFixed(0)),
                  onChanged: (v) { final d = double.tryParse(v); if (d != null) _settings = _settings.copyWith(lateFeePerDay: d); }))),
          ],
        ])),
        const SizedBox(height: 24),
        _sectionTitle('COLLECTION PRIORITY'),
        Card(child: Column(children: [
          RadioListTile<String>(title: const Text('FIFO (Oldest loan first)'), value: 'fifo', groupValue: _settings.collectionPriority,
            onChanged: (v) => setState(() => _settings = _settings.copyWith(collectionPriority: v!))),
          RadioListTile<String>(title: const Text('Manual (Choose each time)'), value: 'manual', groupValue: _settings.collectionPriority,
            onChanged: (v) => setState(() => _settings = _settings.copyWith(collectionPriority: v!))),
          RadioListTile<String>(title: const Text('Equal Split'), value: 'equal', groupValue: _settings.collectionPriority,
            onChanged: (v) => setState(() => _settings = _settings.copyWith(collectionPriority: v!))),
        ])),
        const SizedBox(height: 24),
        _sectionTitle('SMS'),
        Card(child: Column(children: [
          SwitchListTile(title: const Text('SMS Enabled'), value: _settings.smsEnabled,
            onChanged: (v) => setState(() => _settings = _settings.copyWith(smsEnabled: v))),
          if (_settings.smsEnabled) ...[
            const Divider(height: 1),
            SwitchListTile(title: const Text('Payment Confirmation'), value: _settings.smsOnPayment,
              onChanged: (v) => setState(() => _settings = _settings.copyWith(smsOnPayment: v))),
            const Divider(height: 1),
            SwitchListTile(title: const Text('Missed Payment Reminder'), value: _settings.smsOnMissed,
              onChanged: (v) => setState(() => _settings = _settings.copyWith(smsOnMissed: v))),
            const Divider(height: 1),
            SwitchListTile(title: const Text('Loan Completion'), value: _settings.smsOnCompletion,
              onChanged: (v) => setState(() => _settings = _settings.copyWith(smsOnCompletion: v))),
            const Divider(height: 1),
            SwitchListTile(title: const Text('Pre-Closure'), value: _settings.smsOnPreclosure,
              onChanged: (v) => setState(() => _settings = _settings.copyWith(smsOnPreclosure: v))),
            const Divider(height: 1),
            SwitchListTile(title: const Text('Auto-Send (no prompt)'), value: _settings.smsAutoSend,
              onChanged: (v) => setState(() => _settings = _settings.copyWith(smsAutoSend: v))),
            const Divider(height: 1),
            ListTile(title: const Text('Auto-Reminder After (days)'), subtitle: const Text('Send reminder after X days missed'),
              trailing: SizedBox(width: 60,
                child: TextField(decoration: const InputDecoration(border: InputBorder.none), textAlign: TextAlign.center, keyboardType: TextInputType.number,
                  controller: TextEditingController(text: _settings.autoReminderDays.toString()),
                  onChanged: (v) { final d = int.tryParse(v); if (d != null) _settings = _settings.copyWith(autoReminderDays: d); }))),
          ],
        ])),
        const SizedBox(height: 24),
        _sectionTitle('APPEARANCE'),
        Card(child: Column(children: [
          SwitchListTile(title: const Text('Dark Mode'), value: _settings.darkMode,
            onChanged: (v) { setState(() => _settings = _settings.copyWith(darkMode: v)); _saveSettings(); }),
          const Divider(height: 1),
          ListTile(title: const Text('Theme Color'),
            trailing: DropdownButton<String>(
              value: _settings.themeColor,
              items: ThemeColors.colors.keys.map((k) => DropdownMenuItem(value: k, child: Row(children: [
                Container(width: 16, height: 16, color: ThemeColors.colors[k]),
                const SizedBox(width: 8), Text(k[0].toUpperCase() + k.substring(1)),
              ]))).toList(),
              onChanged: (v) { if (v != null) { setState(() => _settings = _settings.copyWith(themeColor: v)); _saveSettings(); } },
            )),
        ])),
        const SizedBox(height: 24),
        _sectionTitle('REMINDERS'),
        Card(child: Column(children: [
          SwitchListTile(title: const Text('Morning Collection Reminder'),
            subtitle: const Text('Roz subah pending collections ka notification'),
            value: _settings.morningReminderEnabled,
            onChanged: (v) {
              setState(() => _settings = _settings.copyWith(morningReminderEnabled: v));
              _saveSettings();
              LocalReminderService().syncReminderFromSettings();
            }),
          if (_settings.morningReminderEnabled) ...[
            const Divider(height: 1),
            ListTile(title: const Text('Reminder Time (hour)'),
              subtitle: const Text('Kitne baje notification aaye (0-23)'),
              trailing: SizedBox(width: 60,
                child: TextField(decoration: const InputDecoration(border: InputBorder.none), textAlign: TextAlign.center, keyboardType: TextInputType.number,
                  controller: TextEditingController(text: _settings.reminderHour.toString()),
                  onChanged: (v) { final d = int.tryParse(v); if (d != null && d >= 0 && d <= 23) { _settings = _settings.copyWith(reminderHour: d); _saveSettings(); LocalReminderService().syncReminderFromSettings(); } }))),
          ],
        ])),
        const SizedBox(height: 24),
        _sectionTitle('SECURITY'),
        Card(child: Column(children: [
          SwitchListTile(title: const Text('App Lock (PIN)'), subtitle: const Text('Require PIN to open app'),
            value: _settings.appLockEnabled,
            onChanged: (v) async {
              if (v) {
                final pin = await _showPinDialog();
                if (pin != null && pin.length == 4) {
                  setState(() => _settings = _settings.copyWith(appLockEnabled: true, appPin: pin));
                  _saveSettings();
                }
              } else {
                setState(() => _settings = _settings.copyWith(appLockEnabled: false, appPin: '', biometricEnabled: false));
                _saveSettings();
              }
            }),
          const Divider(height: 1),
          SwitchListTile(
            title: const Text('Fingerprint Unlock'),
            subtitle: Text(_biometricAvailable == false
              ? 'Device mein fingerprint support nahi hai'
              : 'App lock ke saath fingerprint se bhi unlock kar sakte hain'),
            value: _settings.biometricEnabled && (_biometricAvailable ?? false) && _settings.appLockEnabled,
            onChanged: (_biometricAvailable ?? false) && _settings.appLockEnabled
              ? (v) async {
                  if (v) {
                    // Pehle verify karo, phir enable
                    final ok = await _biometricService.authenticate(reason: 'Fingerprint enable karne ke liye verify karein');
                    if (!ok) {
                      if (mounted) {
                        ScaffoldMessenger.of(context).showSnackBar(
                          const SnackBar(content: Text('Verification fail — fingerprint enable nahi hua')));
                      }
                      return;
                    }
                  }
                  setState(() => _settings = _settings.copyWith(biometricEnabled: v));
                  _saveSettings();
                }
              : null,
          ),
        ])),
        const SizedBox(height: 24),
        _sectionTitle('CUSTOM PATHS (v9.1)'),
        Card(child: Column(children: [
          ListTile(
            leading: const Icon(Icons.format_quote, color: AppColors.warning),
            title: const Text('Quotes File Path'),
            subtitle: Text(_settings.quotesCustomPath.isEmpty
              ? 'Default: app documents folder'
              : _settings.quotesCustomPath),
            trailing: TextButton(
              child: const Text('Set Path'),
              onPressed: () async {
                final result = await _showPathDialog(
                  title: 'Quotes File Path',
                  current: _settings.quotesCustomPath,
                  hint: '/storage/emulated/0/Documents',
                  helper: 'funny_quotes.txt isi folder mein milega (khud edit kar sakte ho)',
                );
                if (result != null) {
                  setState(() => _settings = _settings.copyWith(quotesCustomPath: result));
                  _saveSettings();
                }
              },
            ),
          ),
        ])),
        const SizedBox(height: 24),
        _sectionTitle('GOOGLE DRIVE BACKUP (v9.1)'),
        Card(child: Column(children: [
          SwitchListTile(
            title: const Text('Google Drive Backup Enabled'),
            subtitle: const Text('Backup file Drive par upload hogi (SameTopic folder)'),
            value: _settings.gDriveBackupEnabled,
            onChanged: (v) { setState(() => _settings = _settings.copyWith(gDriveBackupEnabled: v)); _saveSettings(); },
          ),
          if (_settings.gDriveBackupEnabled) ...[
            const Divider(height: 1),
            ListTile(
              leading: _isDriveUploading
                ? const SizedBox(width: 24, height: 24, child: CircularProgressIndicator(strokeWidth: 2))
                : const Icon(Icons.cloud_upload, color: AppColors.primary),
              title: const Text('Backup Now (Drive)'),
              subtitle: const Text('JSON backup banake Drive par daalo'),
              onTap: _isDriveUploading ? null : _uploadToDrive,
            ),
          ],
        ])),
        const SizedBox(height: 24),
        _sectionTitle('AUTO-BACKUP'),
        Card(child: Column(children: [
          ListTile(title: const Text('Auto-Backup Frequency (days)'),
            trailing: SizedBox(width: 60,
              child: TextField(decoration: const InputDecoration(border: InputBorder.none), textAlign: TextAlign.center, keyboardType: TextInputType.number,
                controller: TextEditingController(text: _settings.autoBackupDays.toString()),
                onChanged: (v) { final d = int.tryParse(v); if (d != null && d > 0) _settings = _settings.copyWith(autoBackupDays: d); }))),
        ])),
        const SizedBox(height: 24),
        _sectionTitle('DATA & BACKUP'),
        Card(child: Column(children: [
          ListTile(leading: _isExporting
            ? const SizedBox(width: 24, height: 24, child: CircularProgressIndicator(strokeWidth: 2))
            : const Icon(Icons.backup, color: AppColors.primary),
            title: const Text('Export Data (Backup)'), subtitle: const Text('Save as JSON'),
            onTap: _isExporting ? null : _exportData),
          const Divider(height: 1),
          ListTile(leading: const Icon(Icons.restore, color: AppColors.primary),
            title: const Text('Import Data (Restore)'),
            subtitle: const Text('Backup JSON file ka path paste karke restore karein'),
            onTap: _importData),
          const Divider(height: 1),
          ListTile(leading: const Icon(Icons.table_chart, color: AppColors.success),
            title: const Text('Export as Excel (.xlsx)'),
            subtitle: const Text('Loans + Collections 2 sheets mein'),
            onTap: _isExporting ? null : _exportExcel),
          const Divider(height: 1),
          ListTile(leading: const Icon(Icons.article, color: AppColors.success),
            title: const Text('Export as CSV'), onTap: _exportCsv),
          const Divider(height: 1),
          ListTile(leading: const Icon(Icons.delete_forever, color: AppColors.error),
            title: const Text('Clear all local data', style: TextStyle(color: AppColors.error)),
            subtitle: const Text('Testing ya fresh start ke liye destructive action'),
            onTap: _clearAllData),
        ])),
        const SizedBox(height: 24),
        _sectionTitle('ABOUT'),
        Card(child: Column(children: [
          const ListTile(leading: Icon(Icons.info, color: AppColors.textSecondary),
            title: Text('Daily Collection App'), subtitle: const Text('Version 3.4.0 (v9.2)')),
          const Divider(height: 1),
          ListTile(
            leading: const Icon(Icons.person, color: AppColors.primary),
            title: const Text('Created by Harish', style: TextStyle(fontWeight: FontWeight.bold)),
            subtitle: const Text('Daily Collection Loan Tracking App'),
          ),
        ])),
        const SizedBox(height: 32),
      ]),
    );
  }

  /// v9.2: Sab data clear karo (settings stay) — double confirm ke saath
  Future<void> _clearAllData() async {
    final confirmed = await showDialog<bool>(
      context: context,
      builder: (ctx) => AlertDialog(
        title: const Text('Clear All Local Data?'),
        content: const Text('Saare customers, loans, collections PERMANENTLY delete ho jayenge. Settings bachi rahengi. Pehle backup lena better hai!'),
        actions: [
          TextButton(onPressed: () => Navigator.pop(ctx, false), child: const Text('Cancel')),
          ElevatedButton(style: ElevatedButton.styleFrom(backgroundColor: AppColors.error), onPressed: () => Navigator.pop(ctx, true), child: const Text('Delete Everything')),
        ],
      ),
    );
    if (confirmed != true) return;
    // Dobara confirm (type-to-confirm nahi, simple double check)
    final confirmed2 = await showDialog<bool>(
      context: context,
      builder: (ctx) => AlertDialog(
        title: const Text('Pakka?'),
        content: const Text('Ye action undo nahi ho sakta.'),
        actions: [
          TextButton(onPressed: () => Navigator.pop(ctx, false), child: const Text('Nahi')),
          ElevatedButton(style: ElevatedButton.styleFrom(backgroundColor: AppColors.error), onPressed: () => Navigator.pop(ctx, true), child: const Text('Haan, delete karo')),
        ],
      ),
    );
    if (confirmed2 != true) return;
    try {
      await DatabaseHelper().deleteAllData();
      if (mounted) {
        ScaffoldMessenger.of(context).showSnackBar(const SnackBar(content: Text('Saara data clear ho gaya')));
      }
    } catch (e) {
      if (mounted) {
        ScaffoldMessenger.of(context).showSnackBar(SnackBar(content: Text('Clear failed: $e')));
      }
    }
  }

  /// v9.1: Custom folder path input dialog (quotes / backup path ke liye)
  Future<String?> _showPathDialog({
    required String title,
    required String current,
    required String hint,
    required String helper,
  }) async {
    final ctrl = TextEditingController(text: current);
    return showDialog<String>(
      context: context,
      builder: (ctx) => AlertDialog(
        title: Text(title),
        content: Column(
          mainAxisSize: MainAxisSize.min,
          children: [
            Text(helper, style: const TextStyle(fontSize: 12)),
            const SizedBox(height: 12),
            TextField(
              controller: ctrl,
              decoration: InputDecoration(labelText: 'Folder path', border: const OutlineInputBorder(), hintText: hint),
            ),
          ],
        ),
        actions: [
          TextButton(onPressed: () => Navigator.pop(ctx, null), child: const Text('Cancel')),
          TextButton(onPressed: () => Navigator.pop(ctx, ''), child: const Text('Clear')),
          ElevatedButton(onPressed: () => Navigator.pop(ctx, ctrl.text.trim()), child: const Text('Save')),
        ],
      ),
    );
  }

  /// v9.1: Backup JSON banake Google Drive par upload karo
  Future<void> _uploadToDrive() async {
    setState(() => _isDriveUploading = true);
    try {
      final backup = await _backupService.exportData();
      if (!backup.success || backup.filePath == null) {
        if (mounted) {
          ScaffoldMessenger.of(context).showSnackBar(SnackBar(content: Text(backup.message)));
        }
        return;
      }
      final json = await File(backup.filePath!).readAsString();
      final ok = await _driveService.uploadBackup(json);
      if (mounted) {
        ScaffoldMessenger.of(context).showSnackBar(SnackBar(
          content: Text(ok ? 'Drive par backup upload ho gaya ✅' : 'Drive upload fail — sign-in ya network check karein')));
      }
    } catch (e) {
      if (mounted) {
        ScaffoldMessenger.of(context).showSnackBar(SnackBar(content: Text('Drive error: $e')));
      }
    } finally {
      if (mounted) setState(() => _isDriveUploading = false);
    }
  }

  Future<String?> _showPinDialog() async {
    final pinCtrl = TextEditingController();
    return showDialog<String>(context: context, builder: (ctx) => AlertDialog(
      title: const Text('Set PIN'),
      content: TextField(controller: pinCtrl, decoration: const InputDecoration(labelText: '4-digit PIN', border: OutlineInputBorder()),
        keyboardType: TextInputType.number, maxLength: 4, obscureText: true),
      actions: [
        TextButton(onPressed: () => Navigator.pop(ctx, null), child: const Text('Cancel')),
        ElevatedButton(onPressed: () => Navigator.pop(ctx, pinCtrl.text), child: const Text('Set')),
      ],
    ));
  }

  Widget _sectionTitle(String title) {
    return Padding(padding: const EdgeInsets.only(bottom: 8),
      child: Text(title, style: TextStyle(fontSize: 13, fontWeight: FontWeight.bold, color: AppColors.textSecondary)));
  }
}
