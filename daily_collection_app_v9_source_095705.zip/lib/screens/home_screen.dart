import 'package:flutter/material.dart';
import '../models/loan.dart';
import '../models/schedule_entry.dart';
import '../database/dao/loan_dao.dart';
import '../database/dao/collection_dao.dart';
import '../database/dao/schedule_dao.dart';
import '../database/dao/settings_dao.dart';
import '../services/calculation_service.dart';
import '../services/notification_service.dart';
import '../services/quotes_service.dart';
import '../utils/constants.dart';
import 'add_customer_screen.dart';
import 'calculators_screen.dart';
import 'customer_list_screen.dart';
import 'daily_collection_screen.dart';
import 'loan_list_screen.dart';
import 'loan_detail_screen.dart';
import 'outstanding_snapshot_screen.dart';

/// v9.2: MHT-prototype style Home — dark header, outstanding card,
/// stat grid (EMI/Interest loans, installments, due today), quick actions,
/// insights (loan mix, this month), quote, alerts.
class HomeScreen extends StatefulWidget {
  const HomeScreen({super.key});

  @override
  State<HomeScreen> createState() => _HomeScreenState();
}

class _HomeScreenState extends State<HomeScreen> {
  final LoanDao _loanDao = LoanDao();
  final CollectionDao _collectionDao = CollectionDao();
  final ScheduleDao _scheduleDao = ScheduleDao();
  final SettingsDao _settingsDao = SettingsDao();

  bool _isLoading = true;
  String _ownerName = '';
  double _totalOutstanding = 0;
  int _emiLoans = 0;
  int _interestLoans = 0;
  int _activeLoans = 0;
  int _totalInstallmentsPending = 0;
  int _dueToday = 0;
  double _collectedToday = 0;
  double _monthCollected = 0;
  String _quote = '';
  List<AlertItem> _alerts = [];
  List<Loan> _recentLoans = [];

  @override
  void initState() {
    super.initState();
    _loadData();
  }

  Future<void> _loadData() async {
    setState(() => _isLoading = true);
    try {
      final settings = await _settingsDao.getSettings();
      _ownerName = settings.ownerName;

      final loans = await _loanDao.getAll();
      final today = CalculationService.today();
      final monthPrefix = today.substring(0, 7);

      double outstanding = 0;
      int emi = 0, interest = 0, active = 0;
      final activeLoanIds = <int>[];
      for (final loan in loans) {
        if (loan.status == LoanStatus.cancelled) continue;
        final collected = await _collectionDao.getTotalCollectedByLoan(loan.id!);
        if (loan.status == LoanStatus.active || loan.status == LoanStatus.overdue) {
          active++;
          activeLoanIds.add(loan.id!);
          outstanding += (loan.returnAmount - collected).clamp(0.0, double.infinity);
          if (loan.loanType == LoanType.emi) {
            emi++;
          } else {
            interest++;
          }
        }
      }

      // Pending installments + due today
      int pendingInstallments = 0;
      int dueToday = 0;
      for (final loanId in activeLoanIds) {
        final entries = await _scheduleDao.getByLoanId(loanId, limit: 500);
        for (final e in entries) {
          if (e.status == ScheduleEntryStatus.pending || e.status == ScheduleEntryStatus.partial) {
            pendingInstallments++;
            if (e.scheduledDate.substring(0, 10) == today) dueToday++;
          }
        }
      }

      // Today collected
      _collectedToday = await _collectionDao.getTotalCollectedByDate(today);

      // This month collected — raw rows scan (collection_date prefix)
      double monthCollected = 0;
      final rawCols = await _collectionDao.getAllRaw();
      for (final c in rawCols) {
        final d = (c['collection_date'] as String?) ?? '';
        if (d.startsWith(monthPrefix)) {
          monthCollected += (c['collected_amount'] as num?)?.toDouble() ?? 0;
        }
      }
      _monthCollected = monthCollected;

      // Recent active loans (top 3)
      final activeLoans = await _loanDao.getActiveLoans();
      activeLoans.sort((a, b) => b.startDate.compareTo(a.startDate));
      _recentLoans = activeLoans.take(3).toList();

      // Quote
      try {
        _quote = await QuotesService().getRandomQuote(customPath: settings.quotesCustomPath);
      } catch (_) {
        _quote = '';
      }

      // Alerts (reuse NotificationService)
      try {
        final notif = NotificationService();
        _alerts = await notif.getDashboardAlerts();
      } catch (_) {
        _alerts = [];
      }

      _emiLoans = emi;
      _interestLoans = interest;
      _activeLoans = active;
      _totalOutstanding = outstanding;
      _totalInstallmentsPending = pendingInstallments;
      _dueToday = dueToday;
    } catch (_) {}
    if (mounted) setState(() => _isLoading = false);
  }

  @override
  Widget build(BuildContext context) {
    final dark = Theme.of(context).brightness == Brightness.dark;
    if (_isLoading) {
      return const Scaffold(body: Center(child: CircularProgressIndicator()));
    }

    return Scaffold(
      body: RefreshIndicator(
        onRefresh: _loadData,
        child: ListView(
          padding: EdgeInsets.zero,
          children: [
            _buildHeader(dark),
            const SizedBox(height: 16),
            Padding(
              padding: const EdgeInsets.symmetric(horizontal: AppConstants.padding),
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  _buildOutstandingCard(dark),
                  const SizedBox(height: 16),
                  _buildStatGrid(dark),
                  const SizedBox(height: 16),
                  _buildQuickActions(dark),
                  const SizedBox(height: 24),
                  _buildInsights(dark),
                  const SizedBox(height: 24),
                  if (_alerts.isNotEmpty) ...[
                    _sectionTitle('ALERTS'),
                    ..._alerts.map(_buildAlertTile),
                    const SizedBox(height: 16),
                  ],
                  if (_recentLoans.isNotEmpty) ...[
                    _sectionTitle('RECENT LOANS'),
                    ..._recentLoans.map(_buildLoanTile),
                    const SizedBox(height: 16),
                  ],
                  if (_quote.isNotEmpty) _buildQuoteCard(dark),
                  const SizedBox(height: 16),
                  _buildFooter(dark),
                  const SizedBox(height: 24),
                ],
              ),
            ),
          ],
        ),
      ),
      floatingActionButton: FloatingActionButton.extended(
        onPressed: () async {
          await Navigator.push(context, MaterialPageRoute(builder: (_) => const AddCustomerScreen()));
          _loadData();
        },
        icon: const Icon(Icons.person_add),
        label: const Text('New loan'),
      ),
    );
  }

  // ---------- Header ----------
  Widget _buildHeader(bool dark) {
    final hour = DateTime.now().hour;
    final greet = hour < 12 ? 'Good morning' : (hour < 17 ? 'Good afternoon' : 'Good evening');
    return Container(
      width: double.infinity,
      padding: EdgeInsets.fromLTRB(AppConstants.padding, MediaQuery.of(context).padding.top + 20, AppConstants.padding, 24),
      decoration: BoxDecoration(
        gradient: LinearGradient(
          begin: Alignment.topLeft,
          end: Alignment.bottomRight,
          colors: [AppColors.primary, AppColors.primary.withOpacity(0.75)],
        ),
      ),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Text('DAILY HISAB',
            style: TextStyle(fontSize: 11, letterSpacing: 2, fontWeight: FontWeight.bold, color: Colors.white.withOpacity(0.75))),
          const SizedBox(height: 4),
          Text('$greet${_ownerName.isNotEmpty ? ', $_ownerName' : ''} 👋',
            style: const TextStyle(fontSize: 20, fontWeight: FontWeight.bold, color: Colors.white)),
          const SizedBox(height: 4),
          Text('Your collection at a glance.',
            style: TextStyle(fontSize: 12, color: Colors.white.withOpacity(0.8))),
        ],
      ),
    );
  }

  // ---------- Outstanding card ----------
  Widget _buildOutstandingCard(bool dark) {
    return Container(
      width: double.infinity,
      padding: const EdgeInsets.all(20),
      decoration: BoxDecoration(
        gradient: const LinearGradient(colors: [Color(0xFF0D2A4A), Color(0xFF0A1E33)]),
        borderRadius: BorderRadius.circular(AppConstants.cardRadius),
      ),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Text('TOTAL OUTSTANDING', style: TextStyle(fontSize: 10, letterSpacing: 1.5, color: Colors.white.withOpacity(0.6))),
          const SizedBox(height: 6),
          Text(CalculationService.formatCurrency(_totalOutstanding),
            style: const TextStyle(fontSize: 30, fontWeight: FontWeight.bold, color: Colors.white)),
          const SizedBox(height: 14),
          Row(children: [
            _miniStat(Icons.trending_up, '$_activeLoans active', 'loans'),
            const SizedBox(width: 20),
            _miniStat(Icons.calendar_today, '$_dueToday due today', ''),
            const SizedBox(width: 20),
            _miniStat(Icons.check_circle, CalculationService.formatCurrency(_collectedToday), 'collected'),
          ]),
        ],
      ),
    );
  }

  Widget _miniStat(IconData icon, String value, String label) {
    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        Row(children: [
          Icon(icon, size: 14, color: Colors.white.withOpacity(0.7)),
          const SizedBox(width: 4),
          Text(value, style: const TextStyle(fontSize: 12, fontWeight: FontWeight.bold, color: Colors.white)),
        ]),
        if (label.isNotEmpty)
          Text(label, style: TextStyle(fontSize: 10, color: Colors.white.withOpacity(0.55))),
      ],
    );
  }

  // ---------- Stat grid ----------
  Widget _buildStatGrid(bool dark) {
    return Row(children: [
      Expanded(child: _statTile(dark, 'EMI loans', '$_emiLoans', Icons.credit_card, AppColors.primary,
        onTap: () => Navigator.push(context, MaterialPageRoute(builder: (_) => const LoanListScreen())))),
      const SizedBox(width: 8),
      Expanded(child: _statTile(dark, 'Interest loans', '$_interestLoans', Icons.percent, AppColors.warning,
        onTap: () => Navigator.push(context, MaterialPageRoute(builder: (_) => const LoanListScreen())))),
    ]);
  }

  Widget _statTile(bool dark, String label, String value, IconData icon, Color color, {VoidCallback? onTap}) {
    return Card(
      elevation: dark ? 0 : 2,
      margin: EdgeInsets.zero,
      child: InkWell(
        borderRadius: BorderRadius.circular(AppConstants.cardRadius),
        onTap: onTap,
        child: Padding(
          padding: const EdgeInsets.all(14),
          child: Row(children: [
            Container(
              padding: const EdgeInsets.all(8),
              decoration: BoxDecoration(color: color.withOpacity(0.12), borderRadius: BorderRadius.circular(10)),
              child: Icon(icon, color: color, size: 22),
            ),
            const SizedBox(width: 10),
            Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
              Text(value, style: const TextStyle(fontSize: 18, fontWeight: FontWeight.bold)),
              Text(label, style: TextStyle(fontSize: 11, color: AppColors.textSecondary)),
            ]),
          ]),
        ),
      ),
    );
  }

  // ---------- Quick actions ----------
  Widget _buildQuickActions(bool dark) {
    return Card(
      elevation: dark ? 0 : 2,
      margin: EdgeInsets.zero,
      child: Padding(
        padding: const EdgeInsets.symmetric(vertical: 12, horizontal: 8),
        child: Row(
          mainAxisAlignment: MainAxisAlignment.spaceEvenly,
          children: [
            _quickAction(Icons.person_add, 'New loan', () async {
              await Navigator.push(context, MaterialPageRoute(builder: (_) => const AddCustomerScreen()));
              _loadData();
            }),
            _quickAction(Icons.people, 'Customers', () => Navigator.push(context, MaterialPageRoute(builder: (_) => const CustomerListScreen()))),
            _quickAction(Icons.payments, 'Collect', () => Navigator.push(context, MaterialPageRoute(builder: (_) => const DailyCollectionScreen()))),
            _quickAction(Icons.calculate, 'Calc', () => Navigator.push(context, MaterialPageRoute(builder: (_) => const CalculatorsScreen()))),
            _quickAction(Icons.pending_actions, '$_dueToday due', () => Navigator.push(context, MaterialPageRoute(builder: (_) => const DailyCollectionScreen()))),
          ],
        ),
      ),
    );
  }

  Widget _quickAction(IconData icon, String label, VoidCallback onTap) {
    return InkWell(
      borderRadius: BorderRadius.circular(10),
      onTap: onTap,
      child: Padding(
        padding: const EdgeInsets.symmetric(horizontal: 6, vertical: 4),
        child: Column(children: [
          Container(
            padding: const EdgeInsets.all(10),
            decoration: BoxDecoration(color: AppColors.primary.withOpacity(0.1), shape: BoxShape.circle),
            child: Icon(icon, color: AppColors.primary, size: 22),
          ),
          const SizedBox(height: 6),
          Text(label, style: const TextStyle(fontSize: 11)),
        ]),
      ),
    );
  }

  // ---------- Insights ----------
  Widget _buildInsights(bool dark) {
    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        _sectionTitle('INSIGHTS'),
        Card(
          margin: EdgeInsets.zero,
          elevation: dark ? 0 : 2,
          child: Padding(
            padding: const EdgeInsets.all(14),
            child: Column(children: [
              Row(children: [
                Expanded(child: _insightTile('Loan mix', '$_emiLoans EMI / $_interestLoans Interest', Icons.donut_small, AppColors.primary)),
                const SizedBox(width: 12),
                Expanded(child: _insightTile('This month', '${CalculationService.formatCurrency(_monthCollected)} collected', Icons.calendar_month, AppColors.success)),
              ]),
              const SizedBox(height: 12),
              Row(children: [
                Expanded(child: _insightTile('Installments', '$_totalInstallmentsPending pending', Icons.view_week, AppColors.warning)),
                const SizedBox(width: 12),
                Expanded(child: _insightTile('Today', '${CalculationService.formatCurrency(_collectedToday)} collected', Icons.today, AppColors.primary)),
              ]),
            ]),
          ),
        ),
      ],
    );
  }

  Widget _insightTile(String label, String value, IconData icon, Color color) {
    return Row(children: [
      Icon(icon, color: color, size: 20),
      const SizedBox(width: 8),
      Expanded(child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
        Text(label, style: TextStyle(fontSize: 10, color: AppColors.textSecondary)),
        Text(value, style: const TextStyle(fontSize: 12, fontWeight: FontWeight.bold), overflow: TextOverflow.ellipsis),
      ])),
    ]);
  }

  // ---------- Alerts ----------
  Widget _buildAlertTile(AlertItem alert) {
    return Card(
      margin: const EdgeInsets.only(bottom: 6),
      child: ListTile(
        leading: Icon(_alertIcon(alert.type), color: _alertColor(alert.type)),
        title: Text(alert.title, style: const TextStyle(fontWeight: FontWeight.bold, fontSize: 14)),
        subtitle: Text(alert.description, style: const TextStyle(fontSize: 12)),
        dense: true,
      ),
    );
  }

  // ---------- Recent loans ----------
  Widget _buildLoanTile(Loan loan) {
    return Card(
      margin: const EdgeInsets.only(bottom: 6),
      child: ListTile(
        leading: CircleAvatar(
          backgroundColor: (loan.loanType == LoanType.emi ? AppColors.primary : AppColors.warning).withOpacity(0.15),
          child: Icon(loan.loanType == LoanType.emi ? Icons.credit_card : Icons.percent,
            color: loan.loanType == LoanType.emi ? AppColors.primary : AppColors.warning, size: 20),
        ),
        title: Text('Loan #${loan.id} — ${loan.status.label}', style: const TextStyle(fontSize: 14, fontWeight: FontWeight.w600)),
        subtitle: Text('${CalculationService.formatCurrency(loan.principal)} -> ${CalculationService.formatCurrency(loan.returnAmount)} | ${loan.totalInstallments} x ${loan.installmentFrequency.label}',
          style: const TextStyle(fontSize: 12)),
        onTap: () => Navigator.push(context, MaterialPageRoute(builder: (_) => LoanDetailScreen(loanId: loan.id!))),
      ),
    );
  }

  // ---------- Quote ----------
  Widget _buildQuoteCard(bool dark) {
    return Container(
      width: double.infinity,
      padding: const EdgeInsets.all(14),
      decoration: BoxDecoration(
        color: AppColors.warning.withOpacity(0.08),
        borderRadius: BorderRadius.circular(AppConstants.cardRadius),
        border: Border.all(color: AppColors.warning.withOpacity(0.3)),
      ),
      child: Row(children: [
        const Icon(Icons.format_quote, color: AppColors.warning, size: 20),
        const SizedBox(width: 8),
        Expanded(child: Text('"$_quote"', style: TextStyle(fontSize: 12, fontStyle: FontStyle.italic, color: dark ? Colors.white70 : AppColors.textSecondary))),
      ]),
    );
  }

  Widget _buildFooter(bool dark) {
    return Center(child: Column(children: [
      Text('Local-first app · Data device par stored hai', style: TextStyle(fontSize: 10, color: AppColors.textSecondary.withOpacity(0.7))),
      const SizedBox(height: 4),
      Text('Created by Harish · v9.2', style: TextStyle(fontSize: 11, fontWeight: FontWeight.bold, color: AppColors.primary.withOpacity(0.7))),
    ]));
  }

  Widget _sectionTitle(String title) {
    return Padding(
      padding: const EdgeInsets.only(bottom: 8),
      child: Text(title, style: TextStyle(fontSize: 12, fontWeight: FontWeight.bold, letterSpacing: 1, color: AppColors.textSecondary)),
    );
  }

  IconData _alertIcon(AlertType type) {
    switch (type) {
      case AlertType.overdue: return Icons.warning;
      case AlertType.missedPayment: return Icons.cancel;
      case AlertType.loanCompleted: return Icons.check_circle;
      case AlertType.pendingToday: return Icons.today;
      case AlertType.defaulted: return Icons.error;
    }
  }

  Color _alertColor(AlertType type) {
    switch (type) {
      case AlertType.overdue: return AppColors.overdue;
      case AlertType.missedPayment: return AppColors.error;
      case AlertType.loanCompleted: return AppColors.success;
      case AlertType.pendingToday: return AppColors.warning;
      case AlertType.defaulted: return AppColors.error;
    }
  }
}
