import 'package:local_auth/local_auth.dart';
import 'package:local_auth_android/local_auth_android.dart';

/// v9.1: Fingerprint / Face unlock service (local_auth).
class BiometricService {
  final LocalAuthentication _auth = LocalAuthentication();

  /// Device mein biometric hardware + enrolled fingerprint hai kya?
  Future<bool> isBiometricAvailable() async {
    try {
      final supported = await _auth.isDeviceSupported();
      final canCheck = await _auth.canCheckBiometrics;
      return supported && canCheck;
    } catch (_) {
      return false;
    }
  }

  /// Biometric prompt dikhao. Returns: success true/false.
  Future<bool> authenticate({String reason = 'App unlock karne ke liye verify karein'}) async {
    try {
      return await _auth.authenticate(
        localizedReason: reason,
        authMessages: const <AuthMessages>[
          AndroidAuthMessages(
            biometricHint: '',
            signInTitle: 'Daily Collection — Verify karein',
            cancelButton: 'Cancel',
          ),
        ],
        options: const AuthenticationOptions(
          biometricOnly: true, // sirf fingerprint/face — PIN nahi (app ka apna PIN fallback hai)
          stickyAuth: true,
          useErrorDialogs: true,
        ),
      );
    } catch (_) {
      return false;
    }
  }
}
