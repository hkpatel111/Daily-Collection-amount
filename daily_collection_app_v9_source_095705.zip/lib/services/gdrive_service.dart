import 'dart:convert';
import 'dart:typed_data';

import 'package:googleapis/drive/v3.dart' as drive;
import 'package:google_sign_in/google_sign_in.dart';
import 'package:http/http.dart' as http;

/// Google Drive backup service — sign-in, upload, download/restore.
///
/// Backup file name: daily_collection_backup.json (app folder "SameTopic")
class GDriveService {
  static const _fileName = 'daily_collection_backup.json';
  static const _scopes = [drive.DriveApi.driveFileScope];

  GoogleSignInAccount? _currentUser;
  drive.DriveApi? _driveApi;

  /// Sign in to Google. Returns null on failure/cancel.
  Future<GoogleSignInAccount?> signIn() async {
    final googleSignIn = GoogleSignIn(scopes: _scopes);
    try {
      // Pehle silent try karo
      var account = await googleSignIn.signInSilently();
      account ??= await googleSignIn.signIn();
      if (account == null) return null; // user cancelled

      final auth = await account.authentication;
      if (auth.accessToken == null) return null;

      final client = _AuthClient(auth.accessToken!, _scopes);
      _driveApi = drive.DriveApi(client);
      _currentUser = account;
      return account;
    } catch (e) {
      print('GDrive sign-in error: $e');
      return null;
    }
  }

  Future<bool> isSignedIn() async {
    final googleSignIn = GoogleSignIn(scopes: _scopes);
    return googleSignIn.currentUser != null;
  }

  Future<void> signOut() async {
    final googleSignIn = GoogleSignIn(scopes: _scopes);
    await googleSignIn.signOut();
    _currentUser = null;
    _driveApi = null;
  }

  /// Find existing backup file in Drive (by name) — returns fileId or null.
  Future<String?> _findBackupFile() async {
    if (_driveApi == null) return null;
    final result = await _driveApi!.files.list(
      q: "name = '$_fileName' and trashed = false",
      spaces: 'drive',
      $fields: 'files(id, name, modifiedTime)',
    );
    final files = result.files ?? [];
    if (files.isEmpty) return null;
    return files.first.id;
  }

  /// Upload JSON content as backup to Drive. Creates or updates the file.
  Future<bool> uploadBackup(String jsonContent) async {
    if (_driveApi == null) {
      final account = await signIn();
      if (account == null || _driveApi == null) return false;
    }

    try {
      final existingId = await _findBackupFile();

      if (existingId != null) {
        // Update existing file (naya upload, same fileId)
        final media = drive.Media(
          Stream.value(utf8.encode(jsonContent) as Uint8List),
          utf8.encode(jsonContent).length,
        );
        await _driveApi!.files.update(
          drive.File()..name = _fileName,
          existingId,
          uploadMedia: media,
        );
      } else {
        // Create new file
        final media = drive.Media(
          Stream.value(utf8.encode(jsonContent) as Uint8List),
          utf8.encode(jsonContent).length,
        );
        await _driveApi!.files.create(
          drive.File()
            ..name = _fileName
            ..mimeType = 'application/json',
          uploadMedia: media,
        );
      }
      return true;
    } catch (e) {
      print('GDrive upload error: $e');
      return false;
    }
  }

  /// Download backup JSON from Drive — returns content or null.
  Future<String?> downloadBackup() async {
    if (_driveApi == null) {
      final account = await signIn();
      if (account == null || _driveApi == null) return null;
    }

    try {
      final fileId = await _findBackupFile();
      if (fileId == null) return null;

      final media = await _driveApi!.files.get(
        fileId,
        downloadOptions: drive.DownloadOptions.fullMedia,
      ) as drive.Media;

      final chunks = <int>[];
      await for (final chunk in media.stream) {
        chunks.addAll(chunk);
      }
      return utf8.decode(chunks);
    } catch (e) {
      print('GDrive download error: $e');
      return null;
    }
  }

  /// Get info about the remote backup (exists? when last modified?)
  Future<({bool exists, String? modified})> getBackupInfo() async {
    if (_driveApi == null) {
      final account = await signIn();
      if (account == null || _driveApi == null) return (exists: false, modified: null);
    }
    try {
      final result = await _driveApi!.files.list(
        q: "name = '$_fileName' and trashed = false",
        spaces: 'drive',
        $fields: 'files(id, name, modifiedTime)',
      );
      final files = result.files ?? [];
      if (files.isEmpty) return (exists: false, modified: null);
      return (exists: true, modified: files.first.modifiedTime?.toIso8601String());
    } catch (e) {
      return (exists: false, modified: null);
    }
  }

  String? get signedInEmail => _currentUser?.email;
}

/// Minimal authenticated HTTP client wrapping the access token.
class _AuthClient extends http.BaseClient {
  final String _token;
  final List<String> _scopes;
  http.Client? _inner;

  _AuthClient(this._token, this._scopes) : _inner = http.Client();

  @override
  Future<http.StreamedResponse> send(http.BaseRequest request) {
    request.headers['Authorization'] = 'Bearer $_token';
    request.headers['X-Goog-AuthUser'] = '0';
    return _inner!.send(request);
  }

  @override
  void close() {
    _inner?.close();
    _inner = null;
  }
}
