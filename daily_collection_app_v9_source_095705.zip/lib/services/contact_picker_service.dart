import 'package:flutter_contacts/flutter_contacts.dart';
import '../models/customer.dart';

/// v9.1: Phone contact list se customer pick karne ki service.
/// flutter_contacts 1.1.9+2 API ke hisaab se (CI par yahi resolve hota hai):
/// - FlutterContacts.requestPermission(readonly: true)
/// - FlutterContacts.openExternalPick() -> system contact picker
/// - FlutterContacts.getContact(id) -> full contact (phones included)
class ContactPickerService {
  /// Pehle permission maango, phir system contact picker kholo.
  /// Returns: selected contact ya null (cancel/denied).
  Future<Customer?> pickContact() async {
    // Permission check + request (readonly kaafi hai)
    if (!await FlutterContacts.requestPermission(readonly: true)) {
      return null; // denied
    }

    // System contact picker kholo (native UI)
    final picked = await FlutterContacts.openExternalPick();
    if (picked == null) return null; // user ne cancel kiya

    // Picker se sirf id milta hai — phones ke liye full fetch karo
    final full = await FlutterContacts.getContact(picked.id);
    final name = full?.displayName ?? picked.displayName ?? '';
    String mobile = '';
    if (full?.phones.isNotEmpty ?? false) {
      mobile = full!.phones.first.number.replaceAll(RegExp(r'[^0-9+]'), '');
      // +91 / 91 prefix strip karo (10-digit rakho)
      if (mobile.startsWith('+91')) mobile = mobile.substring(3);
      if (mobile.startsWith('91') && mobile.length > 10) {
        mobile = mobile.substring(2);
      }
      mobile = mobile.trim();
    }

    if (name.isEmpty || mobile.isEmpty) return null;

    return Customer(name: name, mobile: mobile, createdAt: '');
  }
}
