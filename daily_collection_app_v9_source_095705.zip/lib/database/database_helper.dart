import 'package:sqflite/sqflite.dart';
import 'package:path/path.dart';

class DatabaseHelper {
  static final DatabaseHelper _instance = DatabaseHelper._internal();
  factory DatabaseHelper() => _instance;
  DatabaseHelper._internal();

  Database? _database;
  static const int _dbVersion = 6; // v9.1 — quotes custom path
  static const String _dbName = 'daily_collection.db';

  Future<Database> get database async {
    if (_database != null) return _database!;
    _database = await _initDatabase();
    return _database!;
  }

  Future<Database> _initDatabase() async {
    final dbPath = await getDatabasesPath();
    final path = join(dbPath, _dbName);
    return await openDatabase(path, version: _dbVersion, onCreate: _onCreate, onUpgrade: _onUpgrade);
  }

  Future<void> _onCreate(Database db, int version) async {
    await db.execute('''
      CREATE TABLE customers (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        name TEXT NOT NULL,
        mobile TEXT NOT NULL,
        nickname TEXT,
        created_at TEXT NOT NULL,
        is_active INTEGER NOT NULL DEFAULT 1
      )
    ''');

    await db.execute('''
      CREATE TABLE loans (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        customer_id INTEGER NOT NULL,
        principal REAL NOT NULL,
        return_amount REAL NOT NULL,
        daily_installment REAL NOT NULL,
        total_days INTEGER NOT NULL,
        profit REAL NOT NULL,
        daily_interest_rate REAL NOT NULL,
        monthly_interest_rate REAL NOT NULL DEFAULT 0,
        start_date TEXT NOT NULL,
        end_date TEXT NOT NULL,
        status TEXT NOT NULL DEFAULT 'active',
        last_day_adjusted_amount REAL NOT NULL DEFAULT 0,
        created_at TEXT NOT NULL,
        loan_tag TEXT NOT NULL DEFAULT '',
        account_name TEXT,
        interest_type TEXT NOT NULL DEFAULT 'simple',
        installment_frequency TEXT NOT NULL DEFAULT 'daily',
        compounding_frequency TEXT NOT NULL DEFAULT 'quarterly',
        loan_type TEXT NOT NULL DEFAULT 'emi',
        FOREIGN KEY (customer_id) REFERENCES customers (id)
      )
    ''');

    await db.execute('''
      CREATE TABLE schedule_entries (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        loan_id INTEGER NOT NULL,
        day_number INTEGER NOT NULL,
        scheduled_date TEXT NOT NULL,
        expected_amount REAL NOT NULL,
        is_holiday INTEGER NOT NULL DEFAULT 0,
        status TEXT NOT NULL DEFAULT 'pending',
        created_at TEXT NOT NULL,
        FOREIGN KEY (loan_id) REFERENCES loans (id)
      )
    ''');

    await db.execute('''
      CREATE TABLE collection_entries (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        loan_id INTEGER NOT NULL,
        schedule_entry_id INTEGER NOT NULL,
        collection_date TEXT NOT NULL,
        expected_amount REAL NOT NULL,
        collected_amount REAL NOT NULL,
        shortfall REAL NOT NULL DEFAULT 0,
        is_missed INTEGER NOT NULL DEFAULT 0,
        overdue_interest REAL NOT NULL DEFAULT 0,
        note TEXT,
        payment_mode TEXT NOT NULL DEFAULT 'cash',
        created_at TEXT NOT NULL,
        updated_at TEXT NOT NULL,
        FOREIGN KEY (loan_id) REFERENCES loans (id),
        FOREIGN KEY (schedule_entry_id) REFERENCES schedule_entries (id)
      )
    ''');

    await db.execute('''
      CREATE TABLE settings (
        id INTEGER PRIMARY KEY DEFAULT 1,
        grace_period_days INTEGER NOT NULL DEFAULT 1,
        sunday_holiday_enabled INTEGER NOT NULL DEFAULT 0,
        defaulted_threshold_days INTEGER NOT NULL DEFAULT 15,
        sms_enabled INTEGER NOT NULL DEFAULT 1,
        sms_on_payment INTEGER NOT NULL DEFAULT 1,
        sms_on_missed INTEGER NOT NULL DEFAULT 1,
        sms_on_completion INTEGER NOT NULL DEFAULT 1,
        sms_on_preclosure INTEGER NOT NULL DEFAULT 1,
        sms_auto_send INTEGER NOT NULL DEFAULT 0,
        owner_name TEXT NOT NULL DEFAULT '',
        dark_mode INTEGER NOT NULL DEFAULT 0,
        auto_backup_days INTEGER NOT NULL DEFAULT 7,
        collection_priority TEXT NOT NULL DEFAULT 'fifo',
        app_lock_enabled INTEGER NOT NULL DEFAULT 0,
        app_pin TEXT NOT NULL DEFAULT '',
        gdrive_backup_enabled INTEGER NOT NULL DEFAULT 0,
        late_fee_enabled INTEGER NOT NULL DEFAULT 0,
        late_fee_per_day REAL NOT NULL DEFAULT 10,
        auto_reminder_days INTEGER NOT NULL DEFAULT 3,
        theme_color TEXT NOT NULL DEFAULT 'blue',
        custom_backup_path TEXT NOT NULL DEFAULT '',
        biometric_enabled INTEGER NOT NULL DEFAULT 0,
        morning_reminder_enabled INTEGER NOT NULL DEFAULT 0,
        reminder_hour INTEGER NOT NULL DEFAULT 8,
        quotes_custom_path TEXT NOT NULL DEFAULT ''
      )
    ''');

    await db.execute('''
      CREATE TABLE transaction_logs (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        action_type TEXT NOT NULL,
        description TEXT NOT NULL,
        loan_id INTEGER,
        customer_id INTEGER,
        amount REAL,
        created_at TEXT NOT NULL
      )
    ''');

    await db.execute('''
      CREATE TABLE sms_logs (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        loan_id INTEGER,
        customer_id INTEGER,
        mobile TEXT NOT NULL,
        message TEXT NOT NULL,
        status TEXT NOT NULL DEFAULT 'sent',
        sms_type TEXT NOT NULL DEFAULT '',
        created_at TEXT NOT NULL
      )
    ''');

    await db.execute('''
      CREATE TABLE edit_history (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        collection_entry_id INTEGER NOT NULL,
        field_name TEXT NOT NULL,
        old_value TEXT NOT NULL,
        new_value TEXT NOT NULL,
        edited_at TEXT NOT NULL,
        FOREIGN KEY (collection_entry_id) REFERENCES collection_entries (id)
      )
    ''');

    await db.insert('settings', {
      'id': 1, 'grace_period_days': 1, 'sunday_holiday_enabled': 0,
      'defaulted_threshold_days': 15, 'sms_enabled': 1, 'sms_on_payment': 1,
      'sms_on_missed': 1, 'sms_on_completion': 1, 'sms_on_preclosure': 1,
      'sms_auto_send': 0, 'owner_name': '', 'dark_mode': 0,
      'auto_backup_days': 7, 'collection_priority': 'fifo',
      'app_lock_enabled': 0, 'app_pin': '', 'gdrive_backup_enabled': 0,
      'late_fee_enabled': 0, 'late_fee_per_day': 10, 'auto_reminder_days': 3,
      'theme_color': 'blue', 'custom_backup_path': '', 'biometric_enabled': 0,
      'morning_reminder_enabled': 0, 'reminder_hour': 8,
      'quotes_custom_path': '',
    });

    await db.execute('CREATE INDEX idx_loans_customer ON loans(customer_id)');
    await db.execute('CREATE INDEX idx_schedule_loan ON schedule_entries(loan_id)');
    await db.execute('CREATE INDEX idx_schedule_date ON schedule_entries(scheduled_date)');
    await db.execute('CREATE INDEX idx_collection_loan ON collection_entries(loan_id)');
    await db.execute('CREATE INDEX idx_collection_date ON collection_entries(collection_date)');
    await db.execute('CREATE INDEX idx_logs_created ON transaction_logs(created_at)');
    await db.execute('CREATE INDEX idx_sms_logs_loan ON sms_logs(loan_id)');
    await db.execute('CREATE INDEX idx_edit_history_entry ON edit_history(collection_entry_id)');
  }

  Future<void> _onUpgrade(Database db, int oldVersion, int newVersion) async {
    if (oldVersion < 2) {
      for (final sql in [
        'ALTER TABLE loans ADD COLUMN loan_tag TEXT NOT NULL DEFAULT "";',
        'ALTER TABLE collection_entries ADD COLUMN payment_mode TEXT NOT NULL DEFAULT "cash";',
        'ALTER TABLE settings ADD COLUMN dark_mode INTEGER NOT NULL DEFAULT 0;',
        'ALTER TABLE settings ADD COLUMN auto_backup_days INTEGER NOT NULL DEFAULT 7;',
        'ALTER TABLE settings ADD COLUMN collection_priority TEXT NOT NULL DEFAULT "fifo";',
      ]) {
        try { await db.execute(sql); } catch (_) {}
      }
      try {
        await db.execute('''CREATE TABLE IF NOT EXISTS transaction_logs (
          id INTEGER PRIMARY KEY AUTOINCREMENT,
          action_type TEXT NOT NULL, description TEXT NOT NULL,
          loan_id INTEGER, customer_id INTEGER, amount REAL, created_at TEXT NOT NULL
        )''');
      } catch (_) {}
    }
    if (oldVersion < 3) {
      for (final sql in [
        'ALTER TABLE customers ADD COLUMN nickname TEXT;',
        'ALTER TABLE loans ADD COLUMN account_name TEXT;',
        'ALTER TABLE settings ADD COLUMN app_lock_enabled INTEGER NOT NULL DEFAULT 0;',
        'ALTER TABLE settings ADD COLUMN app_pin TEXT NOT NULL DEFAULT "";',
        'ALTER TABLE settings ADD COLUMN gdrive_backup_enabled INTEGER NOT NULL DEFAULT 0;',
        'ALTER TABLE settings ADD COLUMN late_fee_enabled INTEGER NOT NULL DEFAULT 0;',
        'ALTER TABLE settings ADD COLUMN late_fee_per_day REAL NOT NULL DEFAULT 10;',
        'ALTER TABLE settings ADD COLUMN auto_reminder_days INTEGER NOT NULL DEFAULT 3;',
        'ALTER TABLE settings ADD COLUMN theme_color TEXT NOT NULL DEFAULT "blue";',
      ]) {
        try { await db.execute(sql); } catch (_) {}
      }
      try {
        await db.execute('''CREATE TABLE IF NOT EXISTS sms_logs (
          id INTEGER PRIMARY KEY AUTOINCREMENT,
          loan_id INTEGER, customer_id INTEGER,
          mobile TEXT NOT NULL, message TEXT NOT NULL,
          status TEXT NOT NULL DEFAULT 'sent', sms_type TEXT NOT NULL DEFAULT '',
          created_at TEXT NOT NULL
        )''');
      } catch (_) {}
      try {
        await db.execute('''CREATE TABLE IF NOT EXISTS edit_history (
          id INTEGER PRIMARY KEY AUTOINCREMENT,
          collection_entry_id INTEGER NOT NULL,
          field_name TEXT NOT NULL, old_value TEXT NOT NULL,
          new_value TEXT NOT NULL, edited_at TEXT NOT NULL,
          FOREIGN KEY (collection_entry_id) REFERENCES collection_entries (id)
        )''');
      } catch (_) {}
    }
    // v8 upgrades
    if (oldVersion < 4) {
      for (final sql in [
        'ALTER TABLE loans ADD COLUMN monthly_interest_rate REAL NOT NULL DEFAULT 0;',
        'ALTER TABLE loans ADD COLUMN interest_type TEXT NOT NULL DEFAULT "simple";',
        'ALTER TABLE loans ADD COLUMN installment_frequency TEXT NOT NULL DEFAULT "daily";',
        'ALTER TABLE loans ADD COLUMN compounding_frequency TEXT NOT NULL DEFAULT "quarterly";',
        'ALTER TABLE settings ADD COLUMN custom_backup_path TEXT NOT NULL DEFAULT "";',
        'ALTER TABLE settings ADD COLUMN biometric_enabled INTEGER NOT NULL DEFAULT 0;',
      ]) {
        try { await db.execute(sql); } catch (_) {}
      }
      // Backfill monthly_interest_rate from daily for existing loans
      try {
        await db.execute('UPDATE loans SET monthly_interest_rate = daily_interest_rate * 30 WHERE monthly_interest_rate = 0 OR monthly_interest_rate IS NULL;');
      } catch (_) {}
    }
    // v9 upgrades
    if (oldVersion < 5) {
      for (final sql in [
        'ALTER TABLE loans ADD COLUMN loan_type TEXT NOT NULL DEFAULT "emi";',
        'ALTER TABLE settings ADD COLUMN morning_reminder_enabled INTEGER NOT NULL DEFAULT 0;',
        'ALTER TABLE settings ADD COLUMN reminder_hour INTEGER NOT NULL DEFAULT 8;',
      ]) {
        try { await db.execute(sql); } catch (_) {}
      }
    }
    // v9.1 upgrades
    if (oldVersion < 6) {
      for (final sql in [
        'ALTER TABLE settings ADD COLUMN quotes_custom_path TEXT NOT NULL DEFAULT "";',
      ]) {
        try { await db.execute(sql); } catch (_) {}
      }
    }
  }

  Future<void> close() async {
    if (_database != null) { await _database!.close(); _database = null; }
  }

  Future<void> deleteAllData() async {
    final db = await database;
    await db.delete('edit_history');
    await db.delete('sms_logs');
    await db.delete('transaction_logs');
    await db.delete('collection_entries');
    await db.delete('schedule_entries');
    await db.delete('loans');
    await db.delete('customers');
  }
}
