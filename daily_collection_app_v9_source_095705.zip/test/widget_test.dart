// Placeholder test — widget_test.dart hata diya (flutter create ka default test
// MyApp reference karta tha jo hamari app mein exist nahi karta).
// Baad mein asli unit tests yahan add kiye ja sakte hain.
import 'package:flutter_test/flutter_test.dart';

void main() {
  test('placeholder', () {
    expect(1 + 1, 2);
  });
}
