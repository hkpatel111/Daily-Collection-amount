class AppSettings {
  final int id;
  int gracePeriodDays;
  bool sundayHolidayEnabled;
  int defaultedThresholdDays;
  bool smsEnabled;
  bool smsOnPayment;
  bool smsOnMissed;
  bool smsOnCompletion;
  bool smsOnPreclosure;
  bool smsAutoSend;
  String ownerName;
  bool darkMode;
  int autoBackupDays;
  String collectionPriority;
  bool appLockEnabled;
  String appPin;
  bool gDriveBackupEnabled;
  bool lateFeeEnabled;
  double lateFeePerDay;
  int autoReminderDays;
  String themeColor;
  // New in v8
  String customBackupPath;
  bool biometricEnabled;

  AppSettings({
    this.id = 1,
    this.gracePeriodDays = 1,
    this.sundayHolidayEnabled = false,
    this.defaultedThresholdDays = 15,
    this.smsEnabled = true,
    this.smsOnPayment = true,
    this.smsOnMissed = true,
    this.smsOnCompletion = true,
    this.smsOnPreclosure = true,
    this.smsAutoSend = false,
    this.ownerName = '',
    this.darkMode = false,
    this.autoBackupDays = 7,
    this.collectionPriority = 'fifo',
    this.appLockEnabled = false,
    this.appPin = '',
    this.gDriveBackupEnabled = false,
    this.lateFeeEnabled = false,
    this.lateFeePerDay = 10.0,
    this.autoReminderDays = 3,
    this.themeColor = 'blue',
    this.customBackupPath = '',
    this.biometricEnabled = false,
  });

  Map<String, dynamic> toMap() {
    return {
      'id': id,
      'grace_period_days': gracePeriodDays,
      'sunday_holiday_enabled': sundayHolidayEnabled ? 1 : 0,
      'defaulted_threshold_days': defaultedThresholdDays,
      'sms_enabled': smsEnabled ? 1 : 0,
      'sms_on_payment': smsOnPayment ? 1 : 0,
      'sms_on_missed': smsOnMissed ? 1 : 0,
      'sms_on_completion': smsOnCompletion ? 1 : 0,
      'sms_on_preclosure': smsOnPreclosure ? 1 : 0,
      'sms_auto_send': smsAutoSend ? 1 : 0,
      'owner_name': ownerName,
      'dark_mode': darkMode ? 1 : 0,
      'auto_backup_days': autoBackupDays,
      'collection_priority': collectionPriority,
      'app_lock_enabled': appLockEnabled ? 1 : 0,
      'app_pin': appPin,
      'gdrive_backup_enabled': gDriveBackupEnabled ? 1 : 0,
      'late_fee_enabled': lateFeeEnabled ? 1 : 0,
      'late_fee_per_day': lateFeePerDay,
      'auto_reminder_days': autoReminderDays,
      'theme_color': themeColor,
      'custom_backup_path': customBackupPath,
      'biometric_enabled': biometricEnabled ? 1 : 0,
    };
  }

  factory AppSettings.fromMap(Map<String, dynamic> map) {
    return AppSettings(
      id: map['id'] as int? ?? 1,
      gracePeriodDays: map['grace_period_days'] as int? ?? 1,
      sundayHolidayEnabled: (map['sunday_holiday_enabled'] as int? ?? 0) == 1,
      defaultedThresholdDays: map['defaulted_threshold_days'] as int? ?? 15,
      smsEnabled: (map['sms_enabled'] as int? ?? 1) == 1,
      smsOnPayment: (map['sms_on_payment'] as int? ?? 1) == 1,
      smsOnMissed: (map['sms_on_missed'] as int? ?? 1) == 1,
      smsOnCompletion: (map['sms_on_completion'] as int? ?? 1) == 1,
      smsOnPreclosure: (map['sms_on_preclosure'] as int? ?? 1) == 1,
      smsAutoSend: (map['sms_auto_send'] as int? ?? 0) == 1,
      ownerName: map['owner_name'] as String? ?? '',
      darkMode: (map['dark_mode'] as int? ?? 0) == 1,
      autoBackupDays: map['auto_backup_days'] as int? ?? 7,
      collectionPriority: map['collection_priority'] as String? ?? 'fifo',
      appLockEnabled: (map['app_lock_enabled'] as int? ?? 0) == 1,
      appPin: map['app_pin'] as String? ?? '',
      gDriveBackupEnabled: (map['gdrive_backup_enabled'] as int? ?? 0) == 1,
      lateFeeEnabled: (map['late_fee_enabled'] as int? ?? 0) == 1,
      lateFeePerDay: (map['late_fee_per_day'] as num?)?.toDouble() ?? 10.0,
      autoReminderDays: map['auto_reminder_days'] as int? ?? 3,
      themeColor: map['theme_color'] as String? ?? 'blue',
      customBackupPath: map['custom_backup_path'] as String? ?? '',
      biometricEnabled: (map['biometric_enabled'] as int? ?? 0) == 1,
    );
  }

  AppSettings copyWith({
    int? id, int? gracePeriodDays, bool? sundayHolidayEnabled,
    int? defaultedThresholdDays, bool? smsEnabled, bool? smsOnPayment,
    bool? smsOnMissed, bool? smsOnCompletion, bool? smsOnPreclosure,
    bool? smsAutoSend, String? ownerName, bool? darkMode,
    int? autoBackupDays, String? collectionPriority, bool? appLockEnabled,
    String? appPin, bool? gDriveBackupEnabled, bool? lateFeeEnabled,
    double? lateFeePerDay, int? autoReminderDays, String? themeColor,
    String? customBackupPath, bool? biometricEnabled,
  }) {
    return AppSettings(
      id: id ?? this.id,
      gracePeriodDays: gracePeriodDays ?? this.gracePeriodDays,
      sundayHolidayEnabled: sundayHolidayEnabled ?? this.sundayHolidayEnabled,
      defaultedThresholdDays: defaultedThresholdDays ?? this.defaultedThresholdDays,
      smsEnabled: smsEnabled ?? this.smsEnabled,
      smsOnPayment: smsOnPayment ?? this.smsOnPayment,
      smsOnMissed: smsOnMissed ?? this.smsOnMissed,
      smsOnCompletion: smsOnCompletion ?? this.smsOnCompletion,
      smsOnPreclosure: smsOnPreclosure ?? this.smsOnPreclosure,
      smsAutoSend: smsAutoSend ?? this.smsAutoSend,
      ownerName: ownerName ?? this.ownerName,
      darkMode: darkMode ?? this.darkMode,
      autoBackupDays: autoBackupDays ?? this.autoBackupDays,
      collectionPriority: collectionPriority ?? this.collectionPriority,
      appLockEnabled: appLockEnabled ?? this.appLockEnabled,
      appPin: appPin ?? this.appPin,
      gDriveBackupEnabled: gDriveBackupEnabled ?? this.gDriveBackupEnabled,
      lateFeeEnabled: lateFeeEnabled ?? this.lateFeeEnabled,
      lateFeePerDay: lateFeePerDay ?? this.lateFeePerDay,
      autoReminderDays: autoReminderDays ?? this.autoReminderDays,
      themeColor: themeColor ?? this.themeColor,
      customBackupPath: customBackupPath ?? this.customBackupPath,
      biometricEnabled: biometricEnabled ?? this.biometricEnabled,
    );
  }
}
