enum LoanStatus {
  active, overdue, preClosed, completed, defaulted, cancelled;

  String get label {
    switch (this) {
      case LoanStatus.active: return 'Active';
      case LoanStatus.overdue: return 'Overdue';
      case LoanStatus.preClosed: return 'Pre-Closed';
      case LoanStatus.completed: return 'Completed';
      case LoanStatus.defaulted: return 'Defaulted';
      case LoanStatus.cancelled: return 'Cancelled';
    }
  }

  String get dbValue {
    switch (this) {
      case LoanStatus.active: return 'active';
      case LoanStatus.overdue: return 'overdue';
      case LoanStatus.preClosed: return 'pre_closed';
      case LoanStatus.completed: return 'completed';
      case LoanStatus.defaulted: return 'defaulted';
      case LoanStatus.cancelled: return 'cancelled';
    }
  }

  static LoanStatus fromDbValue(String value) {
    switch (value) {
      case 'active': return LoanStatus.active;
      case 'overdue': return LoanStatus.overdue;
      case 'pre_closed': return LoanStatus.preClosed;
      case 'completed': return LoanStatus.completed;
      case 'defaulted': return LoanStatus.defaulted;
      case 'cancelled': return LoanStatus.cancelled;
      default: return LoanStatus.active;
    }
  }
}

enum InterestType {
  simple, compound;

  String get label {
    switch (this) {
      case InterestType.simple: return 'Simple Interest';
      case InterestType.compound: return 'Compound Interest';
    }
  }

  String get dbValue {
    switch (this) {
      case InterestType.simple: return 'simple';
      case InterestType.compound: return 'compound';
    }
  }

  static InterestType fromDbValue(String? value) {
    switch (value) {
      case 'compound': return InterestType.compound;
      default: return InterestType.simple;
    }
  }
}

enum InstallmentFrequency {
  daily, weekly, monthly, quarterly, yearly;

  String get label {
    switch (this) {
      case InstallmentFrequency.daily: return 'Daily';
      case InstallmentFrequency.weekly: return 'Weekly';
      case InstallmentFrequency.monthly: return 'Monthly';
      case InstallmentFrequency.quarterly: return 'Quarterly';
      case InstallmentFrequency.yearly: return 'Yearly';
    }
  }

  String get dbValue {
    switch (this) {
      case InstallmentFrequency.daily: return 'daily';
      case InstallmentFrequency.weekly: return 'weekly';
      case InstallmentFrequency.monthly: return 'monthly';
      case InstallmentFrequency.quarterly: return 'quarterly';
      case InstallmentFrequency.yearly: return 'yearly';
    }
  }

  int get daysPerPeriod {
    switch (this) {
      case InstallmentFrequency.daily: return 1;
      case InstallmentFrequency.weekly: return 7;
      case InstallmentFrequency.monthly: return 30;
      case InstallmentFrequency.quarterly: return 90;
      case InstallmentFrequency.yearly: return 365;
    }
  }

  static InstallmentFrequency fromDbValue(String? value) {
    switch (value) {
      case 'weekly': return InstallmentFrequency.weekly;
      case 'monthly': return InstallmentFrequency.monthly;
      case 'quarterly': return InstallmentFrequency.quarterly;
      case 'yearly': return InstallmentFrequency.yearly;
      default: return InstallmentFrequency.daily;
    }
  }
}

enum CompoundingFrequency {
  monthly, quarterly, halfYearly, yearly;

  String get label {
    switch (this) {
      case CompoundingFrequency.monthly: return 'Monthly';
      case CompoundingFrequency.quarterly: return 'Quarterly';
      case CompoundingFrequency.halfYearly: return 'Half-Yearly';
      case CompoundingFrequency.yearly: return 'Yearly';
    }
  }

  String get dbValue {
    switch (this) {
      case CompoundingFrequency.monthly: return 'monthly';
      case CompoundingFrequency.quarterly: return 'quarterly';
      case CompoundingFrequency.halfYearly: return 'half_yearly';
      case CompoundingFrequency.yearly: return 'yearly';
    }
  }

  int get timesPerYear {
    switch (this) {
      case CompoundingFrequency.monthly: return 12;
      case CompoundingFrequency.quarterly: return 4;
      case CompoundingFrequency.halfYearly: return 2;
      case CompoundingFrequency.yearly: return 1;
    }
  }

  static CompoundingFrequency fromDbValue(String? value) {
    switch (value) {
      case 'monthly': return CompoundingFrequency.monthly;
      case 'half_yearly': return CompoundingFrequency.halfYearly;
      case 'yearly': return CompoundingFrequency.yearly;
      default: return CompoundingFrequency.quarterly; // default as requested
    }
  }
}

class Loan {
  final int? id;
  final int customerId;
  final double principal;
  double returnAmount;
  final double installmentAmount; // renamed conceptually from dailyInstallment
  final int totalInstallments;    // total number of installments
  final double profit;
  final double monthlyInterestRate; // primary rate stored
  final String startDate;
  final String endDate;
  LoanStatus status;
  final double lastInstallmentAdjustedAmount;
  final String createdAt;
  String loanTag;
  String? accountName;

  // New fields for v8
  final InterestType interestType;
  final InstallmentFrequency installmentFrequency;
  final CompoundingFrequency compoundingFrequency;
  final double dailyInterestRate; // kept for compatibility & calculations

  Loan({
    this.id,
    required this.customerId,
    required this.principal,
    required this.returnAmount,
    required this.installmentAmount,
    required this.totalInstallments,
    required this.profit,
    required this.monthlyInterestRate,
    required this.startDate,
    required this.endDate,
    this.status = LoanStatus.active,
    required this.lastInstallmentAdjustedAmount,
    required this.createdAt,
    this.loanTag = '',
    this.accountName,
    this.interestType = InterestType.simple,
    this.installmentFrequency = InstallmentFrequency.daily,
    this.compoundingFrequency = CompoundingFrequency.quarterly,
    double? dailyInterestRate,
  }) : dailyInterestRate = dailyInterestRate ?? (monthlyInterestRate / 30);

  // Backward compatibility getters
  double get dailyInstallment => installmentAmount;
  int get totalDays => totalInstallments;
  double get lastDayAdjustedAmount => lastInstallmentAdjustedAmount;
  double get yearlyInterestRate => monthlyInterestRate * 12;

  Map<String, dynamic> toMap() {
    return {
      'id': id,
      'customer_id': customerId,
      'principal': principal,
      'return_amount': returnAmount,
      'daily_installment': installmentAmount, // keep column name for migration ease
      'total_days': totalInstallments,
      'profit': profit,
      'daily_interest_rate': dailyInterestRate,
      'monthly_interest_rate': monthlyInterestRate,
      'start_date': startDate,
      'end_date': endDate,
      'status': status.dbValue,
      'last_day_adjusted_amount': lastInstallmentAdjustedAmount,
      'created_at': createdAt,
      'loan_tag': loanTag,
      'account_name': accountName,
      'interest_type': interestType.dbValue,
      'installment_frequency': installmentFrequency.dbValue,
      'compounding_frequency': compoundingFrequency.dbValue,
    };
  }

  factory Loan.fromMap(Map<String, dynamic> map) {
    final monthlyRate = (map['monthly_interest_rate'] as num?)?.toDouble() ??
        ((map['daily_interest_rate'] as num?)?.toDouble() ?? 0) * 30;

    return Loan(
      id: map['id'] as int?,
      customerId: map['customer_id'] as int,
      principal: (map['principal'] as num).toDouble(),
      returnAmount: (map['return_amount'] as num).toDouble(),
      installmentAmount: (map['daily_installment'] as num).toDouble(),
      totalInstallments: map['total_days'] as int,
      profit: (map['profit'] as num).toDouble(),
      monthlyInterestRate: monthlyRate,
      startDate: map['start_date'] as String,
      endDate: map['end_date'] as String,
      status: LoanStatus.fromDbValue(map['status'] as String),
      lastInstallmentAdjustedAmount: (map['last_day_adjusted_amount'] as num).toDouble(),
      createdAt: map['created_at'] as String,
      loanTag: map['loan_tag'] as String? ?? '',
      accountName: map['account_name'] as String?,
      interestType: InterestType.fromDbValue(map['interest_type'] as String?),
      installmentFrequency: InstallmentFrequency.fromDbValue(map['installment_frequency'] as String?),
      compoundingFrequency: CompoundingFrequency.fromDbValue(map['compounding_frequency'] as String?),
      dailyInterestRate: (map['daily_interest_rate'] as num?)?.toDouble(),
    );
  }

  Loan copyWith({
    int? id,
    int? customerId,
    double? principal,
    double? returnAmount,
    double? installmentAmount,
    int? totalInstallments,
    double? profit,
    double? monthlyInterestRate,
    String? startDate,
    String? endDate,
    LoanStatus? status,
    double? lastInstallmentAdjustedAmount,
    String? createdAt,
    String? loanTag,
    String? accountName,
    InterestType? interestType,
    InstallmentFrequency? installmentFrequency,
    CompoundingFrequency? compoundingFrequency,
    double? dailyInterestRate,
  }) {
    return Loan(
      id: id ?? this.id,
      customerId: customerId ?? this.customerId,
      principal: principal ?? this.principal,
      returnAmount: returnAmount ?? this.returnAmount,
      installmentAmount: installmentAmount ?? this.installmentAmount,
      totalInstallments: totalInstallments ?? this.totalInstallments,
      profit: profit ?? this.profit,
      monthlyInterestRate: monthlyInterestRate ?? this.monthlyInterestRate,
      startDate: startDate ?? this.startDate,
      endDate: endDate ?? this.endDate,
      status: status ?? this.status,
      lastInstallmentAdjustedAmount: lastInstallmentAdjustedAmount ?? this.lastInstallmentAdjustedAmount,
      createdAt: createdAt ?? this.createdAt,
      loanTag: loanTag ?? this.loanTag,
      accountName: accountName ?? this.accountName,
      interestType: interestType ?? this.interestType,
      installmentFrequency: installmentFrequency ?? this.installmentFrequency,
      compoundingFrequency: compoundingFrequency ?? this.compoundingFrequency,
      dailyInterestRate: dailyInterestRate ?? this.dailyInterestRate,
    );
  }
}
