import 'dart:io';
import 'dart:math';
import 'package:path_provider/path_provider.dart';
import 'package:path/path.dart' as p;

class QuotesService {
  static const String _fileName = 'funny_quotes.txt';

  static const List<String> _defaultQuotes = [
    'East aur West, Prithvi Banna is the Best!',
    'Jay Johar ka nara hai, Bharat desh humara hai... aur collection bhi humara hai!',
    'Jab tak suraj chaand rahega, Prithvi Banna ka naam rahega!',
    'Paisa bolta hai... lekin kabhi-kabhi chillata bhi hai "Wapas kar do!"',
    'Loan diya hai toh tension mat lo... tension customer ko do!',
    'Udhhar dena asaan hai, wapas lena art hai.',
    'Aaj ka collection kal ka tension kam karta hai.',
    'Customer bolta hai "kal dunga", kal bolta hai "parso dunga"... ant mein bolta hai "bhool gaya".',
    'Byaj toh lagta hai, lekin dil pe nahi... hisaab pe lagta hai.',
    'Jo time pe paise de, usko Rab bhi maaf kar de... hum toh bilkul kar denge!',
    'Collection nahi hua toh gussa mat karo... bas mild reminder bhej do.',
    'Zindagi mein do cheezein sure hain — Death aur Daily Collection.',
    'Customer se rishta nibhana hai toh hisaab saaf rakhna hai.',
    'Aaj ka pending, kal ka headache.',
    'Prithvi Banna ka rule: Trust is good, but written schedule is better.',
  ];

  Future<String> _getQuotesFilePath({String? customPath}) async {
    if (customPath != null && customPath.isNotEmpty) {
      final dir = Directory(customPath);
      if (!await dir.exists()) {
        await dir.create(recursive: true);
      }
      return p.join(customPath, _fileName);
    }
    // Fallback to app documents
    final dir = await getApplicationDocumentsDirectory();
    return p.join(dir.path, _fileName);
  }

  Future<List<String>> getQuotes({String? customPath}) async {
    try {
      final path = await _getQuotesFilePath(customPath: customPath);
      final file = File(path);
      if (!await file.exists()) {
        await _writeDefaultQuotes(file);
        return List.from(_defaultQuotes);
      }
      final content = await file.readAsString();
      final lines = content
          .split('\n')
          .map((e) => e.trim())
          .where((e) => e.isNotEmpty && !e.startsWith('#'))
          .toList();
      if (lines.isEmpty) {
        await _writeDefaultQuotes(file);
        return List.from(_defaultQuotes);
      }
      return lines;
    } catch (_) {
      return List.from(_defaultQuotes);
    }
  }

  Future<String> getRandomQuote({String? customPath}) async {
    final quotes = await getQuotes(customPath: customPath);
    if (quotes.isEmpty) return _defaultQuotes.first;
    final index = Random().nextInt(quotes.length);
    return quotes[index];
  }

  Future<void> _writeDefaultQuotes(File file) async {
    final buffer = StringBuffer();
    buffer.writeln('# Daily Collection App - Funny Quotes');
    buffer.writeln('# Aap is file ko edit kar sakte ho. Har line ek quote hogi.');
    buffer.writeln('# Khali line aur # se start hone wali lines ignore hongi.');
    buffer.writeln('');
    for (final q in _defaultQuotes) {
      buffer.writeln(q);
    }
    await file.writeAsString(buffer.toString());
  }

  Future<void> ensureQuotesFileExists({String? customPath}) async {
    final path = await _getQuotesFilePath(customPath: customPath);
    final file = File(path);
    if (!await file.exists()) {
      await _writeDefaultQuotes(file);
    }
  }
}
