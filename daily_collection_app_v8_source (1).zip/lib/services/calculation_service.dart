import '../models/loan.dart';

class CalcResult {
  final int totalInstallments;
  final double profit;
  final double dailyInterestRate;
  final double monthlyInterestRate;
  final double yearlyInterestRate;
  final String endDate;
  final double lastInstallmentAdjustedAmount;
  final double installmentAmount;
  final double returnAmount;
  final InterestType interestType;
  final InstallmentFrequency frequency;
  final CompoundingFrequency compoundingFrequency;
  final String compoundingLabel;

  CalcResult({
    required this.totalInstallments,
    required this.profit,
    required this.dailyInterestRate,
    required this.monthlyInterestRate,
    required this.yearlyInterestRate,
    required this.endDate,
    required this.lastInstallmentAdjustedAmount,
    required this.installmentAmount,
    required this.returnAmount,
    required this.interestType,
    required this.frequency,
    required this.compoundingFrequency,
    required this.compoundingLabel,
  });

  // Backward compatibility
  int get totalDays => totalInstallments;
  double get lastDayAdjustedAmount => lastInstallmentAdjustedAmount;
}

class CalculationService {
  static String today() {
    final now = DateTime.now();
    return '${now.year}-${now.month.toString().padLeft(2, '0')}-${now.day.toString().padLeft(2, '0')}';
  }

  static String now() {
    final now = DateTime.now();
    return '${now.year}-${now.month.toString().padLeft(2, '0')}-${now.day.toString().padLeft(2, '0')} '
           '${now.hour.toString().padLeft(2, '0')}:${now.minute.toString().padLeft(2, '0')}:${now.second.toString().padLeft(2, '0')}';
  }

  static String formatDate(String date) {
    if (date.length < 10) return date;
    final parts = date.substring(0, 10).split('-');
    if (parts.length != 3) return date;
    return '${parts[2]}/${parts[1]}/${parts[0]}';
  }

  static String formatDateTime(String dt) {
    if (dt.length < 10) return dt;
    final datePart = dt.substring(0, 10);
    final timePart = dt.length > 10 ? dt.substring(11) : '';
    return '${formatDate(datePart)} $timePart';
  }

  static String formatCurrency(double amount) {
    bool isNegative = amount < 0;
    amount = amount.abs();
    int rupees = amount.toInt();
    String rupeeStr = rupees.toString();
    if (rupeeStr.length > 3) {
      final sb = StringBuffer();
      int count = 0;
      for (int i = rupeeStr.length - 1; i >= 0; i--) {
        if (count == 3) { sb.write(','); count = 1; }
        else if (count > 0 && count % 2 == 0) { sb.write(','); }
        sb.write(rupeeStr[i]);
        count++;
      }
      rupeeStr = sb.toString().split('').reversed.join();
    }
    return 'Rs $rupeeStr${isNegative ? ' (Dr)' : ''}';
  }

  static int daysBetween(String startDate, String endDate) {
    final start = DateTime.parse(startDate);
    final end = DateTime.parse(endDate);
    return end.difference(start).inDays;
  }

  // ==================== NEW FLEXIBLE LOAN CALCULATION ====================

  /// Main flexible calculator used by Add Customer / Loan Create screen.
  /// Supports Simple & Compound, multiple frequencies, live reverse calculation.
  static CalcResult calculateFlexibleLoan({
    required double principal,
    required double monthlyRatePercent, // e.g. 2.0 for 2%
    required int numberOfInstallments,
    required InstallmentFrequency frequency,
    required InterestType interestType,
    required CompoundingFrequency compoundingFrequency,
    required String startDate,
    double? fixedInstallmentAmount, // if user enters installment amount instead
    double? fixedReturnAmount,      // if user enters total return
  }) {
    if (principal <= 0) {
      return _emptyResult(startDate, interestType, frequency, compoundingFrequency);
    }

    final periodsPerYear = _periodsPerYear(frequency);
    final monthlyRate = monthlyRatePercent / 100.0;
    final yearlyRate = monthlyRate * 12;

    double returnAmount;
    double installmentAmount;
    double profit;
    int totalInstallments = numberOfInstallments;

    if (interestType == InterestType.simple) {
      // Simple Interest
      // Interest for whole tenure based on monthly rate
      final totalMonthsApprox = _totalMonths(frequency, totalInstallments);
      final totalInterest = principal * monthlyRate * totalMonthsApprox;
      returnAmount = principal + totalInterest;
      profit = totalInterest;

      if (fixedReturnAmount != null && fixedReturnAmount > principal) {
        returnAmount = fixedReturnAmount;
        profit = returnAmount - principal;
      }

      installmentAmount = returnAmount / totalInstallments;
      if (fixedInstallmentAmount != null && fixedInstallmentAmount > 0) {
        installmentAmount = fixedInstallmentAmount;
        // reverse: adjust totalInstallments or returnAmount
        if (numberOfInstallments <= 0) {
          totalInstallments = (returnAmount / installmentAmount).ceil();
        }
      }
    } else {
      // Compound Interest
      final n = compoundingFrequency.timesPerYear.toDouble();
      final t = _totalYears(frequency, totalInstallments);
      final rate = yearlyRate; // annual decimal

      // A = P (1 + r/n)^(n*t)
      final amount = principal * powDouble(1 + (rate / n), n * t);
      returnAmount = amount;
      profit = returnAmount - principal;

      if (fixedReturnAmount != null && fixedReturnAmount > principal) {
        returnAmount = fixedReturnAmount;
        profit = returnAmount - principal;
      }

      installmentAmount = returnAmount / totalInstallments;
      if (fixedInstallmentAmount != null && fixedInstallmentAmount > 0) {
        installmentAmount = fixedInstallmentAmount;
      }
    }

    // Last installment adjustment
    final lastAdjusted = (returnAmount - (installmentAmount * (totalInstallments - 1))).roundToDouble();
    final dailyRate = (monthlyRatePercent / 30);

    final endDate = _calculateEndDate(startDate, frequency, totalInstallments);
    final compoundingLabel = interestType == InterestType.compound
        ? 'Compounded ${compoundingFrequency.label}'
        : 'Simple Interest';

    return CalcResult(
      totalInstallments: totalInstallments,
      profit: profit,
      dailyInterestRate: dailyRate,
      monthlyInterestRate: monthlyRatePercent,
      yearlyInterestRate: monthlyRatePercent * 12,
      endDate: endDate,
      lastInstallmentAdjustedAmount: lastAdjusted,
      installmentAmount: installmentAmount,
      returnAmount: returnAmount,
      interestType: interestType,
      frequency: frequency,
      compoundingFrequency: compoundingFrequency,
      compoundingLabel: compoundingLabel,
    );
  }

  /// Backward compatible method (old daily style)
  static CalcResult calculateLoan({
    required double principal,
    required double returnAmount,
    required double dailyInstallment,
    required String startDate,
  }) {
    if (principal <= 0 || returnAmount <= principal || dailyInstallment <= 0) {
      return _emptyResult(startDate, InterestType.simple, InstallmentFrequency.daily, CompoundingFrequency.quarterly);
    }
    final profit = returnAmount - principal;
    final exactDays = returnAmount / dailyInstallment;
    final totalDays = exactDays.ceil();
    final lastDayAdjustedAmount = (returnAmount - (dailyInstallment * (totalDays - 1))).roundToDouble();
    final dailyInterestRate = (profit / (principal * totalDays)) * 100;
    final monthlyInterestRate = dailyInterestRate * 30;
    final yearlyInterestRate = dailyInterestRate * 365;
    final endDate = _calculateEndDate(startDate, InstallmentFrequency.daily, totalDays);

    return CalcResult(
      totalInstallments: totalDays,
      profit: profit,
      dailyInterestRate: dailyInterestRate,
      monthlyInterestRate: monthlyInterestRate,
      yearlyInterestRate: yearlyInterestRate,
      endDate: endDate,
      lastInstallmentAdjustedAmount: lastDayAdjustedAmount,
      installmentAmount: dailyInstallment,
      returnAmount: returnAmount,
      interestType: InterestType.simple,
      frequency: InstallmentFrequency.daily,
      compoundingFrequency: CompoundingFrequency.quarterly,
      compoundingLabel: 'Simple Interest',
    );
  }

  static double calculateOverdueInterest({
    required double overduePrincipal,
    required double dailyInterestRate,
    required int daysOverdue,
    required int gracePeriodDays,
  }) {
    if (daysOverdue <= gracePeriodDays || overduePrincipal <= 0) return 0.0;
    final effectiveDays = daysOverdue - gracePeriodDays;
    return (overduePrincipal * dailyInterestRate / 100) * effectiveDays;
  }

  static double calculateLateFee({
    required int daysMissed,
    required double lateFeePerDay,
    required bool enabled,
  }) {
    if (!enabled || daysMissed <= 0) return 0.0;
    return daysMissed * lateFeePerDay;
  }

  // ==================== OUTSTANDING SNAPSHOT ====================

  static double calculateOutstandingAsOnDate({
    required double returnAmount,
    required double totalCollected,
    required double overdueInterest,
    required double lateFee,
  }) {
    final outstanding = returnAmount - totalCollected + overdueInterest + lateFee;
    return outstanding < 0 ? 0 : outstanding;
  }

  // ==================== HELPERS ====================

  static double pow(double base, int exp) {
    double result = 1.0;
    for (int i = 0; i < exp; i++) result *= base;
    return result;
  }

  static double powDouble(double base, double exponent) {
    if (base <= 0) return 0;
    // Simple approximation using exp & ln via iterative method for positive numbers
    // For production quality we use dart:math, but keep self-contained
    return _powApprox(base, exponent);
  }

  static double _powApprox(double base, double exp) {
    // Using identity: x^y = e^(y * ln(x))
    // Simple series for ln and exp (good enough for financial calc)
    if (exp == 0) return 1;
    if (base == 1) return 1;
    final ln = _ln(base);
    return _exp(exp * ln);
  }

  static double _ln(double x) {
    // Natural log approximation (Mercator series around 1)
    if (x <= 0) return 0;
    double y = (x - 1) / (x + 1);
    double y2 = y * y;
    double result = 0;
    double term = y;
    for (int i = 1; i <= 20; i += 2) {
      result += term / i;
      term *= y2;
    }
    return 2 * result;
  }

  static double _exp(double x) {
    // Taylor series
    double result = 1;
    double term = 1;
    for (int i = 1; i <= 20; i++) {
      term *= x / i;
      result += term;
    }
    return result;
  }

  static int _periodsPerYear(InstallmentFrequency freq) {
    switch (freq) {
      case InstallmentFrequency.daily: return 365;
      case InstallmentFrequency.weekly: return 52;
      case InstallmentFrequency.monthly: return 12;
      case InstallmentFrequency.quarterly: return 4;
      case InstallmentFrequency.yearly: return 1;
    }
  }

  static double _totalMonths(InstallmentFrequency freq, int installments) {
    switch (freq) {
      case InstallmentFrequency.daily: return installments / 30.0;
      case InstallmentFrequency.weekly: return installments * 7 / 30.0;
      case InstallmentFrequency.monthly: return installments.toDouble();
      case InstallmentFrequency.quarterly: return installments * 3.0;
      case InstallmentFrequency.yearly: return installments * 12.0;
    }
  }

  static double _totalYears(InstallmentFrequency freq, int installments) {
    return _totalMonths(freq, installments) / 12.0;
  }

  static String _calculateEndDate(String startDate, InstallmentFrequency freq, int installments) {
    final start = DateTime.parse(startDate);
    DateTime end;
    switch (freq) {
      case InstallmentFrequency.daily:
        end = start.add(Duration(days: installments - 1));
        break;
      case InstallmentFrequency.weekly:
        end = start.add(Duration(days: (installments - 1) * 7));
        break;
      case InstallmentFrequency.monthly:
        end = DateTime(start.year, start.month + installments - 1, start.day);
        break;
      case InstallmentFrequency.quarterly:
        end = DateTime(start.year, start.month + (installments - 1) * 3, start.day);
        break;
      case InstallmentFrequency.yearly:
        end = DateTime(start.year + installments - 1, start.month, start.day);
        break;
    }
    return '${end.year}-${end.month.toString().padLeft(2, '0')}-${end.day.toString().padLeft(2, '0')}';
  }

  static CalcResult _emptyResult(String startDate, InterestType type, InstallmentFrequency freq, CompoundingFrequency comp) {
    return CalcResult(
      totalInstallments: 0,
      profit: 0,
      dailyInterestRate: 0,
      monthlyInterestRate: 0,
      yearlyInterestRate: 0,
      endDate: startDate,
      lastInstallmentAdjustedAmount: 0,
      installmentAmount: 0,
      returnAmount: 0,
      interestType: type,
      frequency: freq,
      compoundingFrequency: comp,
      compoundingLabel: type == InterestType.compound ? 'Compounded ${comp.label}' : 'Simple Interest',
    );
  }

  // ==================== EXISTING CALCULATORS (kept & improved) ====================

  static Map<String, double> calculateEMI(double principal, double annualRate, int months) {
    if (principal <= 0 || months <= 0) return {'emi': 0, 'total': 0, 'interest': 0};
    final monthlyRate = annualRate / 12 / 100;
    if (monthlyRate == 0) {
      final emi = principal / months;
      return {'emi': emi, 'total': emi * months, 'interest': 0};
    }
    final emi = principal * monthlyRate * pow(1 + monthlyRate, months) / (pow(1 + monthlyRate, months) - 1);
    return {'emi': emi, 'total': emi * months, 'interest': emi * months - principal};
  }

  static Map<String, double> calculateSIP(double monthlyInvestment, double annualRate, int years) {
    if (monthlyInvestment <= 0 || years <= 0) return {'maturity': 0, 'invested': 0, 'gain': 0};
    final monthlyRate = annualRate / 12 / 100;
    final months = years * 12;
    if (monthlyRate == 0) {
      return {'maturity': monthlyInvestment * months, 'invested': monthlyInvestment * months, 'gain': 0};
    }
    final maturity = monthlyInvestment * ((pow(1 + monthlyRate, months) - 1) / monthlyRate) * (1 + monthlyRate);
    return {'maturity': maturity, 'invested': monthlyInvestment * months, 'gain': maturity - monthlyInvestment * months};
  }

  static Map<String, double> calculateFutureValue(double presentValue, double annualRate, int years) {
    final future = presentValue * powDouble(1 + annualRate / 100, years.toDouble());
    return {'future': future, 'gain': future - presentValue};
  }

  static double calculateRateOfReturn(double invested, double currentValue, int years) {
    if (invested <= 0 || years <= 0) return 0;
    return (powDouble(currentValue / invested, 1.0 / years) - 1) * 100;
  }

  static Map<String, double> calculateSimpleInterest(double principal, double rate, double timeYears, {bool monthly = false}) {
    final t = monthly ? timeYears / 12 : timeYears;
    final interest = principal * rate * t / 100;
    return {'interest': interest, 'total': principal + interest};
  }

  static Map<String, double> calculateCompoundInterest(double principal, double rate, double years, int freqPerYear) {
    final amount = principal * powDouble(1 + rate / (100 * freqPerYear), years * freqPerYear);
    return {'amount': amount, 'interest': amount - principal};
  }

  static Map<String, double> calculateProfitMargin(double cost, double sellingPrice) {
    if (cost <= 0) return {'profit': 0, 'margin': 0};
    final profit = sellingPrice - cost;
    final margin = (profit / cost) * 100;
    return {'profit': profit, 'margin': margin};
  }

  static int calculateCreditScore({
    required int completedLoans,
    required int overdueCount,
    required int missedPayments,
  }) {
    int score = 50 + (completedLoans * 10) - (overdueCount * 15) - (missedPayments * 5);
    if (score < 0) score = 0;
    if (score > 100) score = 100;
    return score;
  }
}
