import '../models/loan.dart';
import '../models/schedule_entry.dart';
import '../models/collection_entry.dart';
import '../models/settings.dart';
import '../models/transaction_log.dart';
import '../models/edit_history.dart';
import '../database/dao/loan_dao.dart';
import '../database/dao/schedule_dao.dart';
import '../database/dao/collection_dao.dart';
import '../database/dao/settings_dao.dart';
import '../database/dao/customer_dao.dart';
import '../database/dao/transaction_log_dao.dart';
import '../database/dao/edit_history_dao.dart';
import 'calculation_service.dart';

enum ExcessOption { nextInstallment, principalAdjust, separateEntry }

class ScheduleService {
  final LoanDao _loanDao = LoanDao();
  final ScheduleDao _scheduleDao = ScheduleDao();
  final CollectionDao _collectionDao = CollectionDao();
  final SettingsDao _settingsDao = SettingsDao();
  final CustomerDao _customerDao = CustomerDao();
  final TransactionLogDao _logDao = TransactionLogDao();
  final EditHistoryDao _editHistoryDao = EditHistoryDao();

  Future<void> generateSchedule(Loan loan, AppSettings settings) async {
    final entries = <ScheduleEntry>[];
    DateTime date = DateTime.parse(loan.startDate);
    for (int day = 1; day <= loan.totalDays; day++) {
      // Sunday skip: due date ko next working day par shift karo
      if (settings.sundayHolidayEnabled && date.weekday == DateTime.sunday) {
        date = date.add(const Duration(days: 1));
      }
      double expected = day == loan.totalDays ? loan.lastDayAdjustedAmount : loan.dailyInstallment;
      entries.add(ScheduleEntry(
        loanId: loan.id!, dayNumber: day,
        scheduledDate: '${date.year}-${date.month.toString().padLeft(2, '0')}-${date.day.toString().padLeft(2, '0')}',
        expectedAmount: expected, isHoliday: false,
        status: ScheduleEntryStatus.pending,
        createdAt: CalculationService.now(),
      ));
      // Frequency-aware next due date (v9 fix: monthly/weekly ab sahi)
      date = _advanceDate(date, loan.installmentFrequency);
    }
    await _scheduleDao.insertBatch(entries);
    final customer = await _customerDao.getById(loan.customerId);
    await _logDao.insert(TransactionLog(
      actionType: 'schedule_generated', description: 'Schedule generated for Loan #${loan.id} (${customer?.name ?? ''}) — ${loan.installmentFrequency.label}',
      loanId: loan.id, customerId: loan.customerId, customerName: customer?.name, createdAt: CalculationService.now(),
    ));
  }

  /// Next installment date — frequency ke hisaab se (v9)
  DateTime _advanceDate(DateTime date, InstallmentFrequency freq) {
    switch (freq) {
      case InstallmentFrequency.daily:
        return date.add(const Duration(days: 1));
      case InstallmentFrequency.weekly:
        return date.add(const Duration(days: 7));
      case InstallmentFrequency.monthly:
        return DateTime(date.year, date.month + 1, date.day);
      case InstallmentFrequency.quarterly:
        return DateTime(date.year, date.month + 3, date.day);
      case InstallmentFrequency.yearly:
        return DateTime(date.year + 1, date.month, date.day);
    }
  }

  Future<void> recordCollection({
    required int loanId, required ScheduleEntry scheduleEntry,
    required double collectedAmount, required PaymentMode paymentMode,
    ExcessOption? excessOption,
  }) async {
    final loan = await _loanDao.getById(loanId);
    if (loan == null) return;
    final settings = await _settingsDao.getSettings();

    double actualCollected = collectedAmount;
    double shortfall = 0;
    double overdueInterest = 0;
    double excess = 0;

    if (collectedAmount < scheduleEntry.expectedAmount) {
      shortfall = scheduleEntry.expectedAmount - collectedAmount;
    } else if (collectedAmount > scheduleEntry.expectedAmount) {
      excess = collectedAmount - scheduleEntry.expectedAmount;
    }

    // Handle excess
    if (excess > 0 && excessOption != null) {
      switch (excessOption) {
        case ExcessOption.nextInstallment:
          // Find next pending entry and reduce its expected amount
          final nextEntry = await _scheduleDao.getByLoanIdAndDay(loanId, scheduleEntry.dayNumber + 1);
          if (nextEntry != null && nextEntry.status == ScheduleEntryStatus.pending) {
            final newExpected = (nextEntry.expectedAmount - excess).clamp(0.0, double.infinity);
            await _scheduleDao.update(nextEntry.copyWith(expectedAmount: newExpected));
          }
          break;
        case ExcessOption.principalAdjust:
          // Reduce return amount by excess — entry still recorded
          final newReturn = (loan.returnAmount - excess).clamp(0.0, double.infinity);
          await _loanDao.update(loan.copyWith(returnAmount: newReturn));
          break;
        case ExcessOption.separateEntry:
          // Keep as separate — don't adjust anything
          break;
      }
    }

    final entry = CollectionEntry(
      loanId: loanId, scheduleEntryId: scheduleEntry.id!,
      collectionDate: CalculationService.today(), expectedAmount: scheduleEntry.expectedAmount,
      collectedAmount: actualCollected, shortfall: shortfall,
      overdueInterest: overdueInterest, paymentMode: paymentMode,
      createdAt: CalculationService.now(), updatedAt: CalculationService.now(),
    );
    await _collectionDao.insert(entry);

    ScheduleEntryStatus newStatus = collectedAmount >= scheduleEntry.expectedAmount
      ? ScheduleEntryStatus.paid : ScheduleEntryStatus.partial;
    if (shortfall > 0) newStatus = ScheduleEntryStatus.partial;
    await _scheduleDao.updateStatus(scheduleEntry.id!, newStatus);

    final customer = await _customerDao.getById(loan.customerId);
    await _logDao.insert(TransactionLog(
      actionType: 'collection', description: 'Collection Rs ${collectedAmount.toStringAsFixed(0)} for Day ${scheduleEntry.dayNumber} (${customer?.name ?? ''})',
      loanId: loanId, customerId: loan.customerId, customerName: customer?.name,
      amount: collectedAmount, createdAt: CalculationService.now(),
    ));

    // Check if loan is completed
    final totalCollected = await _collectionDao.getTotalCollectedByLoan(loanId);
    if (totalCollected >= loan.returnAmount) {
      await _loanDao.updateStatus(loanId, LoanStatus.completed);
      await _scheduleDao.cancelPendingByLoan(loanId);
      await _logDao.insert(TransactionLog(
        actionType: 'loan_completed', description: 'Loan #${loanId} completed (${customer?.name ?? ''})',
        loanId: loanId, customerId: loan.customerId, customerName: customer?.name,
        amount: totalCollected, createdAt: CalculationService.now(),
      ));
    }
  }

  Future<void> editCollectionEntry(int entryId, double newAmount, String newDate, PaymentMode newMode) async {
    final entry = await _collectionDao.getById(entryId);
    if (entry == null) return;
    final now = CalculationService.now();

    if (entry.collectedAmount != newAmount) {
      await _editHistoryDao.insert(EditHistory(
        collectionEntryId: entryId, fieldName: 'collected_amount',
        oldValue: entry.collectedAmount.toStringAsFixed(2), newValue: newAmount.toStringAsFixed(2), editedAt: now,
      ));
    }
    if (entry.collectionDate != newDate) {
      await _editHistoryDao.insert(EditHistory(
        collectionEntryId: entryId, fieldName: 'collection_date',
        oldValue: entry.collectionDate, newValue: newDate, editedAt: now,
      ));
    }
    if (entry.paymentMode != newMode) {
      await _editHistoryDao.insert(EditHistory(
        collectionEntryId: entryId, fieldName: 'payment_mode',
        oldValue: entry.paymentMode.label, newValue: newMode.label, editedAt: now,
      ));
    }

    await _collectionDao.update(entry.copyWith(
      collectedAmount: newAmount, collectionDate: newDate, paymentMode: newMode, updatedAt: now,
    ));

    // Update schedule entry status
    final scheduleEntry = await _scheduleDao.getById(entry.scheduleEntryId);
    if (scheduleEntry != null) {
      if (newAmount >= scheduleEntry.expectedAmount) {
        await _scheduleDao.updateStatus(scheduleEntry.id!, ScheduleEntryStatus.paid);
      } else if (newAmount > 0) {
        await _scheduleDao.updateStatus(scheduleEntry.id!, ScheduleEntryStatus.partial);
      } else {
        await _scheduleDao.updateStatus(scheduleEntry.id!, ScheduleEntryStatus.pending);
      }
    }

    await _logDao.insert(TransactionLog(
      actionType: 'edit_collection', description: 'Collection entry #${entryId} edited to Rs ${newAmount.toStringAsFixed(0)}',
      loanId: entry.loanId, amount: newAmount, createdAt: now,
    ));
  }

  Future<void> deleteCollectionEntry(int entryId) async {
    final entry = await _collectionDao.getById(entryId);
    if (entry == null) return;
    final scheduleEntry = await _scheduleDao.getById(entry.scheduleEntryId);
    if (scheduleEntry != null) {
      await _scheduleDao.updateStatus(scheduleEntry.id!, ScheduleEntryStatus.pending);
    }
    await _collectionDao.delete(entryId);
    await _logDao.insert(TransactionLog(
      actionType: 'delete_collection', description: 'Collection entry #${entryId} deleted (Rs ${entry.collectedAmount.toStringAsFixed(0)})',
      loanId: entry.loanId, amount: entry.collectedAmount, createdAt: CalculationService.now(),
    ));
  }

  Future<void> updateOverdueInterest(int loanId, Loan loan, AppSettings settings) async {
    final overdueEntries = await _scheduleDao.getOverdueEntries(loanId);
    for (final entry in overdueEntries) {
      final daysOverdue = CalculationService.daysBetween(entry.scheduledDate, CalculationService.today());
      if (daysOverdue > settings.gracePeriodDays) {
        final interest = CalculationService.calculateOverdueInterest(
          overduePrincipal: entry.expectedAmount, dailyInterestRate: loan.dailyInterestRate,
          daysOverdue: daysOverdue, gracePeriodDays: settings.gracePeriodDays,
        );
        final lateFee = CalculationService.calculateLateFee(
          daysMissed: daysOverdue - settings.gracePeriodDays,
          lateFeePerDay: settings.lateFeePerDay, enabled: settings.lateFeeEnabled,
        );
        final existing = await _collectionDao.getByScheduleEntryId(entry.id!);
        if (existing.isEmpty) {
          await _collectionDao.insert(CollectionEntry(
            loanId: loanId, scheduleEntryId: entry.id!, collectionDate: CalculationService.today(),
            expectedAmount: entry.expectedAmount, collectedAmount: 0, shortfall: entry.expectedAmount,
            isMissed: true, overdueInterest: interest + lateFee,
            paymentMode: PaymentMode.cash, createdAt: CalculationService.now(), updatedAt: CalculationService.now(),
          ));
          await _scheduleDao.updateStatus(entry.id!, ScheduleEntryStatus.missed);
        }
      }
    }
  }

  /// ==================== LOAN RENEWAL / EXTENSION (v9) ====================
  /// Loan ko extend karo — extra installments add hongi, return amount badhega,
  /// naye schedule entries last date ke aage generate hongi.
  Future<bool> extendLoan({
    required int loanId,
    required int extraInstallments,
    double? newInstallmentAmount,
  }) async {
    final loan = await _loanDao.getById(loanId);
    if (loan == null || extraInstallments <= 0) return false;
    final settings = await _settingsDao.getSettings();

    final inst = (newInstallmentAmount != null && newInstallmentAmount > 0)
        ? newInstallmentAmount : loan.installmentAmount;
    final newTotal = loan.totalInstallments + extraInstallments;
    final newReturn = loan.returnAmount + (inst * extraInstallments);
    final lastAdjusted = (newReturn - (inst * (newTotal - 1))).roundToDouble();

    // Last scheduled entry dhundo
    final schedule = await _scheduleDao.getByLoanId(loanId);
    ScheduleEntry? lastEntry;
    for (final e in schedule) {
      if (lastEntry == null || e.dayNumber > lastEntry.dayNumber) lastEntry = e;
    }
    DateTime nextDate = lastEntry != null
        ? _advanceDate(DateTime.parse(lastEntry.scheduledDate), loan.installmentFrequency)
        : DateTime.parse(loan.startDate);

    final entries = <ScheduleEntry>[];
    for (int i = 1; i <= extraInstallments; i++) {
      if (settings.sundayHolidayEnabled && nextDate.weekday == DateTime.sunday) {
        nextDate = nextDate.add(const Duration(days: 1));
      }
      final day = loan.totalInstallments + i;
      final expected = i == extraInstallments ? lastAdjusted : inst;
      entries.add(ScheduleEntry(
        loanId: loanId, dayNumber: day,
        scheduledDate: '${nextDate.year}-${nextDate.month.toString().padLeft(2, '0')}-${nextDate.day.toString().padLeft(2, '0')}',
        expectedAmount: expected, isHoliday: false,
        status: ScheduleEntryStatus.pending,
        createdAt: CalculationService.now(),
      ));
      nextDate = _advanceDate(nextDate, loan.installmentFrequency);
    }
    await _scheduleDao.insertBatch(entries);

    // Loan update karo
    final newEndDate = entries.last.scheduledDate;
    await _loanDao.update(loan.copyWith(
      totalInstallments: newTotal,
      returnAmount: newReturn,
      installmentAmount: inst,
      lastInstallmentAdjustedAmount: lastAdjusted,
      endDate: newEndDate,
      status: LoanStatus.active,
    ));

    final customer = await _customerDao.getById(loan.customerId);
    await _logDao.insert(TransactionLog(
      actionType: 'loan_extended',
      description: 'Loan #$loanId extended by $extraInstallments installments — New return Rs ${newReturn.toStringAsFixed(0)} (${customer?.name ?? ''})',
      loanId: loanId, customerId: loan.customerId, customerName: customer?.name,
      amount: newReturn, createdAt: CalculationService.now(),
    ));
    return true;
  }

  Future<void> preCloseLoan(int loanId) async {
    final loan = await _loanDao.getById(loanId);
    if (loan == null) return;
    await _scheduleDao.cancelPendingByLoan(loanId);
    await _loanDao.updateStatus(loanId, LoanStatus.preClosed);
    final customer = await _customerDao.getById(loan.customerId);
    await _logDao.insert(TransactionLog(
      actionType: 'pre_close', description: 'Loan #${loanId} pre-closed (${customer?.name ?? ''})',
      loanId: loanId, customerId: loan.customerId, customerName: customer?.name, createdAt: CalculationService.now(),
    ));
  }

  Future<void> cancelLoan(int loanId) async {
    final loan = await _loanDao.getById(loanId);
    if (loan == null) return;
    await _scheduleDao.cancelPendingByLoan(loanId);
    await _loanDao.updateStatus(loanId, LoanStatus.cancelled);
    final customer = await _customerDao.getById(loan.customerId);
    await _logDao.insert(TransactionLog(
      actionType: 'cancel_loan', description: 'Loan #${loanId} cancelled (${customer?.name ?? ''})',
      loanId: loanId, customerId: loan.customerId, customerName: customer?.name, createdAt: CalculationService.now(),
    ));
  }

  List<ScheduleEntry> sortEntries(List<ScheduleEntry> entries, ScheduleSortOrder order) {
    final sorted = List<ScheduleEntry>.from(entries);
    switch (order) {
      case ScheduleSortOrder.newToOld:
        sorted.sort((a, b) => b.dayNumber.compareTo(a.dayNumber));
        break;
      case ScheduleSortOrder.oldToNew:
        sorted.sort((a, b) => a.dayNumber.compareTo(b.dayNumber));
        break;
      case ScheduleSortOrder.paidFirst:
        sorted.sort((a, b) {
          int aRank = a.status == ScheduleEntryStatus.paid ? 0 : 1;
          int bRank = b.status == ScheduleEntryStatus.paid ? 0 : 1;
          return aRank.compareTo(bRank);
        });
        break;
      case ScheduleSortOrder.unpaidFirst:
        sorted.sort((a, b) {
          int aRank = a.status != ScheduleEntryStatus.paid ? 0 : 1;
          int bRank = b.status != ScheduleEntryStatus.paid ? 0 : 1;
          return aRank.compareTo(bRank);
        });
        break;
      case ScheduleSortOrder.pendingFirst:
        sorted.sort((a, b) {
          int aRank = a.status == ScheduleEntryStatus.pending ? 0 : 1;
          int bRank = b.status == ScheduleEntryStatus.pending ? 0 : 1;
          return aRank.compareTo(bRank);
        });
        break;
      case ScheduleSortOrder.missedFirst:
        sorted.sort((a, b) {
          int aRank = a.status == ScheduleEntryStatus.missed ? 0 : 1;
          int bRank = b.status == ScheduleEntryStatus.missed ? 0 : 1;
          return aRank.compareTo(bRank);
        });
        break;
    }
    return sorted;
  }
}
