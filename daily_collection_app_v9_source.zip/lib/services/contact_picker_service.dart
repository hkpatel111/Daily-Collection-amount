import 'package:flutter_contacts/flutter_contacts.dart';
import '../models/customer.dart';

/// v9.1: Phone contact list se customer pick karne ki service.
class ContactPickerService {
  /// Pehle permission maango, phir contact picker kholo.
  /// Returns: selected contact ya null (cancel/denied).
  Future<Customer?> pickContact() async {
    // Permission check + request
    if (!await flutter_contacts.hasPermission) {
      if (!await flutter_contacts.requestPermission()) {
        return null; // denied
      }
    }

    // Full contact picker kholo (system UI)
    final contact = await flutter_contacts.pickContact();
    if (contact == null) return null; // user ne cancel kiya

    // Phones fetch karo (picker minimal data deta hai)
    final full = await flutter_contacts.getContact(contact.id);
    final name = full?.displayName ?? contact.displayName ?? '';
    String mobile = '';
    if (full?.phones.isNotEmpty ?? false) {
      mobile = full!.phones.first.number.replaceAll(RegExp(r'[^0-9+]'), '');
      // +91 / 91 prefix strip karo (10-digit rakho)
      if (mobile.startsWith('+91')) mobile = mobile.substring(3);
      if (mobile.startsWith('91') && mobile.length > 10) mobile = mobile.substring(2);
      mobile = mobile.trim();
    }

    if (name.isEmpty || mobile.isEmpty) return null;

    return Customer(name: name, mobile: mobile, createdAt: '');
  }
}
