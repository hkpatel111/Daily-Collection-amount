import 'package:flutter_local_notifications/flutter_local_notifications.dart';
import 'package:timezone/data/latest.dart' as tz;
import 'package:timezone/timezone.dart' as tz;
import '../database/dao/schedule_dao.dart';
import '../database/dao/settings_dao.dart';
import '../models/schedule_entry.dart';
import '../services/calculation_service.dart';

/// v9: Morning reminder — roz subah pending collections ka local notification.
class LocalReminderService {
  static final LocalReminderService _instance = LocalReminderService._internal();
  factory LocalReminderService() => _instance;
  LocalReminderService._internal();

  final FlutterLocalNotificationsPlugin _plugin = FlutterLocalNotificationsPlugin();
  bool _initialized = false;

  Future<void> init() async {
    if (_initialized) return;
    tz.initializeTimeZones();
    // India default (user base India mein hai)
    try {
      tz.setLocalLocation(tz.getLocation('Asia/Kolkata'));
    } catch (_) {}
    const androidInit = AndroidInitializationSettings('@mipmap/ic_launcher');
    const initSettings = InitializationSettings(android: androidInit);
    await _plugin.initialize(initSettings);
    _initialized = true;
  }

  /// Roz reminder_hour baje daily repeat hota notification schedule karo.
  Future<void> scheduleDailyReminder() async {
    await init();
    final settings = await SettingsDao().getSettings();
    if (!settings.morningReminderEnabled) return;

    final hour = settings.reminderHour.clamp(0, 23);
    final now = tz.TZDateTime.now(tz.local);
    var scheduled = tz.TZDateTime(tz.local, now.year, now.month, now.day, hour);
    if (scheduled.isBefore(now)) {
      scheduled = scheduled.add(const Duration(days: 1));
    }

    const androidDetails = AndroidNotificationDetails(
      'morning_reminder',
      'Morning Collection Reminder',
      channelDescription: 'Roz subah pending collections ka reminder',
      importance: Importance.high,
      priority: Priority.high,
      ongoing: false,
      autoCancel: true,
    );
    const details = NotificationDetails(android: androidDetails);

    // Pending count fetch karke body mein dikhao
    final today = CalculationService.today();
    final pending = await ScheduleDao().getByDate(today);

    await _plugin.zonedSchedule(
      1001,
      'Daily Collection Reminder',
      pending.isEmpty
          ? 'Aaj koi collection pending nahi hai. Shubhkamnayein!'
          : 'Aaj ${pending.length} collection(s) pending hain. Hisaab check karein!',
      scheduled,
      details,
      uiLocalNotificationDateInterpretation: UILocalNotificationDateInterpretation.absoluteTime,
      androidScheduleMode: AndroidScheduleMode.inexactAllowWhileIdle,
      matchDateTimeComponents: DateTimeComponents.time,
      payload: 'daily_reminder',
    );
  }

  Future<void> cancelReminder() async {
    await _plugin.cancel(1001);
  }

  /// Settings toggle hone par turant call hota hai.
  Future<void> syncReminderFromSettings() async {
    final settings = await SettingsDao().getSettings();
    if (settings.morningReminderEnabled) {
      await scheduleDailyReminder();
    } else {
      await cancelReminder();
    }
  }
}
