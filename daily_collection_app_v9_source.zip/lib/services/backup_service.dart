import 'dart:convert';
import 'dart:io';
import 'package:path_provider/path_provider.dart';
import 'package:path/path.dart' as p;
import 'package:share_plus/share_plus.dart';
import 'package:excel/excel.dart';
import '../database/database_helper.dart';

class BackupResult {
  final bool success;
  final String message;
  final String? filePath;
  BackupResult({required this.success, required this.message, this.filePath});
}

class BackupService {
  final DatabaseHelper _dbHelper = DatabaseHelper();

  Future<BackupResult> exportData() async {
    try {
      final db = await _dbHelper.database;
      final data = <String, dynamic>{};
      data['customers'] = await db.query('customers');
      data['loans'] = await db.query('loans');
      data['schedule_entries'] = await db.query('schedule_entries');
      data['collection_entries'] = await db.query('collection_entries');
      data['transaction_logs'] = await db.query('transaction_logs');
      data['sms_logs'] = await db.query('sms_logs');
      data['edit_history'] = await db.query('edit_history');
      data['settings'] = await db.query('settings');
      final jsonString = const JsonEncoder.withIndent('  ').convert(data);
      final dir = await getApplicationDocumentsDirectory();
      final timestamp = DateTime.now().millisecondsSinceEpoch;
      final file = File(p.join(dir.path, 'backup_$timestamp.json'));
      await file.writeAsString(jsonString);
      return BackupResult(success: true, message: 'Backup created successfully', filePath: file.path);
    } catch (e) {
      return BackupResult(success: false, message: 'Backup failed: $e');
    }
  }

  Future<BackupResult> importData(String filePath) async {
    try {
      final file = File(filePath);
      final jsonString = await file.readAsString();
      final data = json.decode(jsonString) as Map<String, dynamic>;
      await _dbHelper.deleteAllData();
      final db = await _dbHelper.database;
      for (final table in data.keys) {
        final rows = data[table] as List;
        for (final row in rows) {
          try { await db.insert(table, row as Map<String, dynamic>); } catch (_) {}
        }
      }
      return BackupResult(success: true, message: 'Data imported successfully');
    } catch (e) {
      return BackupResult(success: false, message: 'Import failed: $e');
    }
  }

  Future<BackupResult> exportCsv() async {
    try {
      final db = await _dbHelper.database;
      final loans = await db.rawQuery('''SELECT l.id, c.name as customer_name, c.mobile, l.principal, l.return_amount,
        l.daily_installment, l.total_days, l.profit, l.daily_interest_rate, l.start_date, l.end_date, l.status, l.loan_tag
        FROM loans l LEFT JOIN customers c ON l.customer_id = c.id ORDER BY l.created_at DESC''');
      final sb = StringBuffer();
      sb.writeln('Loan ID,Customer,Mobile,Principal,Return Amount,Daily Installment,Total Days,Profit,Daily Rate,Start Date,End Date,Status,Tag');
      for (final loan in loans) {
        sb.writeln('${loan['id']},${loan['customer_name']},${loan['mobile']},${loan['principal']},'
          '${loan['return_amount']},${loan['daily_installment']},${loan['total_days']},${loan['profit']},'
          '${loan['daily_interest_rate']},${loan['start_date']},${loan['end_date']},${loan['status']},${loan['loan_tag']}');
      }
      final dir = await getApplicationDocumentsDirectory();
      final file = File(p.join(dir.path, 'loans_export_${DateTime.now().millisecondsSinceEpoch}.csv'));
      await file.writeAsString(sb.toString());
      return BackupResult(success: true, message: 'CSV exported', filePath: file.path);
    } catch (e) {
      return BackupResult(success: false, message: 'CSV export failed: $e');
    }
  }

  /// v9: Excel (.xlsx) export — Loans + Collections sheets
  Future<BackupResult> exportExcel() async {
    try {
      final db = await _dbHelper.database;
      final loans = await db.rawQuery('''SELECT l.id, c.name as customer_name, c.mobile, l.principal, l.return_amount,
        l.daily_installment, l.total_days, l.profit, l.interest_type, l.installment_frequency, l.loan_type,
        l.start_date, l.end_date, l.status, l.loan_tag
        FROM loans l LEFT JOIN customers c ON l.customer_id = c.id ORDER BY l.created_at DESC''');
      final collections = await db.rawQuery('''SELECT ce.id, c.name as customer_name, ce.loan_id, ce.collection_date,
        ce.expected_amount, ce.collected_amount, ce.shortfall, ce.payment_mode
        FROM collection_entries ce LEFT JOIN loans l ON ce.loan_id = l.id
        LEFT JOIN customers c ON l.customer_id = c.id ORDER BY ce.collection_date DESC''');

      final excel = Excel.createExcel();
      final loansSheet = excel['Loans'];
      loansSheet.appendRow([
        TextCellValue('Loan ID'), TextCellValue('Customer'), TextCellValue('Mobile'),
        TextCellValue('Principal'), TextCellValue('Return Amount'), TextCellValue('Installment'),
        TextCellValue('Installments'), TextCellValue('Profit'), TextCellValue('Loan Type'),
        TextCellValue('Interest'), TextCellValue('Frequency'), TextCellValue('Start'),
        TextCellValue('End'), TextCellValue('Status'), TextCellValue('Tag'),
      ]);
      for (final l in loans) {
        loansSheet.appendRow([
          TextCellValue('${l['id']}'), TextCellValue('${l['customer_name'] ?? ''}'), TextCellValue('${l['mobile'] ?? ''}'),
          DoubleCellValue((l['principal'] as num?)?.toDouble() ?? 0),
          DoubleCellValue((l['return_amount'] as num?)?.toDouble() ?? 0),
          DoubleCellValue((l['daily_installment'] as num?)?.toDouble() ?? 0),
          IntCellValue((l['total_days'] as num?)?.toInt() ?? 0),
          DoubleCellValue((l['profit'] as num?)?.toDouble() ?? 0),
          TextCellValue('${l['loan_type'] ?? 'emi'}'), TextCellValue('${l['interest_type'] ?? ''}'),
          TextCellValue('${l['installment_frequency'] ?? ''}'), TextCellValue('${l['start_date'] ?? ''}'),
          TextCellValue('${l['end_date'] ?? ''}'), TextCellValue('${l['status'] ?? ''}'),
          TextCellValue('${l['loan_tag'] ?? ''}'),
        ]);
      }

      final collSheet = excel['Collections'];
      collSheet.appendRow([
        TextCellValue('ID'), TextCellValue('Customer'), TextCellValue('Loan ID'), TextCellValue('Date'),
        TextCellValue('Expected'), TextCellValue('Collected'), TextCellValue('Shortfall'), TextCellValue('Mode'),
      ]);
      for (final c in collections) {
        collSheet.appendRow([
          TextCellValue('${c['id']}'), TextCellValue('${c['customer_name'] ?? ''}'),
          TextCellValue('${c['loan_id'] ?? ''}'), TextCellValue('${c['collection_date'] ?? ''}'),
          DoubleCellValue((c['expected_amount'] as num?)?.toDouble() ?? 0),
          DoubleCellValue((c['collected_amount'] as num?)?.toDouble() ?? 0),
          DoubleCellValue((c['shortfall'] as num?)?.toDouble() ?? 0),
          TextCellValue('${c['payment_mode'] ?? ''}'),
        ]);
      }

      try { excel.delete('Sheet1'); } catch (_) {}
      try { excel.setDefaultSheet('Loans'); } catch (_) {}

      final bytes = excel.encode()!;
      final dir = await getApplicationDocumentsDirectory();
      final file = File(p.join(dir.path, 'daily_collection_${DateTime.now().millisecondsSinceEpoch}.xlsx'));
      await file.writeAsBytes(bytes);
      return BackupResult(success: true, message: 'Excel exported', filePath: file.path);
    } catch (e) {
      return BackupResult(success: false, message: 'Excel export failed: $e');
    }
  }

  Future<BackupResult> exportLoanSummary(int loanId) async {
    try {
      final db = await _dbHelper.database;
      final loanData = await db.rawQuery('SELECT l.*, c.name as customer_name, c.mobile FROM loans l JOIN customers c ON l.customer_id = c.id WHERE l.id = ?', [loanId]);
      if (loanData.isEmpty) return BackupResult(success: false, message: 'Loan not found');
      final collections = await db.query('collection_entries', where: 'loan_id = ?', whereArgs: [loanId]);
      final sb = StringBuffer();
      sb.writeln('LOAN SUMMARY');
      sb.writeln('Loan ID: ${loanData[0]['id']}');
      sb.writeln('Customer: ${loanData[0]['customer_name']}');
      sb.writeln('Mobile: ${loanData[0]['mobile']}');
      sb.writeln('Principal: Rs ${loanData[0]['principal']}');
      sb.writeln('Return Amount: Rs ${loanData[0]['return_amount']}');
      sb.writeln('Daily Installment: Rs ${loanData[0]['daily_installment']}');
      sb.writeln('Total Days: ${loanData[0]['total_days']}');
      sb.writeln('Profit: Rs ${loanData[0]['profit']}');
      sb.writeln('Daily Rate: ${(loanData[0]['daily_interest_rate'] as num).toStringAsFixed(3)}%');
      sb.writeln('Monthly Rate: ${((loanData[0]['daily_interest_rate'] as num) * 30).toStringAsFixed(3)}%');
      sb.writeln('Yearly Rate: ${((loanData[0]['daily_interest_rate'] as num) * 365).toStringAsFixed(3)}%');
      sb.writeln('Start: ${loanData[0]['start_date']}  End: ${loanData[0]['end_date']}');
      sb.writeln('Status: ${loanData[0]['status']}');
      sb.writeln('\nCOLLECTIONS:');
      sb.writeln('Date,Expected,Collected,Shortfall,Mode');
      double totalCollected = 0;
      for (final c in collections) {
        sb.writeln('${c['collection_date']},${c['expected_amount']},${c['collected_amount']},${c['shortfall']},${c['payment_mode']}');
        totalCollected += (c['collected_amount'] as num).toDouble();
      }
      sb.writeln('\nTotal Collected: Rs $totalCollected');
      final remaining = (loanData[0]['return_amount'] as num).toDouble() - totalCollected;
      sb.writeln('Remaining: Rs $remaining');
      final dir = await getApplicationDocumentsDirectory();
      final file = File(p.join(dir.path, 'loan_${loanId}_summary.txt'));
      await file.writeAsString(sb.toString());
      return BackupResult(success: true, message: 'Summary exported', filePath: file.path);
    } catch (e) {
      return BackupResult(success: false, message: 'Export failed: $e');
    }
  }

  Future<BackupResult> exportCustomerSummary(int customerId) async {
    try {
      final db = await _dbHelper.database;
      final customer = await db.query('customers', where: 'id = ?', whereArgs: [customerId]);
      if (customer.isEmpty) return BackupResult(success: false, message: 'Customer not found');
      final loans = await db.query('loans', where: 'customer_id = ?', whereArgs: [customerId]);
      final sb = StringBuffer();
      sb.writeln('CUSTOMER SUMMARY');
      sb.writeln('Name: ${customer[0]['name']}');
      sb.writeln('Mobile: ${customer[0]['mobile']}');
      if (customer[0]['nickname'] != null) sb.writeln('Nickname: ${customer[0]['nickname']}');
      sb.writeln('\nLOANS:');
      double totalGiven = 0, totalCollected = 0;
      for (final loan in loans) {
        final collections = await db.query('collection_entries', where: 'loan_id = ?', whereArgs: [loan['id']]);
        double collected = 0;
        for (final c in collections) collected += (c['collected_amount'] as num).toDouble();
        totalCollected += collected;
        totalGiven += (loan['principal'] as num).toDouble();
        sb.writeln('\n  Loan #${loan['id']}: ${(loan['principal'])} -> ${(loan['return_amount'])} | ${loan['status']} | Collected: Rs $collected');
      }
      sb.writeln('\nTotal Given: Rs $totalGiven');
      sb.writeln('Total Collected: Rs $totalCollected');
      final dir = await getApplicationDocumentsDirectory();
      final file = File(p.join(dir.path, 'customer_${customerId}_summary.txt'));
      await file.writeAsString(sb.toString());
      return BackupResult(success: true, message: 'Summary exported', filePath: file.path);
    } catch (e) {
      return BackupResult(success: false, message: 'Export failed: $e');
    }
  }

  Future<BackupResult> exportTransactionLog({String? searchQuery}) async {
    try {
      final db = await _dbHelper.database;
      String sql = '''SELECT t.*, c.name as customer_name, c.mobile as customer_mobile
        FROM transaction_logs t LEFT JOIN customers c ON t.customer_id = c.id''';
      List<dynamic> args = [];
      if (searchQuery != null && searchQuery.isNotEmpty) {
        sql += ' WHERE c.name LIKE ? OR c.mobile LIKE ? OR t.description LIKE ? OR CAST(t.amount AS TEXT) LIKE ?';
        args = ['%$searchQuery%', '%$searchQuery%', '%$searchQuery%', '%$searchQuery%'];
      }
      sql += ' ORDER BY t.created_at DESC';
      final logs = await db.rawQuery(sql, args);
      final sb = StringBuffer();
      sb.writeln('TRANSACTION LOG');
      sb.writeln('Date,Type,Customer,Description,Amount');
      for (final log in logs) {
        sb.writeln('${log['created_at']},${log['action_type']},${log['customer_name'] ?? ''},${log['description']},${log['amount'] ?? ''}');
      }
      final dir = await getApplicationDocumentsDirectory();
      final file = File(p.join(dir.path, 'transaction_log_${DateTime.now().millisecondsSinceEpoch}.txt'));
      await file.writeAsString(sb.toString());
      return BackupResult(success: true, message: 'Log exported', filePath: file.path);
    } catch (e) {
      return BackupResult(success: false, message: 'Export failed: $e');
    }
  }

  Future<BackupResult> exportMonthlyReport(int year, int month) async {
    try {
      final db = await _dbHelper.database;
      final startDate = '$year-${month.toString().padLeft(2, '0')}-01';
      final endMonth = month == 12 ? 1 : month + 1;
      final endYear = month == 12 ? year + 1 : year;
      final endDate = '$endYear-${endMonth.toString().padLeft(2, '0')}-01';
      final collections = await db.rawQuery('SELECT * FROM collection_entries WHERE collection_date >= ? AND collection_date < ?', [startDate, endDate]);
      final newLoans = await db.rawQuery('SELECT * FROM loans WHERE created_at >= ? AND created_at < ?', [startDate, endDate]);
      double totalCollected = 0;
      for (final c in collections) totalCollected += (c['collected_amount'] as num).toDouble();
      double totalGiven = 0;
      for (final l in newLoans) totalGiven += (l['principal'] as num).toDouble();
      double totalProfit = 0;
      for (final l in newLoans) totalProfit += (l['profit'] as num).toDouble();
      final sb = StringBuffer();
      sb.writeln('MONTHLY REPORT - ${month.toString().padLeft(2, '0')}/$year');
      sb.writeln('Total Collections: Rs $totalCollected');
      sb.writeln('New Loans Given: Rs $totalGiven');
      sb.writeln('Expected Profit (new): Rs $totalProfit');
      sb.writeln('Total Collections count: ${collections.length}');
      sb.writeln('New Loans count: ${newLoans.length}');
      final dir = await getApplicationDocumentsDirectory();
      final file = File(p.join(dir.path, 'monthly_report_${year}_${month}.txt'));
      await file.writeAsString(sb.toString());
      return BackupResult(success: true, message: 'Monthly report exported', filePath: file.path);
    } catch (e) {
      return BackupResult(success: false, message: 'Export failed: $e');
    }
  }

  Future<BackupResult> exportYearlyTaxSummary(int year) async {
    try {
      final db = await _dbHelper.database;
      final fyStart = '$year-04-01';
      final fyEnd = '${year + 1}-04-01';
      final loans = await db.rawQuery('SELECT * FROM loans WHERE created_at >= ? AND created_at < ?', [fyStart, fyEnd]);
      final collections = await db.rawQuery('SELECT * FROM collection_entries WHERE collection_date >= ? AND collection_date < ?', [fyStart, fyEnd]);
      double totalProfit = 0, totalCollected = 0, totalGiven = 0;
      for (final l in loans) {
        totalProfit += (l['profit'] as num).toDouble();
        totalGiven += (l['principal'] as num).toDouble();
      }
      for (final c in collections) totalCollected += (c['collected_amount'] as num).toDouble();
      final sb = StringBuffer();
      sb.writeln('YEARLY TAX SUMMARY - FY $year-${year + 1}');
      sb.writeln('Total Loans Given: Rs $totalGiven');
      sb.writeln('Total Collected: Rs $totalCollected');
      sb.writeln('Total Expected Profit: Rs $totalProfit');
      sb.writeln('Total Loans: ${loans.length}');
      sb.writeln('\nLOAN-WISE BREAKUP:');
      for (final l in loans) {
        sb.writeln('  Loan #${l['id']}: Principal ${(l['principal'])}, Profit ${(l['profit'])}, Status ${l['status']}');
      }
      final dir = await getApplicationDocumentsDirectory();
      final file = File(p.join(dir.path, 'tax_summary_$year.txt'));
      await file.writeAsString(sb.toString());
      return BackupResult(success: true, message: 'Tax summary exported', filePath: file.path);
    } catch (e) {
      return BackupResult(success: false, message: 'Export failed: $e');
    }
  }
}
