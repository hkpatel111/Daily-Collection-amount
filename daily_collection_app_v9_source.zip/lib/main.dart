import 'package:flutter/material.dart';
import 'app.dart';
import 'services/local_reminder_service.dart';

void main() {
  WidgetsFlutterBinding.ensureInitialized();
  // v9: Morning reminder schedule sync (agar enabled hai)
  LocalReminderService().syncReminderFromSettings().catchError((_) {});
  runApp(const DailyCollectionApp());
}
