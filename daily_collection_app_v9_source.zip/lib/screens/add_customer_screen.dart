import 'package:flutter/material.dart';
import '../utils/constants.dart';
import '../utils/validators.dart';
import '../models/customer.dart';
import '../models/loan.dart';
import '../database/dao/customer_dao.dart';
import '../database/dao/loan_dao.dart';
import '../database/dao/settings_dao.dart';
import '../services/calculation_service.dart';
import '../services/schedule_service.dart';

class AddCustomerScreen extends StatefulWidget {
  final String? prefillName;
  final String? prefillMobile;
  final int? existingCustomerId; // v9: existing customer ke liye naya loan
  const AddCustomerScreen({super.key, this.prefillName, this.prefillMobile, this.existingCustomerId});

  @override
  State<AddCustomerScreen> createState() => _AddCustomerScreenState();
}

class _AddCustomerScreenState extends State<AddCustomerScreen> {
  final _formKey = GlobalKey<FormState>();
  final _nameController = TextEditingController();
  final _mobileController = TextEditingController();
  final _nicknameController = TextEditingController();
  final _principalController = TextEditingController();
  final _monthlyRateController = TextEditingController(text: '2');
  final _installmentsController = TextEditingController(text: '12');
  final _installmentAmountController = TextEditingController();
  final _returnController = TextEditingController();
  final _tagController = TextEditingController();
  final _accountNameController = TextEditingController();

  DateTime _selectedDate = DateTime.now();
  bool _isSaving = false;

  // v9: EMI vs INTEREST loan type — 2 bullet toggle
  LoanType _loanType = LoanType.emi;
  InterestType _interestType = InterestType.simple;
  InstallmentFrequency _frequency = InstallmentFrequency.monthly;
  CompoundingFrequency _compounding = CompoundingFrequency.quarterly;

  final CustomerDao _customerDao = CustomerDao();
  final LoanDao _loanDao = LoanDao();
  final SettingsDao _settingsDao = SettingsDao();
  final ScheduleService _scheduleService = ScheduleService();

  CalcResult? _preview;

  @override
  void initState() {
    super.initState();
    if (widget.prefillName != null) _nameController.text = widget.prefillName!;
    if (widget.prefillMobile != null) _mobileController.text = widget.prefillMobile!;
    _updatePreview();
  }

  void _updatePreview() {
    final principal = double.tryParse(_principalController.text) ?? 0;
    final installments = int.tryParse(_installmentsController.text) ?? 0;
    final fixedInstallment = double.tryParse(_installmentAmountController.text);
    final fixedReturn = double.tryParse(_returnController.text);

    if (principal <= 0 || installments <= 0) {
      setState(() => _preview = null);
      return;
    }

    if (_loanType == LoanType.emi) {
      // EMI mode: EMI amount se return calculate hota hai
      final emi = fixedInstallment ?? 0;
      if (emi > 0) {
        final result = CalculationService.calculateEmiLoan(
          principal: principal,
          emiAmount: emi,
          numberOfInstallments: installments,
          frequency: _frequency,
          startDate: _fmtDate(_selectedDate),
        );
        setState(() => _preview = result);
        _returnController.text = result.returnAmount.toStringAsFixed(0);
      } else {
        setState(() => _preview = null);
      }
      return;
    }

    // INTEREST mode
    final monthlyRate = double.tryParse(_monthlyRateController.text) ?? 0;
    if (monthlyRate > 0 || (fixedReturn != null && fixedReturn > principal)) {
      final result = CalculationService.calculateFlexibleLoan(
        principal: principal,
        monthlyRatePercent: monthlyRate,
        numberOfInstallments: installments,
        frequency: _frequency,
        interestType: _interestType,
        compoundingFrequency: _compounding,
        startDate: _fmtDate(_selectedDate),
        fixedInstallmentAmount: fixedInstallment,
        fixedReturnAmount: fixedReturn,
      );
      setState(() => _preview = result);

      // Keep fields in sync (live)
      if (fixedInstallment == null && result.installmentAmount > 0) {
        _installmentAmountController.text = result.installmentAmount.toStringAsFixed(0);
      }
      if (fixedReturn == null && result.returnAmount > 0) {
        _returnController.text = result.returnAmount.toStringAsFixed(0);
      }
    } else {
      setState(() => _preview = null);
    }
  }

  String _fmtDate(DateTime date) {
    return '${date.year}-${date.month.toString().padLeft(2, '0')}-${date.day.toString().padLeft(2, '0')}';
  }

  Future<void> _save() async {
    if (!_formKey.currentState!.validate()) return;
    if (_preview == null || _preview!.totalInstallments <= 0) {
      ScaffoldMessenger.of(context).showSnackBar(
        SnackBar(content: Text(_loanType == LoanType.emi
          ? 'Please enter Principal, EMI Amount aur Installments'
          : 'Please enter valid loan details')),
      );
      return;
    }

    setState(() => _isSaving = true);
    try {
      final principal = double.parse(_principalController.text);
      final mobile = _mobileController.text.trim();

      int customerId;
      if (widget.existingCustomerId != null) {
        customerId = widget.existingCustomerId!;
      } else {
        final customer = Customer(
          name: _nameController.text.trim(),
          mobile: mobile,
          nickname: _nicknameController.text.trim().isEmpty ? null : _nicknameController.text.trim(),
          createdAt: CalculationService.now(),
        );
        customerId = await _customerDao.insert(customer);
      }

      final settings = await _settingsDao.getSettings();
      final startDate = _fmtDate(_selectedDate);

      final loan = Loan(
        customerId: customerId,
        principal: principal,
        returnAmount: _preview!.returnAmount,
        installmentAmount: _preview!.installmentAmount,
        totalInstallments: _preview!.totalInstallments,
        profit: _preview!.profit,
        monthlyInterestRate: _preview!.monthlyInterestRate,
        startDate: startDate,
        endDate: _preview!.endDate,
        lastInstallmentAdjustedAmount: _preview!.lastInstallmentAdjustedAmount,
        createdAt: CalculationService.now(),
        loanTag: _tagController.text.trim(),
        accountName: _accountNameController.text.trim().isEmpty ? null : _accountNameController.text.trim(),
        interestType: _loanType == LoanType.emi ? InterestType.simple : _interestType,
        installmentFrequency: _frequency,
        compoundingFrequency: _compounding,
        loanType: _loanType,
        dailyInterestRate: _preview!.dailyInterestRate,
      );

      final savedLoan = await _loanDao.insert(loan);
      final fullLoan = loan.copyWith(id: savedLoan);
      await _scheduleService.generateSchedule(fullLoan, settings);

      if (mounted) {
        ScaffoldMessenger.of(context).showSnackBar(
          SnackBar(content: Text(widget.existingCustomerId != null
            ? 'New ${_loanType.label} loan created successfully'
            : 'Customer & Loan created successfully')),
        );
        Navigator.pop(context, true);
      }
    } catch (e) {
      if (mounted) {
        ScaffoldMessenger.of(context).showSnackBar(
          SnackBar(content: Text('Error: $e')),
        );
      }
    } finally {
      if (mounted) setState(() => _isSaving = false);
    }
  }

  @override
  Widget build(BuildContext context) {
    final isEmi = _loanType == LoanType.emi;
    return Scaffold(
      appBar: AppBar(title: Text(widget.existingCustomerId != null ? 'New Loan' : 'Add Customer + Loan')),
      body: Form(
        key: _formKey,
        child: ListView(
          padding: const EdgeInsets.all(16),
          children: [
            // Customer Info (existing customer ke liye skip)
            if (widget.existingCustomerId == null) ...[
              Text('Customer Details', style: Theme.of(context).textTheme.titleMedium),
              const SizedBox(height: 8),
              TextFormField(
                controller: _nameController,
                decoration: const InputDecoration(labelText: 'Name *', border: OutlineInputBorder()),
                validator: Validators.validateName,
                textCapitalization: TextCapitalization.words,
              ),
              const SizedBox(height: 12),
              TextFormField(
                controller: _mobileController,
                decoration: const InputDecoration(labelText: 'Mobile *', border: OutlineInputBorder()),
                keyboardType: TextInputType.phone,
                validator: Validators.validateMobile,
              ),
              const SizedBox(height: 12),
              TextFormField(
                controller: _nicknameController,
                decoration: const InputDecoration(labelText: 'Nickname (optional)', border: OutlineInputBorder()),
              ),
              const SizedBox(height: 20),
            ],

            // ===== LOAN TYPE — 2 BULLET TOGGLE (v9) =====
            Text('Loan Type', style: Theme.of(context).textTheme.titleMedium),
            const SizedBox(height: 8),
            SegmentedButton<LoanType>(
              style: SegmentedButton.styleFrom(
                selectedBackgroundColor: AppColors.primary,
                selectedForegroundColor: Colors.white,
              ),
              segments: const [
                ButtonSegment(
                  value: LoanType.emi,
                  label: Text('EMI'),
                  icon: Icon(Icons.payments),
                ),
                ButtonSegment(
                  value: LoanType.interest,
                  label: Text('INTREST'),
                  icon: Icon(Icons.percent),
                ),
              ],
              selected: {_loanType},
              onSelectionChanged: (s) {
                setState(() {
                  _loanType = s.first;
                  _installmentAmountController.clear();
                  _returnController.clear();
                });
                _updatePreview();
              },
            ),
            const SizedBox(height: 4),
            Text(
              isEmi
                ? 'EMI tick kiya — fixed EMI amount se loan banega (Return = EMI x Installments)'
                : 'INTREST tick kiya — % rate ke hisaab se interest calculate hoga',
              style: TextStyle(fontSize: 12, color: AppColors.textSecondary),
            ),
            const SizedBox(height: 16),

            // Loan Basics
            Text('Loan Details', style: Theme.of(context).textTheme.titleMedium),
            const SizedBox(height: 8),
            TextFormField(
              controller: _principalController,
              decoration: const InputDecoration(labelText: 'Principal Amount *', border: OutlineInputBorder(), prefixText: 'Rs '),
              keyboardType: TextInputType.number,
              validator: Validators.validateAmount,
              onChanged: (_) => _updatePreview(),
            ),
            const SizedBox(height: 12),

            if (isEmi) ...[
              // ===== EMI MODE FIELDS =====
              TextFormField(
                controller: _installmentAmountController,
                decoration: const InputDecoration(
                  labelText: 'EMI Amount *',
                  border: OutlineInputBorder(),
                  prefixText: 'Rs ',
                  helperText: 'Har installment kitni hogi',
                ),
                keyboardType: TextInputType.number,
                onChanged: (_) => _updatePreview(),
              ),
              const SizedBox(height: 12),
              TextFormField(
                controller: _installmentsController,
                decoration: const InputDecoration(
                  labelText: 'Number of Installments *',
                  border: OutlineInputBorder(),
                ),
                keyboardType: TextInputType.number,
                onChanged: (_) => _updatePreview(),
              ),
            ] else ...[
              // ===== INTEREST MODE FIELDS =====
              TextFormField(
                controller: _monthlyRateController,
                decoration: const InputDecoration(
                  labelText: 'Monthly Interest Rate % *',
                  border: OutlineInputBorder(),
                  suffixText: '%',
                  helperText: 'e.g. 2 for 2% per month',
                ),
                keyboardType: const TextInputType.numberWithOptions(decimal: true),
                onChanged: (_) => _updatePreview(),
              ),
              const SizedBox(height: 12),

              // Interest Type Toggle (only in interest mode)
              Text('Interest Calculation', style: Theme.of(context).textTheme.bodyMedium),
              const SizedBox(height: 6),
              SegmentedButton<InterestType>(
                segments: const [
                  ButtonSegment(value: InterestType.simple, label: Text('Simple'), icon: Icon(Icons.looks_one)),
                  ButtonSegment(value: InterestType.compound, label: Text('Compound'), icon: Icon(Icons.auto_graph)),
                ],
                selected: {_interestType},
                onSelectionChanged: (s) {
                  setState(() => _interestType = s.first);
                  _updatePreview();
                },
              ),
              if (_interestType == InterestType.compound) ...[
                const SizedBox(height: 12),
                DropdownButtonFormField<CompoundingFrequency>(
                  value: _compounding,
                  decoration: const InputDecoration(
                    labelText: 'Compounding Frequency',
                    border: OutlineInputBorder(),
                    helperText: 'Default: Quarterly',
                  ),
                  items: CompoundingFrequency.values
                      .map((e) => DropdownMenuItem(value: e, child: Text(e.label)))
                      .toList(),
                  onChanged: (v) {
                    if (v != null) {
                      setState(() => _compounding = v);
                      _updatePreview();
                    }
                  },
                ),
              ],
              const SizedBox(height: 12),
              TextFormField(
                controller: _installmentsController,
                decoration: const InputDecoration(
                  labelText: 'Number of Installments *',
                  border: OutlineInputBorder(),
                ),
                keyboardType: TextInputType.number,
                onChanged: (_) => _updatePreview(),
              ),
            ],
            const SizedBox(height: 12),

            // Frequency — dono modes mein
            DropdownButtonFormField<InstallmentFrequency>(
              value: _frequency,
              decoration: InputDecoration(
                labelText: 'Installment Frequency *',
                border: const OutlineInputBorder(),
                helperText: isEmi ? 'EMI kab-kab aayegi' : 'Installment kab-kab aayegi',
              ),
              items: InstallmentFrequency.values
                  .map((e) => DropdownMenuItem(value: e, child: Text(e.label)))
                  .toList(),
              onChanged: (v) {
                if (v != null) {
                  setState(() => _frequency = v);
                  _updatePreview();
                }
              },
            ),
            const SizedBox(height: 12),

            if (!isEmi) ...[
              TextFormField(
                controller: _installmentAmountController,
                decoration: const InputDecoration(
                  labelText: 'Installment Amount (auto / editable)',
                  border: OutlineInputBorder(),
                  prefixText: 'Rs ',
                ),
                keyboardType: TextInputType.number,
                onChanged: (_) => _updatePreview(),
              ),
              const SizedBox(height: 12),
            ],

            // Return amount — dono modes mein show (EMI mein auto-calculated readonly)
            TextFormField(
              controller: _returnController,
              readOnly: isEmi,
              decoration: InputDecoration(
                labelText: isEmi ? 'Total Return Amount (auto: EMI x Installments)' : 'Total Return Amount (auto / editable)',
                border: const OutlineInputBorder(),
                prefixText: 'Rs ',
                helperText: isEmi ? 'EMI x Installments se auto calculate hua' : null,
                filled: isEmi,
              ),
              keyboardType: TextInputType.number,
              onChanged: (_) => _updatePreview(),
            ),
            const SizedBox(height: 12),

            // Start Date
            ListTile(
              contentPadding: EdgeInsets.zero,
              title: const Text('Start Date'),
              subtitle: Text(CalculationService.formatDate(_fmtDate(_selectedDate))),
              trailing: const Icon(Icons.calendar_today),
              onTap: () async {
                final picked = await showDatePicker(
                  context: context,
                  initialDate: _selectedDate,
                  firstDate: DateTime(2020),
                  lastDate: DateTime(2035),
                );
                if (picked != null) {
                  setState(() => _selectedDate = picked);
                  _updatePreview();
                }
              },
            ),
            const SizedBox(height: 8),

            TextFormField(
              controller: _accountNameController,
              decoration: const InputDecoration(labelText: 'Account / Loan Name (optional)', border: OutlineInputBorder()),
            ),
            const SizedBox(height: 12),
            TextFormField(
              controller: _tagController,
              decoration: const InputDecoration(labelText: 'Tag (optional)', border: OutlineInputBorder()),
            ),
            const SizedBox(height: 20),

            // Live Preview Card
            if (_preview != null && _preview!.totalInstallments > 0)
              Card(
                color: Theme.of(context).colorScheme.primaryContainer.withOpacity(0.3),
                child: Padding(
                  padding: const EdgeInsets.all(16),
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      Text('Live Preview', style: Theme.of(context).textTheme.titleMedium),
                      const Divider(),
                      _previewRow('Loan Type', _loanType.label),
                      if (!isEmi) _previewRow('Interest Type', _preview!.compoundingLabel),
                      _previewRow('Frequency', _preview!.frequency.label),
                      if (!isEmi) ...[
                        _previewRow('Monthly Rate', '${_preview!.monthlyInterestRate.toStringAsFixed(2)}%'),
                        _previewRow('Yearly Rate', '${_preview!.yearlyInterestRate.toStringAsFixed(2)}%'),
                        _previewRow('Daily Rate', '${_preview!.dailyInterestRate.toStringAsFixed(4)}%'),
                      ] else
                        _previewRow('Effective Monthly Rate', '${_preview!.monthlyInterestRate.toStringAsFixed(2)}%'),
                      _previewRow('Installment Amount', CalculationService.formatCurrency(_preview!.installmentAmount)),
                      _previewRow('Total Installments', '${_preview!.totalInstallments}'),
                      _previewRow('Return Amount', CalculationService.formatCurrency(_preview!.returnAmount)),
                      _previewRow('Profit', CalculationService.formatCurrency(_preview!.profit)),
                      _previewRow('End Date', CalculationService.formatDate(_preview!.endDate)),
                      if (_preview!.lastInstallmentAdjustedAmount != _preview!.installmentAmount)
                        _previewRow('Last Installment', CalculationService.formatCurrency(_preview!.lastInstallmentAdjustedAmount)),
                    ],
                  ),
                ),
              ),
            const SizedBox(height: 24),

            SizedBox(
              width: double.infinity,
              height: 48,
              child: ElevatedButton(
                onPressed: _isSaving ? null : _save,
                child: _isSaving
                    ? const SizedBox(width: 22, height: 22, child: CircularProgressIndicator(strokeWidth: 2))
                    : Text(widget.existingCustomerId != null ? 'Create ${_loanType.label} Loan' : 'Create Customer & Loan'),
              ),
            ),
            const SizedBox(height: 32),
          ],
        ),
      ),
    );
  }

  Widget _previewRow(String label, String value) {
    return Padding(
      padding: const EdgeInsets.symmetric(vertical: 3),
      child: Row(
        mainAxisAlignment: MainAxisAlignment.spaceBetween,
        children: [
          Text(label, style: const TextStyle(fontSize: 13)),
          Text(value, style: const TextStyle(fontSize: 13, fontWeight: FontWeight.w600)),
        ],
      ),
    );
  }

  @override
  void dispose() {
    _nameController.dispose();
    _mobileController.dispose();
    _nicknameController.dispose();
    _principalController.dispose();
    _monthlyRateController.dispose();
    _installmentsController.dispose();
    _installmentAmountController.dispose();
    _returnController.dispose();
    _tagController.dispose();
    _accountNameController.dispose();
    super.dispose();
  }
}
