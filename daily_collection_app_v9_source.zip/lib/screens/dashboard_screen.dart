import 'package:flutter/material.dart';
import '../utils/constants.dart';
import '../models/loan.dart';
import '../database/dao/loan_dao.dart';
import '../database/dao/collection_dao.dart';
import '../database/dao/settings_dao.dart';
import '../services/calculation_service.dart';
import '../services/notification_service.dart';
import '../services/quotes_service.dart';
import '../widgets/stat_card.dart';
import 'outstanding_snapshot_screen.dart';
import 'daily_collection_screen.dart';
import 'customer_list_screen.dart';
import 'loan_list_screen.dart';
import 'transaction_log_screen.dart';
import 'search_screen.dart';
import 'settings_screen.dart';
import 'calculators_screen.dart';

class DashboardScreen extends StatefulWidget {
  const DashboardScreen({super.key});

  @override
  State<DashboardScreen> createState() => _DashboardScreenState();
}

class _DashboardScreenState extends State<DashboardScreen> with WidgetsBindingObserver {
  final LoanDao _loanDao = LoanDao();
  final CollectionDao _collectionDao = CollectionDao();
  final SettingsDao _settingsDao = SettingsDao();

  double _totalGiven = 0;
  double _totalCollected = 0;
  double _expectedProfit = 0;
  int _activeLoans = 0;
  int _overdueLoans = 0;
  int _completedLoans = 0;
  List<AlertItem> _alerts = [];
  List<Map<String, dynamic>> _topCustomers = [];
  String _quote = '';
  bool _isLoading = true;

  @override
  void initState() {
    super.initState();
    WidgetsBinding.instance.addObserver(this);
    _loadData();
  }

  @override
  void dispose() {
    WidgetsBinding.instance.removeObserver(this);
    super.dispose();
  }

  @override
  void didChangeAppLifecycleState(AppLifecycleState state) {
    if (state == AppLifecycleState.resumed) _loadData();
  }

  Future<void> _loadData() async {
    setState(() => _isLoading = true);
    _totalGiven = await _loanDao.getTotalGiven();
    _totalCollected = await _collectionDao.getTotalCollected();
    _expectedProfit = await _loanDao.getTotalExpectedProfit();
    _activeLoans = await _loanDao.countByStatus(LoanStatus.active);
    _overdueLoans = await _loanDao.countByStatus(LoanStatus.overdue);
    _completedLoans = await _loanDao.countByStatus(LoanStatus.completed);
    final notifService = NotificationService();
    _alerts = await notifService.getDashboardAlerts();
    final loansData = await _loanDao.getLoansWithCustomerName();
    final customerMap = <int, double>{};
    for (final loan in loansData) {
      final lid = loan['id'] as int;
      final collected = await _collectionDao.getTotalCollectedByLoan(lid);
      customerMap[lid] = collected;
    }
    _topCustomers = loansData.take(5).map((l) => {...l, 'collected': customerMap[l['id']] ?? 0}).toList();
    try {
      _quote = await QuotesService().getRandomQuote();
    } catch (_) {
      _quote = '';
    }
    if (mounted) setState(() => _isLoading = false);
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text('Daily Collection'),
        actions: [
          IconButton(icon: const Icon(Icons.search), onPressed: () => Navigator.push(context, MaterialPageRoute(builder: (_) => const SearchScreen()))),
          IconButton(icon: const Icon(Icons.settings), onPressed: () async {
            await Navigator.push(context, MaterialPageRoute(builder: (_) => const SettingsScreen()));
            _loadData();
          }),
        ],
      ),
      body: _isLoading
        ? const Center(child: CircularProgressIndicator())
        : RefreshIndicator(
            onRefresh: _loadData,
            child: ListView(
              padding: const EdgeInsets.all(AppConstants.padding),
              children: [
                GridView.count(
                  shrinkWrap: true, physics: const NeverScrollableScrollPhysics(),
                  crossAxisCount: 2, childAspectRatio: 1.5, crossAxisSpacing: 8, mainAxisSpacing: 8,
                  children: [
                    StatCard(label: 'Total Given', value: CalculationService.formatCurrency(_totalGiven), color: AppColors.primary, icon: Icons.account_balance_wallet,
                      onTap: () => Navigator.push(context, MaterialPageRoute(builder: (_) => const LoanListScreen()))),
                    StatCard(label: 'Collected', value: CalculationService.formatCurrency(_totalCollected), color: AppColors.success, icon: Icons.check_circle,
                      onTap: () => Navigator.push(context, MaterialPageRoute(builder: (_) => const DailyCollectionScreen()))),
                    StatCard(label: 'Expected Profit', value: CalculationService.formatCurrency(_expectedProfit), color: AppColors.warning, icon: Icons.trending_up,
                      onTap: () => Navigator.push(context, MaterialPageRoute(builder: (_) => const LoanListScreen()))),
                    StatCard(label: 'Active Loans', value: '$_activeLoans', color: AppColors.primary, icon: Icons.list,
                      onTap: () => Navigator.push(context, MaterialPageRoute(builder: (_) => const LoanListScreen()))),
                  ],
                ),
                const SizedBox(height: 8),
                Row(
                  children: [
                    Expanded(child: StatCard(label: 'Overdue', value: '$_overdueLoans', color: AppColors.overdue, icon: Icons.warning,
                      onTap: () => Navigator.push(context, MaterialPageRoute(builder: (_) => const LoanListScreen(statusFilter: 'overdue'))))),
                    const SizedBox(width: 8),
                    Expanded(child: StatCard(label: 'Completed', value: '$_completedLoans', color: AppColors.success, icon: Icons.done_all,
                      onTap: () => Navigator.push(context, MaterialPageRoute(builder: (_) => const LoanListScreen(statusFilter: 'completed'))))),
                  ],
                ),
                const SizedBox(height: 16),
                if (_alerts.isNotEmpty) ...[
                  Text('ALERTS', style: TextStyle(fontSize: 13, fontWeight: FontWeight.bold, color: AppColors.textSecondary)),
                  const SizedBox(height: 8),
                  ..._alerts.map((alert) => Card(
                    margin: const EdgeInsets.only(bottom: 6),
                    child: ListTile(
                      leading: Icon(_alertIcon(alert.type), color: _alertColor(alert.type)),
                      title: Text(alert.title, style: const TextStyle(fontWeight: FontWeight.bold, fontSize: 14)),
                      subtitle: Text(alert.description, style: const TextStyle(fontSize: 12)),
                      trailing: const Icon(Icons.chevron_right),
                      onTap: () => _onAlertTap(alert),
                    ),
                  )),
                  const SizedBox(height: 16),
                ],
                if (_topCustomers.isNotEmpty) ...[
                  Text('TOP LOANS', style: TextStyle(fontSize: 13, fontWeight: FontWeight.bold, color: AppColors.textSecondary)),
                  const SizedBox(height: 8),
                  ..._topCustomers.map((loan) => Card(
                    child: ListTile(
                      leading: CircleAvatar(backgroundColor: AppColors.primary, child: Text('${loan['id']}', style: const TextStyle(color: Colors.white, fontSize: 12))),
                      title: Text(loan['customer_name'] ?? ''),
                      subtitle: Text('${CalculationService.formatCurrency((loan['principal'] as num).toDouble())} -> ${CalculationService.formatCurrency((loan['return_amount'] as num).toDouble())}'),
                      trailing: Text('${loan['status']}', style: TextStyle(color: LoanStatusBadge.getColor(loan['status'] as String), fontSize: 11, fontWeight: FontWeight.bold)),
                      onTap: () => Navigator.push(context, MaterialPageRoute(builder: (_) => LoanListScreen())),
                    ),
                  )),
                ],
                const SizedBox(height: 16),
                Row(
                  children: [
                    Expanded(child: _quickAction(Icons.people, 'Customers', () => Navigator.push(context, MaterialPageRoute(builder: (_) => const CustomerListScreen())))),
                    Expanded(child: _quickAction(Icons.today, 'Today', () => Navigator.push(context, MaterialPageRoute(builder: (_) => const DailyCollectionScreen())))),
                    Expanded(child: _quickAction(Icons.fact_check, 'Dues', () => Navigator.push(context, MaterialPageRoute(builder: (_) => const OutstandingSnapshotScreen())))),
                    Expanded(child: _quickAction(Icons.history, 'Log', () => Navigator.push(context, MaterialPageRoute(builder: (_) => const TransactionLogScreen())))),
                    Expanded(child: _quickAction(Icons.calculate, 'Calc', () => Navigator.push(context, MaterialPageRoute(builder: (_) => const CalculatorsScreen())))),
                  ],
                ),
                const SizedBox(height: 24),
                if (_quote.isNotEmpty)
                  Card(
                    color: AppColors.warning.withOpacity(0.08),
                    child: Padding(
                      padding: const EdgeInsets.all(12),
                      child: Row(
                        children: [
                          const Icon(Icons.format_quote, color: AppColors.warning, size: 20),
                          const SizedBox(width: 8),
                          Expanded(
                            child: Text(
                              _quote,
                              style: TextStyle(fontSize: 12, fontStyle: FontStyle.italic, color: AppColors.textSecondary),
                            ),
                          ),
                        ],
                      ),
                    ),
                  ),
                const SizedBox(height: 12),
                Center(
                  child: Column(
                    children: [
                      Icon(Icons.favorite, size: 16, color: AppColors.textSecondary.withOpacity(0.5)),
                      const SizedBox(height: 4),
                      Text(
                        'Created by Harish',
                        style: TextStyle(
                          fontSize: 13,
                          fontWeight: FontWeight.bold,
                          color: AppColors.primary.withOpacity(0.7),
                        ),
                      ),
                      const SizedBox(height: 2),
                      Text(
                        'Daily Collection App v9.0',
                        style: TextStyle(
                          fontSize: 11,
                          color: AppColors.textSecondary,
                        ),
                      ),
                    ],
                  ),
                ),
                const SizedBox(height: 16),
              ],
            ),
          ),
      floatingActionButton: FloatingActionButton(
        onPressed: () async {
          await Navigator.push(context, MaterialPageRoute(builder: (_) => const CustomerListScreen()));
          _loadData();
        },
        child: const Icon(Icons.add),
      ),
    );
  }

  Widget _quickAction(IconData icon, String label, VoidCallback onTap) {
    return Column(children: [
      IconButton(onPressed: onTap, icon: Icon(icon, color: AppColors.primary, size: 28)),
      Text(label, style: const TextStyle(fontSize: 11)),
    ]);
  }

  IconData _alertIcon(AlertType type) {
    switch (type) {
      case AlertType.overdue: return Icons.warning;
      case AlertType.missedPayment: return Icons.cancel;
      case AlertType.loanCompleted: return Icons.check_circle;
      case AlertType.pendingToday: return Icons.today;
      case AlertType.defaulted: return Icons.error;
    }
  }

  Color _alertColor(AlertType type) {
    switch (type) {
      case AlertType.overdue: return AppColors.overdue;
      case AlertType.missedPayment: return AppColors.error;
      case AlertType.loanCompleted: return AppColors.success;
      case AlertType.pendingToday: return AppColors.warning;
      case AlertType.defaulted: return AppColors.error;
    }
  }

  void _onAlertTap(AlertItem alert) {
    switch (alert.type) {
      case AlertType.overdue:
      case AlertType.defaulted:
        Navigator.push(context, MaterialPageRoute(builder: (_) => const LoanListScreen(statusFilter: 'overdue')));
        break;
      case AlertType.missedPayment:
        Navigator.push(context, MaterialPageRoute(builder: (_) => const LoanListScreen()));
        break;
      case AlertType.loanCompleted:
        Navigator.push(context, MaterialPageRoute(builder: (_) => const LoanListScreen(statusFilter: 'completed')));
        break;
      case AlertType.pendingToday:
        Navigator.push(context, MaterialPageRoute(builder: (_) => const DailyCollectionScreen()));
        break;
    }
  }
}
