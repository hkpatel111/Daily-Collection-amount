import 'package:flutter/material.dart';
import '../utils/constants.dart';
import 'calculators_screen.dart';
import 'outstanding_snapshot_screen.dart';
import 'transaction_log_screen.dart';
import 'sms_history_screen.dart';
import 'loan_list_screen.dart';
import 'customer_list_screen.dart';
import 'search_screen.dart';
import 'daily_collection_screen.dart';

/// v9.2: MHT-prototype "Reports" tab — REPORTS & CALCULATORS + INSIGHTS +
/// RELATIONSHIPS sections. Sab existing screens ke shortcuts.
class ReportsScreen extends StatelessWidget {
  const ReportsScreen({super.key});

  @override
  Widget build(BuildContext context) {
    final dark = Theme.of(context).brightness == Brightness.dark;
    return Scaffold(
      appBar: AppBar(title: const Text('Reports & Calculators')),
      body: ListView(
        padding: const EdgeInsets.all(AppConstants.padding),
        children: [
          _sectionTitle('REPORTS'),
          Card(
            margin: const EdgeInsets.only(bottom: 16),
            elevation: dark ? 0 : 2,
            child: Column(children: [
              _tile(context, Icons.picture_as_pdf, 'Outstanding Snapshot', 'Kisi bhi date par kaun kitna udhaar par tha',
                () => Navigator.push(context, MaterialPageRoute(builder: (_) => const OutstandingSnapshotScreen()))),
              const Divider(height: 1),
              _tile(context, Icons.today, 'Today's Collection', 'Aaj ki pending aur completed collections',
                () => Navigator.push(context, MaterialPageRoute(builder: (_) => const DailyCollectionScreen()))),
              const Divider(height: 1),
              _tile(context, Icons.receipt_long, 'Transaction Log', 'Har edit/delete ka record',
                () => Navigator.push(context, MaterialPageRoute(builder: (_) => const TransactionLogScreen()))),
              const Divider(height: 1),
              _tile(context, Icons.sms, 'SMS History', 'Bheje gaye saare SMS',
                () => Navigator.push(context, MaterialPageRoute(builder: (_) => const SmsHistoryScreen()))),
            ]),
          ),
          _sectionTitle('CALCULATORS'),
          Card(
            margin: const EdgeInsets.only(bottom: 16),
            elevation: dark ? 0 : 2,
            child: Column(children: [
              _tile(context, Icons.calculate, 'Loan Calculator', 'EMI, interest aur profit pehle se calculate karo',
                () => Navigator.push(context, MaterialPageRoute(builder: (_) => const CalculatorsScreen()))),
              const Divider(height: 1),
              _tile(context, Icons.search, 'Search Everything', 'Customer, loan ya collection dhoondo',
                () => Navigator.push(context, MaterialPageRoute(builder: (_) => const SearchScreen()))),
            ]),
          ),
          _sectionTitle('INSIGHTS'),
          Card(
            margin: const EdgeInsets.only(bottom: 16),
            elevation: dark ? 0 : 2,
            child: Column(children: [
              _tile(context, Icons.attach_money, 'Loan Portfolio', 'Saare loans ek list mein — status ke saath',
                () => Navigator.push(context, MaterialPageRoute(builder: (_) => const LoanListScreen()))),
              const Divider(height: 1),
              _tile(context, Icons.people, 'Customer Relationships', 'Sabhi customers aur unka lena-dena',
                () => Navigator.push(context, MaterialPageRoute(builder: (_) => const CustomerListScreen()))),
            ]),
          ),
          const SizedBox(height: 8),
          Center(child: Text('Numbers ko quickly samjhein aur next collection plan karein.',
            style: TextStyle(fontSize: 11, color: AppColors.textSecondary))),
          const SizedBox(height: 24),
        ],
      ),
    );
  }

  Widget _sectionTitle(String title) {
    return Padding(
      padding: const EdgeInsets.only(bottom: 8),
      child: Text(title, style: TextStyle(fontSize: 12, fontWeight: FontWeight.bold, letterSpacing: 1, color: AppColors.textSecondary)),
    );
  }

  Widget _tile(BuildContext context, IconData icon, String title, String subtitle, VoidCallback onTap) {
    return ListTile(
      leading: Container(
        padding: const EdgeInsets.all(8),
        decoration: BoxDecoration(color: AppColors.primary.withOpacity(0.1), borderRadius: BorderRadius.circular(10)),
        child: Icon(icon, color: AppColors.primary, size: 22),
      ),
      title: Text(title, style: const TextStyle(fontSize: 14, fontWeight: FontWeight.w600)),
      subtitle: Text(subtitle, style: const TextStyle(fontSize: 12)),
      trailing: const Icon(Icons.chevron_right),
      onTap: onTap,
    );
  }
}
