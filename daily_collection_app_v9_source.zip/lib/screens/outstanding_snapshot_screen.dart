import 'package:flutter/material.dart';
import 'package:share_plus/share_plus.dart';
import '../utils/constants.dart';
import '../models/loan.dart';
import '../models/schedule_entry.dart';
import '../database/dao/loan_dao.dart';
import '../database/dao/schedule_dao.dart';
import '../database/dao/collection_dao.dart';
import '../services/calculation_service.dart';

/// v9: Outstanding Snapshot — kisi bhi date par kaunsa kitna outstanding tha,
/// ek tap mein. Pending installments + overdue interest include.
class OutstandingSnapshotScreen extends StatefulWidget {
  const OutstandingSnapshotScreen({super.key});

  @override
  State<OutstandingSnapshotScreen> createState() => _OutstandingSnapshotScreenState();
}

class _LoanOutstanding {
  final Loan loan;
  final String customerName;
  final String mobile;
  double expectedTillDate = 0;
  double collected = 0;
  double get outstanding => (expectedTillDate - collected).clamp(0.0, double.infinity);
  bool get isOverdue => outstanding > 0;

  _LoanOutstanding({required this.loan, required this.customerName, required this.mobile});
}

class _OutstandingSnapshotScreenState extends State<OutstandingSnapshotScreen> {
  final LoanDao _loanDao = LoanDao();
  final ScheduleDao _scheduleDao = ScheduleDao();
  final CollectionDao _collectionDao = CollectionDao();

  DateTime _snapshotDate = DateTime.now();
  List<_LoanOutstanding> _rows = [];
  double _totalOutstanding = 0;
  int _overdueLoans = 0;
  bool _isLoading = true;

  String _fmt(DateTime d) =>
      '${d.year}-${d.month.toString().padLeft(2, '0')}-${d.day.toString().padLeft(2, '0')}';

  @override
  void initState() {
    super.initState();
    _loadSnapshot();
  }

  Future<void> _loadSnapshot() async {
    setState(() => _isLoading = true);
    final dateStr = _fmt(_snapshotDate);
    final loans = await _loanDao.getLoansWithCustomerName();
    final rows = <_LoanOutstanding>[];
    double total = 0;
    int overdue = 0;

    for (final lm in loans) {
      final loan = Loan.fromMap(lm);
      if (loan.status == LoanStatus.cancelled) continue;

      // Loan start date ke baad hi snapshot meaningful hai
      if (loan.startDate.compareTo(dateStr) > 0) continue;

      final row = _LoanOutstanding(
        loan: loan,
        customerName: (lm['customer_name'] ?? '') as String,
        mobile: (lm['customer_mobile'] ?? '') as String,
      );

      // Us date tak ke expected installments
      final schedule = await _scheduleDao.getByLoanId(loan.id!);
      for (final e in schedule) {
        if (e.scheduledDate.compareTo(dateStr) <= 0 &&
            e.status != ScheduleEntryStatus.cancelled &&
            e.status != ScheduleEntryStatus.holiday) {
          row.expectedTillDate += e.expectedAmount;
        }
      }

      // Us date tak ke collections
      final collections = await _collectionDao.getByLoanId(loan.id!);
      for (final c in collections) {
        if (c.collectionDate.compareTo(dateStr) <= 0) {
          row.collected += c.collectedAmount;
        }
      }

      // Us date ke baad loan complete/preclosed ho gaya tha? Phir outstanding 0
      if (loan.status == LoanStatus.completed || loan.status == LoanStatus.preClosed) {
        final endDate = loan.endDate;
        if (endDate.compareTo(dateStr) <= 0) {
          row.expectedTillDate = row.collected; // fully settled as of that date
        }
      }

      if (row.isOverdue) {
        overdue++;
        total += row.outstanding;
        rows.add(row);
      }
    }

    // Sabse zyada outstanding pehle
    rows.sort((a, b) => b.outstanding.compareTo(a.outstanding));

    if (mounted) {
      setState(() {
        _rows = rows;
        _totalOutstanding = total;
        _overdueLoans = overdue;
        _isLoading = false;
      });
    }
  }

  Future<void> _pickDate() async {
    final picked = await showDatePicker(
      context: context,
      initialDate: _snapshotDate,
      firstDate: DateTime(2020),
      lastDate: DateTime.now(),
    );
    if (picked != null) {
      setState(() => _snapshotDate = picked);
      _loadSnapshot();
    }
  }

  void _shareSnapshot() {
    final buf = StringBuffer();
    buf.writeln('==== OUTSTANDING SNAPSHOT ====');
    buf.writeln('Date: ${CalculationService.formatDate(_fmt(_snapshotDate))}');
    buf.writeln('Total Outstanding: ${CalculationService.formatCurrency(_totalOutstanding)}');
    buf.writeln('Loans with dues: ${_rows.length} ($_overdueLoans overdue)');
    buf.writeln('----');
    for (final r in _rows) {
      buf.writeln(
        '${r.customerName} | Loan #${r.loan.id} | Expected: ${r.expectedTillDate.toStringAsFixed(0)} | '
        'Collected: ${r.collected.toStringAsFixed(0)} | Outstanding: ${r.outstanding.toStringAsFixed(0)}');
    }
    buf.writeln('==== Created by Harish ====');
    Share.share(buf.toString(), subject: 'Outstanding Snapshot ${_fmt(_snapshotDate)}');
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text('Outstanding Snapshot'),
        actions: [
          IconButton(icon: const Icon(Icons.share), onPressed: _rows.isEmpty ? null : _shareSnapshot),
        ],
      ),
      floatingActionButton: FloatingActionButton.extended(
        onPressed: _pickDate,
        icon: const Icon(Icons.calendar_today),
        label: Text(CalculationService.formatDate(_fmt(_snapshotDate))),
      ),
      body: _isLoading
          ? const Center(child: CircularProgressIndicator())
          : RefreshIndicator(
              onRefresh: _loadSnapshot,
              child: ListView(
                padding: const EdgeInsets.fromLTRB(16, 16, 16, 90),
                children: [
                  Card(
                    color: AppColors.primary.withOpacity(0.08),
                    child: Padding(
                      padding: const EdgeInsets.all(16),
                      child: Column(
                        crossAxisAlignment: CrossAxisAlignment.start,
                        children: [
                          Text('AS ON ${CalculationService.formatDate(_fmt(_snapshotDate))}',
                              style: TextStyle(fontSize: 12, fontWeight: FontWeight.bold, color: AppColors.textSecondary)),
                          const SizedBox(height: 8),
                          Text(
                            CalculationService.formatCurrency(_totalOutstanding),
                            style: TextStyle(fontSize: 28, fontWeight: FontWeight.bold, color: AppColors.primary),
                          ),
                          const SizedBox(height: 4),
                          Text(
                            '$_overdueLoans loan(s) mein dues hain',
                            style: TextStyle(fontSize: 13, color: AppColors.textSecondary),
                          ),
                        ],
                      ),
                    ),
                  ),
                  const SizedBox(height: 16),
                  if (_rows.isEmpty)
                    const Card(
                      child: ListTile(
                        leading: Icon(Icons.emoji_emotions, color: AppColors.success),
                        title: Text('Sab clear hai!'),
                        subtitle: Text('Is date par koi outstanding nahi tha.'),
                      ),
                    )
                  else
                    ..._rows.map(_buildRow),
                  const SizedBox(height: 24),
                  const Center(child: Text('Created by Harish', style: TextStyle(fontSize: 12, fontWeight: FontWeight.bold))),
                ],
              ),
            ),
    );
  }

  Widget _buildRow(_LoanOutstanding r) {
    return Card(
      margin: const EdgeInsets.only(bottom: 8),
      child: Padding(
        padding: const EdgeInsets.all(12),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Row(
              children: [
                Expanded(
                  child: Text(
                    '${r.customerName} (Loan #${r.loan.id})',
                    style: const TextStyle(fontWeight: FontWeight.bold, fontSize: 15),
                  ),
                ),
                Text(
                  CalculationService.formatCurrency(r.outstanding),
                  style: TextStyle(fontWeight: FontWeight.bold, fontSize: 15, color: AppColors.overdue),
                ),
              ],
            ),
            const SizedBox(height: 4),
            Text(
              '${r.loan.loanType.label} | ${r.loan.installmentFrequency.label} | '
              'Expected: ${CalculationService.formatCurrency(r.expectedTillDate)} | '
              'Collected: ${CalculationService.formatCurrency(r.collected)}',
              style: TextStyle(fontSize: 12, color: AppColors.textSecondary),
            ),
            const SizedBox(height: 6),
            ClipRRect(
              borderRadius: BorderRadius.circular(4),
              child: LinearProgressIndicator(
                value: r.expectedTillDate > 0 ? (r.collected / r.expectedTillDate).clamp(0.0, 1.0) : 0,
                backgroundColor: AppColors.overdue.withOpacity(0.15),
                color: AppColors.success,
                minHeight: 6,
              ),
            ),
          ],
        ),
      ),
    );
  }
}
