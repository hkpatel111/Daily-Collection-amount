import 'package:flutter/material.dart';
import 'package:url_launcher/url_launcher.dart';
import '../utils/constants.dart';
import '../models/customer.dart';
import '../models/loan.dart';
import '../database/dao/customer_dao.dart';
import '../database/dao/loan_dao.dart';
import '../database/dao/collection_dao.dart';
import '../services/calculation_service.dart';
import '../widgets/stat_card.dart';
import 'loan_detail_screen.dart';

/// v9: Customer Ledger — customer ka pura lena-dena ek screen par.
/// Loans, collections, aur transactions sab timeline mein.
class CustomerLedgerScreen extends StatefulWidget {
  final int customerId;
  const CustomerLedgerScreen({super.key, required this.customerId});

  @override
  State<CustomerLedgerScreen> createState() => _CustomerLedgerScreenState();
}

class _LedgerItem {
  final String date;
  final String title;
  final String subtitle;
  final IconData icon;
  final Color color;
  final double? amount;
  final bool isDebit; // true = paisa diya (red side), false = paisa aaya (green side)
  final int? loanId;

  _LedgerItem({
    required this.date,
    required this.title,
    required this.subtitle,
    required this.icon,
    required this.color,
    this.amount,
    required this.isDebit,
    this.loanId,
  });
}

class _CustomerLedgerScreenState extends State<CustomerLedgerScreen> {
  final CustomerDao _customerDao = CustomerDao();
  final LoanDao _loanDao = LoanDao();
  final CollectionDao _collectionDao = CollectionDao();

  Customer? _customer;
  List<_LedgerItem> _items = [];
  double _totalGiven = 0;
  double _totalCollected = 0;
  double _outstanding = 0;
  bool _isLoading = true;
  String _mobile = '';

  @override
  void initState() {
    super.initState();
    _loadData();
  }

  Future<void> _loadData() async {
    setState(() => _isLoading = true);
    _customer = await _customerDao.getById(widget.customerId);
    _mobile = _customer?.mobile ?? '';
    _items = [];

    final loans = await _loanDao.getByCustomer(widget.customerId);
    double totalReturn = 0;

    for (final loan in loans) {
      if (loan.status != LoanStatus.cancelled) {
        _totalGiven += loan.principal;
        totalReturn += loan.returnAmount;
      }
      _items.add(_LedgerItem(
        date: loan.startDate,
        title: 'Loan #${loan.id} Given (${loan.loanType.label})',
        subtitle: '${CalculationService.formatCurrency(loan.principal)} -> ${CalculationService.formatCurrency(loan.returnAmount)}'
            ' | ${loan.totalInstallments} x ${loan.installmentFrequency.label}',
        icon: Icons.account_balance_wallet,
        color: AppColors.primary,
        amount: loan.principal,
        isDebit: true,
        loanId: loan.id,
      ));

      final collections = await _collectionDao.getByLoanId(loan.id!);
      for (final c in collections) {
        if (c.collectedAmount > 0) {
          _totalCollected += c.collectedAmount;
          _items.add(_LedgerItem(
            date: c.collectionDate,
            title: 'Collection - Loan #${loan.id}',
            subtitle: '${c.paymentMode.label}${c.shortfall > 0 ? ' | Shortfall: ${CalculationService.formatCurrency(c.shortfall)}' : ''}',
            icon: Icons.payments,
            color: AppColors.success,
            amount: c.collectedAmount,
            isDebit: false,
            loanId: loan.id,
          ));
        }
      }
    }

    _outstanding = (totalReturn - _totalCollected).clamp(0.0, double.infinity);

    // Newest first
    _items.sort((a, b) => b.date.compareTo(a.date));

    if (mounted) setState(() => _isLoading = false);
  }

  void _sendWhatsApp() {
    if (_mobile.isEmpty) return;
    final buf = StringBuffer();
    buf.writeln('==== LEDGER: ${_customer?.name ?? ''} ====');
    buf.writeln('Total Given: ${CalculationService.formatCurrency(_totalGiven)}');
    buf.writeln('Total Collected: ${CalculationService.formatCurrency(_totalCollected)}');
    buf.writeln('Outstanding: ${CalculationService.formatCurrency(_outstanding)}');
    buf.writeln('----');
    for (final item in _items.take(20)) {
      buf.writeln('${CalculationService.formatDate(item.date)} | ${item.title} | ${item.amount != null ? CalculationService.formatCurrency(item.amount!) : ''}');
    }
    buf.writeln('==== Created by Harish ====');
    final uri = Uri.parse('https://wa.me/91$_mobile?text=${Uri.encodeComponent(buf.toString())}');
    launchUrl(uri, mode: LaunchMode.externalApplication);
  }

  @override
  Widget build(BuildContext context) {
    if (_isLoading) {
      return Scaffold(appBar: AppBar(title: const Text('Ledger')), body: const Center(child: CircularProgressIndicator()));
    }
    if (_customer == null) {
      return Scaffold(appBar: AppBar(title: const Text('Ledger')), body: const Center(child: Text('Customer not found')));
    }

    return Scaffold(
      appBar: AppBar(
        title: Text('${_customer!.name} — Ledger'),
        actions: [
          IconButton(icon: const Icon(Icons.chat), onPressed: _sendWhatsApp, tooltip: 'WhatsApp Ledger'),
        ],
      ),
      body: ListView(
        padding: const EdgeInsets.all(AppConstants.padding),
        children: [
          GridView.count(
            shrinkWrap: true,
            physics: const NeverScrollableScrollPhysics(),
            crossAxisCount: 3,
            childAspectRatio: 1.3,
            crossAxisSpacing: 6,
            mainAxisSpacing: 6,
            children: [
              StatCard(label: 'Given', value: CalculationService.formatCurrency(_totalGiven), color: AppColors.primary, icon: Icons.account_balance_wallet),
              StatCard(label: 'Collected', value: CalculationService.formatCurrency(_totalCollected), color: AppColors.success, icon: Icons.check_circle),
              StatCard(label: 'Dues', value: CalculationService.formatCurrency(_outstanding), color: AppColors.warning, icon: Icons.pending),
            ],
          ),
          const SizedBox(height: 8),
          Card(
            color: _outstanding > 0 ? AppColors.warning.withOpacity(0.1) : AppColors.success.withOpacity(0.1),
            child: Padding(
              padding: const EdgeInsets.all(16),
              child: Row(
                mainAxisAlignment: MainAxisAlignment.spaceBetween,
                children: [
                  Text('OUTSTANDING', style: TextStyle(fontSize: 13, fontWeight: FontWeight.bold, color: AppColors.textSecondary)),
                  Text(
                    CalculationService.formatCurrency(_outstanding),
                    style: TextStyle(fontSize: 20, fontWeight: FontWeight.bold, color: _outstanding > 0 ? AppColors.warning : AppColors.success),
                  ),
                ],
              ),
            ),
          ),
          const SizedBox(height: 16),
          Text('FULL HISTORY (${_items.length})', style: TextStyle(fontSize: 13, fontWeight: FontWeight.bold, color: AppColors.textSecondary)),
          const SizedBox(height: 8),
          if (_items.isEmpty)
            const Card(child: ListTile(leading: Icon(Icons.inbox), title: Text('Koi entry nahi mili')))
          else
            ..._items.map(_buildLedgerTile),
          const SizedBox(height: 24),
          const Center(child: Text('Created by Harish', style: TextStyle(fontSize: 12, fontWeight: FontWeight.bold))),
          const SizedBox(height: 16),
        ],
      ),
    );
  }

  Widget _buildLedgerTile(_LedgerItem item) {
    return Card(
      margin: const EdgeInsets.only(bottom: 6),
      child: ListTile(
        leading: CircleAvatar(
          backgroundColor: item.color.withOpacity(0.15),
          child: Icon(item.icon, color: item.color, size: 20),
        ),
        title: Text(item.title, style: const TextStyle(fontSize: 14, fontWeight: FontWeight.w600)),
        subtitle: Text('${CalculationService.formatDate(item.date)}\n${item.subtitle}', style: const TextStyle(fontSize: 12)),
        isThreeLine: true,
        trailing: item.amount != null
            ? Text(
                '${item.isDebit ? '-' : '+'} ${CalculationService.formatCurrency(item.amount!)}',
                style: TextStyle(
                  fontSize: 13,
                  fontWeight: FontWeight.bold,
                  color: item.isDebit ? AppColors.error : AppColors.success,
                ),
              )
            : null,
        onTap: item.loanId != null
            ? () => Navigator.push(context, MaterialPageRoute(builder: (_) => LoanDetailScreen(loanId: item.loanId!)))
            : null,
      ),
    );
  }
}
