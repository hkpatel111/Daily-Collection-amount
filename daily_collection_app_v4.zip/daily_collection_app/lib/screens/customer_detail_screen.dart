import 'package:flutter/material.dart';
import '../utils/constants.dart';
import '../models/customer.dart';
import '../models/loan.dart';
import '../database/dao/customer_dao.dart';
import '../database/dao/loan_dao.dart';
import '../database/dao/collection_dao.dart';
import '../services/calculation_service.dart';
import 'loan_detail_screen.dart';
import 'add_customer_screen.dart';

class CustomerDetailScreen extends StatefulWidget {
  final int customerId;
  const CustomerDetailScreen({super.key, required this.customerId});

  @override
  State<CustomerDetailScreen> createState() => _CustomerDetailScreenState();
}

class _CustomerDetailScreenState extends State<CustomerDetailScreen> {
  final CustomerDao _customerDao = CustomerDao();
  final LoanDao _loanDao = LoanDao();
  final CollectionDao _collectionDao = CollectionDao();

  Customer? _customer;
  List<Loan> _activeLoans = [];
  List<Loan> _pastLoans = [];
  bool _isLoading = true;
  double _totalGiven = 0;
  double _totalCollected = 0;
  double _totalProfit = 0;

  @override
  void initState() { super.initState(); _loadData(); }

  Future<void> _loadData() async {
    setState(() => _isLoading = true);
    _customer = await _customerDao.getById(widget.customerId);
    _activeLoans = await _loanDao.getActiveLoansByCustomer(widget.customerId);
    final allLoans = await _loanDao.getByCustomer(widget.customerId);
    _pastLoans = allLoans.where((l) => l.status != LoanStatus.active && l.status != LoanStatus.overdue).toList();
    _totalGiven = 0; _totalCollected = 0; _totalProfit = 0;
    for (final loan in allLoans) {
      if (loan.status != LoanStatus.cancelled) {
        _totalGiven += loan.principal;
        _totalProfit += loan.profit;
      }
      _totalCollected += await _collectionDao.getTotalCollectedByLoan(loan.id!);
    }
    setState(() => _isLoading = false);
  }

  Future<void> _editCustomer() async {
    final nameCtrl = TextEditingController(text: _customer!.name);
    final mobileCtrl = TextEditingController(text: _customer!.mobile);
    final formKey = GlobalKey<FormState>();
    final result = await showDialog<bool>(
      context: context,
      builder: (ctx) => AlertDialog(
        title: const Text('Edit Customer'),
        content: Form(
          key: formKey,
          child: Column(mainAxisSize: MainAxisSize.min, children: [
            TextFormField(controller: nameCtrl, decoration: const InputDecoration(labelText: 'Name', border: OutlineInputBorder()),
              validator: (v) => v == null || v.trim().isEmpty ? 'Required' : null),
            const SizedBox(height: 12),
            TextFormField(controller: mobileCtrl, decoration: const InputDecoration(labelText: 'Mobile', border: OutlineInputBorder()), keyboardType: TextInputType.phone, maxLength: 10),
          ]),
        ),
        actions: [
          TextButton(onPressed: () => Navigator.pop(ctx, false), child: const Text('Cancel')),
          ElevatedButton(onPressed: () { if (formKey.currentState!.validate()) Navigator.pop(ctx, true); }, child: const Text('Save')),
        ],
      ),
    );
    if (result == true) {
      await _customerDao.update(_customer!.copyWith(name: nameCtrl.text.trim(), mobile: mobileCtrl.text.trim()));
      _loadData();
    }
  }

  Future<void> _deletePermanently() async {
    final confirmed = await showDialog<bool>(
      context: context,
      builder: (ctx) => AlertDialog(
        title: const Text('Delete Permanently'),
        content: Text('Delete ${_customer!.name} and ALL related data? This cannot be undone.'),
        actions: [
          TextButton(onPressed: () => Navigator.pop(ctx, false), child: const Text('Cancel')),
          ElevatedButton(style: ElevatedButton.styleFrom(backgroundColor: AppColors.error), onPressed: () => Navigator.pop(ctx, true), child: const Text('Delete')),
        ],
      ),
    );
    if (confirmed == true) {
      await _customerDao.permanentDelete(widget.customerId);
      if (mounted) Navigator.pop(context);
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text(_customer?.name ?? 'Customer'),
        actions: [
          IconButton(icon: const Icon(Icons.edit), onPressed: _editCustomer),
          PopupMenuButton(
            itemBuilder: (ctx) => [
              const PopupMenuItem(value: 'archive', child: Text('Archive')),
              const PopupMenuItem(value: 'delete', child: Text('Delete Permanently')),
            ],
            onSelected: (v) {
              if (v == 'archive') { _customerDao.softDelete(widget.customerId); Navigator.pop(context); }
              if (v == 'delete') _deletePermanently();
            },
          ),
        ],
      ),
      body: _isLoading
        ? const Center(child: CircularProgressIndicator())
        : ListView(
            padding: const EdgeInsets.all(AppConstants.padding),
            children: [
              Card(
                child: Padding(
                  padding: const EdgeInsets.all(16),
                  child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
                    Row(children: [const Icon(Icons.phone, color: AppColors.primary), const SizedBox(width: 8), Text(_customer?.mobile ?? '', style: const TextStyle(fontSize: 16))]),
                    const SizedBox(height: 8),
                    Text('Customer since: ${CalculationService.formatDate(_customer!.createdAt.substring(0, 10))}', style: TextStyle(color: AppColors.textSecondary, fontSize: 13)),
                  ]),
                ),
              ),
              const SizedBox(height: 16),
              if (_activeLoans.isNotEmpty || _pastLoans.isNotEmpty) ...[
                Card(
                  color: AppColors.primary.withOpacity(0.05),
                  child: Padding(
                    padding: const EdgeInsets.all(16),
                    child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
                      Text('CUSTOMER SUMMARY', style: TextStyle(fontSize: 13, fontWeight: FontWeight.bold, color: AppColors.textSecondary)),
                      const SizedBox(height: 8),
                      _buildRow('Total Given', CalculationService.formatCurrency(_totalGiven)),
                      _buildRow('Total Collected', CalculationService.formatCurrency(_totalCollected)),
                      _buildRow('Total Profit', CalculationService.formatCurrency(_totalProfit)),
                      _buildRow('Active Loans', '${_activeLoans.length}'),
                      _buildRow('Past Loans', '${_pastLoans.length}'),
                    ]),
                  ),
                ),
                const SizedBox(height: 16),
              ],
              if (_activeLoans.isNotEmpty) ...[
                Text('ACTIVE LOANS', style: TextStyle(fontSize: 13, fontWeight: FontWeight.bold, color: AppColors.textSecondary)),
                const SizedBox(height: 8),
                ..._activeLoans.map((loan) => _buildLoanCard(loan)),
                const SizedBox(height: 16),
              ],
              if (_pastLoans.isNotEmpty) ...[
                Text('LOAN HISTORY', style: TextStyle(fontSize: 13, fontWeight: FontWeight.bold, color: AppColors.textSecondary)),
                const SizedBox(height: 8),
                ..._pastLoans.map((loan) => _buildLoanCard(loan)),
              ],
              if (_activeLoans.isEmpty && _pastLoans.isEmpty)
                Card(
                  child: ListTile(
                    leading: const Icon(Icons.add_circle, color: AppColors.primary),
                    title: const Text('No loans yet'),
                    subtitle: const Text('Create a new loan'),
                    onTap: () async {
                      await Navigator.push(context, MaterialPageRoute(builder: (_) => const AddCustomerScreen()));
                      _loadData();
                    },
                  ),
                ),
            ],
          ),
    );
  }

  Widget _buildRow(String label, String value) {
    return Padding(padding: const EdgeInsets.symmetric(vertical: 4),
      child: Row(mainAxisAlignment: MainAxisAlignment.spaceBetween, children: [
        Text(label, style: TextStyle(color: AppColors.textSecondary)),
        Text(value, style: const TextStyle(fontWeight: FontWeight.bold)),
      ]));
  }

  Widget _buildLoanCard(Loan loan) {
    return Card(
      child: FutureBuilder<double>(
        future: _collectionDao.getTotalCollectedByLoan(loan.id!),
        builder: (context, snapshot) {
          final collected = snapshot.data ?? 0;
          return ListTile(
            title: Text('#${loan.id} - ${CalculationService.formatCurrency(loan.principal)} -> ${CalculationService.formatCurrency(loan.returnAmount)}'),
            subtitle: Text('Collected: ${CalculationService.formatCurrency(collected)} | ${loan.totalDays} days | ${loan.status.label}'),
            trailing: LoanStatusBadge(status: loan.status),
            onTap: () async {
              await Navigator.push(context, MaterialPageRoute(builder: (_) => LoanDetailScreen(loanId: loan.id!)));
              _loadData();
            },
          );
        },
      ),
    );
  }
}
