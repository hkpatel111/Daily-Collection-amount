import 'dart:io';
import 'package:pdf/pdf.dart';
import 'package:pdf/widgets.dart' as pw;
import 'package:path_provider/path_provider.dart';
import 'package:share_plus/share_plus.dart';
import 'package:intl/intl.dart';
import '../models/loan.dart';
import '../models/customer.dart';
import '../models/collection_entry.dart';
import 'calculation_service.dart';

class PdfService {
  static final _currency = NumberFormat.currency(locale: 'en_IN', symbol: 'Rs ', decimalDigits: 0);

  Future<File> generateCollectionReceipt({
    required Customer customer,
    required Loan loan,
    required CollectionEntry entry,
    required String ownerName,
  }) async {
    final pdf = pw.Document();
    final dateStr = CalculationService.formatDate(entry.collectionDate);

    pdf.addPage(
      pw.Page(
        pageFormat: PdfPageFormat.a4,
        margin: const pw.EdgeInsets.all(32),
        build: (context) {
          return pw.Column(
            crossAxisAlignment: pw.CrossAxisAlignment.start,
            children: [
              pw.Center(
                child: pw.Text(
                  'PAYMENT RECEIPT',
                  style: pw.TextStyle(fontSize: 20, fontWeight: pw.FontWeight.bold),
                ),
              ),
              pw.SizedBox(height: 8),
              pw.Center(
                child: pw.Text(
                  ownerName.isNotEmpty ? ownerName : 'Daily Collection App',
                  style: const pw.TextStyle(fontSize: 14),
                ),
              ),
              pw.SizedBox(height: 4),
              pw.Center(
                child: pw.Text(
                  'Created by Harish',
                  style: pw.TextStyle(fontSize: 10, color: PdfColors.grey600),
                ),
              ),
              pw.Divider(thickness: 1),
              pw.SizedBox(height: 12),
              _row('Receipt Date', dateStr),
              _row('Customer', customer.name),
              if (customer.nickname != null && customer.nickname!.isNotEmpty)
                _row('Nickname', customer.nickname!),
              _row('Mobile', customer.mobile),
              _row('Loan ID', '#${loan.id}'),
              if (loan.loanTag.isNotEmpty) _row('Loan Tag', loan.loanTag),
              pw.SizedBox(height: 8),
              pw.Divider(),
              pw.SizedBox(height: 8),
              _row('Principal', _currency.format(loan.principal)),
              _row('Return Amount', _currency.format(loan.returnAmount)),
              _row('Interest Type', loan.interestType.label),
              if (loan.interestType == InterestType.compound)
                _row('Compounding', loan.compoundingFrequency.label),
              _row('Frequency', loan.installmentFrequency.label),
              pw.SizedBox(height: 8),
              pw.Divider(),
              pw.SizedBox(height: 8),
              _row('Expected Amount', _currency.format(entry.expectedAmount)),
              _row('Collected Amount', _currency.format(entry.collectedAmount), bold: true),
              if (entry.shortfall > 0)
                _row('Shortfall', _currency.format(entry.shortfall)),
              if (entry.overdueInterest > 0)
                _row('Overdue Interest', _currency.format(entry.overdueInterest)),
              _row('Payment Mode', entry.paymentMode.toUpperCase()),
              if (entry.note != null && entry.note!.isNotEmpty)
                _row('Note', entry.note!),
              pw.SizedBox(height: 24),
              pw.Divider(),
              pw.SizedBox(height: 8),
              pw.Center(
                child: pw.Text(
                  'Thank you for your payment!',
                  style: pw.TextStyle(fontSize: 12, fontStyle: pw.FontStyle.italic),
                ),
              ),
              pw.SizedBox(height: 4),
              pw.Center(
                child: pw.Text(
                  'This is a computer generated receipt.',
                  style: pw.TextStyle(fontSize: 9, color: PdfColors.grey600),
                ),
              ),
            ],
          );
        },
      ),
    );

    final dir = await getTemporaryDirectory();
    final file = File('${dir.path}/receipt_${loan.id}_${entry.id ?? DateTime.now().millisecondsSinceEpoch}.pdf');
    await file.writeAsBytes(await pdf.save());
    return file;
  }

  Future<File> generateLoanSummaryPdf({
    required Customer customer,
    required Loan loan,
    required double totalCollected,
    required double outstanding,
    required String ownerName,
  }) async {
    final pdf = pw.Document();

    pdf.addPage(
      pw.Page(
        pageFormat: PdfPageFormat.a4,
        margin: const pw.EdgeInsets.all(32),
        build: (context) {
          return pw.Column(
            crossAxisAlignment: pw.CrossAxisAlignment.start,
            children: [
              pw.Center(
                child: pw.Text('LOAN SUMMARY', style: pw.TextStyle(fontSize: 20, fontWeight: pw.FontWeight.bold)),
              ),
              pw.SizedBox(height: 4),
              pw.Center(child: pw.Text(ownerName.isNotEmpty ? ownerName : 'Daily Collection App')),
              pw.Center(child: pw.Text('Created by Harish', style: pw.TextStyle(fontSize: 10, color: PdfColors.grey600))),
              pw.Divider(),
              pw.SizedBox(height: 12),
              _row('Customer', customer.name),
              _row('Mobile', customer.mobile),
              _row('Loan ID', '#${loan.id}'),
              _row('Start Date', CalculationService.formatDate(loan.startDate)),
              _row('End Date', CalculationService.formatDate(loan.endDate)),
              _row('Status', loan.status.label),
              pw.SizedBox(height: 8),
              _row('Principal', _currency.format(loan.principal)),
              _row('Return Amount', _currency.format(loan.returnAmount)),
              _row('Profit', _currency.format(loan.profit)),
              _row('Monthly Rate', '${loan.monthlyInterestRate.toStringAsFixed(2)}%'),
              _row('Interest Type', loan.interestType.label),
              if (loan.interestType == InterestType.compound)
                _row('Compounding', 'Compounded ${loan.compoundingFrequency.label}'),
              _row('Frequency', loan.installmentFrequency.label),
              _row('Installment Amount', _currency.format(loan.installmentAmount)),
              _row('Total Installments', '${loan.totalInstallments}'),
              pw.SizedBox(height: 8),
              pw.Divider(),
              _row('Total Collected', _currency.format(totalCollected)),
              _row('Outstanding', _currency.format(outstanding), bold: true),
              pw.SizedBox(height: 24),
              pw.Center(child: pw.Text('Generated on ${CalculationService.formatDate(CalculationService.today())}',
                  style: pw.TextStyle(fontSize: 9, color: PdfColors.grey600))),
            ],
          );
        },
      ),
    );

    final dir = await getTemporaryDirectory();
    final file = File('${dir.path}/loan_summary_${loan.id}.pdf');
    await file.writeAsBytes(await pdf.save());
    return file;
  }

  Future<void> sharePdf(File file, {String? subject}) async {
    await Share.shareXFiles([XFile(file.path)], subject: subject ?? 'Daily Collection Document');
  }

  pw.Widget _row(String label, String value, {bool bold = false}) {
    return pw.Padding(
      padding: const pw.EdgeInsets.symmetric(vertical: 3),
      child: pw.Row(
        mainAxisAlignment: pw.MainAxisAlignment.spaceBetween,
        children: [
          pw.Text(label, style: const pw.TextStyle(fontSize: 11)),
          pw.Text(value, style: pw.TextStyle(fontSize: 11, fontWeight: bold ? pw.FontWeight.bold : pw.FontWeight.normal)),
        ],
      ),
    );
  }
}
