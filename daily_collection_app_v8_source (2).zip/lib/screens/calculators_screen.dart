import 'package:flutter/material.dart';
import 'package:share_plus/share_plus.dart';
import '../utils/constants.dart';
import '../services/calculation_service.dart';

class CalculatorsScreen extends StatefulWidget {
  const CalculatorsScreen({super.key});

  @override
  State<CalculatorsScreen> createState() => _CalculatorsScreenState();
}

class _CalculatorsScreenState extends State<CalculatorsScreen> {
  int _selectedCalculator = 0;

  final _calculators = [
    {'name': 'Daily Collection', 'icon': Icons.today},
    {'name': 'EMI', 'icon': Icons.payment},
    {'name': 'SIP', 'icon': Icons.savings},
    {'name': 'Future Value', 'icon': Icons.trending_up},
    {'name': 'Rate of Return', 'icon': Icons.percent},
    {'name': 'Home Loan', 'icon': Icons.home},
    {'name': 'Simple Interest', 'icon': Icons.calculate},
    {'name': 'Compound Interest', 'icon': Icons.auto_graph},
    {'name': 'Profit Margin', 'icon': Icons.attach_money},
    {'name': 'Loan Compare', 'icon': Icons.compare_arrows},
  ];

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: const Text('Calculators')),
      body: Column(children: [
        SizedBox(height: 60, child: ListView.builder(
          scrollDirection: Axis.horizontal,
          padding: const EdgeInsets.symmetric(horizontal: 8),
          itemCount: _calculators.length,
          itemBuilder: (ctx, i) => Padding(padding: const EdgeInsets.symmetric(horizontal: 4, vertical: 8),
            child: ChoiceChip(
              label: Row(mainAxisSize: MainAxisSize.min, children: [
                Icon(_calculators[i]['icon'] as IconData, size: 16),
                const SizedBox(width: 4),
                Text(_calculators[i]['name'] as String),
              ]),
              selected: _selectedCalculator == i,
              onSelected: (_) => setState(() => _selectedCalculator = i),
              selectedColor: AppColors.primary.withOpacity(0.2),
            ),
          ),
        )),
        Expanded(child: _buildCalculator()),
      ]),
    );
  }

  Widget _buildCalculator() {
    switch (_selectedCalculator) {
      case 0: return const _DailyCollectionCalculator();
      case 1: return const _EMICalculator();
      case 2: return const _SIPCalculator();
      case 3: return const _FutureValueCalculator();
      case 4: return const _RateOfReturnCalculator();
      case 5: return const _HomeLoanCalculator();
      case 6: return const _SimpleInterestCalculator();
      case 7: return const _CompoundInterestCalculator();
      case 8: return const _ProfitMarginCalculator();
      case 9: return const _LoanCompareCalculator();
      default: return const SizedBox();
    }
  }
}

class _CalcCard extends StatelessWidget {
  final String title;
  final List<Widget> children;
  const _CalcCard({required this.title, required this.children});

  @override
  Widget build(BuildContext context) {
    return SingleChildScrollView(padding: const EdgeInsets.all(16),
      child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
        Text(title, style: const TextStyle(fontSize: 18, fontWeight: FontWeight.bold)),
        const SizedBox(height: 16),
        ...children,
      ]),
    );
  }
}

Widget _inputField(String label, TextEditingController controller, {String prefix = 'Rs '}) {
  return Padding(padding: const EdgeInsets.only(bottom: 12),
    child: TextField(
      controller: controller,
      decoration: InputDecoration(labelText: label, border: const OutlineInputBorder(), prefixText: prefix),
      keyboardType: TextInputType.number,
    ));
}

Widget _resultRow(String label, String value) {
  return Padding(padding: const EdgeInsets.symmetric(vertical: 4),
    child: Row(mainAxisAlignment: MainAxisAlignment.spaceBetween, children: [
      Text(label, style: TextStyle(color: AppColors.textSecondary)),
      Text(value, style: const TextStyle(fontWeight: FontWeight.bold)),
    ]));
}

void _shareResult(String title, String content) {
  Share.share('$title\n\n$content', subject: title);
}

class _DailyCollectionCalculator extends StatefulWidget {
  const _DailyCollectionCalculator();
  @override
  State<_DailyCollectionCalculator> createState() => _DailyCollectionCalculatorState();
}

class _DailyCollectionCalculatorState extends State<_DailyCollectionCalculator> {
  final _principal = TextEditingController();
  final _return = TextEditingController();
  final _installment = TextEditingController();
  String _result = '';

  void _calc() {
    final p = double.tryParse(_principal.text) ?? 0;
    final r = double.tryParse(_return.text) ?? 0;
    final i = double.tryParse(_installment.text) ?? 0;
    if (p > 0 && r > p && i > 0) {
      final res = CalculationService.calculateLoan(principal: p, returnAmount: r, dailyInstallment: i, startDate: CalculationService.today());
      setState(() {
        _result = 'Total Days: ${res.totalDays}\n'
          'Profit: ${CalculationService.formatCurrency(res.profit)}\n'
          'Daily Rate: ${res.dailyInterestRate.toStringAsFixed(3)}%\n'
          'Monthly Rate: ${res.monthlyInterestRate.toStringAsFixed(3)}%\n'
          'Yearly Rate: ${res.yearlyInterestRate.toStringAsFixed(3)}%';
      });
    }
  }

  @override
  Widget build(BuildContext context) {
    return _CalcCard(title: 'Daily Collection Calculator', children: [
      _inputField('Principal', _principal),
      _inputField('Return Amount', _return),
      _inputField('Daily Installment', _installment),
      ElevatedButton(onPressed: _calc, child: const Text('Calculate')),
      if (_result.isNotEmpty) ...[const SizedBox(height: 16), Card(child: Padding(padding: const EdgeInsets.all(16), child: Column(children: [
        Text(_result, style: const TextStyle(fontSize: 14, height: 1.5)),
        const SizedBox(height: 8),
        TextButton(onPressed: () => _shareResult('Daily Collection Calc', _result), child: const Text('Share Result')),
      ])))],
    ]);
  }
}

class _EMICalculator extends StatefulWidget {
  const _EMICalculator();
  @override
  State<_EMICalculator> createState() => _EMICalculatorState();
}

class _EMICalculatorState extends State<_EMICalculator> {
  final _principal = TextEditingController();
  final _rate = TextEditingController();
  final _months = TextEditingController();
  String _result = '';
  void _calc() {
    final p = double.tryParse(_principal.text) ?? 0;
    final r = double.tryParse(_rate.text) ?? 0;
    final m = int.tryParse(_months.text) ?? 0;
    if (p > 0 && m > 0) {
      final res = CalculationService.calculateEMI(p, r, m);
      setState(() {
        _result = 'Monthly EMI: ${CalculationService.formatCurrency(res['emi']!)}\n'
          'Total Payment: ${CalculationService.formatCurrency(res['total']!)}\n'
          'Total Interest: ${CalculationService.formatCurrency(res['interest']!)}';
      });
    }
  }
  @override
  Widget build(BuildContext context) {
    return _CalcCard(title: 'EMI Calculator', children: [
      _inputField('Loan Amount', _principal),
      _inputField('Annual Interest Rate (%)', _rate, prefix: ''),
      _inputField('Tenure (months)', _months, prefix: ''),
      ElevatedButton(onPressed: _calc, child: const Text('Calculate')),
      if (_result.isNotEmpty) ...[const SizedBox(height: 16), Card(child: Padding(padding: const EdgeInsets.all(16), child: Column(children: [
        Text(_result, style: const TextStyle(fontSize: 14, height: 1.5)),
        const SizedBox(height: 8),
        TextButton(onPressed: () => _shareResult('EMI Calc', _result), child: const Text('Share Result')),
      ])))],
    ]);
  }
}

class _SIPCalculator extends StatefulWidget {
  const _SIPCalculator();
  @override
  State<_SIPCalculator> createState() => _SIPCalculatorState();
}

class _SIPCalculatorState extends State<_SIPCalculator> {
  final _monthly = TextEditingController();
  final _rate = TextEditingController();
  final _years = TextEditingController();
  String _result = '';
  void _calc() {
    final m = double.tryParse(_monthly.text) ?? 0;
    final r = double.tryParse(_rate.text) ?? 0;
    final y = int.tryParse(_years.text) ?? 0;
    if (m > 0 && y > 0) {
      final res = CalculationService.calculateSIP(m, r, y);
      setState(() {
        _result = 'Maturity Value: ${CalculationService.formatCurrency(res['maturity']!)}\n'
          'Total Invested: ${CalculationService.formatCurrency(res['invested']!)}\n'
          'Total Gain: ${CalculationService.formatCurrency(res['gain']!)}';
      });
    }
  }
  @override
  Widget build(BuildContext context) {
    return _CalcCard(title: 'SIP Calculator', children: [
      _inputField('Monthly Investment', _monthly),
      _inputField('Expected Return (%)', _rate, prefix: ''),
      _inputField('Period (years)', _years, prefix: ''),
      ElevatedButton(onPressed: _calc, child: const Text('Calculate')),
      if (_result.isNotEmpty) ...[const SizedBox(height: 16), Card(child: Padding(padding: const EdgeInsets.all(16), child: Column(children: [
        Text(_result, style: const TextStyle(fontSize: 14, height: 1.5)),
        const SizedBox(height: 8),
        TextButton(onPressed: () => _shareResult('SIP Calc', _result), child: const Text('Share Result')),
      ])))],
    ]);
  }
}

class _FutureValueCalculator extends StatefulWidget {
  const _FutureValueCalculator();
  @override
  State<_FutureValueCalculator> createState() => _FutureValueCalculatorState();
}

class _FutureValueCalculatorState extends State<_FutureValueCalculator> {
  final _pv = TextEditingController();
  final _rate = TextEditingController();
  final _years = TextEditingController();
  String _result = '';
  void _calc() {
    final pv = double.tryParse(_pv.text) ?? 0;
    final r = double.tryParse(_rate.text) ?? 0;
    final y = int.tryParse(_years.text) ?? 0;
    if (pv > 0 && y > 0) {
      final res = CalculationService.calculateFutureValue(pv, r, y);
      setState(() {
        _result = 'Future Value: ${CalculationService.formatCurrency(res['future']!)}\nTotal Gain: ${CalculationService.formatCurrency(res['gain']!)}';
      });
    }
  }
  @override
  Widget build(BuildContext context) {
    return _CalcCard(title: 'Future Value Calculator', children: [
      _inputField('Present Value', _pv),
      _inputField('Annual Rate (%)', _rate, prefix: ''),
      _inputField('Years', _years, prefix: ''),
      ElevatedButton(onPressed: _calc, child: const Text('Calculate')),
      if (_result.isNotEmpty) ...[const SizedBox(height: 16), Card(child: Padding(padding: const EdgeInsets.all(16), child: Column(children: [
        Text(_result, style: const TextStyle(fontSize: 14, height: 1.5)),
        const SizedBox(height: 8),
        TextButton(onPressed: () => _shareResult('Future Value Calc', _result), child: const Text('Share Result')),
      ])))],
    ]);
  }
}

class _RateOfReturnCalculator extends StatefulWidget {
  const _RateOfReturnCalculator();
  @override
  State<_RateOfReturnCalculator> createState() => _RateOfReturnCalculatorState();
}

class _RateOfReturnCalculatorState extends State<_RateOfReturnCalculator> {
  final _invested = TextEditingController();
  final _current = TextEditingController();
  final _years = TextEditingController();
  String _result = '';
  void _calc() {
    final inv = double.tryParse(_invested.text) ?? 0;
    final cur = double.tryParse(_current.text) ?? 0;
    final y = int.tryParse(_years.text) ?? 0;
    if (inv > 0 && cur > 0 && y > 0) {
      final rate = CalculationService.calculateRateOfReturn(inv, cur, y);
      setState(() {
        _result = 'Annualized Return: ${rate.toStringAsFixed(2)}%\nTotal Return: ${CalculationService.formatCurrency(cur - inv)}';
      });
    }
  }
  @override
  Widget build(BuildContext context) {
    return _CalcCard(title: 'Rate of Return Calculator', children: [
      _inputField('Amount Invested', _invested),
      _inputField('Current Value', _current),
      _inputField('Years', _years, prefix: ''),
      ElevatedButton(onPressed: _calc, child: const Text('Calculate')),
      if (_result.isNotEmpty) ...[const SizedBox(height: 16), Card(child: Padding(padding: const EdgeInsets.all(16), child: Column(children: [
        Text(_result, style: const TextStyle(fontSize: 14, height: 1.5)),
        const SizedBox(height: 8),
        TextButton(onPressed: () => _shareResult('Rate of Return Calc', _result), child: const Text('Share Result')),
      ])))],
    ]);
  }
}

class _HomeLoanCalculator extends StatefulWidget {
  const _HomeLoanCalculator();
  @override
  State<_HomeLoanCalculator> createState() => _HomeLoanCalculatorState();
}

class _HomeLoanCalculatorState extends State<_HomeLoanCalculator> {
  final _principal = TextEditingController();
  final _rate = TextEditingController();
  final _years = TextEditingController();
  String _result = '';
  void _calc() {
    final p = double.tryParse(_principal.text) ?? 0;
    final r = double.tryParse(_rate.text) ?? 0;
    final y = int.tryParse(_years.text) ?? 0;
    final m = y * 12;
    if (p > 0 && m > 0) {
      final res = CalculationService.calculateEMI(p, r, m);
      setState(() {
        _result = 'Monthly EMI: ${CalculationService.formatCurrency(res['emi']!)}\n'
          'Total Payment: ${CalculationService.formatCurrency(res['total']!)}\n'
          'Total Interest: ${CalculationService.formatCurrency(res['interest']!)}';
      });
    }
  }
  @override
  Widget build(BuildContext context) {
    return _CalcCard(title: 'Home Loan Calculator', children: [
      _inputField('Loan Amount', _principal),
      _inputField('Interest Rate (%)', _rate, prefix: ''),
      _inputField('Tenure (years)', _years, prefix: ''),
      ElevatedButton(onPressed: _calc, child: const Text('Calculate')),
      if (_result.isNotEmpty) ...[const SizedBox(height: 16), Card(child: Padding(padding: const EdgeInsets.all(16), child: Column(children: [
        Text(_result, style: const TextStyle(fontSize: 14, height: 1.5)),
        const SizedBox(height: 8),
        TextButton(onPressed: () => _shareResult('Home Loan Calc', _result), child: const Text('Share Result')),
      ])))],
    ]);
  }
}

class _SimpleInterestCalculator extends StatefulWidget {
  const _SimpleInterestCalculator();
  @override
  State<_SimpleInterestCalculator> createState() => _SimpleInterestCalculatorState();
}

class _SimpleInterestCalculatorState extends State<_SimpleInterestCalculator> {
  final _principal = TextEditingController();
  final _rate = TextEditingController();
  final _years = TextEditingController();
  String _result = '';
  void _calc() {
    final p = double.tryParse(_principal.text) ?? 0;
    final r = double.tryParse(_rate.text) ?? 0;
    final y = int.tryParse(_years.text) ?? 0;
    if (p > 0 && y > 0) {
      final res = CalculationService.calculateSimpleInterest(p, r, y.toDouble());
      setState(() {
        _result = 'Interest: ${CalculationService.formatCurrency(res['interest']!)}\nTotal: ${CalculationService.formatCurrency(res['total']!)}';
      });
    }
  }
  @override
  Widget build(BuildContext context) {
    return _CalcCard(title: 'Simple Interest Calculator', children: [
      _inputField('Principal', _principal),
      _inputField('Rate (%)', _rate, prefix: ''),
      _inputField('Years', _years, prefix: ''),
      ElevatedButton(onPressed: _calc, child: const Text('Calculate')),
      if (_result.isNotEmpty) ...[const SizedBox(height: 16), Card(child: Padding(padding: const EdgeInsets.all(16), child: Column(children: [
        Text(_result, style: const TextStyle(fontSize: 14, height: 1.5)),
        const SizedBox(height: 8),
        TextButton(onPressed: () => _shareResult('Simple Interest Calc', _result), child: const Text('Share Result')),
      ])))],
    ]);
  }
}

class _CompoundInterestCalculator extends StatefulWidget {
  const _CompoundInterestCalculator();
  @override
  State<_CompoundInterestCalculator> createState() => _CompoundInterestCalculatorState();
}

class _CompoundInterestCalculatorState extends State<_CompoundInterestCalculator> {
  final _principal = TextEditingController();
  final _rate = TextEditingController();
  final _years = TextEditingController();
  final _freq = TextEditingController(text: '4');
  String _result = '';
  void _calc() {
    final p = double.tryParse(_principal.text) ?? 0;
    final r = double.tryParse(_rate.text) ?? 0;
    final y = int.tryParse(_years.text) ?? 0;
    final f = int.tryParse(_freq.text) ?? 1;
    if (p > 0 && y > 0) {
      final res = CalculationService.calculateCompoundInterest(p, r, y.toDouble(), f);
      setState(() {
        _result = 'Maturity Amount: ${CalculationService.formatCurrency(res['amount']!)}\nInterest: ${CalculationService.formatCurrency(res['interest']!)}';
      });
    }
  }
  @override
  Widget build(BuildContext context) {
    return _CalcCard(title: 'Compound Interest Calculator', children: [
      _inputField('Principal', _principal),
      _inputField('Rate (%)', _rate, prefix: ''),
      _inputField('Years', _years, prefix: ''),
      _inputField('Frequency/Year', _freq, prefix: ''),
      ElevatedButton(onPressed: _calc, child: const Text('Calculate')),
      if (_result.isNotEmpty) ...[const SizedBox(height: 16), Card(child: Padding(padding: const EdgeInsets.all(16), child: Column(children: [
        Text(_result, style: const TextStyle(fontSize: 14, height: 1.5)),
        const SizedBox(height: 8),
        TextButton(onPressed: () => _shareResult('Compound Interest Calc', _result), child: const Text('Share Result')),
      ])))],
    ]);
  }
}

class _ProfitMarginCalculator extends StatefulWidget {
  const _ProfitMarginCalculator();
  @override
  State<_ProfitMarginCalculator> createState() => _ProfitMarginCalculatorState();
}

class _ProfitMarginCalculatorState extends State<_ProfitMarginCalculator> {
  final _cost = TextEditingController();
  final _selling = TextEditingController();
  String _result = '';
  void _calc() {
    final c = double.tryParse(_cost.text) ?? 0;
    final s = double.tryParse(_selling.text) ?? 0;
    if (c > 0) {
      final res = CalculationService.calculateProfitMargin(c, s);
      setState(() {
        _result = 'Profit: ${CalculationService.formatCurrency(res['profit']!)}\nMargin: ${res['margin']!.toStringAsFixed(2)}%';
      });
    }
  }
  @override
  Widget build(BuildContext context) {
    return _CalcCard(title: 'Profit Margin Calculator', children: [
      _inputField('Cost Price', _cost),
      _inputField('Selling Price', _selling),
      ElevatedButton(onPressed: _calc, child: const Text('Calculate')),
      if (_result.isNotEmpty) ...[const SizedBox(height: 16), Card(child: Padding(padding: const EdgeInsets.all(16), child: Column(children: [
        Text(_result, style: const TextStyle(fontSize: 14, height: 1.5)),
        const SizedBox(height: 8),
        TextButton(onPressed: () => _shareResult('Profit Margin Calc', _result), child: const Text('Share Result')),
      ])))],
    ]);
  }
}

class _LoanCompareCalculator extends StatefulWidget {
  const _LoanCompareCalculator();
  @override
  State<_LoanCompareCalculator> createState() => _LoanCompareCalculatorState();
}

class _LoanCompareCalculatorState extends State<_LoanCompareCalculator> {
  final _p1 = TextEditingController(); final _r1 = TextEditingController(); final _d1 = TextEditingController();
  final _p2 = TextEditingController(); final _r2 = TextEditingController(); final _d2 = TextEditingController();
  String _result = '';
  void _calc() {
    final p1 = double.tryParse(_p1.text) ?? 0; final r1 = double.tryParse(_r1.text) ?? 0; final d1 = int.tryParse(_d1.text) ?? 0;
    final p2 = double.tryParse(_p2.text) ?? 0; final r2 = double.tryParse(_r2.text) ?? 0; final d2 = int.tryParse(_d2.text) ?? 0;
    if (p1 > 0 && p2 > 0) {
      final profit1 = r1 - p1; final profit2 = r2 - p2;
      final daily1 = d1 > 0 ? r1 / d1 : 0.0; final daily2 = d2 > 0 ? r2 / d2 : 0.0;
      setState(() {
        _result = 'Loan 1: Profit ${CalculationService.formatCurrency(profit1)} | Daily ${CalculationService.formatCurrency(daily1)} | $d1 days\n'
          'Loan 2: Profit ${CalculationService.formatCurrency(profit2)} | Daily ${CalculationService.formatCurrency(daily2)} | $d2 days\n'
          'Profit Difference: ${CalculationService.formatCurrency((profit1 - profit2).abs())}';
      });
    }
  }
  @override
  Widget build(BuildContext context) {
    return _CalcCard(title: 'Loan Comparison Calculator', children: [
      const Text('Loan 1', style: TextStyle(fontWeight: FontWeight.bold)),
      _inputField('Principal 1', _p1),
      _inputField('Return 1', _r1),
      _inputField('Days 1', _d1, prefix: ''),
      const SizedBox(height: 8),
      const Text('Loan 2', style: TextStyle(fontWeight: FontWeight.bold)),
      _inputField('Principal 2', _p2),
      _inputField('Return 2', _r2),
      _inputField('Days 2', _d2, prefix: ''),
      ElevatedButton(onPressed: _calc, child: const Text('Compare')),
      if (_result.isNotEmpty) ...[const SizedBox(height: 16), Card(child: Padding(padding: const EdgeInsets.all(16), child: Column(children: [
        Text(_result, style: const TextStyle(fontSize: 14, height: 1.5)),
        const SizedBox(height: 8),
        TextButton(onPressed: () => _shareResult('Loan Comparison', _result), child: const Text('Share Result')),
      ])))],
    ]);
  }
}
