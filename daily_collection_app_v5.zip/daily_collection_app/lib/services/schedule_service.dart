import '../models/loan.dart';
import '../models/schedule_entry.dart';
import '../models/collection_entry.dart';
import '../models/settings.dart';
import '../models/transaction_log.dart';
import 'calculation_service.dart';
import '../database/dao/schedule_dao.dart';
import '../database/dao/collection_dao.dart';
import '../database/dao/loan_dao.dart';
import '../database/dao/transaction_log_dao.dart';

enum ExcessOption { nextInstallment, principalAdjust, separateEntry }

class ScheduleService {
  final ScheduleDao _scheduleDao = ScheduleDao();
  final CollectionDao _collectionDao = CollectionDao();
  final LoanDao _loanDao = LoanDao();
  final TransactionLogDao _logDao = TransactionLogDao();

  Future<void> generateSchedule(Loan loan, AppSettings settings) async {
    final List<ScheduleEntry> entries = [];
    String currentDate = loan.startDate;
    int dayNumber = 1;

    while (dayNumber <= loan.totalDays) {
      if (settings.sundayHolidayEnabled && CalculationService.isSunday(currentDate)) {
        entries.add(ScheduleEntry(
          loanId: loan.id!, dayNumber: dayNumber, scheduledDate: currentDate,
          expectedAmount: 0, isHoliday: true,
          status: ScheduleEntryStatus.holiday, createdAt: CalculationService.now(),
        ));
        dayNumber++;
        currentDate = CalculationService.addDays(currentDate, 1);
        continue;
      }

      double expectedAmount = loan.dailyInstallment;
      if (dayNumber == loan.totalDays) {
        expectedAmount = loan.lastDayAdjustedAmount;
      }

      entries.add(ScheduleEntry(
        loanId: loan.id!, dayNumber: dayNumber, scheduledDate: currentDate,
        expectedAmount: expectedAmount, isHoliday: false,
        status: ScheduleEntryStatus.pending, createdAt: CalculationService.now(),
      ));
      dayNumber++;
      currentDate = CalculationService.addDays(currentDate, 1);
    }

    await _scheduleDao.insertBatch(entries);
    await _logDao.insert(TransactionLog(
      actionType: 'schedule_generated', description: 'Schedule generated for Loan #${loan.id} (${loan.totalDays} days)',
      loanId: loan.id, createdAt: CalculationService.now(),
    ));
  }

  Future<CollectionEntry> recordCollection({
    required int loanId,
    required ScheduleEntry scheduleEntry,
    required double collectedAmount,
    String? note,
    PaymentMode paymentMode = PaymentMode.cash,
    ExcessOption? excessOption,
  }) async {
    final double expected = scheduleEntry.expectedAmount;
    double actualCollected = collectedAmount;
    double shortfall = (expected - collectedAmount).clamp(0.0, double.infinity);

    if (collectedAmount > expected) {
      if (excessOption == ExcessOption.nextInstallment) {
        // Excess goes to next installment - shortfall stays 0
        shortfall = 0;
      } else if (excessOption == ExcessOption.principalAdjust) {
        // Adjust the loan's return amount
        final loan = await _loanDao.getById(loanId);
        if (loan != null) {
          final newReturn = loan.returnAmount - (collectedAmount - expected);
          await _loanDao.update(loan.copyWith(returnAmount: newReturn, profit: newReturn - loan.principal));
          actualCollected = expected;
        }
      } else {
        // Separate entry - only record expected amount
        actualCollected = expected;
      }
    }

    ScheduleEntryStatus newStatus;
    bool isMissed = false;

    if (actualCollected >= expected) {
      newStatus = ScheduleEntryStatus.paid;
    } else if (actualCollected > 0) {
      newStatus = ScheduleEntryStatus.partial;
    } else {
      newStatus = ScheduleEntryStatus.missed;
      isMissed = true;
    }

    scheduleEntry.status = newStatus;
    await _scheduleDao.update(scheduleEntry);

    final entry = CollectionEntry(
      loanId: loanId, scheduleEntryId: scheduleEntry.id!,
      collectionDate: CalculationService.today(),
      expectedAmount: expected, collectedAmount: actualCollected,
      shortfall: shortfall, isMissed: isMissed, overdueInterest: 0.0,
      note: note, paymentMode: paymentMode,
      createdAt: CalculationService.now(), updatedAt: CalculationService.now(),
    );

    final id = await _collectionDao.insert(entry);
    await _logDao.insert(TransactionLog(
      actionType: 'collection', description: 'Collection of ${CalculationService.formatCurrency(actualCollected)} recorded for Loan #$loanId Day ${scheduleEntry.dayNumber}',
      loanId: loanId, amount: actualCollected, createdAt: CalculationService.now(),
    ));

    await _checkLoanCompletion(loanId);
    return entry.copyWith(id: id);
  }

  Future<void> editCollectionEntry(int entryId, double newAmount, String newDate, PaymentMode paymentMode) async {
    final entry = await _collectionDao.getById(entryId);
    if (entry == null) return;

    final scheduleEntry = await _scheduleDao.getById(entry.scheduleEntryId);
    if (scheduleEntry == null) return;

    final double expected = scheduleEntry.expectedAmount;
    double shortfall = (expected - newAmount).clamp(0.0, double.infinity);

    ScheduleEntryStatus newStatus;
    bool isMissed = false;

    if (newAmount >= expected) {
      newStatus = ScheduleEntryStatus.paid;
    } else if (newAmount > 0) {
      newStatus = ScheduleEntryStatus.partial;
    } else {
      newStatus = ScheduleEntryStatus.missed;
      isMissed = true;
    }

    entry.collectedAmount = newAmount;
    entry.shortfall = shortfall;
    entry.isMissed = isMissed;
    entry.collectionDate = newDate;
    entry.paymentMode = paymentMode;
    entry.updatedAt = CalculationService.now();
    await _collectionDao.update(entry);

    scheduleEntry.status = newStatus;
    await _scheduleDao.update(scheduleEntry);

    // Recalculate overdue interest for all entries
    final loan = await _loanDao.getById(entry.loanId);
    if (loan != null) {
      final settings = AppSettings();
      await updateOverdueInterest(entry.loanId, loan, settings);
    }

    await _logDao.insert(TransactionLog(
      actionType: 'edit_collection', description: 'Collection entry #$entryId edited to ${CalculationService.formatCurrency(newAmount)}',
      loanId: entry.loanId, amount: newAmount, createdAt: CalculationService.now(),
    ));
  }

  Future<void> deleteCollectionEntry(int entryId) async {
    final entry = await _collectionDao.getById(entryId);
    if (entry == null) return;

    final scheduleEntry = await _scheduleDao.getById(entry.scheduleEntryId);
    if (scheduleEntry != null) {
      scheduleEntry.status = ScheduleEntryStatus.pending;
      await _scheduleDao.update(scheduleEntry);
    }

    await _collectionDao.delete(entryId);
    await _logDao.insert(TransactionLog(
      actionType: 'delete_collection', description: 'Collection entry #$entryId deleted',
      loanId: entry.loanId, createdAt: CalculationService.now(),
    ));
  }

  Future<void> updateOverdueInterest(int loanId, Loan loan, AppSettings settings) async {
    final overdueEntries = await _scheduleDao.getOverdueEntries(loanId);

    for (final entry in overdueEntries) {
      final collections = await _collectionDao.getByScheduleEntryId(entry.id!);
      if (collections.isEmpty) continue;

      final collection = collections.first;
      final double overduePrincipal = collection.shortfall > 0
          ? collection.shortfall : collection.expectedAmount;

      final int daysOverdue = CalculationService.daysBetween(entry.scheduledDate, CalculationService.today());
      final double interest = CalculationService.calculateOverdueInterest(
        overduePrincipal: overduePrincipal,
        dailyInterestRate: loan.dailyInterestRate,
        daysOverdue: daysOverdue,
        gracePeriodDays: settings.gracePeriodDays,
      );

      collection.overdueInterest = interest;
      collection.updatedAt = CalculationService.now();
      await _collectionDao.update(collection);
    }
    await _updateLoanStatus(loanId, settings);
  }

  Future<void> _updateLoanStatus(int loanId, AppSettings settings) async {
    final loan = await _loanDao.getById(loanId);
    if (loan == null) return;
    if (loan.status == LoanStatus.completed || loan.status == LoanStatus.preClosed ||
        loan.status == LoanStatus.cancelled) return;

    final overdueEntries = await _scheduleDao.getOverdueEntries(loanId);
    if (overdueEntries.isEmpty) {
      await _loanDao.updateStatus(loanId, LoanStatus.active);
      return;
    }

    int maxOverdueDays = 0;
    for (final entry in overdueEntries) {
      final int days = CalculationService.daysBetween(entry.scheduledDate, CalculationService.today());
      if (days > maxOverdueDays) maxOverdueDays = days;
    }

    if (maxOverdueDays > settings.defaultedThresholdDays) {
      await _loanDao.updateStatus(loanId, LoanStatus.defaulted);
    } else {
      await _loanDao.updateStatus(loanId, LoanStatus.overdue);
    }
  }

  Future<void> _checkLoanCompletion(int loanId) async {
    final loan = await _loanDao.getById(loanId);
    if (loan == null) return;
    if (loan.status == LoanStatus.completed || loan.status == LoanStatus.preClosed ||
        loan.status == LoanStatus.cancelled) return;

    final totalCollected = await _collectionDao.getTotalCollectedByLoan(loanId);
    if (totalCollected >= loan.returnAmount) {
      await _loanDao.updateStatus(loanId, LoanStatus.completed);
      await _logDao.insert(TransactionLog(
        actionType: 'loan_completed', description: 'Loan #$loanId marked as completed',
        loanId: loanId, amount: loan.returnAmount, createdAt: CalculationService.now(),
      ));
    }
  }

  Future<void> preCloseLoan(int loanId) async {
    await _scheduleDao.cancelPendingByLoan(loanId);
    await _loanDao.updateStatus(loanId, LoanStatus.preClosed);
    await _logDao.insert(TransactionLog(
      actionType: 'pre_close', description: 'Loan #$loanId pre-closed',
      loanId: loanId, createdAt: CalculationService.now(),
    ));
  }

  Future<void> cancelLoan(int loanId) async {
    await _scheduleDao.cancelPendingByLoan(loanId);
    await _loanDao.updateStatus(loanId, LoanStatus.cancelled);
    await _logDao.insert(TransactionLog(
      actionType: 'cancel_loan', description: 'Loan #$loanId cancelled',
      loanId: loanId, createdAt: CalculationService.now(),
    ));
  }

  Future<ScheduleEntry?> getTodayEntry(int loanId) async {
    final today = CalculationService.today();
    return await _scheduleDao.getByLoanIdAndDate(loanId, today);
  }

  Future<List<ScheduleEntry>> getAllEntries(int loanId) async {
    return await _scheduleDao.getByLoanId(loanId);
  }
}
