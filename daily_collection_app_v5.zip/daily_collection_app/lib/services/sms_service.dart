import 'package:telephony/telephony.dart';

class SmsResult {
  final bool success;
  final String message;
  SmsResult({required this.success, required this.message});
}

class SmsService {
  final Telephony _telephony = Telephony.instance;

  Future<bool> hasPermission() async {
    final status = await _telephony.requestSmsPermissions;
    return status ?? false;
  }

  Future<SmsResult> sendSms({required String to, required String body}) async {
    try {
      await _telephony.sendSms(to: to, message: body, isMultipart: true);
      return SmsResult(success: true, message: 'SMS sent successfully');
    } catch (e) {
      return SmsResult(success: false, message: 'Failed to send SMS: $e');
    }
  }

  String buildPaymentReceivedSms({required String customerName, required double amount, required double remaining, required double returnAmount, required int day, required int totalDays, required String ownerName}) {
    final owner = ownerName.isNotEmpty ? ' - $ownerName' : '';
    return 'Payment of ${_fmt(amount)} received from $customerName. Remaining: ${_fmt(remaining)}/${_fmt(returnAmount)}. Day $day/$totalDays.$owner';
  }

  String buildMissedPaymentSms({required String customerName, required double amount, required int day, required String ownerName}) {
    final owner = ownerName.isNotEmpty ? ' - $ownerName' : '';
    return 'Reminder: ${_fmt(amount)} pending for $customerName loan (Day $day). Please pay at the earliest.$owner';
  }

  String buildLoanCompletedSms({required String customerName, required double returnAmount, required String ownerName}) {
    final owner = ownerName.isNotEmpty ? ' - $ownerName' : '';
    return 'Loan completed! Total received: ${_fmt(returnAmount)} from $customerName. Thank you!$owner';
  }

  String buildPreClosureSms({required String customerName, required double payable, required String ownerName}) {
    final owner = ownerName.isNotEmpty ? ' - $ownerName' : '';
    return 'Loan pre-closed for $customerName. Final amount: ${_fmt(payable)}. Schedule cancelled.$owner';
  }

  String buildLoanSummarySms({required String customerName, required double principal, required double returnAmount, required double collected, required double remaining, required int day, required int totalDays, required String ownerName}) {
    final owner = ownerName.isNotEmpty ? ' - $ownerName' : '';
    return 'Loan Summary: $customerName. Principal: ${_fmt(principal)}, Return: ${_fmt(returnAmount)}, Collected: ${_fmt(collected)}, Remaining: ${_fmt(remaining)}, Day $day/$totalDays.$owner';
  }

  String _fmt(double amount) {
    return '₹${amount.toStringAsFixed(0)}';
  }
}
