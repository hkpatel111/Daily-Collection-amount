import 'dart:convert';
import 'dart:io';
import 'package:path/path.dart' as p;
import 'package:path_provider/path_provider.dart';
import 'calculation_service.dart';
import '../database/dao/customer_dao.dart';
import '../database/dao/loan_dao.dart';
import '../database/dao/schedule_dao.dart';
import '../database/dao/collection_dao.dart';
import '../database/dao/settings_dao.dart';
import '../database/dao/transaction_log_dao.dart';
import '../database/database_helper.dart';

class BackupResult {
  final bool success;
  final String? filePath;
  final String message;
  BackupResult({required this.success, this.filePath, required this.message});
}

class BackupService {
  final CustomerDao _customerDao = CustomerDao();
  final LoanDao _loanDao = LoanDao();
  final ScheduleDao _scheduleDao = ScheduleDao();
  final CollectionDao _collectionDao = CollectionDao();
  final SettingsDao _settingsDao = SettingsDao();
  final TransactionLogDao _logDao = TransactionLogDao();
  final DatabaseHelper _dbHelper = DatabaseHelper();

  Future<BackupResult> exportData() async {
    try {
      final customers = await _customerDao.getAllRaw();
      final loans = await _loanDao.getAllRaw();
      final scheduleEntries = await _scheduleDao.getAllRaw();
      final collectionEntries = await _collectionDao.getAllRaw();
      final settings = await _settingsDao.getAllRaw();
      final logs = await _logDao.getAllRaw();

      final Map<String, dynamic> data = {
        'version': 2,
        'exported_at': CalculationService.now(),
        'customers': customers,
        'loans': loans,
        'schedule_entries': scheduleEntries,
        'collection_entries': collectionEntries,
        'settings': settings,
        'transaction_logs': logs,
      };

      final String jsonStr = const JsonEncoder.withIndent('  ').convert(data);
      final directory = await getApplicationDocumentsDirectory();
      final String timestamp = DateTime.now().toIso8601String().replaceAll(':', '-').replaceAll('.', '-');
      final String fileName = 'backup_$timestamp.json';
      final String filePath = p.join(directory.path, fileName);
      final File file = File(filePath);
      await file.writeAsString(jsonStr);

      return BackupResult(success: true, filePath: filePath, message: 'Backup saved successfully');
    } catch (e) {
      return BackupResult(success: false, message: 'Export failed: $e');
    }
  }

  Future<BackupResult> importData(String filePath) async {
    try {
      final File file = File(filePath);
      if (!await file.exists()) {
        return BackupResult(success: false, message: 'Backup file not found');
      }
      final String jsonStr = await file.readAsString();
      final Map<String, dynamic> data = json.decode(jsonStr);

      await _dbHelper.deleteAllData();

      final customers = data['customers'] as List? ?? [];
      for (final c in customers) { await _customerDao.insertRaw(c as Map<String, dynamic>); }
      final loans = data['loans'] as List? ?? [];
      for (final l in loans) { await _loanDao.insertRaw(l as Map<String, dynamic>); }
      final scheduleEntries = data['schedule_entries'] as List? ?? [];
      for (final s in scheduleEntries) { await _scheduleDao.insertRaw(s as Map<String, dynamic>); }
      final collectionEntries = data['collection_entries'] as List? ?? [];
      for (final ce in collectionEntries) { await _collectionDao.insertRaw(ce as Map<String, dynamic>); }
      final settings = data['settings'] as List? ?? [];
      for (final s in settings) { await _settingsDao.insertRaw(s as Map<String, dynamic>); }
      final logs = data['transaction_logs'] as List? ?? [];
      for (final l in logs) { await _logDao.insertRaw(l as Map<String, dynamic>); }

      return BackupResult(success: true, message: 'Data imported successfully');
    } catch (e) {
      return BackupResult(success: false, message: 'Import failed: $e');
    }
  }

  Future<BackupResult> exportCsv() async {
    try {
      final loans = await _loanDao.getAllRaw();
      final collectionEntries = await _collectionDao.getAllRaw();

      final sb = StringBuffer();
      sb.writeln('Loan ID,Start Date,Customer ID,Principal,Return Amount,Daily Installment,Total Days,Profit,Status,Tag');
      for (final loan in loans) {
        sb.writeln('${loan['id']},${loan['start_date']},${loan['customer_id']},${loan['principal']},${loan['return_amount']},${loan['daily_installment']},${loan['total_days']},${loan['profit']},${loan['status']},${loan['loan_tag'] ?? ''}');
      }
      sb.writeln('');
      sb.writeln('Collection Date,Loan ID,Expected Amount,Collected Amount,Shortfall,Overdue Interest,Payment Mode');
      for (final ce in collectionEntries) {
        sb.writeln('${ce['collection_date']},${ce['loan_id']},${ce['expected_amount']},${ce['collected_amount']},${ce['shortfall']},${ce['overdue_interest']},${ce['payment_mode']}');
      }

      final directory = await getApplicationDocumentsDirectory();
      final String timestamp = DateTime.now().toIso8601String().replaceAll(':', '-').replaceAll('.', '-');
      final String fileName = 'export_$timestamp.csv';
      final String filePath = p.join(directory.path, fileName);
      final File file = File(filePath);
      await file.writeAsString(sb.toString());

      return BackupResult(success: true, filePath: filePath, message: 'CSV exported successfully');
    } catch (e) {
      return BackupResult(success: false, message: 'CSV export failed: $e');
    }
  }

  Future<BackupResult> exportLoanSummary(int loanId) async {
    try {
      final loan = await _loanDao.getById(loanId);
      if (loan == null) return BackupResult(success: false, message: 'Loan not found');

      final collections = await _collectionDao.getByLoanId(loanId);
      final totalCollected = await _collectionDao.getTotalCollectedByLoan(loanId);

      final sb = StringBuffer();
      sb.writeln('LOAN SUMMARY');
      sb.writeln('Loan ID: #${loan.id}');
      sb.writeln('Principal: ${CalculationService.formatCurrency(loan.principal)}');
      sb.writeln('Return Amount: ${CalculationService.formatCurrency(loan.returnAmount)}');
      sb.writeln('Profit: ${CalculationService.formatCurrency(loan.profit)}');
      sb.writeln('Daily Installment: ${CalculationService.formatCurrency(loan.dailyInstallment)}');
      sb.writeln('Total Days: ${loan.totalDays}');
      sb.writeln('Start Date: ${CalculationService.formatDate(loan.startDate)}');
      sb.writeln('End Date: ${CalculationService.formatDate(loan.endDate)}');
      sb.writeln('Status: ${loan.status.label}');
      sb.writeln('Total Collected: ${CalculationService.formatCurrency(totalCollected)}');
      sb.writeln('Remaining: ${CalculationService.formatCurrency(loan.returnAmount - totalCollected)}');
      sb.writeln('');
      sb.writeln('COLLECTION ENTRIES');
      sb.writeln('Date,Day,Expected,Collected,Shortfall,Payment Mode');
      for (final ce in collections) {
        final schedule = await _scheduleDao.getById(ce.scheduleEntryId);
        sb.writeln('${CalculationService.formatDate(ce.collectionDate)},Day ${schedule?.dayNumber ?? 0},${CalculationService.formatCurrency(ce.expectedAmount)},${CalculationService.formatCurrency(ce.collectedAmount)},${CalculationService.formatCurrency(ce.shortfall)},${ce.paymentMode.label}');
      }

      final directory = await getApplicationDocumentsDirectory();
      final String fileName = 'loan_${loanId}_summary.txt';
      final String filePath = p.join(directory.path, fileName);
      final File file = File(filePath);
      await file.writeAsString(sb.toString());

      return BackupResult(success: true, filePath: filePath, message: 'Summary exported');
    } catch (e) {
      return BackupResult(success: false, message: 'Export failed: $e');
    }
  }
}
