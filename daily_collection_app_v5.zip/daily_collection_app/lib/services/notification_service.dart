import '../models/loan.dart';
import '../models/schedule_entry.dart';
import '../database/dao/loan_dao.dart';
import '../database/dao/schedule_dao.dart';
import 'calculation_service.dart';

class NotificationInfo {
  final int todayPendingCount;
  final int overdueCount;
  final double todayTargetAmount;
  final double overdueAmount;
  final List<String> messages;

  NotificationInfo({
    required this.todayPendingCount,
    required this.overdueCount,
    required this.todayTargetAmount,
    required this.overdueAmount,
    required this.messages,
  });
}

class NotificationService {
  final LoanDao _loanDao = LoanDao();
  final ScheduleDao _scheduleDao = ScheduleDao();

  Future<NotificationInfo> getNotifications() async {
    final today = CalculationService.today();
    final activeLoans = await _loanDao.getActiveLoans();
    int todayPending = 0;
    double todayTarget = 0;
    int overdueCount = 0;
    double overdueAmount = 0;
    final messages = <String>[];

    for (final loan in activeLoans) {
      final entry = await _scheduleDao.getByLoanIdAndDate(loan.id!, today);
      if (entry != null && entry.status == ScheduleEntryStatus.pending && !entry.isHoliday) {
        todayPending++;
        todayTarget += entry.expectedAmount;
      }

      final overdueEntries = await _scheduleDao.getOverdueEntries(loan.id!);
      if (overdueEntries.isNotEmpty) {
        overdueCount++;
        for (final oe in overdueEntries) {
          final daysOverdue = CalculationService.daysBetween(oe.scheduledDate, today);
          overdueAmount += oe.expectedAmount;
        }
      }
    }

    if (todayPending > 0) {
      messages.add('$todayPending collection(s) pending for today (${CalculationService.formatCurrency(todayTarget)})');
    }
    if (overdueCount > 0) {
      messages.add('$overdueCount loan(s) have overdue payments (${CalculationService.formatCurrency(overdueAmount)})');
    }

    return NotificationInfo(
      todayPendingCount: todayPending,
      overdueCount: overdueCount,
      todayTargetAmount: todayTarget,
      overdueAmount: overdueAmount,
      messages: messages,
    );
  }
}
