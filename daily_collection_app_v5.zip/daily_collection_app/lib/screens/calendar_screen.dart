import 'package:flutter/material.dart';
import '../utils/constants.dart';
import '../models/schedule_entry.dart';
import '../database/dao/schedule_dao.dart';
import '../services/calculation_service.dart';

class CalendarScreen extends StatefulWidget {
  final int loanId;
  const CalendarScreen({super.key, required this.loanId});

  @override
  State<CalendarScreen> createState() => _CalendarScreenState();
}

class _CalendarScreenState extends State<CalendarScreen> {
  final ScheduleDao _scheduleDao = ScheduleDao();
  DateTime _selectedMonth = DateTime(DateTime.now().year, DateTime.now().month, 1);
  Map<String, ScheduleEntry> _entryByDate = {};

  @override
  void initState() { super.initState(); _loadData(); }

  Future<void> _loadData() async {
    final entries = await _scheduleDao.getByLoanId(widget.loanId);
    _entryByDate = {for (final e in entries) e.scheduledDate: e};
    setState(() {});
  }

  @override
  Widget build(BuildContext context) {
    final firstDay = _selectedMonth;
    final lastDay = DateTime(_selectedMonth.year, _selectedMonth.month + 1, 0);
    final startWeekday = firstDay.weekday % 7;
    final daysInMonth = lastDay.day;

    return Scaffold(
      appBar: AppBar(title: const Text('Calendar View')),
      body: Column(children: [
        Row(mainAxisAlignment: MainAxisAlignment.spaceBetween, children: [
          IconButton(icon: const Icon(Icons.chevron_left), onPressed: () {
            setState(() => _selectedMonth = DateTime(_selectedMonth.year, _selectedMonth.month - 1, 1));
          }),
          Text('${_monthName(_selectedMonth.month)} ${_selectedMonth.year}', style: const TextStyle(fontSize: 18, fontWeight: FontWeight.bold)),
          IconButton(icon: const Icon(Icons.chevron_right), onPressed: () {
            setState(() => _selectedMonth = DateTime(_selectedMonth.year, _selectedMonth.month + 1, 1));
          }),
        ]),
        Row(children: ['S','M','T','W','T','F','S'].map((d) =>
          Expanded(child: Center(child: Padding(padding: const EdgeInsets.all(8),
            child: Text(d, style: TextStyle(fontWeight: FontWeight.bold, color: AppColors.textSecondary)))))).toList()),
        Expanded(child: GridView.builder(
          gridDelegate: const SliverGridDelegateWithFixedCrossAxisCount(crossAxisCount: 7),
          itemCount: startWeekday + daysInMonth,
          itemBuilder: (context, index) {
            if (index < startWeekday) return const SizedBox();
            final day = index - startWeekday + 1;
            final dateStr = '${_selectedMonth.year}-${_selectedMonth.month.toString().padLeft(2, '0')}-${day.toString().padLeft(2, '0')}';
            final entry = _entryByDate[dateStr];
            Color bgColor = Colors.transparent;
            if (entry != null) {
              switch (entry.status) {
                case ScheduleEntryStatus.paid: bgColor = AppColors.success.withOpacity(0.3); break;
                case ScheduleEntryStatus.partial: bgColor = AppColors.warning.withOpacity(0.3); break;
                case ScheduleEntryStatus.missed: bgColor = AppColors.error.withOpacity(0.3); break;
                case ScheduleEntryStatus.holiday: bgColor = AppColors.cancelled.withOpacity(0.2); break;
                case ScheduleEntryStatus.pending: bgColor = Colors.grey.withOpacity(0.1); break;
                case ScheduleEntryStatus.cancelled: bgColor = AppColors.cancelled.withOpacity(0.1); break;
              }
            }
            return Container(
              margin: const EdgeInsets.all(2),
              decoration: BoxDecoration(color: bgColor, border: Border.all(color: Colors.grey.withOpacity(0.2)), borderRadius: BorderRadius.circular(4)),
              child: Center(child: Text('$day', style: TextStyle(fontSize: 12, color: entry != null ? AppColors.textPrimary : AppColors.textSecondary))),
            );
          },
        )),
        const SizedBox(height: 8),
        Row(mainAxisAlignment: MainAxisAlignment.spaceEvenly, children: [
          _legend('Paid', AppColors.success),
          _legend('Partial', AppColors.warning),
          _legend('Missed', AppColors.error),
          _legend('Pending', Colors.grey),
        ]),
        const SizedBox(height: 16),
      ]),
    );
  }

  Widget _legend(String label, Color color) {
    return Row(children: [
      Container(width: 12, height: 12, decoration: BoxDecoration(color: color.withOpacity(0.5), borderRadius: BorderRadius.circular(2))),
      const SizedBox(width: 4),
      Text(label, style: const TextStyle(fontSize: 11)),
    ]);
  }

  String _monthName(int month) {
    const names = ['Jan','Feb','Mar','Apr','May','Jun','Jul','Aug','Sep','Oct','Nov','Dec'];
    return names[month - 1];
  }
}
