import 'package:flutter/material.dart';
import 'package:share_plus/share_plus.dart';
import '../utils/constants.dart';
import '../models/loan.dart';
import '../models/schedule_entry.dart';
import '../models/collection_entry.dart';
import '../models/settings.dart';
import '../database/dao/loan_dao.dart';
import '../database/dao/schedule_dao.dart';
import '../database/dao/collection_dao.dart';
import '../database/dao/settings_dao.dart';
import '../database/dao/customer_dao.dart';
import '../services/calculation_service.dart';
import '../services/schedule_service.dart';
import '../services/sms_service.dart';
import '../services/backup_service.dart';
import '../widgets/stat_card.dart';
import '../widgets/schedule_entry_tile.dart';
import 'pre_close_screen.dart';
import 'collection_list_screen.dart';
import 'calendar_screen.dart';

class LoanDetailScreen extends StatefulWidget {
  final int loanId;
  const LoanDetailScreen({super.key, required this.loanId});

  @override
  State<LoanDetailScreen> createState() => _LoanDetailScreenState();
}

class _LoanDetailScreenState extends State<LoanDetailScreen> {
  final LoanDao _loanDao = LoanDao();
  final ScheduleDao _scheduleDao = ScheduleDao();
  final CollectionDao _collectionDao = CollectionDao();
  final SettingsDao _settingsDao = SettingsDao();
  final CustomerDao _customerDao = CustomerDao();
  final ScheduleService _scheduleService = ScheduleService();
  final SmsService _smsService = SmsService();
  final BackupService _backupService = BackupService();

  Loan? _loan;
  String _customerName = '';
  String _customerMobile = '';
  List<ScheduleEntry> _schedule = [];
  List<CollectionEntry> _collections = [];
  AppSettings _settings = AppSettings();
  double _totalCollected = 0;
  double _totalShortfall = 0;
  double _totalOverdueInterest = 0;
  bool _isLoading = true;
  ScheduleEntryStatus? _filterStatus;

  @override
  void initState() { super.initState(); _loadData(); }

  Future<void> _loadData() async {
    setState(() => _isLoading = true);
    _loan = await _loanDao.getById(widget.loanId);
    if (_loan != null) {
      final customer = await _customerDao.getById(_loan!.customerId);
      _customerName = customer?.name ?? '';
      _customerMobile = customer?.mobile ?? '';
      _settings = await _settingsDao.getSettings();
      _schedule = await _scheduleDao.getByLoanIdFiltered(widget.loanId, _filterStatus);
      _collections = await _collectionDao.getByLoanId(widget.loanId);
      _totalCollected = await _collectionDao.getTotalCollectedByLoan(widget.loanId);
      _totalShortfall = await _collectionDao.getTotalShortfallByLoan(widget.loanId);
      _totalOverdueInterest = await _collectionDao.getTotalOverdueInterestByLoan(widget.loanId);
      if (_loan!.status == LoanStatus.active || _loan!.status == LoanStatus.overdue) {
        await _scheduleService.updateOverdueInterest(widget.loanId, _loan!, _settings);
        _loan = await _loanDao.getById(widget.loanId);
        _totalOverdueInterest = await _collectionDao.getTotalOverdueInterestByLoan(widget.loanId);
      }
    }
    if (mounted) setState(() => _isLoading = false);
  }

  Future<void> _recordCollection(ScheduleEntry entry, double amount) async {
    if (_loan == null) return;
    ExcessOption? excessOption;
    if (amount > entry.expectedAmount) {
      excessOption = await _showExcessDialog(amount - entry.expectedAmount);
      if (excessOption == null) return;
    }
    PaymentMode? mode = await _showPaymentModeDialog();
    if (mode == null) return;

    await _scheduleService.recordCollection(
      loanId: widget.loanId, scheduleEntry: entry, collectedAmount: amount,
      paymentMode: mode, excessOption: excessOption,
    );

    if (_settings.smsEnabled && _settings.smsOnPayment && _customerMobile.isNotEmpty) {
      final newCollected = _totalCollected + amount;
      final remaining = _loan!.returnAmount - newCollected;
      final msg = _smsService.buildPaymentReceivedSms(
        customerName: _customerName, amount: amount, remaining: remaining,
        returnAmount: _loan!.returnAmount, day: entry.dayNumber, totalDays: _loan!.totalDays, ownerName: _settings.ownerName,
      );
      if (_settings.smsAutoSend) {
        await _smsService.sendSms(to: _customerMobile, body: msg);
      } else {
        _showSmsPreview(msg, _customerMobile);
      }
    }
    _loadData();
  }

  Future<ExcessOption?> _showExcessDialog(double excess) async {
    return showDialog<ExcessOption>(
      context: context,
      builder: (ctx) => AlertDialog(
        title: const Text('Excess Amount'),
        content: Text('Excess of ${CalculationService.formatCurrency(excess)} received. How to adjust?'),
        actions: [
          TextButton(onPressed: () => Navigator.pop(ctx, ExcessOption.nextInstallment), child: const Text('Next Installment')),
          TextButton(onPressed: () => Navigator.pop(ctx, ExcessOption.principalAdjust), child: const Text('Principal Adjust')),
          TextButton(onPressed: () => Navigator.pop(ctx, ExcessOption.separateEntry), child: const Text('Separate Entry')),
          TextButton(onPressed: () => Navigator.pop(ctx, null), child: const Text('Cancel')),
        ],
      ),
    );
  }

  Future<PaymentMode?> _showPaymentModeDialog() async {
    return showDialog<PaymentMode>(
      context: context,
      builder: (ctx) => AlertDialog(
        title: const Text('Payment Mode'),
        content: Column(mainAxisSize: MainAxisSize.min, children: [
          for (final mode in PaymentMode.values)
            ListTile(
              title: Text(mode.label),
              leading: Icon(mode == PaymentMode.cash ? Icons.money : mode == PaymentMode.upi ? Icons.phone_android : Icons.account_balance),
              onTap: () => Navigator.pop(ctx, mode),
            ),
        ]),
      ),
    );
  }

  void _showSmsPreview(String message, String mobile) {
    showDialog(context: context, builder: (ctx) => AlertDialog(
      title: const Text('Send SMS?'),
      content: Column(mainAxisSize: MainAxisSize.min, crossAxisAlignment: CrossAxisAlignment.start, children: [
        Text('To: +91 $mobile'),
        const SizedBox(height: 8),
        Text(message),
      ]),
      actions: [
        TextButton(onPressed: () => Navigator.pop(ctx), child: const Text('Skip')),
        ElevatedButton(onPressed: () async { Navigator.pop(ctx); await _smsService.sendSms(to: mobile, body: message); }, child: const Text('Send')),
      ],
    ));
  }

  void _showCollectionDialog(ScheduleEntry entry) {
    final amountCtrl = TextEditingController(text: entry.expectedAmount.toStringAsFixed(0));
    DateTime selectedDate = DateTime.now();
    showDialog(context: context, builder: (ctx) => StatefulBuilder(
      builder: (ctx, setState) => AlertDialog(
        title: Text('Day ${entry.dayNumber} Collection'),
        content: Column(mainAxisSize: MainAxisSize.min, children: [
          Text('Expected: ${CalculationService.formatCurrency(entry.expectedAmount)}'),
          Text('Date: ${CalculationService.formatDate(entry.scheduledDate)}'),
          const SizedBox(height: 16),
          TextField(
            controller: amountCtrl,
            decoration: const InputDecoration(labelText: 'Amount Received', border: OutlineInputBorder(), prefixText: 'Rs '),
            keyboardType: TextInputType.number,
          ),
          const SizedBox(height: 12),
          InkWell(
            onTap: () async {
              final picked = await showDatePicker(context: ctx, initialDate: selectedDate, firstDate: DateTime(2020), lastDate: DateTime.now());
              if (picked != null) setState(() => selectedDate = picked);
            },
            child: InputDecorator(
              decoration: const InputDecoration(labelText: 'Collection Date', border: OutlineInputBorder()),
              child: Text(CalculationService.formatDate('${selectedDate.year}-${selectedDate.month.toString().padLeft(2, '0')}-${selectedDate.day.toString().padLeft(2, '0')}')),
            ),
          ),
        ]),
        actions: [
          TextButton(onPressed: () => Navigator.pop(ctx), child: const Text('Cancel')),
          ElevatedButton(onPressed: () {
            final amount = double.tryParse(amountCtrl.text) ?? 0;
            Navigator.pop(ctx);
            _recordCollection(entry, amount);
          }, child: const Text('Record')),
        ],
      ),
    ));
  }

  void _showEditDialog(CollectionEntry entry) {
    final amountCtrl = TextEditingController(text: entry.collectedAmount.toStringAsFixed(0));
    PaymentMode selectedMode = entry.paymentMode;
    DateTime selectedDate = DateTime.tryParse(entry.collectionDate) ?? DateTime.now();
    showDialog(context: context, builder: (ctx) => StatefulBuilder(
      builder: (ctx, setS) => AlertDialog(
        title: const Text('Edit Collection'),
        content: Column(mainAxisSize: MainAxisSize.min, children: [
          TextField(controller: amountCtrl, decoration: const InputDecoration(labelText: 'Amount', border: OutlineInputBorder(), prefixText: 'Rs '), keyboardType: TextInputType.number),
          const SizedBox(height: 12),
          DropdownButtonFormField<PaymentMode>(
            value: selectedMode, decoration: const InputDecoration(labelText: 'Payment Mode', border: OutlineInputBorder()),
            items: PaymentMode.values.map((m) => DropdownMenuItem(value: m, child: Text(m.label))).toList(),
            onChanged: (v) => setS(() => selectedMode = v!),
          ),
          const SizedBox(height: 12),
          InkWell(
            onTap: () async {
              final picked = await showDatePicker(context: ctx, initialDate: selectedDate, firstDate: DateTime(2020), lastDate: DateTime.now());
              if (picked != null) setS(() => selectedDate = picked);
            },
            child: InputDecorator(decoration: const InputDecoration(labelText: 'Date', border: OutlineInputBorder()),
              child: Text(CalculationService.formatDate('${selectedDate.year}-${selectedDate.month.toString().padLeft(2, '0')}-${selectedDate.day.toString().padLeft(2, '0')}'))),
          ),
        ]),
        actions: [
          TextButton(onPressed: () => Navigator.pop(ctx), child: const Text('Cancel')),
          ElevatedButton(onPressed: () async {
            final amount = double.tryParse(amountCtrl.text) ?? 0;
            final dateStr = '${selectedDate.year}-${selectedDate.month.toString().padLeft(2, '0')}-${selectedDate.day.toString().padLeft(2, '0')}';
            Navigator.pop(ctx);
            await _scheduleService.editCollectionEntry(entry.id!, amount, dateStr, selectedMode);
            _loadData();
          }, child: const Text('Save')),
        ],
      ),
    ));
  }

  void _sendSms() {
    if (_loan == null || _customerMobile.isEmpty) return;
    final msg = _smsService.buildLoanSummarySms(
      customerName: _customerName, principal: _loan!.principal, returnAmount: _loan!.returnAmount,
      collected: _totalCollected, remaining: _loan!.returnAmount - _totalCollected,
      day: CalculationService.daysBetween(_loan!.startDate, CalculationService.today()) + 1,
      totalDays: _loan!.totalDays, ownerName: _settings.ownerName,
    );
    _showSmsPreview(msg, _customerMobile);
  }

  Future<void> _exportSummary() async {
    final result = await _backupService.exportLoanSummary(widget.loanId);
    if (result.success && result.filePath != null) {
      await Share.shareXFiles([XFile(result.filePath!)], subject: 'Loan Summary');
    }
  }

  @override
  Widget build(BuildContext context) {
    if (_isLoading) return Scaffold(appBar: AppBar(title: const Text('Loan')), body: const Center(child: CircularProgressIndicator()));
    if (_loan == null) return Scaffold(appBar: AppBar(title: const Text('Loan')), body: const Center(child: Text('Loan not found')));

    final remaining = _loan!.returnAmount - _totalCollected;
    final daysElapsed = CalculationService.daysBetween(_loan!.startDate, CalculationService.today());
    int daysRemaining = _loan!.totalDays - daysElapsed;
    if (daysRemaining < 0) daysRemaining = 0;

    return Scaffold(
      appBar: AppBar(
        title: Text('Loan: $_customerName'),
        actions: [
          IconButton(icon: const Icon(Icons.calendar_today), onPressed: () async {
            await Navigator.push(context, MaterialPageRoute(builder: (_) => CalendarScreen(loanId: widget.loanId)));
          }),
          IconButton(icon: const Icon(Icons.message), onPressed: _sendSms),
          PopupMenuButton(
            itemBuilder: (ctx) => [
              const PopupMenuItem(value: 'export', child: Text('Export Summary')),
              const PopupMenuItem(value: 'preclose', child: Text('Pre-Close Loan')),
              const PopupMenuItem(value: 'cancel', child: Text('Cancel Loan')),
              const PopupMenuItem(value: 'delete', child: Text('Delete Loan')),
            ],
            onSelected: (v) async {
              if (v == 'preclose') {
                final result = await Navigator.push<bool>(context, MaterialPageRoute(builder: (_) => PreCloseScreen(loanId: widget.loanId)));
                if (result == true && mounted) Navigator.pop(context, true);
              } else if (v == 'cancel') {
                final confirmed = await showDialog<bool>(context: context, builder: (ctx) => AlertDialog(
                  title: const Text('Cancel Loan'),
                  content: const Text('Cancel all pending entries? This cannot be undone.'),
                  actions: [
                    TextButton(onPressed: () => Navigator.pop(ctx, false), child: const Text('No')),
                    ElevatedButton(onPressed: () => Navigator.pop(ctx, true), child: const Text('Yes')),
                  ],
                ));
                if (confirmed == true) { await _scheduleService.cancelLoan(widget.loanId); if (mounted) Navigator.pop(context, true); }
              } else if (v == 'delete') {
                final confirmed = await showDialog<bool>(context: context, builder: (ctx) => AlertDialog(
                  title: const Text('Delete Loan'),
                  content: const Text('Permanently delete this loan and all related data?'),
                  actions: [
                    TextButton(onPressed: () => Navigator.pop(ctx, false), child: const Text('Cancel')),
                    ElevatedButton(style: ElevatedButton.styleFrom(backgroundColor: AppColors.error), onPressed: () => Navigator.pop(ctx, true), child: const Text('Delete')),
                  ],
                ));
                if (confirmed == true) { await _loanDao.permanentDelete(widget.loanId); if (mounted) Navigator.pop(context, true); }
              } else if (v == 'export') {
                _exportSummary();
              }
            },
          ),
        ],
      ),
      body: ListView(
        padding: const EdgeInsets.all(AppConstants.padding),
        children: [
          Card(elevation: 3, child: Padding(padding: const EdgeInsets.all(16), child: Column(children: [
            Text('${CalculationService.formatCurrency(_loan!.principal)} -> ${CalculationService.formatCurrency(_loan!.returnAmount)}', style: const TextStyle(fontSize: 20, fontWeight: FontWeight.bold)),
            const SizedBox(height: 4),
            Text('${_loan!.totalDays} Days | ${CalculationService.formatCurrency(_loan!.dailyInstallment)}/day'),
            if (_loan!.loanTag.isNotEmpty) ...[const SizedBox(height: 4), Text('Tag: ${_loan!.loanTag}', style: TextStyle(color: AppColors.textSecondary, fontSize: 12))],
            const SizedBox(height: 8),
            LoanStatusBadge(status: _loan!.status),
          ]))),
          const SizedBox(height: 8),
          GridView.count(
            shrinkWrap: true, physics: const NeverScrollableScrollPhysics(),
            crossAxisCount: 2, childAspectRatio: 1.8, crossAxisSpacing: 8, mainAxisSpacing: 8,
            children: [
              StatCard(label: 'Collected', value: CalculationService.formatCurrency(_totalCollected), color: AppColors.success, icon: Icons.check_circle,
                onTap: () => Navigator.push(context, MaterialPageRoute(builder: (_) => CollectionListScreen(loanId: widget.loanId)))),
              StatCard(label: 'Remaining', value: CalculationService.formatCurrency(remaining), color: AppColors.warning, icon: Icons.pending),
              StatCard(label: 'Days', value: '$daysElapsed/${_loan!.totalDays}', color: AppColors.primary, icon: Icons.calendar_today),
              StatCard(label: 'Overdue', value: CalculationService.formatCurrency(_totalShortfall + _totalOverdueInterest), color: AppColors.overdue, icon: Icons.warning,
                onTap: () => Navigator.push(context, MaterialPageRoute(builder: (_) => CollectionListScreen(loanId: widget.loanId, showOverdueOnly: true)))),
            ],
          ),
          const SizedBox(height: 16),
          Row(children: [
            Text('DAILY SCHEDULE', style: TextStyle(fontSize: 13, fontWeight: FontWeight.bold, color: AppColors.textSecondary)),
            const Spacer(),
            DropdownButton<ScheduleEntryStatus?>(
              value: _filterStatus, isDense: true, underline: Container(),
              hint: const Text('Filter'),
              items: [
                const DropdownMenuItem(value: null, child: Text('All')),
                const DropdownMenuItem(value: ScheduleEntryStatus.pending, child: Text('Pending')),
                const DropdownMenuItem(value: ScheduleEntryStatus.paid, child: Text('Paid')),
                const DropdownMenuItem(value: ScheduleEntryStatus.partial, child: Text('Partial')),
                const DropdownMenuItem(value: ScheduleEntryStatus.missed, child: Text('Missed')),
              ],
              onChanged: (v) { setState(() => _filterStatus = v); _loadData(); },
            ),
          ]),
          const SizedBox(height: 8),
          ..._schedule.map((entry) {
            final entryCollections = _collections.where((c) => c.scheduleEntryId == entry.id).toList();
            return Column(children: [
              ScheduleEntryTile(
                entry: entry, collections: entryCollections,
                onTap: entry.status == ScheduleEntryStatus.pending && !entry.isHoliday
                  ? () => _showCollectionDialog(entry) : null,
              ),
              if (entryCollections.isNotEmpty && entry.status != ScheduleEntryStatus.pending)
                Padding(padding: const EdgeInsets.only(left: 56, bottom: 4),
                  child: Row(children: [
                    Text('${CalculationService.formatDate(entryCollections.first.collectionDate)} | ${CalculationService.formatCurrency(entryCollections.first.collectedAmount)} | ${entryCollections.first.paymentMode.label}',
                      style: TextStyle(fontSize: 11, color: AppColors.textSecondary)),
                    const Spacer(),
                    IconButton(icon: const Icon(Icons.edit, size: 16), onPressed: () => _showEditDialog(entryCollections.first)),
                    IconButton(icon: const Icon(Icons.delete, size: 16, color: AppColors.error),
                      onPressed: () async {
                        await _scheduleService.deleteCollectionEntry(entryCollections.first.id!);
                        _loadData();
                      }),
                  ]),
                ),
              const Divider(height: 1),
            ]);
          }),
        ],
      ),
    );
  }
}
