import 'package:flutter/material.dart';
import '../utils/constants.dart';
import '../models/transaction_log.dart';
import '../database/dao/transaction_log_dao.dart';
import '../services/calculation_service.dart';

class TransactionLogScreen extends StatefulWidget {
  const TransactionLogScreen({super.key});

  @override
  State<TransactionLogScreen> createState() => _TransactionLogScreenState();
}

class _TransactionLogScreenState extends State<TransactionLogScreen> {
  final TransactionLogDao _logDao = TransactionLogDao();
  List<TransactionLog> _logs = [];
  bool _isLoading = true;

  @override
  void initState() { super.initState(); _loadData(); }

  Future<void> _loadData() async {
    setState(() => _isLoading = true);
    _logs = await _logDao.getAll(limit: 200);
    setState(() => _isLoading = false);
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: const Text('Transaction Log')),
      body: _isLoading
        ? const Center(child: CircularProgressIndicator())
        : _logs.isEmpty
          ? Center(child: Text('No transactions yet', style: TextStyle(color: AppColors.textSecondary)))
          : ListView.builder(
              itemCount: _logs.length,
              itemBuilder: (context, index) {
                final log = _logs[index];
                IconData icon;
                Color color;
                switch (log.actionType) {
                  case 'collection': icon = Icons.payment; color = AppColors.success; break;
                  case 'edit_collection': icon = Icons.edit; color = AppColors.warning; break;
                  case 'delete_collection': icon = Icons.delete; color = AppColors.error; break;
                  case 'loan_completed': icon = Icons.check_circle; color = AppColors.completed; break;
                  case 'pre_close': icon = Icons.close; color = AppColors.warning; break;
                  case 'cancel_loan': icon = Icons.cancel; color = AppColors.cancelled; break;
                  case 'schedule_generated': icon = Icons.calendar_today; color = AppColors.primary; break;
                  default: icon = Icons.info; color = AppColors.textSecondary;
                }
                return Card(margin: const EdgeInsets.symmetric(horizontal: 8, vertical: 4),
                  child: ListTile(
                    leading: Icon(icon, color: color, size: 24),
                    title: Text(log.description, style: const TextStyle(fontSize: 14)),
                    subtitle: Text(CalculationService.formatDateTime(log.createdAt), style: const TextStyle(fontSize: 12)),
                    trailing: log.amount != null ? Text(CalculationService.formatCurrency(log.amount!), style: const TextStyle(fontSize: 13, fontWeight: FontWeight.bold)) : null,
                  ),
                );
              },
            ),
    );
  }
}
