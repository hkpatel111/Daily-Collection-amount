import 'package:flutter/material.dart';
import '../utils/constants.dart';
import '../models/collection_entry.dart';
import '../database/dao/collection_dao.dart';
import '../database/dao/schedule_dao.dart';
import '../services/calculation_service.dart';
import '../services/schedule_service.dart';

class CollectionListScreen extends StatefulWidget {
  final int loanId;
  final bool showOverdueOnly;
  const CollectionListScreen({super.key, required this.loanId, this.showOverdueOnly = false});

  @override
  State<CollectionListScreen> createState() => _CollectionListScreenState();
}

class _CollectionListScreenState extends State<CollectionListScreen> {
  final CollectionDao _collectionDao = CollectionDao();
  final ScheduleDao _scheduleDao = ScheduleDao();
  final ScheduleService _scheduleService = ScheduleService();
  List<CollectionEntry> _entries = [];
  bool _isLoading = true;

  @override
  void initState() { super.initState(); _loadData(); }

  Future<void> _loadData() async {
    setState(() => _isLoading = true);
    _entries = await _collectionDao.getByLoanId(widget.loanId);
    if (widget.showOverdueOnly) {
      _entries = _entries.where((e) => e.shortfall > 0 || e.isMissed).toList();
    }
    setState(() => _isLoading = false);
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: Text(widget.showOverdueOnly ? 'Overdue Entries' : 'Collection Entries')),
      body: _isLoading
        ? const Center(child: CircularProgressIndicator())
        : _entries.isEmpty
          ? Center(child: Text('No entries found', style: TextStyle(color: AppColors.textSecondary)))
          : ListView.builder(
              itemCount: _entries.length,
              itemBuilder: (context, index) {
                final entry = _entries[index];
                return Card(
                  margin: const EdgeInsets.symmetric(horizontal: 8, vertical: 4),
                  child: FutureBuilder(
                    future: _scheduleDao.getById(entry.scheduleEntryId),
                    builder: (ctx, snap) {
                      final schedule = snap.data;
                      return ListTile(
                        title: Text('Day ${schedule?.dayNumber ?? 0} - ${CalculationService.formatDate(entry.collectionDate)}'),
                        subtitle: Text('Expected: ${CalculationService.formatCurrency(entry.expectedAmount)} | Collected: ${CalculationService.formatCurrency(entry.collectedAmount)} | ${entry.paymentMode.label}'
                          '${entry.shortfall > 0 ? ' | Shortfall: ${CalculationService.formatCurrency(entry.shortfall)}' : ''}'
                          '${entry.overdueInterest > 0 ? ' | Interest: ${CalculationService.formatCurrency(entry.overdueInterest)}' : ''}'),
                        trailing: Row(mainAxisSize: MainAxisSize.min, children: [
                          IconButton(icon: const Icon(Icons.edit, size: 20), onPressed: () => _showEditDialog(entry)),
                          IconButton(icon: const Icon(Icons.delete, size: 20, color: AppColors.error),
                            onPressed: () async {
                              await _scheduleService.deleteCollectionEntry(entry.id!);
                              _loadData();
                            }),
                        ]),
                      );
                    },
                  ),
                );
              },
            ),
    );
  }

  void _showEditDialog(CollectionEntry entry) {
    final amountCtrl = TextEditingController(text: entry.collectedAmount.toStringAsFixed(0));
    showDialog(context: context, builder: (ctx) => AlertDialog(
      title: const Text('Edit Collection'),
      content: TextField(controller: amountCtrl, decoration: const InputDecoration(labelText: 'Amount', border: OutlineInputBorder(), prefixText: 'Rs '), keyboardType: TextInputType.number),
      actions: [
        TextButton(onPressed: () => Navigator.pop(ctx), child: const Text('Cancel')),
        ElevatedButton(onPressed: () async {
          final amount = double.tryParse(amountCtrl.text) ?? 0;
          Navigator.pop(ctx);
          await _scheduleService.editCollectionEntry(entry.id!, amount, entry.collectionDate, entry.paymentMode);
          _loadData();
        }, child: const Text('Save')),
      ],
    ));
  }
}
