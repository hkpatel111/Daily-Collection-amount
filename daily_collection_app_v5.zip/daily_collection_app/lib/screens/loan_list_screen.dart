import 'package:flutter/material.dart';
import '../utils/constants.dart';
import '../models/loan.dart';
import '../database/dao/loan_dao.dart';
import '../database/dao/collection_dao.dart';
import '../services/calculation_service.dart';
import '../widgets/stat_card.dart';
import 'loan_detail_screen.dart';

class LoanListScreen extends StatefulWidget {
  final String title;
  final LoanStatus? statusFilter;
  final bool showCollections;
  final bool showProfit;

  const LoanListScreen({
    super.key,
    required this.title,
    this.statusFilter,
    this.showCollections = false,
    this.showProfit = false,
  });

  @override
  State<LoanListScreen> createState() => _LoanListScreenState();
}

class _LoanListScreenState extends State<LoanListScreen> {
  final LoanDao _loanDao = LoanDao();
  final CollectionDao _collectionDao = CollectionDao();
  List<Map<String, dynamic>> _loans = [];
  bool _isLoading = true;

  @override
  void initState() {
    super.initState();
    _loadData();
  }

  Future<void> _loadData() async {
    setState(() => _isLoading = true);
    if (widget.statusFilter != null) {
      _loans = await _loanDao.getLoansWithCustomerNameByStatus(widget.statusFilter!.dbValue);
    } else {
      _loans = await _loanDao.getLoansWithCustomerName();
    }
    setState(() => _isLoading = false);
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: Text(widget.title)),
      body: _isLoading
        ? const Center(child: CircularProgressIndicator())
        : _loans.isEmpty
          ? Center(child: Text('No loans found', style: TextStyle(color: AppColors.textSecondary)))
          : ListView.builder(
              padding: const EdgeInsets.all(AppConstants.padding),
              itemCount: _loans.length,
              itemBuilder: (context, index) {
                final loan = _loans[index];
                final loanId = loan['id'] as int;
                final customerName = loan['customer_name'] as String? ?? 'Unknown';
                final principal = (loan['principal'] as num).toDouble();
                final returnAmount = (loan['return_amount'] as num).toDouble();
                final profit = (loan['profit'] as num).toDouble();
                final status = LoanStatus.fromDbValue(loan['status'] as String);
                return Card(
                  child: ListTile(
                    title: Text('#$loanId - $customerName'),
                    subtitle: Text(widget.showProfit
                      ? 'Profit: ${CalculationService.formatCurrency(profit)}'
                      : '${CalculationService.formatCurrency(principal)} -> ${CalculationService.formatCurrency(returnAmount)}'),
                    trailing: LoanStatusBadge(status: status),
                    onTap: () async {
                      await Navigator.push(context, MaterialPageRoute(builder: (_) => LoanDetailScreen(loanId: loanId)));
                      _loadData();
                    },
                  ),
                );
              },
            ),
    );
  }
}
