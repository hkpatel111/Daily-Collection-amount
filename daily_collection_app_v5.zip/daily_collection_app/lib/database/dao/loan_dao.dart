import 'package:sqflite/sqflite.dart' as sqflite;
import '../database_helper.dart';
import '../../models/loan.dart';

class LoanDao {
  final DatabaseHelper _dbHelper = DatabaseHelper();

  Future<int> insert(Loan loan) async {
    final db = await _dbHelper.database;
    return await db.insert('loans', loan.toMap());
  }

  Future<Loan?> getById(int id) async {
    final db = await _dbHelper.database;
    final maps = await db.query('loans', where: 'id = ?', whereArgs: [id]);
    if (maps.isEmpty) return null;
    return Loan.fromMap(maps.first);
  }

  Future<List<Loan>> getActiveLoansByCustomer(int customerId) async {
    final db = await _dbHelper.database;
    final maps = await db.query('loans',
      where: 'customer_id = ? AND status IN (?, ?)',
      whereArgs: [customerId, 'active', 'overdue'],
      orderBy: 'created_at DESC');
    return maps.map((m) => Loan.fromMap(m)).toList();
  }

  Future<List<Loan>> getByCustomer(int customerId) async {
    final db = await _dbHelper.database;
    final maps = await db.query('loans',
      where: 'customer_id = ?', whereArgs: [customerId],
      orderBy: 'created_at DESC');
    return maps.map((m) => Loan.fromMap(m)).toList();
  }

  Future<List<Loan>> getByStatus(LoanStatus status) async {
    final db = await _dbHelper.database;
    final maps = await db.query('loans', where: 'status = ?', whereArgs: [status.dbValue]);
    return maps.map((m) => Loan.fromMap(m)).toList();
  }

  Future<List<Loan>> getAll() async {
    final db = await _dbHelper.database;
    final maps = await db.query('loans', orderBy: 'created_at DESC');
    return maps.map((m) => Loan.fromMap(m)).toList();
  }

  Future<int> update(Loan loan) async {
    final db = await _dbHelper.database;
    return await db.update('loans', loan.toMap(), where: 'id = ?', whereArgs: [loan.id]);
  }

  Future<int> updateStatus(int loanId, LoanStatus status) async {
    final db = await _dbHelper.database;
    return await db.update('loans', {'status': status.dbValue}, where: 'id = ?', whereArgs: [loanId]);
  }

  Future<int> permanentDelete(int loanId) async {
    final db = await _dbHelper.database;
    await db.delete('collection_entries', where: 'loan_id = ?', whereArgs: [loanId]);
    await db.delete('schedule_entries', where: 'loan_id = ?', whereArgs: [loanId]);
    await db.delete('transaction_logs', where: 'loan_id = ?', whereArgs: [loanId]);
    return await db.delete('loans', where: 'id = ?', whereArgs: [loanId]);
  }

  Future<double> getTotalGiven() async {
    final db = await _dbHelper.database;
    final result = await db.rawQuery("SELECT COALESCE(SUM(principal), 0) as total FROM loans WHERE status != 'cancelled'");
    return (result.first['total'] as num?)?.toDouble() ?? 0.0;
  }

  Future<double> getTotalExpectedProfit() async {
    final db = await _dbHelper.database;
    final result = await db.rawQuery("SELECT COALESCE(SUM(profit), 0) as total FROM loans WHERE status != 'cancelled'");
    return (result.first['total'] as num?)?.toDouble() ?? 0.0;
  }

  Future<int> countByStatus(LoanStatus status) async {
    final db = await _dbHelper.database;
    final result = await db.rawQuery("SELECT COUNT(*) as count FROM loans WHERE status = ?", [status.dbValue]);
    return sqflite.Sqflite.firstIntValue(result) ?? 0;
  }

  Future<List<Loan>> getActiveLoans() async {
    final db = await _dbHelper.database;
    final maps = await db.query('loans', where: "status IN (?, ?)", whereArgs: ['active', 'overdue'], orderBy: 'created_at DESC');
    return maps.map((m) => Loan.fromMap(m)).toList();
  }

  Future<List<Map<String, dynamic>>> getAllRaw() async {
    final db = await _dbHelper.database;
    return await db.query('loans');
  }

  Future<void> insertRaw(Map<String, dynamic> data) async {
    final db = await _dbHelper.database;
    await db.insert('loans', data);
  }

  Future<List<Map<String, dynamic>>> getLoansWithCustomerName() async {
    final db = await _dbHelper.database;
    return await db.rawQuery('''
      SELECT l.*, c.name as customer_name, c.mobile as customer_mobile
      FROM loans l
      INNER JOIN customers c ON l.customer_id = c.id
      ORDER BY l.created_at DESC
    ''');
  }

  Future<List<Map<String, dynamic>>> getLoansWithCustomerNameByStatus(String status) async {
    final db = await _dbHelper.database;
    return await db.rawQuery('''
      SELECT l.*, c.name as customer_name, c.mobile as customer_mobile
      FROM loans l
      INNER JOIN customers c ON l.customer_id = c.id
      WHERE l.status = ?
      ORDER BY l.created_at DESC
    ''', [status]);
  }
}
