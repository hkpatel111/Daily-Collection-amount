import '../database_helper.dart';
import '../../models/transaction_log.dart';

class TransactionLogDao {
  final DatabaseHelper _dbHelper = DatabaseHelper();

  Future<int> insert(TransactionLog log) async {
    final db = await _dbHelper.database;
    return await db.insert('transaction_logs', log.toMap());
  }

  Future<List<TransactionLog>> getAll({int? limit}) async {
    final db = await _dbHelper.database;
    final maps = await db.query('transaction_logs',
      orderBy: 'created_at DESC', limit: limit);
    return maps.map((m) => TransactionLog.fromMap(m)).toList();
  }

  Future<List<TransactionLog>> getByLoanId(int loanId) async {
    final db = await _dbHelper.database;
    final maps = await db.query('transaction_logs',
      where: 'loan_id = ?', whereArgs: [loanId],
      orderBy: 'created_at DESC');
    return maps.map((m) => TransactionLog.fromMap(m)).toList();
  }

  Future<List<TransactionLog>> getByCustomerId(int customerId) async {
    final db = await _dbHelper.database;
    final maps = await db.query('transaction_logs',
      where: 'customer_id = ?', whereArgs: [customerId],
      orderBy: 'created_at DESC');
    return maps.map((m) => TransactionLog.fromMap(m)).toList();
  }

  Future<int> deleteAll() async {
    final db = await _dbHelper.database;
    return await db.delete('transaction_logs');
  }

  Future<List<Map<String, dynamic>>> getAllRaw() async {
    final db = await _dbHelper.database;
    return await db.query('transaction_logs');
  }

  Future<void> insertRaw(Map<String, dynamic> data) async {
    final db = await _dbHelper.database;
    await db.insert('transaction_logs', data);
  }
}
