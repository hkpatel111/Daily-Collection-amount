import '../database_helper.dart';
import '../../models/settings.dart';

class SettingsDao {
  final DatabaseHelper _dbHelper = DatabaseHelper();

  Future<AppSettings> getSettings() async {
    final db = await _dbHelper.database;
    final maps = await db.query('settings', where: 'id = 1', limit: 1);
    if (maps.isEmpty) {
      final s = AppSettings();
      await db.insert('settings', s.toMap());
      return s;
    }
    return AppSettings.fromMap(maps.first);
  }

  Future<int> updateSettings(AppSettings settings) async {
    final db = await _dbHelper.database;
    return await db.update('settings', settings.toMap(), where: 'id = 1');
  }

  Future<List<Map<String, dynamic>>> getAllRaw() async {
    final db = await _dbHelper.database;
    return await db.query('settings');
  }

  Future<void> insertRaw(Map<String, dynamic> data) async {
    final db = await _dbHelper.database;
    await db.insert('settings', data);
  }
}
