# Daily Collection App v2.0

A daily collection loan tracking app with 30+ features including drill-down navigation, calendar view, transaction log, excess payment handling, and SIM-based SMS.

## Features
- Multiple active loans per customer
- Drill-down navigation everywhere (clickable stats)
- Calendar view with color-coded daily status
- Transaction log / audit trail
- Excess payment handling (3 options)
- Edit/delete collection entries
- Payment mode tracking (Cash/UPI/Bank)
- Bulk collection (mark all paid)
- Global search
- Dark mode
- Auto-backup with customizable days
- Permanent delete (loan & customer)
- Schedule filter (All/Paid/Partial/Missed/Pending)
- SMS from loan account
- Receipt/summary export
- Customer total view

## Setup
1. Upload ZIP to GitHub repo
2. Add workflow file to `.github/workflows/build-apk.yml`
3. Build runs automatically
4. Download APK from Actions > Artifacts
