import 'dart:io';
import 'package:path/path.dart' as p;
import 'package:path_provider/path_provider.dart';
import 'package:pdf/pdf.dart';
import 'package:pdf/widgets.dart' as pw;

class PdfService {
  // Converts any text content into a shareable PDF file.
  static Future<String> textToPdf(String title, String content, {String fileName = 'document'}) async {
    final doc = pw.Document();
    doc.addPage(pw.MultiPage(
      pageFormat: PdfPageFormat.a4,
      margin: const pw.EdgeInsets.all(32),
      build: (ctx) => [
        pw.Text(title, style: pw.TextStyle(fontSize: 18, fontWeight: pw.FontWeight.bold)),
        pw.SizedBox(height: 12),
        pw.Text(content, style: const pw.TextStyle(fontSize: 10, height: 1.4)),
        pw.Divider(),
        pw.Text('Created by Harish', style: pw.TextStyle(fontSize: 9, color: PdfColors.grey)),
      ],
    ));
    final dir = await getApplicationDocumentsDirectory();
    final file = File(p.join(dir.path, '${fileName}.pdf'));
    await file.writeAsBytes(await doc.save());
    return file.path;
  }
}
