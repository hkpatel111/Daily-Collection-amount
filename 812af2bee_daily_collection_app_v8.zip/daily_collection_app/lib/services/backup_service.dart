import 'dart:convert';
import 'dart:io';
import 'package:path_provider/path_provider.dart';
import 'package:path/path.dart' as p;
import 'package:share_plus/share_plus.dart';
import 'package:permission_handler/permission_handler.dart';
import '../database/database_helper.dart';
import '../models/settings.dart';
import '../database/dao/settings_dao.dart';

class BackupResult {
  final bool success;
  final String message;
  final String? filePath;
  BackupResult({required this.success, required this.message, this.filePath});
}

class BackupService {
  final DatabaseHelper _dbHelper = DatabaseHelper();

  Future<BackupResult> exportData() async {
    try {
      final db = await _dbHelper.database;
      final data = <String, dynamic>{};
      data['customers'] = await db.query('customers');
      data['loans'] = await db.query('loans');
      data['schedule_entries'] = await db.query('schedule_entries');
      data['collection_entries'] = await db.query('collection_entries');
      data['transaction_logs'] = await db.query('transaction_logs');
      data['sms_logs'] = await db.query('sms_logs');
      data['edit_history'] = await db.query('edit_history');
      data['settings'] = await db.query('settings');
      final jsonString = const JsonEncoder.withIndent('  ').convert(data);
      final dir = await getApplicationDocumentsDirectory();
      final timestamp = DateTime.now().millisecondsSinceEpoch;
      final file = File(p.join(dir.path, 'backup_$timestamp.json'));
      await file.writeAsString(jsonString);
      return BackupResult(success: true, message: 'Backup created successfully', filePath: file.path);
    } catch (e) {
      return BackupResult(success: false, message: 'Backup failed: $e');
    }
  }

  Future<BackupResult> importData(String filePath) async {
    try {
      final file = File(filePath);
      final jsonString = await file.readAsString();
      final data = json.decode(jsonString) as Map<String, dynamic>;
      await _dbHelper.deleteAllData();
      final db = await _dbHelper.database;
      for (final table in data.keys) {
        final rows = data[table] as List;
        for (final row in rows) {
          try { await db.insert(table, row as Map<String, dynamic>); } catch (_) {}
        }
      }
      return BackupResult(success: true, message: 'Data imported successfully');
    } catch (e) {
      return BackupResult(success: false, message: 'Import failed: $e');
    }
  }

  Future<BackupResult> exportCsv() async {
    try {
      final db = await _dbHelper.database;
      final loans = await db.rawQuery('''SELECT l.id, c.name as customer_name, c.mobile, l.principal, l.return_amount,
        l.daily_installment, l.total_days, l.profit, l.daily_interest_rate, l.start_date, l.end_date, l.status, l.loan_tag
        FROM loans l LEFT JOIN customers c ON l.customer_id = c.id ORDER BY l.created_at DESC''');
      final sb = StringBuffer();
      sb.writeln('Loan ID,Customer,Mobile,Principal,Return Amount,Daily Installment,Total Days,Profit,Daily Rate,Start Date,End Date,Status,Tag');
      for (final loan in loans) {
        sb.writeln('${loan['id']},${loan['customer_name']},${loan['mobile']},${loan['principal']},'
          '${loan['return_amount']},${loan['daily_installment']},${loan['total_days']},${loan['profit']},'
          '${loan['daily_interest_rate']},${loan['start_date']},${loan['end_date']},${loan['status']},${loan['loan_tag']}');
      }
      final dir = await getApplicationDocumentsDirectory();
      final file = File(p.join(dir.path, 'loans_export_${DateTime.now().millisecondsSinceEpoch}.csv'));
      await file.writeAsString(sb.toString());
      return BackupResult(success: true, message: 'CSV exported', filePath: file.path);
    } catch (e) {
      return BackupResult(success: false, message: 'CSV export failed: $e');
    }
  }

  Future<BackupResult> exportLoanSummary(int loanId) async {
    try {
      final db = await _dbHelper.database;
      final loanData = await db.rawQuery('SELECT l.*, c.name as customer_name, c.mobile FROM loans l JOIN customers c ON l.customer_id = c.id WHERE l.id = ?', [loanId]);
      if (loanData.isEmpty) return BackupResult(success: false, message: 'Loan not found');
      final collections = await db.query('collection_entries', where: 'loan_id = ?', whereArgs: [loanId]);
      final sb = StringBuffer();
      sb.writeln('LOAN SUMMARY');
      sb.writeln('Loan ID: ${loanData[0]['id']}');
      sb.writeln('Customer: ${loanData[0]['customer_name']}');
      sb.writeln('Mobile: ${loanData[0]['mobile']}');
      sb.writeln('Principal: Rs ${loanData[0]['principal']}');
      sb.writeln('Return Amount: Rs ${loanData[0]['return_amount']}');
      sb.writeln('Daily Installment: Rs ${loanData[0]['daily_installment']}');
      sb.writeln('Total Days: ${loanData[0]['total_days']}');
      sb.writeln('Profit: Rs ${loanData[0]['profit']}');
      sb.writeln('Daily Rate: ${(loanData[0]['daily_interest_rate'] as num).toStringAsFixed(3)}%');
      sb.writeln('Monthly Rate: ${((loanData[0]['daily_interest_rate'] as num) * 30).toStringAsFixed(3)}%');
      sb.writeln('Yearly Rate: ${((loanData[0]['daily_interest_rate'] as num) * 365).toStringAsFixed(3)}%');
      sb.writeln('Start: ${loanData[0]['start_date']}  End: ${loanData[0]['end_date']}');
      sb.writeln('Status: ${loanData[0]['status']}');
      sb.writeln('\nCOLLECTIONS:');
      sb.writeln('Date,Expected,Collected,Shortfall,Mode');
      double totalCollected = 0;
      for (final c in collections) {
        sb.writeln('${c['collection_date']},${c['expected_amount']},${c['collected_amount']},${c['shortfall']},${c['payment_mode']}');
        totalCollected += (c['collected_amount'] as num).toDouble();
      }
      sb.writeln('\nTotal Collected: Rs $totalCollected');
      final remaining = (loanData[0]['return_amount'] as num).toDouble() - totalCollected;
      sb.writeln('Remaining: Rs $remaining');
      final dir = await getApplicationDocumentsDirectory();
      final file = File(p.join(dir.path, 'loan_${loanId}_summary.txt'));
      await file.writeAsString(sb.toString());
      return BackupResult(success: true, message: 'Summary exported', filePath: file.path);
    } catch (e) {
      return BackupResult(success: false, message: 'Export failed: $e');
    }
  }

  Future<BackupResult> exportCustomerSummary(int customerId) async {
    try {
      final db = await _dbHelper.database;
      final customer = await db.query('customers', where: 'id = ?', whereArgs: [customerId]);
      if (customer.isEmpty) return BackupResult(success: false, message: 'Customer not found');
      final loans = await db.query('loans', where: 'customer_id = ?', whereArgs: [customerId]);
      final sb = StringBuffer();
      sb.writeln('CUSTOMER SUMMARY');
      sb.writeln('Name: ${customer[0]['name']}');
      sb.writeln('Mobile: ${customer[0]['mobile']}');
      if (customer[0]['nickname'] != null) sb.writeln('Nickname: ${customer[0]['nickname']}');
      sb.writeln('\nLOANS:');
      double totalGiven = 0, totalCollected = 0;
      for (final loan in loans) {
        final collections = await db.query('collection_entries', where: 'loan_id = ?', whereArgs: [loan['id']]);
        double collected = 0;
        for (final c in collections) collected += (c['collected_amount'] as num).toDouble();
        totalCollected += collected;
        totalGiven += (loan['principal'] as num).toDouble();
        sb.writeln('\n  Loan #${loan['id']}: ${(loan['principal'])} -> ${(loan['return_amount'])} | ${loan['status']} | Collected: Rs $collected');
      }
      sb.writeln('\nTotal Given: Rs $totalGiven');
      sb.writeln('Total Collected: Rs $totalCollected');
      final dir = await getApplicationDocumentsDirectory();
      final file = File(p.join(dir.path, 'customer_${customerId}_summary.txt'));
      await file.writeAsString(sb.toString());
      return BackupResult(success: true, message: 'Summary exported', filePath: file.path);
    } catch (e) {
      return BackupResult(success: false, message: 'Export failed: $e');
    }
  }

  Future<BackupResult> exportTransactionLog({String? searchQuery}) async {
    try {
      final db = await _dbHelper.database;
      String sql = '''SELECT t.*, c.name as customer_name, c.mobile as customer_mobile
        FROM transaction_logs t LEFT JOIN customers c ON t.customer_id = c.id''';
      List<dynamic> args = [];
      if (searchQuery != null && searchQuery.isNotEmpty) {
        sql += ' WHERE c.name LIKE ? OR c.mobile LIKE ? OR t.description LIKE ? OR CAST(t.amount AS TEXT) LIKE ?';
        args = ['%$searchQuery%', '%$searchQuery%', '%$searchQuery%', '%$searchQuery%'];
      }
      sql += ' ORDER BY t.created_at DESC';
      final logs = await db.rawQuery(sql, args);
      final sb = StringBuffer();
      sb.writeln('TRANSACTION LOG');
      sb.writeln('Date,Type,Customer,Description,Amount');
      for (final log in logs) {
        sb.writeln('${log['created_at']},${log['action_type']},${log['customer_name'] ?? ''},${log['description']},${log['amount'] ?? ''}');
      }
      final dir = await getApplicationDocumentsDirectory();
      final file = File(p.join(dir.path, 'transaction_log_${DateTime.now().millisecondsSinceEpoch}.txt'));
      await file.writeAsString(sb.toString());
      return BackupResult(success: true, message: 'Log exported', filePath: file.path);
    } catch (e) {
      return BackupResult(success: false, message: 'Export failed: $e');
    }
  }

  Future<BackupResult> exportMonthlyReport(int year, int month) async {
    try {
      final db = await _dbHelper.database;
      final startDate = '$year-${month.toString().padLeft(2, '0')}-01';
      final endMonth = month == 12 ? 1 : month + 1;
      final endYear = month == 12 ? year + 1 : year;
      final endDate = '$endYear-${endMonth.toString().padLeft(2, '0')}-01';
      final collections = await db.rawQuery('SELECT * FROM collection_entries WHERE collection_date >= ? AND collection_date < ?', [startDate, endDate]);
      final newLoans = await db.rawQuery('SELECT * FROM loans WHERE created_at >= ? AND created_at < ?', [startDate, endDate]);
      double totalCollected = 0;
      for (final c in collections) totalCollected += (c['collected_amount'] as num).toDouble();
      double totalGiven = 0;
      for (final l in newLoans) totalGiven += (l['principal'] as num).toDouble();
      double totalProfit = 0;
      for (final l in newLoans) totalProfit += (l['profit'] as num).toDouble();
      final sb = StringBuffer();
      sb.writeln('MONTHLY REPORT - ${month.toString().padLeft(2, '0')}/$year');
      sb.writeln('Total Collections: Rs $totalCollected');
      sb.writeln('New Loans Given: Rs $totalGiven');
      sb.writeln('Expected Profit (new): Rs $totalProfit');
      sb.writeln('Total Collections count: ${collections.length}');
      sb.writeln('New Loans count: ${newLoans.length}');
      final dir = await getApplicationDocumentsDirectory();
      final file = File(p.join(dir.path, 'monthly_report_${year}_${month}.txt'));
      await file.writeAsString(sb.toString());
      return BackupResult(success: true, message: 'Monthly report exported', filePath: file.path);
    } catch (e) {
      return BackupResult(success: false, message: 'Export failed: $e');
    }
  }

  Future<BackupResult> exportYearlyTaxSummary(int year) async {
    try {
      final db = await _dbHelper.database;
      final fyStart = '$year-04-01';
      final fyEnd = '${year + 1}-04-01';
      final loans = await db.rawQuery('SELECT * FROM loans WHERE created_at >= ? AND created_at < ?', [fyStart, fyEnd]);
      final collections = await db.rawQuery('SELECT * FROM collection_entries WHERE collection_date >= ? AND collection_date < ?', [fyStart, fyEnd]);
      double totalProfit = 0, totalCollected = 0, totalGiven = 0;
      for (final l in loans) {
        totalProfit += (l['profit'] as num).toDouble();
        totalGiven += (l['principal'] as num).toDouble();
      }
      for (final c in collections) totalCollected += (c['collected_amount'] as num).toDouble();
      final sb = StringBuffer();
      sb.writeln('YEARLY TAX SUMMARY - FY $year-${year + 1}');
      sb.writeln('Total Loans Given: Rs $totalGiven');
      sb.writeln('Total Collected: Rs $totalCollected');
      sb.writeln('Total Expected Profit: Rs $totalProfit');
      sb.writeln('Total Loans: ${loans.length}');
      sb.writeln('\nLOAN-WISE BREAKUP:');
      for (final l in loans) {
        sb.writeln('  Loan #${l['id']}: Principal ${(l['principal'])}, Profit ${(l['profit'])}, Status ${l['status']}');
      }
      final dir = await getApplicationDocumentsDirectory();
      final file = File(p.join(dir.path, 'tax_summary_$year.txt'));
      await file.writeAsString(sb.toString());
      return BackupResult(success: true, message: 'Tax summary exported', filePath: file.path);
    } catch (e) {
      return BackupResult(success: false, message: 'Export failed: $e');
    }
  }

  // ===== PHONE STORAGE AUTO-BACKUP (survives app uninstall) =====
  static const String _storageRoot = '/storage/emulated/0';

  Future<bool> ensureStoragePermission() async {
    if (!Platform.isAndroid) return true;
    var status = await Permission.manageExternalStorage.status;
    if (status.isGranted) return true;
    status = await Permission.manageExternalStorage.request();
    if (status.isGranted) return true;
    final legacy = await Permission.storage.request();
    return legacy.isGranted || legacy.isLimited;
  }

  Future<bool> hasStorageReadAccess() async {
    if (!Platform.isAndroid) return true;
    if ((await Permission.manageExternalStorage.status).isGranted) return true;
    final legacy = await Permission.storage.status;
    return legacy.isGranted || legacy.isLimited;
  }

  Future<BackupResult> saveBackupToStorage(AppSettings settings) async {
    try {
      final granted = await ensureStoragePermission();
      if (!granted) return BackupResult(success: false, message: 'Storage permission not granted');
      final dir = Directory('$_storageRoot/${settings.backupFolderPath}');
      if (!await dir.exists()) await dir.create(recursive: true);
      final db = await _dbHelper.database;
      final data = <String, dynamic>{};
      data['customers'] = await db.query('customers');
      data['loans'] = await db.query('loans');
      data['schedule_entries'] = await db.query('schedule_entries');
      data['collection_entries'] = await db.query('collection_entries');
      data['transaction_logs'] = await db.query('transaction_logs');
      data['sms_logs'] = await db.query('sms_logs');
      data['edit_history'] = await db.query('edit_history');
      data['settings'] = await db.query('settings');
      final jsonString = const JsonEncoder.withIndent('  ').convert(data);
      final file = File(p.join(dir.path, 'latest_backup.json'));
      await file.writeAsString(jsonString);
      return BackupResult(success: true, message: 'Backup saved: ${dir.path}', filePath: file.path);
    } catch (e) {
      return BackupResult(success: false, message: 'Backup failed: $e');
    }
  }

  Future<String?> findStorageBackup(String folderName) async {
    try {
      if (!await hasStorageReadAccess()) return null;
      var dir = Directory('$_storageRoot/$folderName');
      if (!await dir.exists()) {
        dir = Directory('$_storageRoot/DailyCollectionBackup');
        if (!await dir.exists()) return null;
      }
      final latest = File(p.join(dir.path, 'latest_backup.json'));
      if (await latest.exists()) return latest.path;
      final candidates = dir.listSync().whereType<File>()
        .where((f) => p.basename(f.path).startsWith('backup_') && f.path.endsWith('.json'))
        .toList()
        ..sort((a, b) => b.lastModifiedSync().compareTo(a.lastModifiedSync()));
      return candidates.isNotEmpty ? candidates.first.path : null;
    } catch (_) {
      return null;
    }
  }

  Future<bool> autoBackupIfNeeded(AppSettings settings) async {
    try {
      if (!settings.autoBackupToStorage) return false;
      final now = DateTime.now();
      if (settings.lastAutoBackupAt.isNotEmpty) {
        final last = DateTime.tryParse(settings.lastAutoBackupAt);
        if (last != null) {
          final days = settings.autoBackupDays < 1 ? 1 : settings.autoBackupDays;
          if (now.isBefore(last.add(Duration(days: days)))) return false;
        }
      }
      final result = await saveBackupToStorage(settings);
      if (result.success) {
        final dao = SettingsDao();
        final fresh = await dao.getSettings();
        await dao.updateSettings(fresh.copyWith(lastAutoBackupAt: now.toIso8601String()));
        return true;
      }
      return false;
    } catch (_) {
      return false;
    }
  }
}
