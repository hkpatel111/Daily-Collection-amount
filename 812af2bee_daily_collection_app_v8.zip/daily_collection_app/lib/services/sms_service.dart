import 'dart:async';
import 'package:telephony/telephony.dart';
import '../models/sms_log.dart';
import '../database/dao/sms_log_dao.dart';

class SmsService {
  final Telephony _telephony = Telephony.instance;
  final SmsLogDao _smsLogDao = SmsLogDao();

  Future<bool> requestPermissions() async {
    final status = await _telephony.requestSmsPermissions;
    return status ?? false;
  }

  Future<bool> sendSms({required String to, required String body, int? loanId, int? customerId, String smsType = 'general'}) async {
    try {
      final result = await _telephony.sendSms(to: to, message: body, isMultipart: true);
      await _smsLogDao.insert(SmsLog(
        loanId: loanId, customerId: customerId, mobile: to, message: body,
        status: 'sent', smsType: smsType, createdAt: DateTime.now().toIso8601String(),
      ));
      return true;
    } catch (e) {
      await _smsLogDao.insert(SmsLog(
        loanId: loanId, customerId: customerId, mobile: to, message: body,
        status: 'failed', smsType: smsType, createdAt: DateTime.now().toIso8601String(),
      ));
      return false;
    }
  }

  String buildPaymentReceivedSms({
    required String customerName, required double amount, required double remaining,
    required double returnAmount, required int day, required int totalDays, String ownerName = '',
  }) {
    final owner = ownerName.isNotEmpty ? ' - $ownerName' : '';
    return 'Dear $customerName, Rs ${amount.toStringAsFixed(0)} received for Day $day/$totalDays. '
           'Remaining: Rs ${remaining.toStringAsFixed(0)} of Rs ${returnAmount.toStringAsFixed(0)}. Thank you$owner.';
  }

  String buildMissedPaymentSms({
    required String customerName, required double amount, required int day, String ownerName = '',
  }) {
    final owner = ownerName.isNotEmpty ? ' - $ownerName' : '';
    return 'Dear $customerName, your Day $day payment of Rs ${amount.toStringAsFixed(0)} is pending. '
           'Please pay soon to avoid late fees. Thank you$owner.';
  }

  String buildLoanSummarySms({
    required String customerName, required double principal, required double returnAmount,
    required double collected, required double remaining, required int day, required int totalDays,
    String ownerName = '',
  }) {
    final owner = ownerName.isNotEmpty ? ' - $ownerName' : '';
    return 'Dear $customerName, Loan Summary: Principal Rs ${principal.toStringAsFixed(0)}, '
           'Return Rs ${returnAmount.toStringAsFixed(0)}, Collected Rs ${collected.toStringAsFixed(0)}, '
           'Remaining Rs ${remaining.toStringAsFixed(0)}, Day $day/$totalDays.$owner';
  }

  String buildCompletionSms({required String customerName, required double returnAmount, String ownerName = ''}) {
    final owner = ownerName.isNotEmpty ? ' - $ownerName' : '';
    return 'Dear $customerName, congratulations! Your loan of Rs ${returnAmount.toStringAsFixed(0)} is fully paid. '
           'Thank you for timely payments.$owner';
  }

  String buildPreClosureSms({required String customerName, required double payable, String ownerName = ''}) {
    final owner = ownerName.isNotEmpty ? ' - $ownerName' : '';
    return 'Dear $customerName, your loan has been pre-closed. Total payable: Rs ${payable.toStringAsFixed(0)}.$owner';
  }

  String buildAutoReminderSms({required String customerName, required double pending, required int daysLate, String ownerName = ''}) {
    final owner = ownerName.isNotEmpty ? ' - $ownerName' : '';
    return 'Dear $customerName, your payment is $daysLate days late (Rs ${pending.toStringAsFixed(0)} pending). '
           'Please pay immediately to avoid additional charges.$owner';
  }
}
