import '../models/loan.dart';
import '../models/schedule_entry.dart';
import '../models/settings.dart';
import '../database/dao/loan_dao.dart';
import '../database/dao/schedule_dao.dart';
import '../database/dao/settings_dao.dart';
import '../services/calculation_service.dart';

class AlertItem {
  final String title;
  final String description;
  final AlertType type;
  final int? loanId;
  AlertItem({required this.title, required this.description, required this.type, this.loanId});
}

enum AlertType { overdue, missedPayment, loanCompleted, pendingToday, defaulted }

class NotificationService {
  final LoanDao _loanDao = LoanDao();
  final ScheduleDao _scheduleDao = ScheduleDao();
  final SettingsDao _settingsDao = SettingsDao();

  Future<List<AlertItem>> getDashboardAlerts() async {
    final alerts = <AlertItem>[];
    final settings = await _settingsDao.getSettings();
    final today = CalculationService.today();
    final activeLoans = await _loanDao.getActiveLoans();
    int overdueCount = 0;
    int missedCount = 0;
    int pendingToday = 0;

    for (final loan in activeLoans) {
      final schedule = await _scheduleDao.getByLoanId(loan.id!);
      for (final entry in schedule) {
        if (entry.status == ScheduleEntryStatus.missed) {
          missedCount++;
          overdueCount++;
        } else if (entry.status == ScheduleEntryStatus.pending && !entry.isHoliday) {
          if (entry.scheduledDate.compareTo(today) < 0) {
            overdueCount++;
          } else if (entry.scheduledDate == today) {
            pendingToday++;
          }
        }
      }
      // Check for defaulted
      final daysElapsed = CalculationService.daysBetween(loan.startDate, today);
      if (daysElapsed > settings.defaultedThresholdDays) {
        final totalCollected = 0.0; // simplified
        if (loan.status == LoanStatus.overdue) {
          alerts.add(AlertItem(
            title: 'Defaulted Loan',
            description: 'Loan #${loan.id} may be defaulted (${daysElapsed} days elapsed)',
            type: AlertType.defaulted, loanId: loan.id,
          ));
        }
      }
    }

    if (overdueCount > 0) {
      alerts.add(AlertItem(
        title: 'Overdue Payments',
        description: '$overdueCount payment(s) are overdue',
        type: AlertType.overdue,
      ));
    }
    if (missedCount > 0) {
      alerts.add(AlertItem(
        title: 'Missed Payments',
        description: '$missedCount payment(s) missed',
        type: AlertType.missedPayment,
      ));
    }
    if (pendingToday > 0) {
      alerts.add(AlertItem(
        title: 'Pending Today',
        description: '$pendingToday collection(s) pending for today',
        type: AlertType.pendingToday,
      ));
    }

    final completedLoans = await _loanDao.getByStatus(LoanStatus.completed);
    if (completedLoans.isNotEmpty) {
      alerts.add(AlertItem(
        title: 'Completed Loans',
        description: '${completedLoans.length} loan(s) completed',
        type: AlertType.loanCompleted,
      ));
    }

    return alerts;
  }
}
