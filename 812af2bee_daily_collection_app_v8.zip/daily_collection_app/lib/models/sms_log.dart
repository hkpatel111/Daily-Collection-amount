class SmsLog {
  final int? id;
  final int? loanId;
  final int? customerId;
  final String mobile;
  final String message;
  final String status;
  final String smsType;
  final String createdAt;

  SmsLog({
    this.id,
    this.loanId,
    this.customerId,
    required this.mobile,
    required this.message,
    required this.status,
    required this.smsType,
    required this.createdAt,
  });

  Map<String, dynamic> toMap() {
    return {
      'id': id,
      'loan_id': loanId,
      'customer_id': customerId,
      'mobile': mobile,
      'message': message,
      'status': status,
      'sms_type': smsType,
      'created_at': createdAt,
    };
  }

  factory SmsLog.fromMap(Map<String, dynamic> map) {
    return SmsLog(
      id: map['id'] as int?,
      loanId: map['loan_id'] as int?,
      customerId: map['customer_id'] as int?,
      mobile: map['mobile'] as String,
      message: map['message'] as String,
      status: map['status'] as String,
      smsType: map['sms_type'] as String? ?? '',
      createdAt: map['created_at'] as String,
    );
  }
}
