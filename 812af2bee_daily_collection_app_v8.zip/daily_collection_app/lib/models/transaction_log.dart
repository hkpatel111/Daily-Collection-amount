class TransactionLog {
  final int? id;
  final String actionType;
  final String description;
  final int? loanId;
  final int? customerId;
  final String? customerName;
  final double? amount;
  final String createdAt;

  TransactionLog({
    this.id,
    required this.actionType,
    required this.description,
    this.loanId,
    this.customerId,
    this.customerName,
    this.amount,
    required this.createdAt,
  });

  Map<String, dynamic> toMap() {
    return {
      'id': id,
      'action_type': actionType,
      'description': description,
      'loan_id': loanId,
      'customer_id': customerId,
      'amount': amount,
      'created_at': createdAt,
    };
  }

  factory TransactionLog.fromMap(Map<String, dynamic> map) {
    return TransactionLog(
      id: map['id'] as int?,
      actionType: map['action_type'] as String,
      description: map['description'] as String,
      loanId: map['loan_id'] as int?,
      customerId: map['customer_id'] as int?,
      customerName: map['customer_name'] as String?,
      amount: (map['amount'] as num?)?.toDouble(),
      createdAt: map['created_at'] as String,
    );
  }
}
