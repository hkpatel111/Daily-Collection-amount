import 'package:flutter/material.dart';
import '../utils/constants.dart';

class StatCard extends StatelessWidget {
  final String label;
  final String value;
  final Color color;
  final IconData icon;
  final VoidCallback? onTap;

  const StatCard({
    super.key, required this.label, required this.value,
    required this.color, required this.icon, this.onTap,
  });

  @override
  Widget build(BuildContext context) {
    return Card(
      elevation: 2,
      child: InkWell(
        onTap: onTap,
        borderRadius: BorderRadius.circular(AppConstants.cardRadius),
        child: Padding(
          padding: const EdgeInsets.all(12),
          child: Column(
            mainAxisAlignment: MainAxisAlignment.center,
            children: [
              Icon(icon, color: color, size: 28),
              const SizedBox(height: 4),
              Text(value, style: TextStyle(fontSize: 16, fontWeight: FontWeight.bold, color: color)),
              const SizedBox(height: 2),
              Text(label, style: TextStyle(fontSize: 11, color: AppColors.textSecondary), textAlign: TextAlign.center),
            ],
          ),
        ),
      ),
    );
  }
}

class LoanStatusBadge extends StatelessWidget {
  final String status;
  final Color color;

  const LoanStatusBadge({super.key, required this.status, required this.color});

  @override
  Widget build(BuildContext context) {
    return Container(
      padding: const EdgeInsets.symmetric(horizontal: 8, vertical: 4),
      decoration: BoxDecoration(color: color.withOpacity(0.15), borderRadius: BorderRadius.circular(12)),
      child: Text(status, style: TextStyle(color: color, fontSize: 11, fontWeight: FontWeight.bold)),
    );
  }

  static Color getColor(String status) {
    switch (status) {
      case 'active': return AppColors.primary;
      case 'overdue': return AppColors.overdue;
      case 'completed': return AppColors.success;
      case 'pre_closed': return AppColors.warning;
      case 'defaulted': return AppColors.error;
      case 'cancelled': return AppColors.cancelled;
      default: return AppColors.textSecondary;
    }
  }

  static String getLabel(String status) {
    switch (status) {
      case 'active': return 'Active';
      case 'overdue': return 'Overdue';
      case 'completed': return 'Completed';
      case 'pre_closed': return 'Pre-Closed';
      case 'defaulted': return 'Defaulted';
      case 'cancelled': return 'Cancelled';
      default: return status;
    }
  }
}
