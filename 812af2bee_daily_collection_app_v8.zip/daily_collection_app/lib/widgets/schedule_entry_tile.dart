import 'package:flutter/material.dart';
import '../utils/constants.dart';
import '../models/schedule_entry.dart';
import '../models/collection_entry.dart';
import '../services/calculation_service.dart';

class ScheduleEntryTile extends StatelessWidget {
  final ScheduleEntry entry;
  final List<CollectionEntry> collections;
  final VoidCallback? onTap;

  const ScheduleEntryTile({super.key, required this.entry, required this.collections, this.onTap});

  @override
  Widget build(BuildContext context) {
    Color statusColor;
    IconData statusIcon;
    switch (entry.status) {
      case ScheduleEntryStatus.paid:
        statusColor = AppColors.success; statusIcon = Icons.check_circle; break;
      case ScheduleEntryStatus.partial:
        statusColor = AppColors.warning; statusIcon = Icons.remove_circle; break;
      case ScheduleEntryStatus.missed:
        statusColor = AppColors.error; statusIcon = Icons.cancel; break;
      case ScheduleEntryStatus.holiday:
        statusColor = AppColors.cancelled; statusIcon = Icons.beach_access; break;
      case ScheduleEntryStatus.cancelled:
        statusColor = AppColors.cancelled; statusIcon = Icons.block; break;
      case ScheduleEntryStatus.pending:
        statusColor = AppColors.textSecondary; statusIcon = Icons.radio_button_unchecked; break;
    }

    double collectedAmount = 0;
    for (final c in collections) collectedAmount += c.collectedAmount;

    return ListTile(
      leading: Icon(statusIcon, color: statusColor),
      title: Row(
        children: [
          Text('Day ${entry.dayNumber}', style: const TextStyle(fontWeight: FontWeight.bold)),
          const SizedBox(width: 8),
          Text(CalculationService.formatDate(entry.scheduledDate), style: TextStyle(fontSize: 12, color: AppColors.textSecondary)),
        ],
      ),
      subtitle: Text(
        entry.isHoliday
          ? 'Holiday'
          : 'Expected: ${CalculationService.formatCurrency(entry.expectedAmount)}'
            '${collectedAmount > 0 ? ' | Collected: ${CalculationService.formatCurrency(collectedAmount)}' : ''}',
        style: TextStyle(fontSize: 12, color: entry.isHoliday ? AppColors.cancelled : AppColors.textSecondary),
      ),
      trailing: onTap != null
        ? const Icon(Icons.add_circle, color: AppColors.primary)
        : null,
      onTap: onTap,
    );
  }
}
