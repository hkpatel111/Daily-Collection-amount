import 'package:flutter/material.dart';
import 'screens/dashboard_screen.dart';
import 'screens/customer_list_screen.dart';
import 'screens/daily_collection_screen.dart';
import 'screens/settings_screen.dart';
import 'screens/loan_detail_screen.dart';
import 'screens/transaction_log_screen.dart';
import 'screens/search_screen.dart';
import 'screens/calculators_screen.dart';
import 'screens/app_lock_screen.dart';
import 'screens/sms_history_screen.dart';
import 'utils/constants.dart';
import 'dart:io';
import 'database/dao/settings_dao.dart';
import 'models/settings.dart';
import 'database/database_helper.dart';
import 'services/backup_service.dart';
import 'package:file_picker/file_picker.dart';

class DailyCollectionApp extends StatefulWidget {
  const DailyCollectionApp({super.key});

  @override
  State<DailyCollectionApp> createState() => _DailyCollectionAppState();
}

class _DailyCollectionAppState extends State<DailyCollectionApp> with WidgetsBindingObserver {
  bool _darkMode = false;
  Color _themeColor = AppColors.primary;
  bool _unlocked = false;
  bool _appLockEnabled = false;
  String _appPin = '';
  final GlobalKey<NavigatorState> _navKey = GlobalKey<NavigatorState>();
  bool _startupDone = false;

  @override
  void initState() {
    super.initState();
    WidgetsBinding.instance.addObserver(this);
    _loadTheme();
  }

  @override
  void dispose() {
    WidgetsBinding.instance.removeObserver(this);
    super.dispose();
  }

  @override
  void didChangeAppLifecycleState(AppLifecycleState state) {
    if (state == AppLifecycleState.resumed) {
      _loadTheme();
      _runAutoBackup();
      if (_appLockEnabled) setState(() => _unlocked = false);
    }
  }

  Future<void> _loadTheme() async {
    try {
      final settingsDao = SettingsDao();
      final settings = await settingsDao.getSettings();
      if (mounted) {
        setState(() {
          _darkMode = settings.darkMode;
          _themeColor = ThemeColors.getColor(settings.themeColor);
          _appLockEnabled = settings.appLockEnabled;
          _appPin = settings.appPin;
          if (!_appLockEnabled) _unlocked = true;
        });
      }
      if (!_startupDone) {
        _startupDone = true;
        _runStartupChecks(settings);
      }
    } catch (_) {}
  }

  Future<void> _runAutoBackup() async {
    try {
      final settings = await SettingsDao().getSettings();
      await BackupService().autoBackupIfNeeded(settings);
    } catch (_) {}
  }

  // On fresh install: look for a backup in phone storage and offer Restore/Skip/Choose.
  Future<void> _runStartupChecks(AppSettings settings) async {
    try {
      await BackupService().autoBackupIfNeeded(settings);
      final db = await DatabaseHelper().database;
      final rows = await db.rawQuery('SELECT COUNT(*) AS c FROM customers');
      final count = (rows.first['c'] as int?) ?? 0;
      if (count > 0 || _appLockEnabled) return;
      final backupPath = await BackupService().findStorageBackup(settings.backupFolderPath);
      if (backupPath == null) return;
      await Future.delayed(const Duration(milliseconds: 400));
      final ctx = _navKey.currentContext;
      if (ctx == null) return;
      final modDate = File(backupPath).lastModifiedSync();
      final choice = await showDialog<String>(
        context: ctx,
        barrierDismissible: false,
        builder: (dctx) => AlertDialog(
          title: const Text('Backup Found'),
          content: Text('A data backup was found in phone storage (saved on ${modDate.day}/${modDate.month}/${modDate.year}).\nRestore your data now?'),
          actions: [
            TextButton(onPressed: () => Navigator.pop(dctx, 'skip'), child: const Text('Skip')),
            TextButton(onPressed: () => Navigator.pop(dctx, 'choose'), child: const Text('Choose File')),
            ElevatedButton(onPressed: () => Navigator.pop(dctx, 'restore'), child: const Text('Restore')),
          ],
        ),
      );
      if (choice == 'restore') {
        final result = await BackupService().importData(backupPath);
        if (_navKey.currentContext != null) {
          ScaffoldMessenger.of(_navKey.currentContext!).showSnackBar(SnackBar(content: Text(result.message)));
          _loadTheme();
        }
      } else if (choice == 'choose') {
        final picked = await FilePicker.platform.pickFiles(type: FileType.any, allowMultiple: false);
        if (picked != null && picked.files.isNotEmpty && picked.files.first.path != null) {
          final confirmed = await showDialog<bool>(context: _navKey.currentContext!, builder: (cctx) => AlertDialog(
            title: const Text('Restore Data'),
            content: const Text('This will replace ALL existing data. Continue?'),
            actions: [
              TextButton(onPressed: () => Navigator.pop(cctx, false), child: const Text('Cancel')),
              ElevatedButton(onPressed: () => Navigator.pop(cctx, true), child: const Text('Restore')),
            ],
          ));
          if (confirmed == true) {
            final result = await BackupService().importData(picked.files.first.path!);
            if (_navKey.currentContext != null) {
              ScaffoldMessenger.of(_navKey.currentContext!).showSnackBar(SnackBar(content: Text(result.message)));
              _loadTheme();
            }
          }
        }
      }
    } catch (_) {}
  }

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      navigatorKey: _navKey,
      title: 'Daily Collection',
      debugShowCheckedModeBanner: false,
      theme: _darkMode ? _darkTheme() : _lightTheme(),
      home: _appLockEnabled && !_unlocked
        ? AppLockScreen(correctPin: _appPin, onUnlock: () => setState(() => _unlocked = true))
        : const DashboardScreen(),
      routes: {
        '/customers': (ctx) => const CustomerListScreen(),
        '/daily_collection': (ctx) => const DailyCollectionScreen(),
        '/settings': (ctx) => const SettingsScreen(),
        '/loan_detail': (ctx) => LoanDetailRoute(),
        '/transaction_log': (ctx) => const TransactionLogScreen(),
        '/search': (ctx) => const SearchScreen(),
        '/calculators': (ctx) => const CalculatorsScreen(),
        '/sms_history': (ctx) => const SmsHistoryScreen(),
      },
    );
  }

  ThemeData _lightTheme() {
    return ThemeData(
      colorScheme: ColorScheme.fromSeed(seedColor: _themeColor, primary: _themeColor, brightness: Brightness.light),
      appBarTheme: AppBarTheme(backgroundColor: _themeColor, foregroundColor: Colors.white, elevation: 2),
      elevatedButtonTheme: ElevatedButtonThemeData(
        style: ElevatedButton.styleFrom(backgroundColor: _themeColor, foregroundColor: Colors.white,
          shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(AppConstants.buttonRadius)),
        ),
      ),
      cardTheme: CardThemeData(elevation: 2, shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(AppConstants.cardRadius))),
      scaffoldBackgroundColor: AppColors.background,
      useMaterial3: true,
    );
  }

  ThemeData _darkTheme() {
    return ThemeData(
      colorScheme: ColorScheme.fromSeed(seedColor: _themeColor, primary: _themeColor, brightness: Brightness.dark),
      appBarTheme: AppBarTheme(backgroundColor: _themeColor.withOpacity(0.8), foregroundColor: Colors.white, elevation: 2),
      elevatedButtonTheme: ElevatedButtonThemeData(
        style: ElevatedButton.styleFrom(backgroundColor: _themeColor, foregroundColor: Colors.white,
          shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(AppConstants.buttonRadius)),
        ),
      ),
      cardTheme: CardThemeData(elevation: 2, shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(AppConstants.cardRadius))),
      scaffoldBackgroundColor: DarkColors.background,
      useMaterial3: true,
    );
  }
}

class LoanDetailRoute extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    final loanId = ModalRoute.of(context)!.settings.arguments as int;
    return LoanDetailScreen(loanId: loanId);
  }
}
