import '../database_helper.dart';
import '../../models/transaction_log.dart';

class TransactionLogDao {
  final DatabaseHelper _dbHelper = DatabaseHelper();

  Future<int> insert(TransactionLog log) async {
    final db = await _dbHelper.database;
    return await db.insert('transaction_logs', log.toMap());
  }

  Future<List<TransactionLog>> getAll({int? limit}) async {
    final db = await _dbHelper.database;
    final maps = await db.query('transaction_logs', orderBy: 'created_at DESC', limit: limit);
    return maps.map((m) => TransactionLog.fromMap(m)).toList();
  }

  Future<List<Map<String, dynamic>>> getAllWithCustomerName({int? limit, String? searchQuery}) async {
    final db = await _dbHelper.database;
    String sql = '''SELECT t.*, c.name as customer_name, c.mobile as customer_mobile
      FROM transaction_logs t LEFT JOIN customers c ON t.customer_id = c.id''';
    List<dynamic> args = [];
    if (searchQuery != null && searchQuery.isNotEmpty) {
      sql += ' WHERE c.name LIKE ? OR c.mobile LIKE ? OR t.description LIKE ? OR CAST(t.amount AS TEXT) LIKE ? OR CAST(t.loan_id AS TEXT) LIKE ?';
      args = ['%$searchQuery%', '%$searchQuery%', '%$searchQuery%', '%$searchQuery%', '%$searchQuery%'];
    }
    sql += ' ORDER BY t.created_at DESC';
    if (limit != null) sql += ' LIMIT $limit';
    return await db.rawQuery(sql, args);
  }

  Future<List<Map<String, dynamic>>> getAllRaw() async {
    final db = await _dbHelper.database;
    return await db.query('transaction_logs');
  }

  Future<void> insertRaw(Map<String, dynamic> data) async {
    final db = await _dbHelper.database;
    await db.insert('transaction_logs', data);
  }

  Future<int> deleteAll() async {
    final db = await _dbHelper.database;
    return await db.delete('transaction_logs');
  }
}
