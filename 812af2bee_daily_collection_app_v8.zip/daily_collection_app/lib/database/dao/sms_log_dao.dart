import '../database_helper.dart';
import '../../models/sms_log.dart';

class SmsLogDao {
  final DatabaseHelper _dbHelper = DatabaseHelper();

  Future<int> insert(SmsLog log) async {
    final db = await _dbHelper.database;
    return await db.insert('sms_logs', log.toMap());
  }

  Future<List<SmsLog>> getAll({int? limit}) async {
    final db = await _dbHelper.database;
    final maps = await db.query('sms_logs', orderBy: 'created_at DESC', limit: limit);
    return maps.map((m) => SmsLog.fromMap(m)).toList();
  }

  Future<List<SmsLog>> getByLoanId(int loanId) async {
    final db = await _dbHelper.database;
    final maps = await db.query('sms_logs', where: 'loan_id = ?', whereArgs: [loanId], orderBy: 'created_at DESC');
    return maps.map((m) => SmsLog.fromMap(m)).toList();
  }

  Future<List<SmsLog>> getByCustomerId(int customerId) async {
    final db = await _dbHelper.database;
    final maps = await db.query('sms_logs', where: 'customer_id = ?', whereArgs: [customerId], orderBy: 'created_at DESC');
    return maps.map((m) => SmsLog.fromMap(m)).toList();
  }

  Future<List<Map<String, dynamic>>> getAllRaw() async {
    final db = await _dbHelper.database;
    return await db.query('sms_logs');
  }

  Future<void> insertRaw(Map<String, dynamic> data) async {
    final db = await _dbHelper.database;
    await db.insert('sms_logs', data);
  }
}
