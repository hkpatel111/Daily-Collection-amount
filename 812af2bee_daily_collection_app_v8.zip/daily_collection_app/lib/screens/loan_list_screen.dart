import 'package:flutter/material.dart';
import '../utils/constants.dart';
import '../database/dao/loan_dao.dart';
import '../services/calculation_service.dart';
import '../widgets/stat_card.dart';
import 'loan_detail_screen.dart';

class LoanListScreen extends StatefulWidget {
  final String? statusFilter;
  const LoanListScreen({super.key, this.statusFilter});

  @override
  State<LoanListScreen> createState() => _LoanListScreenState();
}

class _LoanListScreenState extends State<LoanListScreen> {
  final LoanDao _loanDao = LoanDao();
  List<Map<String, dynamic>> _loans = [];
  List<Map<String, dynamic>> _filtered = [];
  bool _isLoading = true;
  String _selectedStatus = 'all';

  @override
  void initState() {
    super.initState();
    if (widget.statusFilter != null) _selectedStatus = widget.statusFilter!;
    _loadLoans();
  }

  Future<void> _loadLoans() async {
    setState(() => _isLoading = true);
    if (_selectedStatus == 'all') {
      _loans = await _loanDao.getLoansWithCustomerName();
    } else {
      _loans = await _loanDao.getLoansWithCustomerNameByStatus(_selectedStatus);
    }
    _filtered = _loans;
    setState(() => _isLoading = false);
  }

  void _filterSearch(String query) {
    setState(() {
      _filtered = query.isEmpty
        ? _loans
        : _loans.where((l) {
            final name = (l['customer_name'] as String? ?? '').toLowerCase();
            final mobile = (l['customer_mobile'] as String? ?? '');
            final id = l['id'].toString();
            final principal = (l['principal'] as num).toDouble().toStringAsFixed(0);
            return name.contains(query.toLowerCase()) || mobile.contains(query) || id.contains(query) || principal.contains(query);
          }).toList();
    });
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: const Text('Loans')),
      body: Column(children: [
        Padding(
          padding: const EdgeInsets.all(AppConstants.padding),
          child: Column(children: [
            TextField(
              decoration: const InputDecoration(labelText: 'Search by name, mobile, loan ID', prefixIcon: Icon(Icons.search), border: OutlineInputBorder()),
              onChanged: _filterSearch,
            ),
            const SizedBox(height: 8),
            SingleChildScrollView(scrollDirection: Axis.horizontal, child: Row(children: [
              _filterChip('All', 'all'), const SizedBox(width: 6),
              _filterChip('Active', 'active'), const SizedBox(width: 6),
              _filterChip('Overdue', 'overdue'), const SizedBox(width: 6),
              _filterChip('Completed', 'completed'), const SizedBox(width: 6),
              _filterChip('Pre-Closed', 'pre_closed'), const SizedBox(width: 6),
              _filterChip('Cancelled', 'cancelled'),
            ])),
          ]),
        ),
        Expanded(
          child: _isLoading
            ? const Center(child: CircularProgressIndicator())
            : _filtered.isEmpty
              ? Center(child: Text('No loans found', style: TextStyle(color: AppColors.textSecondary)))
              : ListView.builder(
                  itemCount: _filtered.length,
                  itemBuilder: (context, index) {
                    final loan = _filtered[index];
                    final status = loan['status'] as String;
                    return Card(
                      margin: const EdgeInsets.symmetric(horizontal: AppConstants.padding, vertical: 4),
                      child: ListTile(
                        title: Text('#${loan['id']} - ${loan['customer_name']}'),
                        subtitle: Text('${CalculationService.formatCurrency((loan['principal'] as num).toDouble())} -> ${CalculationService.formatCurrency((loan['return_amount'] as num).toDouble())} | ${loan['total_days']} days'),
                        trailing: LoanStatusBadge(status: LoanStatusBadge.getLabel(status), color: LoanStatusBadge.getColor(status)),
                        onTap: () async {
                          await Navigator.push(context, MaterialPageRoute(builder: (_) => LoanDetailScreen(loanId: loan['id'] as int)));
                          _loadLoans();
                        },
                      ),
                    );
                  },
                ),
        ),
      ]),
    );
  }

  Widget _filterChip(String label, String value) {
    return ChoiceChip(
      label: Text(label),
      selected: _selectedStatus == value,
      onSelected: (_) { setState(() => _selectedStatus = value); _loadLoans(); },
      selectedColor: AppColors.primary.withOpacity(0.2),
    );
  }
}
