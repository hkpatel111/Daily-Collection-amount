import 'package:flutter/material.dart';
import '../utils/constants.dart';
import '../models/sms_log.dart';
import '../database/dao/sms_log_dao.dart';
import '../services/calculation_service.dart';
import '../services/sms_service.dart';

class SmsHistoryScreen extends StatefulWidget {
  final int? loanId;
  final int? customerId;
  const SmsHistoryScreen({super.key, this.loanId, this.customerId});

  @override
  State<SmsHistoryScreen> createState() => _SmsHistoryScreenState();
}

class _SmsHistoryScreenState extends State<SmsHistoryScreen> {
  final SmsLogDao _smsLogDao = SmsLogDao();
  final SmsService _smsService = SmsService();
  List<SmsLog> _logs = [];
  bool _isLoading = true;

  @override
  void initState() { super.initState(); _loadData(); }

  Future<void> _loadData() async {
    setState(() => _isLoading = true);
    if (widget.loanId != null) {
      _logs = await _smsLogDao.getByLoanId(widget.loanId!);
    } else if (widget.customerId != null) {
      _logs = await _smsLogDao.getByCustomerId(widget.customerId!);
    } else {
      _logs = await _smsLogDao.getAll(limit: 200);
    }
    setState(() => _isLoading = false);
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: const Text('SMS History')),
      body: _isLoading
        ? const Center(child: CircularProgressIndicator())
        : _logs.isEmpty
          ? Center(child: Text('No SMS sent yet', style: TextStyle(color: AppColors.textSecondary)))
          : ListView.builder(
              itemCount: _logs.length,
              itemBuilder: (context, index) {
                final log = _logs[index];
                final isFailed = log.status == 'failed';
                return Card(margin: const EdgeInsets.symmetric(horizontal: 8, vertical: 4),
                  child: ListTile(
                    leading: Icon(isFailed ? Icons.error : Icons.message, color: isFailed ? AppColors.error : AppColors.primary),
                    title: Text(log.message, maxLines: 2, overflow: TextOverflow.ellipsis, style: const TextStyle(fontSize: 13)),
                    subtitle: Text('To: +91 ${log.mobile} | ${CalculationService.formatDateTime(log.createdAt)} | ${log.status}', style: const TextStyle(fontSize: 11)),
                    trailing: isFailed
                      ? TextButton(child: const Text('Resend'), onPressed: () async {
                          await _smsService.sendSms(to: log.mobile, body: log.message, loanId: log.loanId, customerId: log.customerId, smsType: log.smsType);
                          _loadData();
                        })
                      : null,
                  ),
                );
              },
            ),
    );
  }
}
