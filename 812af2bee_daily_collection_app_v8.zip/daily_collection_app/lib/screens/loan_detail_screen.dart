import 'package:flutter/material.dart';
import 'package:share_plus/share_plus.dart';
import 'package:url_launcher/url_launcher.dart';
import 'dart:io';
import '../services/pdf_service.dart';
import '../utils/constants.dart';
import '../models/loan.dart';
import '../models/schedule_entry.dart';
import '../models/collection_entry.dart';
import '../models/settings.dart';
import '../database/dao/loan_dao.dart';
import '../database/dao/schedule_dao.dart';
import '../database/dao/collection_dao.dart';
import '../database/dao/settings_dao.dart';
import '../database/dao/customer_dao.dart';
import '../services/calculation_service.dart';
import '../services/schedule_service.dart';
import '../services/sms_service.dart';
import '../services/backup_service.dart';
import '../widgets/stat_card.dart';
import '../widgets/schedule_entry_tile.dart';
import 'pre_close_screen.dart';
import 'collection_list_screen.dart';
import 'calendar_screen.dart';
import 'sms_history_screen.dart';

class LoanDetailScreen extends StatefulWidget {
  final int loanId;
  const LoanDetailScreen({super.key, required this.loanId});

  @override
  State<LoanDetailScreen> createState() => _LoanDetailScreenState();
}

class _LoanDetailScreenState extends State<LoanDetailScreen> {
  final LoanDao _loanDao = LoanDao();
  final ScheduleDao _scheduleDao = ScheduleDao();
  final CollectionDao _collectionDao = CollectionDao();
  final SettingsDao _settingsDao = SettingsDao();
  final CustomerDao _customerDao = CustomerDao();
  final ScheduleService _scheduleService = ScheduleService();
  final SmsService _smsService = SmsService();
  final BackupService _backupService = BackupService();

  Loan? _loan;
  String _customerName = '';
  String _customerMobile = '';
  List<ScheduleEntry> _schedule = [];
  List<CollectionEntry> _collections = [];
  AppSettings _settings = AppSettings();
  double _totalCollected = 0;
  double _totalShortfall = 0;
  double _totalOverdueInterest = 0;
  bool _isLoading = true;
  ScheduleEntryStatus? _filterStatus;
  ScheduleSortOrder _sortOrder = ScheduleSortOrder.newToOld;

  @override
  void initState() { super.initState(); _loadData(); }

  Future<void> _loadData() async {
    setState(() => _isLoading = true);
    _loan = await _loanDao.getById(widget.loanId);
    if (_loan != null) {
      final customer = await _customerDao.getById(_loan!.customerId);
      _customerName = customer?.name ?? '';
      _customerMobile = customer?.mobile ?? '';
      _settings = await _settingsDao.getSettings();
      _schedule = await _scheduleDao.getByLoanIdFiltered(widget.loanId, _filterStatus);
      _schedule = _scheduleService.sortEntries(_schedule, _sortOrder);
      _collections = await _collectionDao.getByLoanId(widget.loanId);
      _totalCollected = await _collectionDao.getTotalCollectedByLoan(widget.loanId);
      _totalShortfall = await _collectionDao.getTotalShortfallByLoan(widget.loanId);
      _totalOverdueInterest = await _collectionDao.getTotalOverdueInterestByLoan(widget.loanId);
      if (_loan!.status == LoanStatus.active || _loan!.status == LoanStatus.overdue) {
        await _scheduleService.updateOverdueInterest(widget.loanId, _loan!, _settings);
        _loan = await _loanDao.getById(widget.loanId);
        _totalOverdueInterest = await _collectionDao.getTotalOverdueInterestByLoan(widget.loanId);
      }
    }
    if (mounted) setState(() => _isLoading = false);
  }

  Future<void> _recordCollection(ScheduleEntry entry, double amount) async {
    if (_loan == null) return;
    ExcessOption? excessOption;
    if (amount > entry.expectedAmount) {
      excessOption = await _showExcessDialog(amount - entry.expectedAmount);
      if (excessOption == null) return;
    }
    PaymentMode? mode = await _showPaymentModeDialog();
    if (mode == null) return;

    await _scheduleService.recordCollection(
      loanId: widget.loanId, scheduleEntry: entry, collectedAmount: amount,
      paymentMode: mode, excessOption: excessOption,
    );

    if (_settings.smsEnabled && _settings.smsOnPayment && _customerMobile.isNotEmpty) {
      final newCollected = _totalCollected + amount;
      final remaining = _loan!.returnAmount - newCollected;
      final msg = _smsService.buildPaymentReceivedSms(
        customerName: _customerName, amount: amount, remaining: remaining,
        returnAmount: _loan!.returnAmount, day: entry.dayNumber, totalDays: _loan!.totalDays, ownerName: _settings.ownerName,
      );
      if (_settings.smsAutoSend) {
        await _smsService.sendSms(to: _customerMobile, body: msg, loanId: widget.loanId, customerId: _loan!.customerId, smsType: 'payment');
      } else {
        _showSmsPreview(msg, _customerMobile, 'payment');
      }
    }

    // Show receipt option
    if (mounted) {
      final showReceipt = await showDialog<bool>(context: context, builder: (ctx) => AlertDialog(
        title: const Text('Collection Recorded'),
        content: Text('Rs ${amount.toStringAsFixed(0)} collected. Generate receipt?'),
        actions: [
          TextButton(onPressed: () => Navigator.pop(ctx, false), child: const Text('No')),
          ElevatedButton(onPressed: () => Navigator.pop(ctx, true), child: const Text('Receipt')),
        ],
      ));
      if (showReceipt == true) _generateReceipt(entry, amount);
    }
    _loadData();
  }

  bool _showYearlyRate = false;

  void _generateReceipt(ScheduleEntry entry, double amount) {
    final remaining = _loan!.returnAmount - _totalCollected - amount;
    final receipt = StringBuffer();
    receipt.writeln('=========================');
    receipt.writeln('    COLLECTION RECEIPT    ');
    receipt.writeln('=========================');
    receipt.writeln('Date: ${CalculationService.formatDate(CalculationService.today())}');
    receipt.writeln('Loan ID: #${_loan!.id}');
    receipt.writeln('Customer: $_customerName');
    receipt.writeln('Mobile: $_customerMobile');
    receipt.writeln('Day: ${entry.dayNumber}/${_loan!.totalDays}');
    receipt.writeln('Amount Received: Rs ${amount.toStringAsFixed(0)}');
    receipt.writeln('Remaining: Rs ${remaining.toStringAsFixed(0)}');
    receipt.writeln('Return Amount: Rs ${_loan!.returnAmount.toStringAsFixed(0)}');
    receipt.writeln('=========================');
    receipt.writeln('  Created by Harish  ');
    receipt.writeln('=========================');
    showDialog(context: context, builder: (ctx) => AlertDialog(
      title: const Text('Receipt'),
      content: SizedBox(width: double.maxFinite, child: SingleChildScrollView(child: Text(receipt.toString(), style: const TextStyle(fontFamily: 'monospace')))),
      actions: [
        TextButton(onPressed: () => Navigator.pop(ctx), child: const Text('Close')),
        ElevatedButton(onPressed: () async {
          Navigator.pop(ctx);
          try {
            final pdfPath = await PdfService.textToPdf('Collection Receipt', receipt.toString(), fileName: 'receipt_${_loan!.id}_${entry.dayNumber}');
            await Share.shareXFiles([XFile(pdfPath, mimeType: 'application/pdf')], subject: 'Receipt - $_customerName');
          } catch (_) {
            await Share.share(receipt.toString(), subject: 'Receipt - $_customerName');
          }
        }, child: const Text('Share PDF')),
        ElevatedButton(onPressed: () async {
          Navigator.pop(ctx);
          final uri = Uri.parse('https://wa.me/91$_customerMobile?text=${Uri.encodeComponent(receipt.toString())}');
          if (await canLaunchUrl(uri)) await launchUrl(uri, mode: LaunchMode.externalApplication);
        }, child: const Text('WhatsApp')),
      ],
    ));
  }

  Future<ExcessOption?> _showExcessDialog(double excess) async {
    return showDialog<ExcessOption>(
      context: context,
      builder: (ctx) => AlertDialog(
        title: const Text('Excess Amount'),
        content: Text('Excess of ${CalculationService.formatCurrency(excess)} received. How to adjust?'),
        actions: [
          TextButton(onPressed: () => Navigator.pop(ctx, ExcessOption.nextInstallment), child: const Text('Next Installment')),
          TextButton(onPressed: () => Navigator.pop(ctx, ExcessOption.principalAdjust), child: const Text('Principal Adjust')),
          TextButton(onPressed: () => Navigator.pop(ctx, ExcessOption.separateEntry), child: const Text('Separate Entry')),
          TextButton(onPressed: () => Navigator.pop(ctx, null), child: const Text('Cancel')),
        ],
      ),
    );
  }

  Future<PaymentMode?> _showPaymentModeDialog() async {
    return showDialog<PaymentMode>(
      context: context,
      builder: (ctx) => AlertDialog(
        title: const Text('Payment Mode'),
        content: Column(mainAxisSize: MainAxisSize.min, children: [
          for (final mode in PaymentMode.values)
            ListTile(
              title: Text(mode.label),
              leading: Icon(mode == PaymentMode.cash ? Icons.money : mode == PaymentMode.upi ? Icons.phone_android : Icons.account_balance),
              onTap: () => Navigator.pop(ctx, mode),
            ),
        ]),
      ),
    );
  }

  void _showSmsPreview(String message, String mobile, String type) {
    showDialog(context: context, builder: (ctx) => AlertDialog(
      title: const Text('Send SMS?'),
      content: Column(mainAxisSize: MainAxisSize.min, crossAxisAlignment: CrossAxisAlignment.start, children: [
        Text('To: +91 $mobile'),
        const SizedBox(height: 8),
        Text(message),
      ]),
      actions: [
        TextButton(onPressed: () => Navigator.pop(ctx), child: const Text('Skip')),
        ElevatedButton(onPressed: () async {
          Navigator.pop(ctx);
          await _smsService.sendSms(to: mobile, body: message, loanId: widget.loanId, customerId: _loan?.customerId, smsType: type);
        }, child: const Text('Send')),
      ],
    ));
  }

  void _showCollectionDialog(ScheduleEntry entry) {
    final amountCtrl = TextEditingController(text: entry.expectedAmount.toStringAsFixed(0));
    showDialog(context: context, builder: (ctx) => AlertDialog(
      title: Text('Day ${entry.dayNumber} Collection'),
      content: Column(mainAxisSize: MainAxisSize.min, children: [
        Text('Expected: ${CalculationService.formatCurrency(entry.expectedAmount)}'),
        Text('Date: ${CalculationService.formatDate(entry.scheduledDate)}'),
        const SizedBox(height: 16),
        TextField(
          controller: amountCtrl,
          decoration: const InputDecoration(labelText: 'Amount Received', border: OutlineInputBorder(), prefixText: 'Rs '),
          keyboardType: TextInputType.number,
        ),
      ]),
      actions: [
        TextButton(onPressed: () => Navigator.pop(ctx), child: const Text('Cancel')),
        ElevatedButton(onPressed: () {
          final amount = double.tryParse(amountCtrl.text) ?? 0;
          Navigator.pop(ctx);
          _recordCollection(entry, amount);
        }, child: const Text('Record')),
      ],
    ));
  }

  void _showEditDialog(CollectionEntry entry) {
    final amountCtrl = TextEditingController(text: entry.collectedAmount.toStringAsFixed(0));
    PaymentMode selectedMode = entry.paymentMode;
    showDialog(context: context, builder: (ctx) => StatefulBuilder(
      builder: (ctx, setS) => AlertDialog(
        title: const Text('Edit Collection'),
        content: Column(mainAxisSize: MainAxisSize.min, children: [
          TextField(controller: amountCtrl, decoration: const InputDecoration(labelText: 'Amount', border: OutlineInputBorder(), prefixText: 'Rs '), keyboardType: TextInputType.number),
          const SizedBox(height: 12),
          DropdownButtonFormField<PaymentMode>(
            value: selectedMode, decoration: const InputDecoration(labelText: 'Payment Mode', border: OutlineInputBorder()),
            items: PaymentMode.values.map((m) => DropdownMenuItem(value: m, child: Text(m.label))).toList(),
            onChanged: (v) => setS(() => selectedMode = v!),
          ),
        ]),
        actions: [
          TextButton(onPressed: () => Navigator.pop(ctx), child: const Text('Cancel')),
          ElevatedButton(onPressed: () async {
            final amount = double.tryParse(amountCtrl.text) ?? 0;
            Navigator.pop(ctx);
            await _scheduleService.editCollectionEntry(entry.id!, amount, entry.collectionDate, selectedMode);
            _loadData();
          }, child: const Text('Save')),
        ],
      ),
    ));
  }

  void _sendSms() {
    if (_loan == null || _customerMobile.isEmpty) return;
    final msg = _smsService.buildLoanSummarySms(
      customerName: _customerName, principal: _loan!.principal, returnAmount: _loan!.returnAmount,
      collected: _totalCollected, remaining: _loan!.returnAmount - _totalCollected,
      day: CalculationService.daysBetween(_loan!.startDate, CalculationService.today()) + 1,
      totalDays: _loan!.totalDays, ownerName: _settings.ownerName,
    );
    _showSmsPreview(msg, _customerMobile, 'summary');
  }

  Future<void> _exportSummary() async {
    final result = await _backupService.exportLoanSummary(widget.loanId);
    if (result.success && result.filePath != null) {
      try {
        final text = await File(result.filePath!).readAsString();
        final pdfPath = await PdfService.textToPdf('Loan Summary', text, fileName: 'loan_${widget.loanId}_summary');
        await Share.shareXFiles([XFile(pdfPath, mimeType: 'application/pdf')], subject: 'Loan Summary');
        return;
      } catch (_) {}
      await Share.shareXFiles([XFile(result.filePath!)], subject: 'Loan Summary');
    }
  }

  void _sendWhatsApp() {
    if (_customerMobile.isEmpty) return;
    final msg = _smsService.buildLoanSummarySms(
      customerName: _customerName, principal: _loan!.principal, returnAmount: _loan!.returnAmount,
      collected: _totalCollected, remaining: _loan!.returnAmount - _totalCollected,
      day: CalculationService.daysBetween(_loan!.startDate, CalculationService.today()) + 1,
      totalDays: _loan!.totalDays, ownerName: _settings.ownerName,
    );
    final uri = Uri.parse('https://wa.me/91$_customerMobile?text=${Uri.encodeComponent(msg)}');
    launchUrl(uri, mode: LaunchMode.externalApplication);
  }

  @override
  Widget build(BuildContext context) {
    if (_isLoading) return Scaffold(appBar: AppBar(title: const Text('Loan')), body: const Center(child: CircularProgressIndicator()));
    if (_loan == null) return Scaffold(appBar: AppBar(title: const Text('Loan')), body: const Center(child: Text('Loan not found')));

    final remaining = _loan!.returnAmount - _totalCollected;
    final daysElapsed = CalculationService.daysBetween(_loan!.startDate, CalculationService.today());
    int daysRemaining = _loan!.totalDays - daysElapsed;
    if (daysRemaining < 0) daysRemaining = 0;

    return Scaffold(
      appBar: AppBar(
        title: Text('Loan: $_customerName'),
        actions: [
          IconButton(icon: const Icon(Icons.calendar_today), onPressed: () async {
            await Navigator.push(context, MaterialPageRoute(builder: (_) => CalendarScreen(loanId: widget.loanId)));
          }),
          IconButton(icon: const Icon(Icons.message), onPressed: _sendSms),
          IconButton(icon: const Icon(Icons.chat), onPressed: _sendWhatsApp),
          PopupMenuButton(
            itemBuilder: (ctx) => [
              const PopupMenuItem(value: 'export', child: Text('Export Summary')),
              const PopupMenuItem(value: 'preclose', child: Text('Pre-Close Loan')),
              const PopupMenuItem(value: 'cancel', child: Text('Cancel Loan')),
              const PopupMenuItem(value: 'delete', child: Text('Delete Loan')),
              const PopupMenuItem(value: 'sms_history', child: Text('SMS History')),
            ],
            onSelected: (v) async {
              if (v == 'preclose') {
                final result = await Navigator.push<bool>(context, MaterialPageRoute(builder: (_) => PreCloseScreen(loanId: widget.loanId)));
                if (result == true && mounted) Navigator.pop(context, true);
              } else if (v == 'cancel') {
                final confirmed = await showDialog<bool>(context: context, builder: (ctx) => AlertDialog(
                  title: const Text('Cancel Loan'),
                  content: const Text('Cancel all pending entries? This cannot be undone.'),
                  actions: [
                    TextButton(onPressed: () => Navigator.pop(ctx, false), child: const Text('No')),
                    ElevatedButton(onPressed: () => Navigator.pop(ctx, true), child: const Text('Yes')),
                  ],
                ));
                if (confirmed == true) { await _scheduleService.cancelLoan(widget.loanId); if (mounted) Navigator.pop(context, true); }
              } else if (v == 'delete') {
                final confirmed = await showDialog<bool>(context: context, builder: (ctx) => AlertDialog(
                  title: const Text('Delete Loan'),
                  content: const Text('Permanently delete this loan and all related data?'),
                  actions: [
                    TextButton(onPressed: () => Navigator.pop(ctx, false), child: const Text('Cancel')),
                    ElevatedButton(style: ElevatedButton.styleFrom(backgroundColor: AppColors.error), onPressed: () => Navigator.pop(ctx, true), child: const Text('Delete')),
                  ],
                ));
                if (confirmed == true) { await _loanDao.permanentDelete(widget.loanId); if (mounted) Navigator.pop(context, true); }
              } else if (v == 'export') {
                _exportSummary();
              } else if (v == 'sms_history') {
                Navigator.push(context, MaterialPageRoute(builder: (_) => SmsHistoryScreen(loanId: widget.loanId)));
              }
            },
          ),
        ],
      ),
      body: ListView(
        padding: const EdgeInsets.all(AppConstants.padding),
        children: [
          Card(elevation: 3, child: Padding(padding: const EdgeInsets.all(16), child: Column(children: [
            Text('${CalculationService.formatCurrency(_loan!.principal)} -> ${CalculationService.formatCurrency(_loan!.returnAmount)}', style: const TextStyle(fontSize: 20, fontWeight: FontWeight.bold)),
            const SizedBox(height: 4),
            Text('${_loan!.totalDays} Days | ${CalculationService.formatCurrency(_loan!.dailyInstallment)}/day'),
            if (_loan!.accountName != null && _loan!.accountName!.isNotEmpty) ...[const SizedBox(height: 4), Text('Account: ${_loan!.accountName}', style: TextStyle(color: AppColors.textSecondary, fontSize: 12))],
            if (_loan!.loanTag.isNotEmpty) ...[const SizedBox(height: 4), Text('Tag: ${_loan!.loanTag}', style: TextStyle(color: AppColors.textSecondary, fontSize: 12))],
            const SizedBox(height: 8),
            Row(mainAxisAlignment: MainAxisAlignment.spaceEvenly, children: [
              _rateChip('Monthly', '${_loan!.monthlyInterestRate.toStringAsFixed(3)}%'),
              _rateChip('Daily', '${_loan!.dailyInterestRate.toStringAsFixed(3)}%'),
              if (_showYearlyRate) _rateChip('Yearly', '${_loan!.yearlyInterestRate.toStringAsFixed(3)}%'),
            ]),
            TextButton.icon(
              onPressed: () => setState(() => _showYearlyRate = !_showYearlyRate),
              icon: Icon(_showYearlyRate ? Icons.visibility_off : Icons.visibility, size: 16, color: AppColors.primary),
              label: Text(_showYearlyRate ? 'Hide Yearly Rate' : 'Show Yearly Rate', style: const TextStyle(fontSize: 12, color: AppColors.primary)),
            ),
            const SizedBox(height: 8),
            LoanStatusBadge(status: _loan!.status.label, color: LoanStatusBadge.getColor(_loan!.status.dbValue)),
          ]))),
          const SizedBox(height: 8),
          GridView.count(
            shrinkWrap: true, physics: const NeverScrollableScrollPhysics(),
            crossAxisCount: 2, childAspectRatio: 1.8, crossAxisSpacing: 8, mainAxisSpacing: 8,
            children: [
              StatCard(label: 'Collected', value: CalculationService.formatCurrency(_totalCollected), color: AppColors.success, icon: Icons.check_circle,
                onTap: () => Navigator.push(context, MaterialPageRoute(builder: (_) => CollectionListScreen(loanId: widget.loanId)))),
              StatCard(label: 'Remaining', value: CalculationService.formatCurrency(remaining), color: AppColors.warning, icon: Icons.pending),
              StatCard(label: 'Days', value: '$daysElapsed/${_loan!.totalDays}', color: AppColors.primary, icon: Icons.calendar_today),
              StatCard(label: 'Overdue', value: CalculationService.formatCurrency(_totalShortfall + _totalOverdueInterest), color: AppColors.overdue, icon: Icons.warning,
                onTap: () => Navigator.push(context, MaterialPageRoute(builder: (_) => CollectionListScreen(loanId: widget.loanId, showOverdueOnly: true)))),
            ],
          ),
          const SizedBox(height: 16),
          Row(children: [
            Text('DAILY SCHEDULE', style: TextStyle(fontSize: 13, fontWeight: FontWeight.bold, color: AppColors.textSecondary)),
            const Spacer(),
            DropdownButton<ScheduleSortOrder>(
              value: _sortOrder, isDense: true, underline: Container(),
              items: const [
                DropdownMenuItem(value: ScheduleSortOrder.newToOld, child: Text('New->Old')),
                DropdownMenuItem(value: ScheduleSortOrder.oldToNew, child: Text('Old->New')),
                DropdownMenuItem(value: ScheduleSortOrder.paidFirst, child: Text('Paid First')),
                DropdownMenuItem(value: ScheduleSortOrder.unpaidFirst, child: Text('Unpaid First')),
                DropdownMenuItem(value: ScheduleSortOrder.pendingFirst, child: Text('Pending First')),
                DropdownMenuItem(value: ScheduleSortOrder.missedFirst, child: Text('Missed First')),
              ],
              onChanged: (v) { if (v != null) { setState(() => _sortOrder = v); _loadData(); } },
            ),
            const SizedBox(width: 8),
            DropdownButton<ScheduleEntryStatus?>(
              value: _filterStatus, isDense: true, underline: Container(),
              hint: const Text('Filter', style: TextStyle(fontSize: 12)),
              items: const [
                DropdownMenuItem(value: null, child: Text('All')),
                DropdownMenuItem(value: ScheduleEntryStatus.pending, child: Text('Pending')),
                DropdownMenuItem(value: ScheduleEntryStatus.paid, child: Text('Paid')),
                DropdownMenuItem(value: ScheduleEntryStatus.partial, child: Text('Partial')),
                DropdownMenuItem(value: ScheduleEntryStatus.missed, child: Text('Missed')),
              ],
              onChanged: (v) { setState(() => _filterStatus = v); _loadData(); },
            ),
          ]),
          const SizedBox(height: 8),
          ..._schedule.map((entry) {
            final entryCollections = _collections.where((c) => c.scheduleEntryId == entry.id).toList();
            return Column(children: [
              ScheduleEntryTile(
                entry: entry, collections: entryCollections,
                onTap: entry.status == ScheduleEntryStatus.pending && !entry.isHoliday
                  ? () => _showCollectionDialog(entry) : null,
              ),
              if (entryCollections.isNotEmpty && entry.status != ScheduleEntryStatus.pending)
                Padding(padding: const EdgeInsets.only(left: 56, bottom: 4),
                  child: Row(children: [
                    Expanded(child: Text('${CalculationService.formatDate(entryCollections.first.collectionDate)} | ${CalculationService.formatCurrency(entryCollections.first.collectedAmount)} | ${entryCollections.first.paymentMode.label}',
                      style: TextStyle(fontSize: 11, color: AppColors.textSecondary))),
                    IconButton(icon: const Icon(Icons.edit, size: 16), onPressed: () => _showEditDialog(entryCollections.first)),
                    IconButton(icon: const Icon(Icons.delete, size: 16, color: AppColors.error),
                      onPressed: () async { await _scheduleService.deleteCollectionEntry(entryCollections.first.id!); _loadData(); }),
                  ]),
                ),
              const Divider(height: 1),
            ]);
          }),
        ],
      ),
    );
  }

  Widget _rateChip(String label, String value) {
    return Container(padding: const EdgeInsets.symmetric(horizontal: 8, vertical: 4),
      decoration: BoxDecoration(color: AppColors.primary.withOpacity(0.1), borderRadius: BorderRadius.circular(8)),
      child: Column(children: [
        Text(value, style: const TextStyle(fontSize: 11, fontWeight: FontWeight.bold, color: AppColors.primary)),
        Text(label, style: const TextStyle(fontSize: 9, color: AppColors.textSecondary)),
      ]));
  }
}
