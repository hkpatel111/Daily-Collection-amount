import 'package:flutter/material.dart';
import 'package:share_plus/share_plus.dart';
import 'package:file_picker/file_picker.dart';
import '../utils/constants.dart';
import '../models/settings.dart';
import '../database/dao/settings_dao.dart';
import '../services/backup_service.dart';

class SettingsScreen extends StatefulWidget {
  const SettingsScreen({super.key});

  @override
  State<SettingsScreen> createState() => _SettingsScreenState();
}

class _SettingsScreenState extends State<SettingsScreen> {
  final SettingsDao _settingsDao = SettingsDao();
  final BackupService _backupService = BackupService();
  AppSettings _settings = AppSettings();
  bool _isLoading = true;
  bool _isExporting = false;

  @override
  void initState() { super.initState(); _loadSettings(); }

  Future<void> _loadSettings() async {
    _settings = await _settingsDao.getSettings();
    setState(() => _isLoading = false);
  }

  Future<void> _saveSettings() async {
    await _settingsDao.updateSettings(_settings);
    if (mounted) ScaffoldMessenger.of(context).showSnackBar(const SnackBar(content: Text('Settings saved')));
  }

  Future<void> _exportData() async {
    setState(() => _isExporting = true);
    final result = await _backupService.exportData();
    setState(() => _isExporting = false);
    if (result.success && result.filePath != null) {
      await Share.shareXFiles([XFile(result.filePath!)], subject: 'Daily Collection Backup');
    }
  }

  Future<void> _importData() async {
    final result = await FilePicker.platform.pickFiles(type: FileType.any, allowMultiple: false);
    if (result != null && result.files.isNotEmpty) {
      final filePath = result.files.first.path;
      if (filePath == null) return;
      final confirmed = await showDialog<bool>(context: context, builder: (ctx) => AlertDialog(
        title: const Text('Import Data'),
        content: const Text('This will replace ALL existing data. Continue?'),
        actions: [
          TextButton(onPressed: () => Navigator.pop(ctx, false), child: const Text('Cancel')),
          ElevatedButton(onPressed: () => Navigator.pop(ctx, true), child: const Text('Import')),
        ],
      ));
      if (confirmed == true) {
        final importResult = await _backupService.importData(filePath);
        if (mounted) ScaffoldMessenger.of(context).showSnackBar(SnackBar(content: Text(importResult.message)));
      }
    }
  }

  Future<void> _exportCsv() async {
    final result = await _backupService.exportCsv();
    if (result.success && result.filePath != null) {
      await Share.shareXFiles([XFile(result.filePath!)], subject: 'Daily Collection CSV');
    }
  }

  Future<void> _saveBackupNow() async {
    setState(() => _isExporting = true);
    await _settingsDao.updateSettings(_settings);
    final result = await _backupService.saveBackupToStorage(_settings);
    setState(() => _isExporting = false);
    if (mounted) ScaffoldMessenger.of(context).showSnackBar(SnackBar(content: Text(result.message)));
  }

  Future<void> _restoreFromStorage() async {
    final granted = await _backupService.ensureStoragePermission();
    if (!granted) {
      if (mounted) ScaffoldMessenger.of(context).showSnackBar(const SnackBar(content: Text('Storage permission required')));
      return;
    }
    final path = await _backupService.findStorageBackup(_settings.backupFolderPath);
    if (path == null) {
      if (mounted) ScaffoldMessenger.of(context).showSnackBar(const SnackBar(content: Text('No backup found in phone storage')));
      return;
    }
    final confirmed = await showDialog<bool>(context: context, builder: (ctx) => AlertDialog(
      title: const Text('Restore from Storage'),
      content: const Text('This will replace ALL existing data with the storage backup. Continue?'),
      actions: [
        TextButton(onPressed: () => Navigator.pop(ctx, false), child: const Text('Cancel')),
        ElevatedButton(onPressed: () => Navigator.pop(ctx, true), child: const Text('Restore')),
      ],
    ));
    if (confirmed == true) {
      final result = await _backupService.importData(path);
      if (mounted) {
        ScaffoldMessenger.of(context).showSnackBar(SnackBar(content: Text(result.message)));
        _loadSettings();
      }
    }
  }

  @override
  Widget build(BuildContext context) {
    if (_isLoading) return Scaffold(appBar: AppBar(title: const Text('Settings')), body: const Center(child: CircularProgressIndicator()));
    return Scaffold(
      appBar: AppBar(title: const Text('Settings'),
        actions: [TextButton(onPressed: _saveSettings, child: const Text('Save', style: TextStyle(color: Colors.white)))]),
      body: ListView(padding: const EdgeInsets.all(AppConstants.padding), children: [
        _sectionTitle('OWNER'),
        Card(child: Padding(padding: const EdgeInsets.all(16),
          child: TextField(
            decoration: const InputDecoration(labelText: 'Your Name (shown in SMS)', border: OutlineInputBorder()),
            onChanged: (v) => _settings = _settings.copyWith(ownerName: v),
            controller: TextEditingController(text: _settings.ownerName),
          ))),
        const SizedBox(height: 24),
        _sectionTitle('COLLECTION RULES'),
        Card(child: Column(children: [
          ListTile(title: const Text('Grace Period'), subtitle: const Text('Days before overdue interest'),
            trailing: SizedBox(width: 60,
              child: TextField(decoration: const InputDecoration(border: InputBorder.none), textAlign: TextAlign.center, keyboardType: TextInputType.number,
                controller: TextEditingController(text: _settings.gracePeriodDays.toString()),
                onChanged: (v) { final d = int.tryParse(v); if (d != null) _settings = _settings.copyWith(gracePeriodDays: d); }))),
          const Divider(height: 1),
          ListTile(title: const Text('Defaulted Threshold'), subtitle: const Text('Days before loan is defaulted'),
            trailing: SizedBox(width: 60,
              child: TextField(decoration: const InputDecoration(border: InputBorder.none), textAlign: TextAlign.center, keyboardType: TextInputType.number,
                controller: TextEditingController(text: _settings.defaultedThresholdDays.toString()),
                onChanged: (v) { final d = int.tryParse(v); if (d != null) _settings = _settings.copyWith(defaultedThresholdDays: d); }))),
          const Divider(height: 1),
          SwitchListTile(title: const Text('Skip Sundays'), subtitle: const Text('No collection on Sundays'),
            value: _settings.sundayHolidayEnabled,
            onChanged: (v) => setState(() => _settings = _settings.copyWith(sundayHolidayEnabled: v))),
        ])),
        const SizedBox(height: 24),
        _sectionTitle('LATE FEE'),
        Card(child: Column(children: [
          SwitchListTile(title: const Text('Enable Late Fee'), value: _settings.lateFeeEnabled,
            onChanged: (v) => setState(() => _settings = _settings.copyWith(lateFeeEnabled: v))),
          if (_settings.lateFeeEnabled) ...[
            const Divider(height: 1),
            ListTile(title: const Text('Late Fee Per Day (Rs)'),
              trailing: SizedBox(width: 80,
                child: TextField(decoration: const InputDecoration(border: InputBorder.none), textAlign: TextAlign.center, keyboardType: TextInputType.number,
                  controller: TextEditingController(text: _settings.lateFeePerDay.toStringAsFixed(0)),
                  onChanged: (v) { final d = double.tryParse(v); if (d != null) _settings = _settings.copyWith(lateFeePerDay: d); }))),
          ],
        ])),
        const SizedBox(height: 24),
        _sectionTitle('COLLECTION PRIORITY'),
        Card(child: Column(children: [
          RadioListTile<String>(title: const Text('FIFO (Oldest loan first)'), value: 'fifo', groupValue: _settings.collectionPriority,
            onChanged: (v) => setState(() => _settings = _settings.copyWith(collectionPriority: v!))),
          RadioListTile<String>(title: const Text('Manual (Choose each time)'), value: 'manual', groupValue: _settings.collectionPriority,
            onChanged: (v) => setState(() => _settings = _settings.copyWith(collectionPriority: v!))),
          RadioListTile<String>(title: const Text('Equal Split'), value: 'equal', groupValue: _settings.collectionPriority,
            onChanged: (v) => setState(() => _settings = _settings.copyWith(collectionPriority: v!))),
        ])),
        const SizedBox(height: 24),
        _sectionTitle('SMS'),
        Card(child: Column(children: [
          SwitchListTile(title: const Text('SMS Enabled'), value: _settings.smsEnabled,
            onChanged: (v) => setState(() => _settings = _settings.copyWith(smsEnabled: v))),
          if (_settings.smsEnabled) ...[
            const Divider(height: 1),
            SwitchListTile(title: const Text('Payment Confirmation'), value: _settings.smsOnPayment,
              onChanged: (v) => setState(() => _settings = _settings.copyWith(smsOnPayment: v))),
            const Divider(height: 1),
            SwitchListTile(title: const Text('Missed Payment Reminder'), value: _settings.smsOnMissed,
              onChanged: (v) => setState(() => _settings = _settings.copyWith(smsOnMissed: v))),
            const Divider(height: 1),
            SwitchListTile(title: const Text('Loan Completion'), value: _settings.smsOnCompletion,
              onChanged: (v) => setState(() => _settings = _settings.copyWith(smsOnCompletion: v))),
            const Divider(height: 1),
            SwitchListTile(title: const Text('Pre-Closure'), value: _settings.smsOnPreclosure,
              onChanged: (v) => setState(() => _settings = _settings.copyWith(smsOnPreclosure: v))),
            const Divider(height: 1),
            SwitchListTile(title: const Text('Auto-Send (no prompt)'), value: _settings.smsAutoSend,
              onChanged: (v) => setState(() => _settings = _settings.copyWith(smsAutoSend: v))),
            const Divider(height: 1),
            ListTile(title: const Text('Auto-Reminder After (days)'), subtitle: const Text('Send reminder after X days missed'),
              trailing: SizedBox(width: 60,
                child: TextField(decoration: const InputDecoration(border: InputBorder.none), textAlign: TextAlign.center, keyboardType: TextInputType.number,
                  controller: TextEditingController(text: _settings.autoReminderDays.toString()),
                  onChanged: (v) { final d = int.tryParse(v); if (d != null) _settings = _settings.copyWith(autoReminderDays: d); }))),
          ],
        ])),
        const SizedBox(height: 24),
        _sectionTitle('APPEARANCE'),
        Card(child: Column(children: [
          SwitchListTile(title: const Text('Dark Mode'), value: _settings.darkMode,
            onChanged: (v) { setState(() => _settings = _settings.copyWith(darkMode: v)); _saveSettings(); }),
          const Divider(height: 1),
          ListTile(title: const Text('Theme Color'),
            trailing: DropdownButton<String>(
              value: _settings.themeColor,
              items: ThemeColors.colors.keys.map((k) => DropdownMenuItem(value: k, child: Row(children: [
                Container(width: 16, height: 16, color: ThemeColors.colors[k]),
                const SizedBox(width: 8), Text(k[0].toUpperCase() + k.substring(1)),
              ]))).toList(),
              onChanged: (v) { if (v != null) { setState(() => _settings = _settings.copyWith(themeColor: v)); _saveSettings(); } },
            )),
        ])),
        const SizedBox(height: 24),
        _sectionTitle('SECURITY'),
        Card(child: Column(children: [
          SwitchListTile(title: const Text('App Lock (PIN)'), subtitle: const Text('Require PIN to open app'),
            value: _settings.appLockEnabled,
            onChanged: (v) async {
              if (v) {
                final pin = await _showPinDialog();
                if (pin != null && pin.length == 4) {
                  setState(() => _settings = _settings.copyWith(appLockEnabled: true, appPin: pin));
                  _saveSettings();
                }
              } else {
                setState(() => _settings = _settings.copyWith(appLockEnabled: false, appPin: ''));
                _saveSettings();
              }
            }),
        ])),
        const SizedBox(height: 24),
        _sectionTitle('AUTO-BACKUP (PHONE STORAGE)'),
        Card(child: Column(children: [
          SwitchListTile(
            title: const Text('Save Backup to Phone Storage'),
            subtitle: const Text('Auto-save backup at a custom path (survives app uninstall)'),
            value: _settings.autoBackupToStorage,
            onChanged: (v) async {
              if (v) {
                final granted = await _backupService.ensureStoragePermission();
                if (!granted) {
                  if (mounted) ScaffoldMessenger.of(context).showSnackBar(const SnackBar(content: Text('Storage permission required')));
                  return;
                }
              }
              setState(() => _settings = _settings.copyWith(autoBackupToStorage: v));
            }),
          if (_settings.autoBackupToStorage) ...[
            const Divider(height: 1),
            ListTile(title: const Text('Backup Folder'), subtitle: Text('Phone storage: /storage/emulated/0/${_settings.backupFolderPath}'),
              trailing: SizedBox(width: 130,
                child: TextField(decoration: const InputDecoration(border: InputBorder.none), textAlign: TextAlign.center,
                  controller: TextEditingController(text: _settings.backupFolderPath),
                  onChanged: (v) => _settings = _settings.copyWith(backupFolderPath: v.trim())))),
            const Divider(height: 1),
            ListTile(title: const Text('Auto-Backup Frequency (days)'), subtitle: const Text('Auto-saves after every X days (on app open)'),
              trailing: SizedBox(width: 60,
                child: TextField(decoration: const InputDecoration(border: InputBorder.none), textAlign: TextAlign.center, keyboardType: TextInputType.number,
                  controller: TextEditingController(text: _settings.autoBackupDays.toString()),
                  onChanged: (v) { final d = int.tryParse(v); if (d != null && d > 0) _settings = _settings.copyWith(autoBackupDays: d); }))),
            const Divider(height: 1),
            ListTile(leading: _isExporting
              ? const SizedBox(width: 24, height: 24, child: CircularProgressIndicator(strokeWidth: 2))
              : const Icon(Icons.save, color: AppColors.primary),
              title: const Text('Save Backup Now'), onTap: _isExporting ? null : _saveBackupNow),
            const Divider(height: 1),
            ListTile(leading: const Icon(Icons.restore, color: AppColors.success),
              title: const Text('Restore from Phone Storage'), onTap: _restoreFromStorage),
          ],
          const Divider(height: 1),
          SwitchListTile(title: const Text('Google Drive Backup'), subtitle: const Text('Auto-upload to Google Drive'),
            value: _settings.gDriveBackupEnabled,
            onChanged: (v) => setState(() => _settings = _settings.copyWith(gDriveBackupEnabled: v))),
        ])),
        const SizedBox(height: 24),
        _sectionTitle('DATA & BACKUP'),
        Card(child: Column(children: [
          ListTile(leading: _isExporting
            ? const SizedBox(width: 24, height: 24, child: CircularProgressIndicator(strokeWidth: 2))
            : const Icon(Icons.backup, color: AppColors.primary),
            title: const Text('Export Data (Backup)'), subtitle: const Text('Save as JSON'),
            onTap: _isExporting ? null : _exportData),
          const Divider(height: 1),
          ListTile(leading: const Icon(Icons.restore, color: AppColors.primary),
            title: const Text('Import Data (Restore)'), onTap: _importData),
          const Divider(height: 1),
          ListTile(leading: const Icon(Icons.table_chart, color: AppColors.success),
            title: const Text('Export as CSV'), onTap: _exportCsv),
        ])),
        const SizedBox(height: 24),
        _sectionTitle('ABOUT'),
        Card(child: Column(children: [
          const ListTile(leading: Icon(Icons.info, color: AppColors.textSecondary),
            title: Text('Daily Collection App'), subtitle: Text('Version 3.0.0')),
          const Divider(height: 1),
          ListTile(
            leading: const Icon(Icons.person, color: AppColors.primary),
            title: const Text('Created by Harish', style: TextStyle(fontWeight: FontWeight.bold)),
            subtitle: const Text('Daily Collection Loan Tracking App'),
          ),
        ])),
        const SizedBox(height: 32),
      ]),
    );
  }

  Future<String?> _showPinDialog() async {
    final pinCtrl = TextEditingController();
    return showDialog<String>(context: context, builder: (ctx) => AlertDialog(
      title: const Text('Set PIN'),
      content: TextField(controller: pinCtrl, decoration: const InputDecoration(labelText: '4-digit PIN', border: OutlineInputBorder()),
        keyboardType: TextInputType.number, maxLength: 4, obscureText: true),
      actions: [
        TextButton(onPressed: () => Navigator.pop(ctx, null), child: const Text('Cancel')),
        ElevatedButton(onPressed: () => Navigator.pop(ctx, pinCtrl.text), child: const Text('Set')),
      ],
    ));
  }

  Widget _sectionTitle(String title) {
    return Padding(padding: const EdgeInsets.only(bottom: 8),
      child: Text(title, style: TextStyle(fontSize: 13, fontWeight: FontWeight.bold, color: AppColors.textSecondary)));
  }
}
