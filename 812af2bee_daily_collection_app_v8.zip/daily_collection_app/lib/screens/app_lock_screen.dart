import 'package:flutter/material.dart';
import '../utils/constants.dart';

class AppLockScreen extends StatefulWidget {
  final String correctPin;
  final VoidCallback onUnlock;
  const AppLockScreen({super.key, required this.correctPin, required this.onUnlock});

  @override
  State<AppLockScreen> createState() => _AppLockScreenState();
}

class _AppLockScreenState extends State<AppLockScreen> {
  String _enteredPin = '';
  String _error = '';

  void _onKeyPress(String digit) {
    if (_enteredPin.length < 4) {
      setState(() {
        _enteredPin += digit;
        _error = '';
      });
      if (_enteredPin.length == 4) {
        if (_enteredPin == widget.correctPin) {
          widget.onUnlock();
        } else {
          Future.delayed(const Duration(milliseconds: 300), () {
            setState(() { _enteredPin = ''; _error = 'Wrong PIN. Try again.'; });
          });
        }
      }
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: Center(child: Column(mainAxisAlignment: MainAxisAlignment.center, children: [
        const Icon(Icons.lock, size: 64, color: AppColors.primary),
        const SizedBox(height: 16),
        const Text('Enter PIN', style: TextStyle(fontSize: 20, fontWeight: FontWeight.bold)),
        const SizedBox(height: 24),
        Row(mainAxisAlignment: MainAxisAlignment.center, children: [
          for (int i = 0; i < 4; i++)
            Container(margin: const EdgeInsets.symmetric(horizontal: 8), width: 16, height: 16,
              decoration: BoxDecoration(shape: BoxShape.circle, color: i < _enteredPin.length ? AppColors.primary : Colors.grey.shade300)),
        ]),
        const SizedBox(height: 16),
        if (_error.isNotEmpty) Text(_error, style: const TextStyle(color: AppColors.error)),
        const SizedBox(height: 24),
        SizedBox(width: 240, child: GridView.count(crossAxisCount: 3, shrinkWrap: true, mainAxisSpacing: 12, crossAxisSpacing: 12, childAspectRatio: 1.5,
          children: [
            for (int i = 1; i <= 9; i++) _keyButton('$i'),
            _keyButton(''),
            _keyButton('0'),
            _keyButton('⌫', isBackspace: true),
          ],
        )),
      ])),
    );
  }

  Widget _keyButton(String label, {bool isBackspace = false}) {
    if (label.isEmpty) return const SizedBox();
    return ElevatedButton(
      onPressed: () {
        if (isBackspace) {
          setState(() { if (_enteredPin.isNotEmpty) _enteredPin = _enteredPin.substring(0, _enteredPin.length - 1); });
        } else {
          _onKeyPress(label);
        }
      },
      style: ElevatedButton.styleFrom(shape: const CircleBorder(), padding: const EdgeInsets.all(16)),
      child: Text(label, style: const TextStyle(fontSize: 24)),
    );
  }
}
