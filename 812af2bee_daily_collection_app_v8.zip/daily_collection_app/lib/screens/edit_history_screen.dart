import 'package:flutter/material.dart';
import '../utils/constants.dart';
import '../database/dao/edit_history_dao.dart';
import '../services/calculation_service.dart';

class EditHistoryScreen extends StatefulWidget {
  final int collectionEntryId;
  const EditHistoryScreen({super.key, required this.collectionEntryId});

  @override
  State<EditHistoryScreen> createState() => _EditHistoryScreenState();
}

class _EditHistoryScreenState extends State<EditHistoryScreen> {
  final EditHistoryDao _editHistoryDao = EditHistoryDao();
  List _history = [];
  bool _isLoading = true;

  @override
  void initState() { super.initState(); _loadData(); }

  Future<void> _loadData() async {
    setState(() => _isLoading = true);
    _history = await _editHistoryDao.getByCollectionEntry(widget.collectionEntryId);
    setState(() => _isLoading = false);
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: const Text('Edit History')),
      body: _isLoading
        ? const Center(child: CircularProgressIndicator())
        : _history.isEmpty
          ? Center(child: Text('No edits recorded', style: TextStyle(color: AppColors.textSecondary)))
          : ListView.builder(
              itemCount: _history.length,
              itemBuilder: (context, index) {
                final h = _history[index];
                return Card(margin: const EdgeInsets.symmetric(horizontal: 8, vertical: 4),
                  child: ListTile(
                    leading: const Icon(Icons.edit, color: AppColors.warning),
                    title: Text('${h.fieldName}: ${h.oldValue} -> ${h.newValue}', style: const TextStyle(fontSize: 14)),
                    subtitle: Text(CalculationService.formatDateTime(h.editedAt), style: const TextStyle(fontSize: 12)),
                  ),
                );
              },
            ),
    );
  }
}
