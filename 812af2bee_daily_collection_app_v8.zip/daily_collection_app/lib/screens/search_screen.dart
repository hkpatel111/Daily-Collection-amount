import 'package:flutter/material.dart';
import '../utils/constants.dart';
import '../database/dao/customer_dao.dart';
import '../database/dao/loan_dao.dart';
import '../services/calculation_service.dart';
import 'customer_detail_screen.dart';
import 'loan_detail_screen.dart';

class SearchScreen extends StatefulWidget {
  const SearchScreen({super.key});

  @override
  State<SearchScreen> createState() => _SearchScreenState();
}

class _SearchScreenState extends State<SearchScreen> {
  final CustomerDao _customerDao = CustomerDao();
  final LoanDao _loanDao = LoanDao();
  final _searchController = TextEditingController();
  List<Map<String, dynamic>> _results = [];
  bool _hasSearched = false;

  void _search(String query) async {
    if (query.trim().isEmpty) { setState(() { _results = []; _hasSearched = false; }); return; }
    setState(() => _hasSearched = true);
    final customers = await _customerDao.search(query);
    final loans = await _loanDao.getLoansWithCustomerName();
    final filteredLoans = loans.where((l) {
      final name = (l['customer_name'] as String? ?? '').toLowerCase();
      final mobile = (l['customer_mobile'] as String? ?? '');
      final id = l['id'].toString();
      final principal = (l['principal'] as num).toDouble().toStringAsFixed(0);
      final returnAmt = (l['return_amount'] as num).toDouble().toStringAsFixed(0);
      final installment = (l['daily_installment'] as num).toDouble().toStringAsFixed(0);
      final startDate = (l['start_date'] as String?) ?? '';
      return name.contains(query.toLowerCase()) || mobile.contains(query) || id.contains(query) ||
             principal.contains(query) || returnAmt.contains(query) || installment.contains(query) ||
             startDate.contains(query);
    }).toList();
    setState(() {
      _results = [
        ...customers.map((c) => {'type': 'customer', 'id': c.id, 'title': c.name, 'subtitle': c.mobile}),
        ...filteredLoans.map((l) => {'type': 'loan', 'id': l['id'], 'title': '#${l['id']} - ${l['customer_name']}', 'subtitle': '${CalculationService.formatCurrency((l['principal'] as num).toDouble())} | ${l['start_date']}'}),
      ];
    });
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: const Text('Search')),
      body: Column(children: [
        Padding(padding: const EdgeInsets.all(AppConstants.padding),
          child: TextField(
            controller: _searchController,
            decoration: const InputDecoration(labelText: 'Search name, mobile, loan ID, amount, date', prefixIcon: Icon(Icons.search), border: OutlineInputBorder()),
            onChanged: _search,
          )),
        Expanded(
          child: !_hasSearched
            ? const Center(child: Text('Start typing to search...'))
            : _results.isEmpty
              ? const Center(child: Text('No results found'))
              : ListView.builder(
                  itemCount: _results.length,
                  itemBuilder: (context, index) {
                    final r = _results[index];
                    return Card(margin: const EdgeInsets.symmetric(horizontal: 8, vertical: 4),
                      child: ListTile(
                        leading: Icon(r['type'] == 'customer' ? Icons.person : Icons.account_balance_wallet, color: AppColors.primary),
                        title: Text(r['title']),
                        subtitle: Text(r['subtitle']),
                        onTap: () async {
                          if (r['type'] == 'customer') {
                            await Navigator.push(context, MaterialPageRoute(builder: (_) => CustomerDetailScreen(customerId: r['id'])));
                          } else {
                            await Navigator.push(context, MaterialPageRoute(builder: (_) => LoanDetailScreen(loanId: r['id'])));
                          }
                        },
                      ),
                    );
                  },
                ),
        ),
      ]),
    );
  }
}
