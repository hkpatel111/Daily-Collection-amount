import 'package:flutter/material.dart';

class AppColors {
  static const Color primary = Color(0xFF1565C0);
  static const Color success = Color(0xFF2E7D32);
  static const Color warning = Color(0xFFEF6C00);
  static const Color error = Color(0xFFC62828);
  static const Color overdue = Color(0xFFB71C1C);
  static const Color completed = Color(0xFF2E7D32);
  static const Color cancelled = Color(0xFF616161);
  static const Color background = Color(0xFFF5F5F5);
  static const Color textPrimary = Color(0xFF212121);
  static const Color textSecondary = Color(0xFF757575);
}

class DarkColors {
  static const Color background = Color(0xFF121212);
  static const Color surface = Color(0xFF1E1E1E);
}

class AppConstants {
  static const double padding = 16.0;
  static const double cardRadius = 12.0;
  static const double buttonRadius = 8.0;
}

class ThemeColors {
  static const Map<String, Color> colors = {
    'blue': Color(0xFF1565C0),
    'green': Color(0xFF2E7D32),
    'purple': Color(0xFF6A1B9A),
    'orange': Color(0xFFE65100),
    'teal': Color(0xFF00695C),
  };
  static Color getColor(String name) => colors[name] ?? colors['blue']!;
}
