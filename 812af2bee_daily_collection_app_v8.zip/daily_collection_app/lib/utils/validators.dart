class Validators {
  static String? validateName(String? value) {
    if (value == null || value.trim().isEmpty) return 'Name is required';
    if (value.trim().length < 2) return 'Name too short';
    return null;
  }

  static String? validateMobile(String? value) {
    if (value == null || value.trim().isEmpty) return 'Mobile is required';
    if (value.trim().length != 10) return 'Must be 10 digits';
    if (!RegExp(r'^[0-9]+$').hasMatch(value.trim())) return 'Only digits allowed';
    return null;
  }

  static String? validateAmount(String? value, {String label = 'Amount'}) {
    if (value == null || value.trim().isEmpty) return '$label is required';
    final amount = double.tryParse(value);
    if (amount == null) return 'Invalid amount';
    if (amount <= 0) return '$label must be positive';
    return null;
  }

  static String? validateReturnAmount(String? value, double principal) {
    if (value == null || value.trim().isEmpty) return 'Return amount is required';
    final amount = double.tryParse(value);
    if (amount == null) return 'Invalid amount';
    if (amount <= 0) return 'Must be positive';
    if (amount <= principal) return 'Return must be greater than principal';
    return null;
  }

  static String? validateDailyInstallment(String? value, double returnAmount) {
    if (value == null || value.trim().isEmpty) return 'Daily installment is required';
    final amount = double.tryParse(value);
    if (amount == null) return 'Invalid amount';
    if (amount <= 0) return 'Must be positive';
    if (amount >= returnAmount) return 'Installment too high';
    return null;
  }

  static String? validatePin(String? value) {
    if (value == null || value.isEmpty) return 'PIN is required';
    if (value.length != 4) return 'PIN must be 4 digits';
    if (!RegExp(r'^[0-9]+$').hasMatch(value)) return 'Only digits';
    return null;
  }
}
