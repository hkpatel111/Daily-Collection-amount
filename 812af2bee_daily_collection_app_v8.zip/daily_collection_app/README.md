# Daily Collection App v3.0

Daily collection loan tracking app with 37+ features including calculators, SMS history, edit history, app lock, and more.

## Features
- Multiple active loans per customer
- Drill-down navigation everywhere (clickable stats + alerts)
- Calendar view with color-coded daily status
- Transaction log with customer names + filter/search + export
- Edit history with timestamps (old value -> new value)
- Excess payment handling (3 options: Next Installment, Principal Adjust, Separate Entry)
- Edit/delete collection entries
- Payment mode tracking (Cash/UPI/Bank)
- Bulk collection (mark all paid)
- Global search (name/mobile/loan ID/amount/date)
- Dark mode + theme color customization
- Auto-backup with customizable days + Google Drive option
- Permanent delete (loan & customer)
- Schedule filter + sorting (New-Old, Old-New, Paid first, Unpaid first, Pending first, Missed first)
- SMS from loan account + SMS history log + resend failed
- Receipt generate (text/share/WhatsApp) after every collection
- Contact list picker + nickname + loan account name
- Interest rate display (daily/monthly/yearly) at creation + loan detail
- Customer credit score (internal)
- Late fee auto-calculation
- Auto reminder SMS (configurable days)
- App Lock (PIN)
- WhatsApp integration
- Monthly summary report + Yearly tax summary
- 10 Calculators (Daily, EMI, SIP, Future Value, Rate of Return, Home Loan, Simple Interest, Compound Interest, Profit Margin, Loan Comparison)
- Export/Import data (JSON backup)
- CSV export
- Print/Share as PDF for loan & customer

## Setup
1. Upload ZIP to GitHub repo
2. Add workflow file to `.github/workflows/build-apk.yml`
3. Build runs automatically
4. Download APK from Actions > Artifacts
