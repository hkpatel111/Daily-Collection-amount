import 'package:flutter/material.dart';
import '../database/database_helper.dart';
import '../database/dao/customer_dao.dart';
import '../database/dao/loan_dao.dart';
import '../database/dao/collection_dao.dart';
import '../database/dao/schedule_dao.dart';
import '../models/schedule_entry.dart';
import '../services/notification_service.dart';
import '../services/calculation_service.dart';
import '../utils/constants.dart';
import '../widgets/stat_card.dart';
import 'daily_collection_screen.dart';
import 'customer_list_screen.dart';
import 'loan_list_screen.dart';
import 'search_screen.dart';
import 'calculators_screen.dart';
import 'settings_screen.dart';
import 'transaction_log_screen.dart';

class DashboardScreen extends StatefulWidget {
  const DashboardScreen({super.key});

  @override
  State<DashboardScreen> createState() => _DashboardScreenState();
}

class _DashboardScreenState extends State<DashboardScreen> {
  final _dbHelper = DatabaseHelper();
  late final CustomerDao _customerDao;
  late final LoanDao _loanDao;
  late final CollectionDao _collectionDao;
  late final ScheduleDao _scheduleDao;
  final _notificationService = NotificationService();

  int _customerCount = 0;
  int _activeLoanCount = 0;
  double _todayCollection = 0;
  double _totalOutstanding = 0;
  int _pendingToday = 0;
  int _overdueCount = 0;
  bool _isLoading = true;

  @override
  void initState() {
    super.initState();
    _customerDao = CustomerDao(_dbHelper);
    _loanDao = LoanDao(_dbHelper);
    _collectionDao = CollectionDao(_dbHelper);
    _scheduleDao = ScheduleDao(_dbHelper);
    _loadData();
  }

  Future<void> _loadData() async {
    setState(() => _isLoading = true);
    final customerCount = await _customerDao.count();
    final activeLoans = await _loanDao.getActive();
    final todayCollection = await _collectionDao.getTodayTotal();
    final totalOutstanding = await _loanDao.getTotalOutstanding();
    final today = DateTime.now();
    final todayEntries = await _scheduleDao.getByDate(today);
    final pendingToday = todayEntries.where((e) => e.status != ScheduleEntryStatus.paid && e.status != ScheduleEntryStatus.skipped).length;
    final overdueCount = todayEntries.where((e) => e.isOverdue).length;

    _notificationService.generateAlerts(
      overdueCount: overdueCount,
      pendingTodayCount: pendingToday,
      activeLoansCount: activeLoans.length,
      totalOutstanding: totalOutstanding,
    );

    setState(() {
      _customerCount = customerCount;
      _activeLoanCount = activeLoans.length;
      _todayCollection = todayCollection;
      _totalOutstanding = totalOutstanding;
      _pendingToday = pendingToday;
      _overdueCount = overdueCount;
      _isLoading = false;
    });
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text(AppConstants.appName),
        actions: [
          IconButton(
            icon: const Icon(Icons.search),
            onPressed: () => Navigator.pushNamed(context, '/search'),
          ),
          IconButton(
            icon: const Icon(Icons.settings),
            onPressed: () => Navigator.pushNamed(context, '/settings'),
          ),
        ],
      ),
      body: _isLoading
          ? const Center(child: CircularProgressIndicator())
          : RefreshIndicator(
              onRefresh: _loadData,
              child: ListView(
                padding: const EdgeInsets.all(16),
                children: [
                  // Stats Grid
                  GridView.count(
                    shrinkWrap: true,
                    physics: const NeverScrollableScrollPhysics(),
                    crossAxisCount: 2,
                    crossAxisSpacing: 12,
                    mainAxisSpacing: 12,
                    childAspectRatio: 1.3,
                    children: [
                      StatCard(
                        title: 'Customers',
                        value: '$_customerCount',
                        icon: Icons.people,
                        color: AppColors.primary,
                        onTap: () => Navigator.pushNamed(context, '/customers'),
                      ),
                      StatCard(
                        title: 'Active Loans',
                        value: '$_activeLoanCount',
                        icon: Icons.account_balance,
                        color: AppColors.accent,
                        onTap: () => Navigator.pushNamed(context, '/loans'),
                      ),
                      StatCard(
                        title: 'Today Collection',
                        value: CalculationService.formatCurrencySimple(_todayCollection),
                        icon: Icons.today,
                        color: AppColors.success,
                        onTap: () => Navigator.push(context, MaterialPageRoute(builder: (_) => const DailyCollectionScreen())),
                      ),
                      StatCard(
                        title: 'Outstanding',
                        value: CalculationService.formatCurrencySimple(_totalOutstanding),
                        icon: Icons.warning,
                        color: AppColors.overdue,
                        onTap: () => Navigator.pushNamed(context, '/loans'),
                      ),
                    ],
                  ),
                  const SizedBox(height: 16),
                  // Alerts Section
                  if (_notificationService.alerts.isNotEmpty) ...[
                    const Text(
                      'Alerts',
                      style: TextStyle(fontSize: 18, fontWeight: FontWeight.bold),
                    ),
                    const SizedBox(height: 8),
                    ..._notificationService.alerts.map((alert) => Card(
                          margin: const EdgeInsets.only(bottom: 8),
                          child: ListTile(
                            leading: Icon(alert.icon, color: alert.color),
                            title: Text(alert.title, style: const TextStyle(fontWeight: FontWeight.w600)),
                            subtitle: Text(alert.message),
                          ),
                        )),
                    const SizedBox(height: 16),
                  ],
                  // Quick Actions
                  const Text(
                    'Quick Actions',
                    style: TextStyle(fontSize: 18, fontWeight: FontWeight.bold),
                  ),
                  const SizedBox(height: 8),
                  Wrap(
                    spacing: 8,
                    runSpacing: 8,
                    children: [
                      ActionChip(
                        label: const Text('Add Customer'),
                        avatar: const Icon(Icons.person_add),
                        onPressed: () => Navigator.pushNamed(context, '/add_customer'),
                      ),
                      ActionChip(
                        label: const Text('Daily Collection'),
                        avatar: const Icon(Icons.payments),
                        onPressed: () => Navigator.push(context, MaterialPageRoute(builder: (_) => const DailyCollectionScreen())),
                      ),
                      ActionChip(
                        label: const Text('Calculators'),
                        avatar: const Icon(Icons.calculate),
                        onPressed: () => Navigator.push(context, MaterialPageRoute(builder: (_) => const CalculatorsScreen())),
                      ),
                      ActionChip(
                        label: const Text('Calendar'),
                        avatar: const Icon(Icons.calendar_month),
                        onPressed: () => Navigator.pushNamed(context, '/calendar'),
                      ),
                      ActionChip(
                        label: const Text('Transaction Log'),
                        avatar: const Icon(Icons.history),
                        onPressed: () => Navigator.push(context, MaterialPageRoute(builder: (_) => const TransactionLogScreen())),
                      ),
                    ],
                  ),
                  const SizedBox(height: 24),
                  // Created by Harish
                  const Center(
                    child: Column(
                      children: [
                        Text(
                          AppConstants.createdBy,
                          style: TextStyle(
                            fontSize: 14,
                            fontWeight: FontWeight.w600,
                            color: AppColors.primary,
                          ),
                        ),
                        Text(
                          'Developer: ${AppConstants.developerName}',
                          style: TextStyle(
                            fontSize: 12,
                            color: Colors.grey,
                          ),
                        ),
                        Text(
                          'Version ${AppConstants.appVersion}',
                          style: TextStyle(
                            fontSize: 10,
                            color: Colors.grey,
                          ),
                        ),
                      ],
                    ),
                  ),
                ],
              ),
            ),
      floatingActionButton: FloatingActionButton(
        onPressed: () => Navigator.pushNamed(context, '/add_customer'),
        child: const Icon(Icons.add),
      ),
    );
  }
}
