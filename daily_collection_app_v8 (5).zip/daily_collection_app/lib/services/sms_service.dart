import 'package:url_launcher/url_launcher.dart';
import '../database/database_helper.dart';
import '../database/dao/sms_log_dao.dart';
import '../models/sms_log.dart';

class SmsService {
  final DatabaseHelper _dbHelper;
  late final SmsLogDao _smsLogDao;

  SmsService(this._dbHelper) {
    _smsLogDao = SmsLogDao(_dbHelper);
  }

  // SMS permissions not needed with url_launcher approach
  Future<bool> requestPermissions() async {
    return true;
  }

  // Send SMS - opens SMS app with pre-filled message via url_launcher
  Future<bool> sendSms({
    required String recipient,
    required String message,
    int? loanId,
    int? customerId,
  }) async {
    try {
      final cleanNumber = recipient.replaceAll(RegExp(r'[^0-9+]'), '');
      if (cleanNumber.isEmpty) {
        await _logSms(recipient, message, SmsStatus.failed, 'Invalid recipient number', loanId, customerId);
        return false;
      }

      final uri = Uri.parse('sms:$cleanNumber?body=${Uri.encodeComponent(message)}');
      final launched = await launchUrl(uri, mode: LaunchMode.externalApplication);

      if (launched) {
        await _logSms(recipient, message, SmsStatus.sent, '', loanId, customerId);
        return true;
      } else {
        await _logSms(recipient, message, SmsStatus.failed, 'Could not launch SMS app', loanId, customerId);
        return false;
      }
    } catch (e) {
      await _logSms(recipient, message, SmsStatus.failed, e.toString(), loanId, customerId);
      return false;
    }
  }

  // Send WhatsApp message
  Future<bool> sendWhatsApp({
    required String recipient,
    required String message,
  }) async {
    try {
      final cleanNumber = recipient.replaceAll(RegExp(r'[^0-9]'), '');
      final uri = Uri.parse('https://wa.me/91$cleanNumber?text=${Uri.encodeComponent(message)}');
      return await launchUrl(uri, mode: LaunchMode.externalApplication);
    } catch (e) {
      return false;
    }
  }

  Future<void> _logSms(String recipient, String message, SmsStatus status, String error, int? loanId, int? customerId) async {
    await _smsLogDao.insert(SmsLog(
      loanId: loanId,
      customerId: customerId,
      recipient: recipient,
      message: message,
      status: status,
      sentAt: DateTime.now(),
      errorMessage: error,
    ));
  }

  String generateReminderMessage(String customerName, double amount, int daysOverdue) {
    if (daysOverdue > 0) {
      return 'Namaste $customerName, aapka daily collection $daysOverdue din pending hai. Amount: Rs ${amount.toStringAsFixed(0)}. Kripya jaldi pay karein. - Harish K Patidar';
    }
    return 'Namaste $customerName, aaj ka daily collection Rs ${amount.toStringAsFixed(0)} due hai. Kripya pay karein. - Harish K Patidar';
  }

  String generateLoanCreatedMessage(String customerName, double principal, double returnAmount, double dailyInstallment, int totalDays) {
    return 'Namaste $customerName, aapka loan approved hai. Principal: Rs ${principal.toStringAsFixed(0)}, Return Amount: Rs ${returnAmount.toStringAsFixed(0)}, Daily: Rs ${dailyInstallment.toStringAsFixed(0)}, Days: $totalDays. - Harish K Patidar';
  }

  String generatePreCloseMessage(String customerName, double preCloseAmount) {
    return 'Namaste $customerName, aapka loan pre-close ho gaya hai. Final amount: Rs ${preCloseAmount.toStringAsFixed(0)}. Dhanyavaad! - Harish K Patidar';
  }

  String generateWhatsAppMessage(String customerName, double amount, {bool overdue = false}) {
    if (overdue) {
      return 'Namaste $customerName, aapka payment pending hai. Amount: Rs ${amount.toStringAsFixed(0)}. Kripya jaldi pay karein.';
    }
    return 'Namaste $customerName, aaj ka collection Rs ${amount.toStringAsFixed(0)} due hai. Kripya pay karein.';
  }

  Future<List<SmsLog>> getAllLogs() async {
    return await _smsLogDao.getAll();
  }

  Future<List<SmsLog>> getLogsByLoanId(int loanId) async {
    return await _smsLogDao.getByLoanId(loanId);
  }
}
