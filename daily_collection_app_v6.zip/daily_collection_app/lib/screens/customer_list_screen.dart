import 'package:flutter/material.dart';
import 'package:contact_picker/contact_picker.dart';
import '../utils/constants.dart';
import '../models/customer.dart';
import '../models/loan.dart';
import '../database/dao/customer_dao.dart';
import '../database/dao/loan_dao.dart';
import '../services/calculation_service.dart';
import '../widgets/stat_card.dart';
import 'add_customer_screen.dart';
import 'customer_detail_screen.dart';

class CustomerListScreen extends StatefulWidget {
  const CustomerListScreen({super.key});

  @override
  State<CustomerListScreen> createState() => _CustomerListScreenState();
}

class _CustomerListScreenState extends State<CustomerListScreen> {
  final CustomerDao _customerDao = CustomerDao();
  final LoanDao _loanDao = LoanDao();
  List<Customer> _customers = [];
  List<Customer> _filtered = [];
  bool _isLoading = true;
  bool _showArchived = false;

  @override
  void initState() { super.initState(); _loadCustomers(); }

  Future<void> _loadCustomers() async {
    setState(() => _isLoading = true);
    _customers = await _customerDao.getAll(activeOnly: !_showArchived);
    _filtered = _customers;
    setState(() => _isLoading = false);
  }

  void _filterSearch(String query) {
    setState(() {
      _filtered = query.isEmpty
        ? _customers
        : _customers.where((c) => c.name.toLowerCase().contains(query.toLowerCase()) || c.mobile.contains(query) || (c.nickname ?? '').toLowerCase().contains(query.toLowerCase())).toList();
    });
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text('Customers'),
        actions: [
          IconButton(icon: Icon(_showArchived ? Icons.list : Icons.archive), onPressed: () { _showArchived = !_showArchived; _loadCustomers(); }, tooltip: _showArchived ? 'Show Active' : 'Show Archived'),
        ],
      ),
      body: Column(children: [
        Padding(
          padding: const EdgeInsets.all(AppConstants.padding),
          child: TextField(
            decoration: const InputDecoration(labelText: 'Search by name, mobile, or nickname', prefixIcon: Icon(Icons.search), border: OutlineInputBorder()),
            onChanged: _filterSearch,
          ),
        ),
        Expanded(
          child: _isLoading
            ? const Center(child: CircularProgressIndicator())
            : _filtered.isEmpty
              ? Center(child: Text(_showArchived ? 'No archived customers' : 'No customers yet. Tap + to add one.', style: TextStyle(color: AppColors.textSecondary)))
              : ListView.builder(
                  itemCount: _filtered.length,
                  itemBuilder: (context, index) => _buildCustomerTile(_filtered[index]),
                ),
        ),
      ]),
      floatingActionButton: Column(
        mainAxisAlignment: MainAxisAlignment.end,
        children: [
          FloatingActionButton.small(
            heroTag: 'contact',
            onPressed: () async {
              final ContactPicker picker = ContactPicker();
              try {
                final Contact contact = await picker.selectContact();
                if (contact.fullName != null && contact.phoneNumber != null) {
                  var mobile = contact.phoneNumber!.number.replaceAll(RegExp(r'[^0-9]'), '');
                  if (mobile.length > 10) mobile = mobile.substring(mobile.length - 10);
                  await Navigator.push(context, MaterialPageRoute(builder: (_) => AddCustomerScreen(prefillName: contact.fullName, prefillMobile: mobile)));
                  _loadCustomers();
                }
              } catch (_) {}
            },
            child: const Icon(Icons.contacts),
          ),
          const SizedBox(height: 8),
          FloatingActionButton(
            heroTag: 'add',
            onPressed: () async {
              await Navigator.push(context, MaterialPageRoute(builder: (_) => const AddCustomerScreen()));
              _loadCustomers();
            },
            child: const Icon(Icons.add),
          ),
        ],
      ),
    );
  }

  Widget _buildCustomerTile(Customer customer) {
    return Card(
      margin: const EdgeInsets.symmetric(horizontal: AppConstants.padding, vertical: 4),
      child: FutureBuilder<List<Loan>>(
        future: _loanDao.getActiveLoansByCustomer(customer.id!),
        builder: (context, snapshot) {
          final activeLoans = snapshot.data ?? [];
          final loanText = activeLoans.isEmpty
            ? 'No active loan'
            : activeLoans.length == 1
              ? '${CalculationService.formatCurrency(activeLoans[0].principal)} -> ${CalculationService.formatCurrency(activeLoans[0].returnAmount)}'
              : '${activeLoans.length} active loans';
          return ListTile(
            leading: CircleAvatar(backgroundColor: AppColors.primary, child: Text(customer.name.isNotEmpty ? customer.name[0].toUpperCase() : '?', style: const TextStyle(color: Colors.white))),
            title: Text(customer.name + (customer.nickname != null && customer.nickname!.isNotEmpty ? ' (${customer.nickname})' : '')),
            subtitle: Text('${customer.mobile} | $loanText'),
            trailing: activeLoans.isNotEmpty ? LoanStatusBadge(status: LoanStatusBadge.getLabel('active'), color: LoanStatusBadge.getColor('active')) : null,
            onTap: () async {
              await Navigator.push(context, MaterialPageRoute(builder: (_) => CustomerDetailScreen(customerId: customer.id!)));
              _loadCustomers();
            },
          );
        },
      ),
    );
  }
}
