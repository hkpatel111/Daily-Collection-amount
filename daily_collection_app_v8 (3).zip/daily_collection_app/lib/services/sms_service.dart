import 'package:telephony/telephony.dart' hide SmsStatus;
import '../database/database_helper.dart';
import '../database/dao/sms_log_dao.dart';
import '../models/sms_log.dart';

class SmsService {
  final DatabaseHelper _dbHelper;
  late final SmsLogDao _smsLogDao;

  SmsService(this._dbHelper) {
    _smsLogDao = SmsLogDao(_dbHelper);
  }

  // Use Telephony.instance - NOT Telephony as type
  final telephony = Telephony.instance;

  // requestSmsPermissions is a GETTER (no parentheses) that returns Future<bool?>
  Future<bool> requestPermissions() async {
    try {
      final granted = await telephony.requestSmsPermissions;
      return granted ?? false;
    } catch (e) {
      return false;
    }
  }

  // Send SMS - telephony.sendSms returns void, so we use try/catch
  Future<bool> sendSms({
    required String recipient,
    required String message,
    int? loanId,
    int? customerId,
  }) async {
    try {
      // Clean recipient number
      final cleanNumber = recipient.replaceAll(RegExp(r'[^0-9+]'), '');
      if (cleanNumber.isEmpty) {
        await _logSms(recipient, message, SmsStatus.failed, 'Invalid recipient number', loanId, customerId);
        return false;
      }

      // sendSms returns void - we cannot check return value
      // Just call it inside try/catch
      telephony.sendSms(
        to: cleanNumber,
        message: message,
      );

      await _logSms(recipient, message, SmsStatus.sent, '', loanId, customerId);
      return true;
    } catch (e) {
      await _logSms(recipient, message, SmsStatus.failed, e.toString(), loanId, customerId);
      return false;
    }
  }

  Future<void> _logSms(String recipient, String message, SmsStatus status, String error, int? loanId, int? customerId) async {
    await _smsLogDao.insert(SmsLog(
      loanId: loanId,
      customerId: customerId,
      recipient: recipient,
      message: message,
      status: status,
      sentAt: DateTime.now(),
      errorMessage: error,
    ));
  }

  // Generate collection reminder SMS
  String generateReminderMessage(String customerName, double amount, int daysOverdue) {
    if (daysOverdue > 0) {
      return 'Namaste $customerName, aapka daily collection ${daysOverdue} din pending hai. Amount: Rs ${amount.toStringAsFixed(0)}. Kripya jaldi pay karein. - Harish K Patidar';
    }
    return 'Namaste $customerName, aaj ka daily collection Rs ${amount.toStringAsFixed(0)} due hai. Kripya pay karein. - Harish K Patidar';
  }

  // Generate loan created SMS
  String generateLoanCreatedMessage(String customerName, double principal, double returnAmount, double dailyInstallment, int totalDays) {
    return 'Namaste $customerName, aapka loan approved hai. Principal: Rs ${principal.toStringAsFixed(0)}, Return Amount: Rs ${returnAmount.toStringAsFixed(0)}, Daily: Rs ${dailyInstallment.toStringAsFixed(0)}, Days: $totalDays. - Harish K Patidar';
  }

  // Generate pre-close SMS
  String generatePreCloseMessage(String customerName, double preCloseAmount) {
    return 'Namaste $customerName, aapka loan pre-close ho gaya hai. Final amount: Rs ${preCloseAmount.toStringAsFixed(0)}. Dhanyavaad! - Harish K Patidar';
  }

  // Generate WhatsApp message (same content, different delivery)
  String generateWhatsAppMessage(String customerName, double amount, {bool overdue = false}) {
    if (overdue) {
      return 'Namaste $customerName, aapka payment pending hai. Amount: Rs ${amount.toStringAsFixed(0)}. Kripya jaldi pay karein.';
    }
    return 'Namaste $customerName, aaj ka collection Rs ${amount.toStringAsFixed(0)} due hai. Kripya pay karein.';
  }

  Future<List<SmsLog>> getAllLogs() async {
    return await _smsLogDao.getAll();
  }

  Future<List<SmsLog>> getLogsByLoanId(int loanId) async {
    return await _smsLogDao.getByLoanId(loanId);
  }
}
