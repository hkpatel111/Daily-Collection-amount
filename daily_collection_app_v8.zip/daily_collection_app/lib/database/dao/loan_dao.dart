import '../database_helper.dart';
import '../../models/loan.dart';

class LoanDao {
  final DatabaseHelper _dbHelper = DatabaseHelper();

  Future<int> insert(Loan loan) async {
    final db = await _dbHelper.database;
    return await db.insert('loans', loan.toMap());
  }

  Future<Loan?> getById(int id) async {
    final db = await _dbHelper.database;
    final maps = await db.query('loans', where: 'id = ?', whereArgs: [id]);
    if (maps.isEmpty) return null;
    return Loan.fromMap(maps.first);
  }

  Future<List<Loan>> getAll({LoanStatus? statusFilter}) async {
    final db = await _dbHelper.database;
    List<Map<String, dynamic>> maps;
    if (statusFilter != null) {
      maps = await db.query('loans', where: 'status = ?', whereArgs: [statusFilter.index], orderBy: 'created_at DESC');
    } else {
      maps = await db.query('loans', orderBy: 'created_at DESC');
    }
    return maps.map((m) => Loan.fromMap(m)).toList();
  }

  Future<List<Loan>> getByCustomer(int customerId) async {
    final db = await _dbHelper.database;
    final maps = await db.query('loans', where: 'customer_id = ?', whereArgs: [customerId], orderBy: 'created_at DESC');
    return maps.map((m) => Loan.fromMap(m)).toList();
  }

  Future<List<Map<String, dynamic>>> getAllWithCustomer() async {
    final db = await _dbHelper.database;
    return await db.rawQuery('''
      SELECT l.*, c.name as customer_name, c.mobile as customer_mobile, c.nickname as customer_nickname
      FROM loans l
      INNER JOIN customers c ON l.customer_id = c.id
      ORDER BY l.created_at DESC
    ''');
  }

  Future<List<Map<String, dynamic>>> getByStatusWithCustomer(int statusIndex) async {
    final db = await _dbHelper.database;
    return await db.rawQuery('''
      SELECT l.*, c.name as customer_name, c.mobile as customer_mobile
      FROM loans l
      INNER JOIN customers c ON l.customer_id = c.id
      WHERE l.status = ?
      ORDER BY l.created_at DESC
    ''', [statusIndex]);
  }

  Future<List<Loan>> search(String query) async {
    final db = await _dbHelper.database;
    final maps = await db.rawQuery('''
      SELECT l.* FROM loans l
      INNER JOIN customers c ON l.customer_id = c.id
      WHERE c.name LIKE ? OR c.mobile LIKE ? OR l.account_name LIKE ? OR l.tag LIKE ? OR CAST(l.id AS TEXT) LIKE ?
      ORDER BY l.created_at DESC
    ''', ['%$query%', '%$query%', '%$query%', '%$query%', '%$query%']);
    return maps.map((m) => Loan.fromMap(m)).toList();
  }

  Future<int> update(Loan loan) async {
    final db = await _dbHelper.database;
    loan = loan.copyWith(updatedAt: DateTime.now());
    return await db.update('loans', loan.toMap(), where: 'id = ?', whereArgs: [loan.id]);
  }

  Future<int> delete(int id) async {
    final db = await _dbHelper.database;
    await db.delete('schedule_entries', where: 'loan_id = ?', whereArgs: [id]);
    await db.delete('collection_entries', where: 'loan_id = ?', whereArgs: [id]);
    return await db.delete('loans', where: 'id = ?', whereArgs: [id]);
  }

  Future<Map<String, double>> getAggregates() async {
    final db = await _dbHelper.database;
    final totalPrincipal = await db.rawQuery('SELECT COALESCE(SUM(principal), 0) as total FROM loans WHERE status != 5');
    final totalReturn = await db.rawQuery('SELECT COALESCE(SUM(return_amount), 0) as total FROM loans WHERE status != 5');
    final activeCount = await db.rawQuery('SELECT COUNT(*) as count FROM loans WHERE status = 0');
    final overdueCount = await db.rawQuery('SELECT COUNT(*) as count FROM loans WHERE status = 1');
    return {
      'totalPrincipal': (totalPrincipal.first['total'] as num).toDouble(),
      'totalReturn': (totalReturn.first['total'] as num).toDouble(),
      'activeCount': (activeCount.first['count'] as int).toDouble(),
      'overdueCount': (overdueCount.first['count'] as int).toDouble(),
    };
  }
}
