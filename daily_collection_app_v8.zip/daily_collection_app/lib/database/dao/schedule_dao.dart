import '../database_helper.dart';
import '../../models/schedule_entry.dart';

class ScheduleDao {
  final DatabaseHelper _dbHelper = DatabaseHelper();

  Future<int> insert(ScheduleEntry entry) async {
    final db = await _dbHelper.database;
    return await db.insert('schedule_entries', entry.toMap());
  }

  Future<void> batchInsert(List<ScheduleEntry> entries) async {
    final db = await _dbHelper.database;
    final batch = db.batch();
    for (final entry in entries) {
      batch.insert('schedule_entries', entry.toMap());
    }
    await batch.commit();
  }

  Future<ScheduleEntry?> getById(int id) async {
    final db = await _dbHelper.database;
    final maps = await db.query('schedule_entries', where: 'id = ?', whereArgs: [id]);
    if (maps.isEmpty) return null;
    return ScheduleEntry.fromMap(maps.first);
  }

  Future<List<ScheduleEntry>> getByLoan(int loanId) async {
    final db = await _dbHelper.database;
    final maps = await db.query('schedule_entries', where: 'loan_id = ?', whereArgs: [loanId], orderBy: 'entry_date ASC');
    return maps.map((m) => ScheduleEntry.fromMap(m)).toList();
  }

  Future<List<ScheduleEntry>> getByLoanFiltered(int loanId, {List<int>? statusIndexes}) async {
    final db = await _dbHelper.database;
    if (statusIndexes != null && statusIndexes.isNotEmpty) {
      final placeholders = statusIndexes.map((_) => '?').join(',');
      final maps = await db.query(
        'schedule_entries',
        where: 'loan_id = ? AND status IN ($placeholders)',
        whereArgs: [loanId, ...statusIndexes],
        orderBy: 'entry_date ASC',
      );
      return maps.map((m) => ScheduleEntry.fromMap(m)).toList();
    }
    return await getByLoan(loanId);
  }

  Future<List<ScheduleEntry>> getOverdueEntries(int loanId, DateTime beforeDate) async {
    final db = await _dbHelper.database;
    final maps = await db.query(
      'schedule_entries',
      where: 'loan_id = ? AND entry_date < ? AND status = ?',
      whereArgs: [loanId, beforeDate.toIso8601String(), ScheduleEntryStatus.pending.index],
      orderBy: 'entry_date ASC',
    );
    return maps.map((m) => ScheduleEntry.fromMap(m)).toList();
  }

  Future<int> update(ScheduleEntry entry) async {
    final db = await _dbHelper.database;
    return await db.update('schedule_entries', entry.toMap(), where: 'id = ?', whereArgs: [entry.id]);
  }

  Future<int> delete(int id) async {
    final db = await _dbHelper.database;
    return await db.delete('schedule_entries', where: 'id = ?', whereArgs: [id]);
  }

  Future<int> deleteByLoan(int loanId) async {
    final db = await _dbHelper.database;
    return await db.delete('schedule_entries', where: 'loan_id = ?', whereArgs: [loanId]);
  }

  Future<List<ScheduleEntry>> getPendingForDate(DateTime date) async {
    final db = await _dbHelper.database;
    final dateStr = DateTime(date.year, date.month, date.day).toIso8601String();
    final maps = await db.query(
      'schedule_entries',
      where: 'entry_date <= ? AND status IN (0, 3, 5)',
      whereArgs: [dateStr],
      orderBy: 'entry_date ASC',
    );
    return maps.map((m) => ScheduleEntry.fromMap(m)).toList();
  }
}
