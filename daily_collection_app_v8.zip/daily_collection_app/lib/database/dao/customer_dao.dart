import '../database_helper.dart';
import '../../models/customer.dart';

class CustomerDao {
  final DatabaseHelper _dbHelper = DatabaseHelper();

  Future<int> insert(Customer customer) async {
    final db = await _dbHelper.database;
    return await db.insert('customers', customer.toMap());
  }

  Future<Customer?> getById(int id) async {
    final db = await _dbHelper.database;
    final maps = await db.query('customers', where: 'id = ?', whereArgs: [id]);
    if (maps.isEmpty) return null;
    return Customer.fromMap(maps.first);
  }

  Future<List<Customer>> getAll({bool activeOnly = false}) async {
    final db = await _dbHelper.database;
    final maps = activeOnly
        ? await db.query('customers', where: 'is_active = 1', orderBy: 'name ASC')
        : await db.query('customers', orderBy: 'name ASC');
    return maps.map((m) => Customer.fromMap(m)).toList();
  }

  Future<List<Customer>> search(String query) async {
    final db = await _dbHelper.database;
    final maps = await db.query(
      'customers',
      where: 'name LIKE ? OR mobile LIKE ? OR nickname LIKE ?',
      whereArgs: ['%$query%', '%$query%', '%$query%'],
      orderBy: 'name ASC',
    );
    return maps.map((m) => Customer.fromMap(m)).toList();
  }

  Future<int> update(Customer customer) async {
    final db = await _dbHelper.database;
    customer = customer.copyWith(updatedAt: DateTime.now());
    return await db.update('customers', customer.toMap(), where: 'id = ?', whereArgs: [customer.id]);
  }

  Future<int> softDelete(int id) async {
    final db = await _dbHelper.database;
    return await db.update('customers', {'is_active': 0, 'updated_at': DateTime.now().toIso8601String()}, where: 'id = ?', whereArgs: [id]);
  }

  Future<int> permanentDelete(int id) async {
    final db = await _dbHelper.database;
    return await db.delete('customers', where: 'id = ?', whereArgs: [id]);
  }

  Future<int> count() async {
    final db = await _dbHelper.database;
    final result = await db.rawQuery('SELECT COUNT(*) as count FROM customers WHERE is_active = 1');
    return result.first['count'] as int;
  }
}
