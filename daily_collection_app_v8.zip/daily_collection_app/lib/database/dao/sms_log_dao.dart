import '../database_helper.dart';
import '../../models/sms_log.dart';

class SmsLogDao {
  final DatabaseHelper _dbHelper = DatabaseHelper();

  Future<int> insert(SmsLog log) async {
    final db = await _dbHelper.database;
    return await db.insert('sms_logs', log.toMap());
  }

  Future<List<Map<String, dynamic>>> getAll() async {
    final db = await _dbHelper.database;
    return await db.rawQuery('''
      SELECT s.*, c.name as customer_name, l.account_name as loan_name
      FROM sms_logs s
      LEFT JOIN customers c ON s.customer_id = c.id
      LEFT JOIN loans l ON s.loan_id = l.id
      ORDER BY s.sent_at DESC
    ''');
  }

  Future<List<Map<String, dynamic>>> getByLoan(int loanId) async {
    final db = await _dbHelper.database;
    return await db.rawQuery('''
      SELECT s.*, c.name as customer_name
      FROM sms_logs s
      LEFT JOIN customers c ON s.customer_id = c.id
      WHERE s.loan_id = ?
      ORDER BY s.sent_at DESC
    ''', [loanId]);
  }

  Future<List<Map<String, dynamic>>> getByCustomer(int customerId) async {
    final db = await _dbHelper.database;
    return await db.rawQuery('''
      SELECT s.*, l.account_name as loan_name
      FROM sms_logs s
      LEFT JOIN loans l ON s.loan_id = l.id
      WHERE s.customer_id = ?
      ORDER BY s.sent_at DESC
    ''', [customerId]);
  }
}
