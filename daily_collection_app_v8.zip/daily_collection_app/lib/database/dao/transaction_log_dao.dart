import '../database_helper.dart';
import '../../models/transaction_log.dart';

class TransactionLogDao {
  final DatabaseHelper _dbHelper = DatabaseHelper();

  Future<int> insert(TransactionLog log) async {
    final db = await _dbHelper.database;
    return await db.insert('transaction_logs', log.toMap());
  }

  Future<List<Map<String, dynamic>>> getAll() async {
    final db = await _dbHelper.database;
    return await db.rawQuery('''
      SELECT tl.*, c.name as customer_name
      FROM transaction_logs tl
      LEFT JOIN customers c ON tl.customer_id = c.id
      ORDER BY tl.timestamp DESC
    ''');
  }

  Future<List<Map<String, dynamic>>> search(String query) async {
    final db = await _dbHelper.database;
    return await db.rawQuery('''
      SELECT tl.*, c.name as customer_name
      FROM transaction_logs tl
      LEFT JOIN customers c ON tl.customer_id = c.id
      WHERE tl.action LIKE ? OR tl.description LIKE ? OR c.name LIKE ?
      ORDER BY tl.timestamp DESC
    ''', ['%$query%', '%$query%', '%$query%']);
  }

  Future<List<Map<String, dynamic>>> filter({String? action, int? customerId, int? loanId}) async {
    final db = await _dbHelper.database;
    final conditions = <String>[];
    final args = <dynamic>[];
    if (action != null) {
      conditions.add('tl.action = ?');
      args.add(action);
    }
    if (customerId != null) {
      conditions.add('tl.customer_id = ?');
      args.add(customerId);
    }
    if (loanId != null) {
      conditions.add('tl.loan_id = ?');
      args.add(loanId);
    }
    final where = conditions.isEmpty ? '' : 'WHERE ${conditions.join(' AND ')}';
    return await db.rawQuery('''
      SELECT tl.*, c.name as customer_name
      FROM transaction_logs tl
      LEFT JOIN customers c ON tl.customer_id = c.id
      $where
      ORDER BY tl.timestamp DESC
    ''', args);
  }
}
