import '../database_helper.dart';
import '../../models/settings.dart';

class SettingsDao {
  final DatabaseHelper _dbHelper = DatabaseHelper();

  Future<AppSettings> getSettings() async {
    final db = await _dbHelper.database;
    final maps = await db.query('settings', where: 'id = 1');
    if (maps.isEmpty) {
      final settings = AppSettings();
      await db.insert('settings', settings.toMap());
      return settings;
    }
    return AppSettings.fromMap(maps.first);
  }

  Future<int> update(AppSettings settings) async {
    final db = await _dbHelper.database;
    return await db.update('settings', settings.toMap(), where: 'id = 1');
  }
}
