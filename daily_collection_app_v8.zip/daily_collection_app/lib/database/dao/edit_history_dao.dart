import '../database_helper.dart';
import '../../models/edit_history.dart';

class EditHistoryDao {
  final DatabaseHelper _dbHelper = DatabaseHelper();

  Future<int> insert(EditHistory history) async {
    final db = await _dbHelper.database;
    return await db.insert('edit_history', history.toMap());
  }

  Future<List<EditHistory>> getByCollectionEntry(int collectionEntryId) async {
    final db = await _dbHelper.database;
    final maps = await db.query('edit_history', where: 'collection_entry_id = ?', whereArgs: [collectionEntryId], orderBy: 'edited_at DESC');
    return maps.map((m) => EditHistory.fromMap(m)).toList();
  }
}
