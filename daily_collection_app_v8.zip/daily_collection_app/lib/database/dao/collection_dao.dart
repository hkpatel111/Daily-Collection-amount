import '../database_helper.dart';
import '../../models/collection_entry.dart';

class CollectionDao {
  final DatabaseHelper _dbHelper = DatabaseHelper();

  Future<int> insert(CollectionEntry entry) async {
    final db = await _dbHelper.database;
    return await db.insert('collection_entries', entry.toMap());
  }

  Future<CollectionEntry?> getById(int id) async {
    final db = await _dbHelper.database;
    final maps = await db.query('collection_entries', where: 'id = ?', whereArgs: [id]);
    if (maps.isEmpty) return null;
    return CollectionEntry.fromMap(maps.first);
  }

  Future<List<CollectionEntry>> getByLoan(int loanId) async {
    final db = await _dbHelper.database;
    final maps = await db.query('collection_entries', where: 'loan_id = ?', whereArgs: [loanId], orderBy: 'collected_date DESC');
    return maps.map((m) => CollectionEntry.fromMap(m)).toList();
  }

  Future<List<Map<String, dynamic>>> getAllWithDetails() async {
    final db = await _dbHelper.database;
    return await db.rawQuery('''
      SELECT ce.*, c.name as customer_name, c.mobile as customer_mobile,
             l.account_name as loan_name, se.entry_date as schedule_date
      FROM collection_entries ce
      INNER JOIN customers c ON ce.customer_id = c.id
      INNER JOIN loans l ON ce.loan_id = l.id
      LEFT JOIN schedule_entries se ON ce.schedule_entry_id = se.id
      ORDER BY ce.collected_date DESC
    ''');
  }

  Future<List<Map<String, dynamic>>> getByLoanWithDetails(int loanId) async {
    final db = await _dbHelper.database;
    return await db.rawQuery('''
      SELECT ce.*, c.name as customer_name, se.entry_date as schedule_date, se.day_number
      FROM collection_entries ce
      INNER JOIN customers c ON ce.customer_id = c.id
      LEFT JOIN schedule_entries se ON ce.schedule_entry_id = se.id
      WHERE ce.loan_id = ?
      ORDER BY ce.collected_date DESC
    ''', [loanId]);
  }

  Future<int> update(CollectionEntry entry) async {
    final db = await _dbHelper.database;
    return await db.update('collection_entries', entry.toMap(), where: 'id = ?', whereArgs: [entry.id]);
  }

  Future<int> delete(int id) async {
    final db = await _dbHelper.database;
    return await db.delete('collection_entries', where: 'id = ?', whereArgs: [id]);
  }

  Future<double> getTotalCollected(int loanId) async {
    final db = await _dbHelper.database;
    final result = await db.rawQuery('SELECT COALESCE(SUM(amount), 0) as total FROM collection_entries WHERE loan_id = ?', [loanId]);
    return (result.first['total'] as num).toDouble();
  }

  Future<double> getTotalCollectedByDate(DateTime date) async {
    final db = await _dbHelper.database;
    final dateStr = DateTime(date.year, date.month, date.day).toIso8601String();
    final nextDay = DateTime(date.year, date.month, date.day).add(Duration(days: 1)).toIso8601String();
    final result = await db.rawQuery(
      'SELECT COALESCE(SUM(amount), 0) as total FROM collection_entries WHERE collected_date >= ? AND collected_date < ?',
      [dateStr, nextDay],
    );
    return (result.first['total'] as num).toDouble();
  }

  Future<List<Map<String, dynamic>>> getByDateWithDetails(DateTime date) async {
    final db = await _dbHelper.database;
    final dateStr = DateTime(date.year, date.month, date.day).toIso8601String();
    final nextDay = DateTime(date.year, date.month, date.day).add(Duration(days: 1)).toIso8601String();
    return await db.rawQuery('''
      SELECT ce.*, c.name as customer_name, c.mobile as customer_mobile, l.id as loan_id, l.account_name
      FROM collection_entries ce
      INNER JOIN customers c ON ce.customer_id = c.id
      INNER JOIN loans l ON ce.loan_id = l.id
      WHERE ce.collected_date >= ? AND ce.collected_date < ?
      ORDER BY ce.collected_date DESC
    ''', [dateStr, nextDay]);
  }
}
