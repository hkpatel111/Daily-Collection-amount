import 'package:sqflite/sqflite.dart';
import 'package:path/path.dart';

class DatabaseHelper {
  static final DatabaseHelper _instance = DatabaseHelper._internal();
  factory DatabaseHelper() => _instance;
  DatabaseHelper._internal();

  static const int _dbVersion = 4;
  static const String _dbName = 'daily_collection.db';

  Database? _db;

  Future<Database> get database async {
    _db ??= await _initDb();
    return _db!;
  }

  Future<Database> _initDb() async {
    final dbPath = await getDatabasesPath();
    final path = join(dbPath, _dbName);
    return await openDatabase(
      path,
      version: _dbVersion,
      onCreate: _onCreate,
      onUpgrade: _onUpgrade,
    );
  }

  Future<void> _onCreate(Database db, int version) async {
    await db.execute("""
      CREATE TABLE customers (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        name TEXT NOT NULL,
        mobile TEXT NOT NULL,
        nickname TEXT,
        photo_path TEXT,
        id_number TEXT,
        is_active INTEGER NOT NULL DEFAULT 1,
        created_at TEXT NOT NULL,
        updated_at TEXT NOT NULL
      )
    """);

    await db.execute("""
      CREATE TABLE loans (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        customer_id INTEGER NOT NULL,
        account_name TEXT DEFAULT '',
        tag TEXT,
        principal REAL NOT NULL,
        return_amount REAL NOT NULL,
        daily_installment REAL NOT NULL,
        start_date TEXT NOT NULL,
        total_days INTEGER NOT NULL,
        monthly_interest_rate REAL DEFAULT 0,
        interest_mode INTEGER DEFAULT 0,
        grace_period INTEGER DEFAULT 0,
        sunday_holiday_enabled INTEGER DEFAULT 0,
        late_fee_per_day REAL DEFAULT 0,
        late_fee_enabled INTEGER DEFAULT 0,
        excess_payment_mode TEXT DEFAULT 'separateEntry',
        status INTEGER NOT NULL DEFAULT 0,
        renewed_from_loan_id INTEGER,
        created_at TEXT NOT NULL,
        updated_at TEXT NOT NULL,
        FOREIGN KEY (customer_id) REFERENCES customers(id)
      )
    """);

    await db.execute("""
      CREATE TABLE schedule_entries (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        loan_id INTEGER NOT NULL,
        entry_date TEXT NOT NULL,
        expected_amount REAL NOT NULL,
        collected_amount REAL DEFAULT 0,
        status INTEGER NOT NULL DEFAULT 0,
        day_number INTEGER NOT NULL,
        is_sunday INTEGER DEFAULT 0,
        FOREIGN KEY (loan_id) REFERENCES loans(id)
      )
    """);

    await db.execute("""
      CREATE TABLE collection_entries (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        schedule_entry_id INTEGER NOT NULL,
        loan_id INTEGER NOT NULL,
        customer_id INTEGER NOT NULL,
        collected_date TEXT NOT NULL,
        amount REAL NOT NULL,
        payment_mode INTEGER DEFAULT 0,
        note TEXT,
        FOREIGN KEY (schedule_entry_id) REFERENCES schedule_entries(id),
        FOREIGN KEY (loan_id) REFERENCES loans(id),
        FOREIGN KEY (customer_id) REFERENCES customers(id)
      )
    """);

    await db.execute("""
      CREATE TABLE settings (
        id INTEGER PRIMARY KEY,
        is_dark_mode INTEGER DEFAULT 0,
        theme_color_index INTEGER DEFAULT 0,
        app_lock_enabled INTEGER DEFAULT 0,
        app_pin TEXT,
        security_question TEXT,
        security_answer TEXT,
        auto_backup_enabled INTEGER DEFAULT 0,
        auto_backup_interval_days INTEGER DEFAULT 7,
        backup_path TEXT,
        notification_enabled INTEGER DEFAULT 0,
        notification_time TEXT DEFAULT '09:00',
        reminder_sms_enabled INTEGER DEFAULT 0,
        reminder_sms_days INTEGER DEFAULT 1,
        sunday_holiday_default INTEGER DEFAULT 0,
        default_grace_period INTEGER DEFAULT 0,
        default_late_fee_per_day REAL DEFAULT 0,
        default_late_fee_enabled INTEGER DEFAULT 0,
        interest_display_mode INTEGER DEFAULT 1,
        currency_symbol TEXT DEFAULT '\u20B9',
        drive_backup_enabled INTEGER DEFAULT 0
      )
    """);

    await db.execute("""
      CREATE TABLE transaction_logs (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        customer_id INTEGER,
        loan_id INTEGER,
        collection_entry_id INTEGER,
        action TEXT NOT NULL,
        description TEXT NOT NULL,
        timestamp TEXT NOT NULL
      )
    """);

    await db.execute("""
      CREATE TABLE sms_logs (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        loan_id INTEGER,
        customer_id INTEGER,
        recipient TEXT NOT NULL,
        message TEXT NOT NULL,
        status INTEGER NOT NULL,
        sent_at TEXT NOT NULL
      )
    """);

    await db.execute("""
      CREATE TABLE edit_history (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        collection_entry_id INTEGER NOT NULL,
        field_name TEXT NOT NULL,
        old_value TEXT NOT NULL,
        new_value TEXT NOT NULL,
        edited_at TEXT NOT NULL,
        FOREIGN KEY (collection_entry_id) REFERENCES collection_entries(id)
      )
    """);

    await db.execute("""
      CREATE TABLE loan_templates (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        name TEXT NOT NULL,
        principal REAL NOT NULL,
        return_amount REAL NOT NULL,
        daily_installment REAL NOT NULL,
        total_days INTEGER NOT NULL,
        monthly_interest_rate REAL DEFAULT 0,
        interest_mode INTEGER DEFAULT 0,
        grace_period INTEGER DEFAULT 0,
        sunday_holiday_enabled INTEGER DEFAULT 0,
        late_fee_per_day REAL DEFAULT 0,
        late_fee_enabled INTEGER DEFAULT 0,
        excess_payment_mode TEXT DEFAULT 'separateEntry'
      )
    """);

    await db.insert('settings', {'id': 1});
  }

  Future<void> _onUpgrade(Database db, int oldVersion, int newVersion) async {
    if (oldVersion < 2) {
      await db.execute("ALTER TABLE customers ADD COLUMN nickname TEXT");
      await db.execute("ALTER TABLE loans ADD COLUMN account_name TEXT DEFAULT ''");
      await db.execute("ALTER TABLE loans ADD COLUMN tag TEXT");
    }
    if (oldVersion < 3) {
      await db.execute("ALTER TABLE loans ADD COLUMN grace_period INTEGER DEFAULT 0");
      await db.execute("ALTER TABLE loans ADD COLUMN sunday_holiday_enabled INTEGER DEFAULT 0");
      await db.execute("ALTER TABLE loans ADD COLUMN late_fee_per_day REAL DEFAULT 0");
      await db.execute("ALTER TABLE loans ADD COLUMN late_fee_enabled INTEGER DEFAULT 0");
      await db.execute("ALTER TABLE loans ADD COLUMN excess_payment_mode TEXT DEFAULT 'separateEntry'");
      await db.execute("ALTER TABLE settings ADD COLUMN reminder_sms_enabled INTEGER DEFAULT 0");
      await db.execute("ALTER TABLE settings ADD COLUMN reminder_sms_days INTEGER DEFAULT 1");
      await db.execute("ALTER TABLE settings ADD COLUMN sunday_holiday_default INTEGER DEFAULT 0");
      await db.execute("ALTER TABLE settings ADD COLUMN default_grace_period INTEGER DEFAULT 0");
      await db.execute("ALTER TABLE settings ADD COLUMN default_late_fee_per_day REAL DEFAULT 0");
      await db.execute("ALTER TABLE settings ADD COLUMN default_late_fee_enabled INTEGER DEFAULT 0");
    }
    if (oldVersion < 4) {
      await db.execute("ALTER TABLE customers ADD COLUMN photo_path TEXT");
      await db.execute("ALTER TABLE customers ADD COLUMN id_number TEXT");
      await db.execute("ALTER TABLE loans ADD COLUMN monthly_interest_rate REAL DEFAULT 0");
      await db.execute("ALTER TABLE loans ADD COLUMN interest_mode INTEGER DEFAULT 0");
      await db.execute("ALTER TABLE loans ADD COLUMN renewed_from_loan_id INTEGER");
      await db.execute("ALTER TABLE settings ADD COLUMN security_question TEXT");
      await db.execute("ALTER TABLE settings ADD COLUMN security_answer TEXT");
      await db.execute("ALTER TABLE settings ADD COLUMN auto_backup_enabled INTEGER DEFAULT 0");
      await db.execute("ALTER TABLE settings ADD COLUMN auto_backup_interval_days INTEGER DEFAULT 7");
      await db.execute("ALTER TABLE settings ADD COLUMN backup_path TEXT");
      await db.execute("ALTER TABLE settings ADD COLUMN notification_enabled INTEGER DEFAULT 0");
      await db.execute("ALTER TABLE settings ADD COLUMN notification_time TEXT DEFAULT '09:00'");
      await db.execute("ALTER TABLE settings ADD COLUMN interest_display_mode INTEGER DEFAULT 1");
      await db.execute("ALTER TABLE settings ADD COLUMN currency_symbol TEXT DEFAULT '\u20B9'");
      await db.execute("ALTER TABLE settings ADD COLUMN drive_backup_enabled INTEGER DEFAULT 0");
      await db.execute("""
        CREATE TABLE IF NOT EXISTS loan_templates (
          id INTEGER PRIMARY KEY AUTOINCREMENT,
          name TEXT NOT NULL,
          principal REAL NOT NULL,
          return_amount REAL NOT NULL,
          daily_installment REAL NOT NULL,
          total_days INTEGER NOT NULL,
          monthly_interest_rate REAL DEFAULT 0,
          interest_mode INTEGER DEFAULT 0,
          grace_period INTEGER DEFAULT 0,
          sunday_holiday_enabled INTEGER DEFAULT 0,
          late_fee_per_day REAL DEFAULT 0,
          late_fee_enabled INTEGER DEFAULT 0,
          excess_payment_mode TEXT DEFAULT 'separateEntry'
        )
      """);
    }
  }

  Future<void> close() async {
    await _db?.close();
    _db = null;
  }
}
