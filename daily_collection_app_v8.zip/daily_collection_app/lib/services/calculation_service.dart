import 'dart:math';
import 'package:intl/intl.dart';
import '../models/loan.dart';
import '../models/settings.dart';

class CalculationService {
  static String formatCurrency(double amount, {String symbol = '\u20B9'}) {
    final format = NumberFormat.currency(locale: 'en_IN', symbol: symbol);
    return format.format(amount);
  }

  static String formatCurrencyShort(double amount, {String symbol = '\u20B9'}) {
    if (amount >= 10000000) {
      return '$symbol${(amount / 10000000).toStringAsFixed(2)} Cr';
    } else if (amount >= 100000) {
      return '$symbol${(amount / 100000).toStringAsFixed(2)} L';
    } else if (amount >= 1000) {
      return '$symbol${(amount / 1000).toStringAsFixed(1)}K';
    }
    return '$symbol${amount.toStringAsFixed(0)}';
  }

  static String formatDate(DateTime date) {
    return DateFormat('dd/MM/yyyy').format(date);
  }

  static String formatDateTime(DateTime date) {
    return DateFormat('dd/MM/yyyy HH:mm').format(date);
  }

  static String formatTime(DateTime date) {
    return DateFormat('HH:mm').format(date);
  }

  // Custom pow with int exponent
  static double pow(double base, int exp) {
    double result = 1;
    for (int i = 0; i < exp; i++) {
      result *= base;
    }
    return result;
  }

  // Custom pow with double exponent (for Rate of Return etc)
  static double powDouble(double base, double exponent) {
    return dart_pow(base, exponent);
  }

  static double dart_pow(double base, double exponent) {
    return exp(exponent * log(base));
  }

  // ===== LOAN CALCULATIONS =====

  static int calcTotalDays(double returnAmount, double dailyInstallment) {
    if (dailyInstallment <= 0) return 0;
    return (returnAmount / dailyInstallment).ceil();
  }

  static double calcLastDayAdjusted(double returnAmount, double dailyInstallment, int totalDays) {
    if (totalDays <= 1) return returnAmount;
    return returnAmount - (dailyInstallment * (totalDays - 1));
  }

  static double calcProfit(double returnAmount, double principal) {
    return returnAmount - principal;
  }

  // Interest rates from fixed return model
  static double calcDailyInterestRate(double profit, double principal, int totalDays) {
    if (principal <= 0 || totalDays <= 0) return 0;
    return (profit / (principal * totalDays)) * 100;
  }

  static double calcMonthlyRate(double dailyRate) {
    return dailyRate * 30;
  }

  static double calcYearlyRate(double dailyRate) {
    return dailyRate * 365;
  }

  // ===== MONTHLY % MODE CALCULATIONS =====

  // Flat Monthly: total interest = principal * monthlyRate% * months
  static double calcFlatReturnAmount(double principal, double monthlyRatePercent, int months) {
    final interest = principal * (monthlyRatePercent / 100) * months;
    return principal + interest;
  }

  static double calcFlatMonthlyInterest(double principal, double monthlyRatePercent, int months) {
    return principal * (monthlyRatePercent / 100) * months;
  }

  // Reducing Balance (EMI style)
  static double calcEMI(double principal, double monthlyRatePercent, int months) {
    if (principal <= 0 || months <= 0) return 0;
    final r = monthlyRatePercent / 100 / 30; // daily rate from monthly
    if (r == 0) return principal / (months * 30);
    final n = months * 30; // total days
    return principal * r * powDouble(1 + r, n) / (powDouble(1 + r, n) - 1);
  }

  static double calcReducingReturnAmount(double principal, double monthlyRatePercent, int months) {
    final emi = calcEMI(principal, monthlyRatePercent, months);
    return emi * months * 30; // total payable = EMI * total days
  }

  // Interchangeable calculation: given any 2 of (principal, monthly%, tenure), calc the third
  static Map<String, double> calcInterchangeable({
    double? principal,
    double? monthlyRatePercent,
    int? months,
    double? dailyInstallment,
    double? returnAmount,
    InterestMode mode = InterestMode.flatMonthly,
  }) {
    double p = principal ?? 0;
    double rate = monthlyRatePercent ?? 0;
    int m = months ?? 0;
    double daily = dailyInstallment ?? 0;
    double ret = returnAmount ?? 0;

    if (mode == InterestMode.flatMonthly) {
      // Flat: ret = p + p * rate/100 * m
      if (p > 0 && rate > 0 && m > 0) {
        ret = calcFlatReturnAmount(p, rate, m);
      } else if (p > 0 && ret > 0 && m > 0) {
        rate = ((ret - p) / (p * m)) * 100;
      } else if (p > 0 && rate > 0 && ret > 0) {
        m = ((ret - p) / (p * rate / 100)).round();
      }
      if (ret > 0 && m > 0) {
        daily = ret / (m * 30);
      }
    } else if (mode == InterestMode.reducingBalance) {
      // Reducing: EMI based
      if (p > 0 && rate > 0 && m > 0) {
        ret = calcReducingReturnAmount(p, rate, m);
        daily = calcEMI(p, rate, m);
      } else if (p > 0 && daily > 0 && m > 0) {
        ret = daily * m * 30;
        // Calculate rate from EMI
      }
    } else {
      // Fixed return mode
      if (ret > 0 && daily > 0) {
        m = (ret / daily).round();
      } else if (ret > 0 && m > 0) {
        daily = ret / (m * 30);
      }
      if (p > 0 && ret > 0) {
        rate = calcMonthlyRate(calcDailyInterestRate(ret - p, p, m * 30));
      }
    }

    return {
      'principal': p,
      'monthlyRatePercent': rate,
      'months': m.toDouble(),
      'dailyInstallment': daily,
      'returnAmount': ret,
      'profit': ret - p,
    };
  }

  // ===== OVERDUE CALCULATIONS =====

  static double calcOverdueInterest(double overduePrincipal, double dailyRate, int daysOverdue, int gracePeriod) {
    if (daysOverdue <= gracePeriod) return 0;
    final effectiveDays = daysOverdue - gracePeriod;
    return (overduePrincipal * dailyRate / 100) * effectiveDays;
  }

  static double calcLateFee(int daysMissed, double lateFeePerDay, bool enabled) {
    if (!enabled) return 0;
    return daysMissed * lateFeePerDay;
  }

  // ===== OUTSTANDING SNAPSHOT =====

  static double calcOutstandingAtDate(Loan loan, double totalCollected, DateTime asOfDate) {
    final totalDays = loan.totalDays;
    final elapsedDays = asOfDate.difference(loan.startDate).inDays;
    
    if (elapsedDays >= totalDays) {
      return max(0, loan.returnAmount - totalCollected);
    }
    
    final expectedCollected = loan.dailyInstallment * elapsedDays;
    return max(0, expectedCollected - totalCollected);
  }

  static double calcOutstandingWithInterest(Loan loan, double totalCollected, DateTime asOfDate) {
    final baseOutstanding = calcOutstandingAtDate(loan, totalCollected, asOfDate);
    final overduePrincipal = loan.principal - (totalCollected - (loan.returnAmount - loan.principal));
    final daysOverdue = asOfDate.difference(loan.startDate.add(Duration(days: loan.totalDays))).inDays;
    final dailyRate = calcDailyInterestRate(loan.profit, loan.principal, loan.totalDays);
    final overdueInterest = calcOverdueInterest(max(0, overduePrincipal), dailyRate, max(0, daysOverdue), loan.gracePeriod);
    return baseOutstanding + overdueInterest + calcLateFee(max(0, daysOverdue), loan.lateFeePerDay, loan.lateFeeEnabled);
  }

  // ===== CREDIT SCORE =====

  static int calcCreditScore(int completedLoans, int overdueCount, int missedPayments) {
    int score = 50 + (completedLoans * 10) - (overdueCount * 15) - (missedPayments * 5);
    return score.clamp(0, 100);
  }

  // ===== RATE DISPLAY =====

  static String formatInterestRate(double dailyRate, InterestDisplayMode mode) {
    switch (mode) {
      case InterestDisplayMode.monthly:
        return '${calcMonthlyRate(dailyRate).toStringAsFixed(2)}% / month';
      case InterestDisplayMode.yearly:
        return '${calcYearlyRate(dailyRate).toStringAsFixed(2)}% / year';
      case InterestDisplayMode.daily:
        return '${dailyRate.toStringAsFixed(4)}% / day';
    }
  }

  static String formatInterestRateMonthly(double monthlyRate) {
    return '${monthlyRate.toStringAsFixed(2)}% / month';
  }

  static String formatInterestRateYearly(double yearlyRate) {
    return '${yearlyRate.toStringAsFixed(2)}% / year';
  }

  static double monthlyToYearly(double monthlyRate) {
    return monthlyRate * 12;
  }

  static double yearlyToMonthly(double yearlyRate) {
    return yearlyRate / 12;
  }

  // ===== 10 CALCULATORS (all live) =====

  // 1. Daily Collection Calculator
  static Map<String, dynamic> calcDailyCollection({
    required double principal,
    required double dailyInstallment,
    required int days,
    double? monthlyRate,
  }) {
    double returnAmount;
    if (monthlyRate != null && monthlyRate > 0) {
      final months = days / 30;
      returnAmount = calcFlatReturnAmount(principal, monthlyRate, months.ceil());
    } else {
      returnAmount = dailyInstallment * days;
    }
    return {
      'principal': principal,
      'dailyInstallment': dailyInstallment,
      'days': days,
      'returnAmount': returnAmount,
      'profit': returnAmount - principal,
      'dailyRate': calcDailyInterestRate(returnAmount - principal, principal, days),
      'monthlyRate': calcMonthlyRate(calcDailyInterestRate(returnAmount - principal, principal, days)),
      'yearlyRate': calcYearlyRate(calcDailyInterestRate(returnAmount - principal, principal, days)),
    };
  }

  // 2. EMI Calculator
  static Map<String, dynamic> calcEMICalculator({
    required double principal,
    required double annualRate,
    required int tenureMonths,
    bool isMonthlyRate = false,
  }) {
    final r = isMonthlyRate
        ? annualRate / 100
        : annualRate / 100 / 12;
    final n = tenureMonths;
    double emi;
    if (r == 0) {
      emi = principal / n;
    } else {
      emi = principal * r * powDouble(1 + r, n) / (powDouble(1 + r, n) - 1);
    }
    final totalPayment = emi * n;
    final totalInterest = totalPayment - principal;
    return {
      'principal': principal,
      'emi': emi,
      'totalPayment': totalPayment,
      'totalInterest': totalInterest,
      'monthlyRate': isMonthlyRate ? annualRate : yearlyToMonthly(annualRate),
      'yearlyRate': isMonthlyRate ? monthlyToYearly(annualRate) : annualRate,
    };
  }

  // 3. SIP Calculator
  static Map<String, dynamic> calcSIP({
    required double monthlyInvestment,
    required double annualRate,
    required int years,
    bool isMonthlyRate = false,
  }) {
    final r = isMonthlyRate
        ? annualRate / 100
        : annualRate / 100 / 12;
    final n = years * 12;
    final maturity = monthlyInvestment * (powDouble(1 + r, n) - 1) / r * (1 + r);
    final totalInvested = monthlyInvestment * n;
    final totalGain = maturity - totalInvested;
    return {
      'monthlyInvestment': monthlyInvestment,
      'maturity': maturity,
      'totalInvested': totalInvested,
      'totalGain': totalGain,
      'monthlyRate': isMonthlyRate ? annualRate : yearlyToMonthly(annualRate),
      'yearlyRate': isMonthlyRate ? monthlyToYearly(annualRate) : annualRate,
    };
  }

  // 4. Future Value Calculator
  static Map<String, dynamic> calcFutureValue({
    required double presentValue,
    required double annualRate,
    required int years,
    bool isMonthlyRate = false,
  }) {
    final effectiveAnnualRate = isMonthlyRate ? monthlyToYearly(annualRate) : annualRate;
    final r = effectiveAnnualRate / 100;
    final fv = presentValue * powDouble(1 + r, years);
    return {
      'presentValue': presentValue,
      'futureValue': fv,
      'totalGain': fv - presentValue,
      'monthlyRate': isMonthlyRate ? annualRate : yearlyToMonthly(annualRate),
      'yearlyRate': effectiveAnnualRate,
    };
  }

  // 5. Rate of Return Calculator
  static Map<String, dynamic> calcRateOfReturn({
    required double presentValue,
    required double futureValue,
    required int years,
  }) {
    if (presentValue <= 0 || years <= 0) {
      return {'rate': 0.0, 'monthlyRate': 0.0, 'yearlyRate': 0.0};
    }
    final rate = (powDouble(futureValue / presentValue, 1.0 / years) - 1) * 100;
    return {
      'rate': rate,
      'monthlyRate': rate / 12,
      'yearlyRate': rate,
    };
  }

  // 6. Home Loan Calculator
  static Map<String, dynamic> calcHomeLoan({
    required double principal,
    required double annualRate,
    required int tenureYears,
    bool isMonthlyRate = false,
  }) {
    final tenureMonths = tenureYears * 12;
    return calcEMICalculator(
      principal: principal,
      annualRate: annualRate,
      tenureMonths: tenureMonths,
      isMonthlyRate: isMonthlyRate,
    );
  }

  // 7. Simple Interest Calculator
  static Map<String, dynamic> calcSimpleInterest({
    required double principal,
    required double rate,
    required int time,
    bool isMonthlyRate = false,
    bool isMonths = false,
  }) {
    final effectiveYearlyRate = isMonthlyRate ? monthlyToYearly(rate) : rate;
    final effectiveYears = isMonths ? time / 12 : time.toDouble();
    final interest = principal * effectiveYearlyRate / 100 * effectiveYears;
    return {
      'principal': principal,
      'interest': interest,
      'totalAmount': principal + interest,
      'monthlyRate': isMonthlyRate ? rate : yearlyToMonthly(effectiveYearlyRate),
      'yearlyRate': effectiveYearlyRate,
    };
  }

  // 8. Compound Interest Calculator
  static Map<String, dynamic> calcCompoundInterest({
    required double principal,
    required double rate,
    required int time,
    int compoundingPerYear = 4,
    bool isMonthlyRate = false,
    bool isMonths = false,
  }) {
    final effectiveYearlyRate = isMonthlyRate ? monthlyToYearly(rate) : rate;
    final effectiveYears = isMonths ? time / 12 : time.toDouble();
    final r = effectiveYearlyRate / 100;
    final n = compoundingPerYear;
    final amount = principal * powDouble(1 + r / n, n * effectiveYears);
    return {
      'principal': principal,
      'amount': amount,
      'interest': amount - principal,
      'monthlyRate': isMonthlyRate ? rate : yearlyToMonthly(effectiveYearlyRate),
      'yearlyRate': effectiveYearlyRate,
    };
  }

  // 9. Profit Margin Calculator
  static Map<String, dynamic> calcProfitMargin({
    required double revenue,
    required double cost,
  }) {
    final profit = revenue - cost;
    final margin = revenue > 0 ? (profit / revenue) * 100 : 0;
    final markup = cost > 0 ? (profit / cost) * 100 : 0;
    return {
      'revenue': revenue,
      'cost': cost,
      'profit': profit,
      'marginPercent': margin,
      'markupPercent': markup,
    };
  }

  // 10. Loan Comparison Calculator
  static List<Map<String, dynamic>> calcLoanComparison({
    required double principal,
    required List<double> rates,
    required List<int> tenures,
    bool isMonthlyRate = false,
  }) {
    final results = <Map<String, dynamic>>[];
    for (int i = 0; i < rates.length; i++) {
      final rate = rates[i];
      final tenure = tenures[i];
      final result = calcEMICalculator(
        principal: principal,
        annualRate: rate,
        tenureMonths: tenure,
        isMonthlyRate: isMonthlyRate,
      );
      results.add({
        'option': i + 1,
        'rate': rate,
        'tenure': tenure,
        ...result,
      });
    }
    return results;
  }

  // Loan completion percentage
  static double calcCompletionPercent(int completedDays, int totalDays) {
    if (totalDays <= 0) return 0;
    return (completedDays / totalDays) * 100;
  }

  // Days remaining
  static int calcDaysRemaining(DateTime startDate, int totalDays) {
    final endDate = startDate.add(Duration(days: totalDays));
    final remaining = endDate.difference(DateTime.now()).inDays;
    return remaining > 0 ? remaining : 0;
  }
}
