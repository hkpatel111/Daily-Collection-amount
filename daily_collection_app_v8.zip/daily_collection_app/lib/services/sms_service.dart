import 'dart:async';
import 'package:telephony/telephony.dart';
import '../models/loan.dart';
import '../models/customer.dart';
import '../models/collection_entry.dart';
import '../database/dao/sms_log_dao.dart';
import '../models/sms_log.dart';
import 'calculation_service.dart';

class SmsService {
  final Telephony _telephony = Telephony.instance;
  final SmsLogDao _smsLogDao = SmsLogDao();

  Future<bool> requestPermissions() async {
    final granted = await _telephony.requestSmsPermissions;
    return granted ?? false;
  }

  Future<bool> sendSms({
    required String to,
    required String message,
    int? loanId,
    int? customerId,
  }) async {
    try {
      final success = await _telephony.sendSms(
        to: to,
        message: message,
        isMultipart: true,
      );

      await _smsLogDao.insert(SmsLog(
        loanId: loanId,
        customerId: customerId,
        recipient: to,
        message: message,
        status: success == SmsSendStatus.SUCCESS ? SmsStatus.sent : SmsStatus.failed,
      ));

      return success == SmsSendStatus.SUCCESS;
    } catch (e) {
      await _smsLogDao.insert(SmsLog(
        loanId: loanId,
        customerId: customerId,
        recipient: to,
        message: message,
        status: SmsStatus.failed,
      ));
      return false;
    }
  }

  String buildPaymentReceipt({
    required Customer customer,
    required Loan loan,
    required CollectionEntry collection,
    required int dayNumber,
    required double totalCollected,
    required double remaining,
  }) {
    final sb = StringBuffer();
    sb.writeln('=== Payment Receipt ===');
    sb.writeln('Created by Harish');
    sb.writeln('Date: ${CalculationService.formatDateTime(collection.collectedDate)}');
    sb.writeln('Customer: ${customer.name}');
    sb.writeln('Mobile: ${customer.mobile}');
    sb.writeln('Loan ID: #${loan.id}');
    if (loan.accountName.isNotEmpty) sb.writeln('Account: ${loan.accountName}');
    sb.writeln('---');
    sb.writeln('Day: $dayNumber/${loan.totalDays}');
    sb.writeln('Collected: ${CalculationService.formatCurrency(collection.amount)}');
    sb.writeln('Payment Mode: ${collection.paymentMode.name.toUpperCase()}');
    sb.writeln('---');
    sb.writeln('Total Collected: ${CalculationService.formatCurrency(totalCollected)}');
    sb.writeln('Remaining: ${CalculationService.formatCurrency(remaining)}');
    sb.writeln('Return Amount: ${CalculationService.formatCurrency(loan.returnAmount)}');
    sb.writeln('---');
    sb.writeln('Thank you!');
    return sb.toString();
  }

  String buildMissedReminder({
    required Customer customer,
    required Loan loan,
    required int daysMissed,
    required double lateFee,
  }) {
    final sb = StringBuffer();
    sb.writeln('Dear ${customer.name},');
    sb.writeln('Your loan #${loan.id} payment is overdue.');
    sb.writeln('Days Missed: $daysMissed');
    if (lateFee > 0) sb.writeln('Late Fee: ${CalculationService.formatCurrency(lateFee)}');
    sb.writeln('Daily Installment: ${CalculationService.formatCurrency(loan.dailyInstallment)}');
    sb.writeln('Please pay soon to avoid extra charges.');
    sb.writeln('- Daily Collection App');
    return sb.toString();
  }

  String buildSummary({
    required Customer customer,
    required Loan loan,
    required double totalCollected,
    required double remaining,
    required int paidDays,
  }) {
    final sb = StringBuffer();
    sb.writeln('=== Loan Summary ===');
    sb.writeln('Created by Harish');
    sb.writeln('Customer: ${customer.name}');
    sb.writeln('Loan ID: #${loan.id}');
    sb.writeln('Principal: ${CalculationService.formatCurrency(loan.principal)}');
    sb.writeln('Return Amount: ${CalculationService.formatCurrency(loan.returnAmount)}');
    sb.writeln('Daily Installment: ${CalculationService.formatCurrency(loan.dailyInstallment)}');
    sb.writeln('---');
    sb.writeln('Paid Days: $paidDays/${loan.totalDays}');
    sb.writeln('Total Collected: ${CalculationService.formatCurrency(totalCollected)}');
    sb.writeln('Remaining: ${CalculationService.formatCurrency(remaining)}');
    sb.writeln('Completion: ${(paidDays / loan.totalDays * 100).toStringAsFixed(1)}%');
    sb.writeln('---');
    final dailyRate = CalculationService.calcDailyInterestRate(loan.profit, loan.principal, loan.totalDays);
    sb.writeln('Monthly Rate: ${CalculationService.calcMonthlyRate(dailyRate).toStringAsFixed(2)}%');
    sb.writeln('- Daily Collection App');
    return sb.toString();
  }

  String buildCompletionMessage({
    required Customer customer,
    required Loan loan,
    required double totalCollected,
  }) {
    final sb = StringBuffer();
    sb.writeln('=== Loan Completed ===');
    sb.writeln('Congratulations ${customer.name}!');
    sb.writeln('Your loan #${loan.id} has been fully paid.');
    sb.writeln('Total Paid: ${CalculationService.formatCurrency(totalCollected)}');
    sb.writeln('Principal: ${CalculationService.formatCurrency(loan.principal)}');
    sb.writeln('Profit: ${CalculationService.formatCurrency(loan.profit)}');
    sb.writeln('Thank you for your business!');
    sb.writeln('- Daily Collection App');
    return sb.toString();
  }

  String buildPreClosureMessage({
    required Customer customer,
    required Loan loan,
    required double payableAmount,
  }) {
    final sb = StringBuffer();
    sb.writeln('=== Pre-Closure ===');
    sb.writeln('Customer: ${customer.name}');
    sb.writeln('Loan #${loan.id} has been pre-closed.');
    sb.writeln('Payable Amount: ${CalculationService.formatCurrency(payableAmount)}');
    sb.writeln('- Daily Collection App');
    return sb.toString();
  }

  String buildReminderMessage({
    required Customer customer,
    required Loan loan,
    required double amount,
  }) {
    final sb = StringBuffer();
    sb.writeln('Dear ${customer.name},');
    sb.writeln('Reminder: Your payment of ${CalculationService.formatCurrency(amount)}');
    sb.writeln('for loan #${loan.id} is due today.');
    sb.writeln('Please pay on time. Thank you.');
    sb.writeln('- Daily Collection App');
    return sb.toString();
  }

  String buildDailySummary({
    required DateTime date,
    required double totalCollected,
    required int entryCount,
    required List<Map<String, dynamic>> collections,
  }) {
    final sb = StringBuffer();
    sb.writeln('=== Daily Collection Summary ===');
    sb.writeln('Date: ${CalculationService.formatDate(date)}');
    sb.writeln('Created by Harish');
    sb.writeln('Total Collected: ${CalculationService.formatCurrency(totalCollected)}');
    sb.writeln('Total Entries: $entryCount');
    sb.writeln('---');
    for (final c in collections) {
      sb.writeln('${c['customer_name']}: ${CalculationService.formatCurrency((c['amount'] as num).toDouble())}');
    }
    sb.writeln('---');
    sb.writeln('- Daily Collection App');
    return sb.toString();
  }
}
