import 'package:flutter_local_notifications/flutter_local_notifications.dart';
import '../database/dao/loan_dao.dart';
import '../database/dao/schedule_dao.dart';
import '../database/dao/settings_dao.dart';
import '../models/loan.dart';
import '../models/schedule_entry.dart';
import '../models/settings.dart';

class NotificationService {
  static final FlutterLocalNotificationsPlugin _notifications = FlutterLocalNotificationsPlugin();
  static bool _initialized = false;

  final LoanDao _loanDao = LoanDao();
  final ScheduleDao _scheduleDao = ScheduleDao();
  final SettingsDao _settingsDao = SettingsDao();

  Future<void> init() async {
    if (_initialized) return;
    const androidSettings = AndroidInitializationSettings('@mipmap/ic_launcher');
    const iosSettings = DarwinInitializationSettings();
    const settings = InitializationSettings(android: androidSettings, iOS: iosSettings);
    await _notifications.initialize(settings);
    _initialized = true;
  }

  Future<void> scheduleDailyReminder() async {
    final settings = await _settingsDao.getSettings();
    if (!settings.notificationEnabled) return;

    await cancelDailyReminder();

    final parts = settings.notificationTime.split(':');
    final hour = int.tryParse(parts[0]) ?? 9;
    final minute = int.tryParse(parts[1]) ?? 0;

    final androidDetails = AndroidNotificationDetails(
      'daily_collection_reminder',
      'Daily Collection Reminder',
      channelName: 'Daily Collection Reminder',
      importance: Importance.high,
      priority: Priority.high,
    );
    const iosDetails = DarwinNotificationDetails();
    final details = NotificationDetails(android: androidDetails, iOS: iosDetails);

    final now = DateTime.now();
    var scheduledTime = DateTime(now.year, now.month, now.day, hour, minute);
    if (scheduledTime.isBefore(now)) {
      scheduledTime = scheduledTime.add(const Duration(days: 1));
    }

    await _notifications.zonedScheduleDailyAtTimeFallback(
      title: 'Daily Collection Reminder',
      body: 'Check today pending collections',
      hour: hour,
      minute: minute,
      details: details,
    );
  }

  Future<void> cancelDailyReminder() async {
    await _notifications.cancel(0);
  }

  Future<void> showNotification({required String title, required String body, int id = 0}) async {
    await init();
    const androidDetails = AndroidNotificationDetails(
      'daily_collection_alerts',
      'Collection Alerts',
      channelName: 'Collection Alerts',
      importance: Importance.high,
      priority: Priority.high,
    );
    const iosDetails = DarwinNotificationDetails();
    const details = NotificationDetails(android: androidDetails, iOS: iosDetails);
    await _notifications.show(id, title, body, details);
  }

  // ===== DASHBOARD ALERTS =====

  Future<List<Map<String, dynamic>>> getDashboardAlerts() async {
    final alerts = <Map<String, dynamic>>[];
    final loans = await _loanDao.getAll();
    final today = DateTime.now();
    final todayDate = DateTime(today.year, today.month, today.day);

    int overdueCount = 0;
    int missedCount = 0;
    int pendingTodayCount = 0;
    int completedCount = 0;
    int defaultedCount = 0;

    for (final loan in loans) {
      switch (loan.status) {
        case LoanStatus.overdue:
          overdueCount++;
          break;
        case LoanStatus.completed:
          completedCount++;
          break;
        case LoanStatus.defaulted:
          defaultedCount++;
          break;
        case LoanStatus.cancelled:
        case LoanStatus.preClosed:
          break;
        case LoanStatus.active:
          break;
      }
    }

    final pendingEntries = await _scheduleDao.getPendingForDate(todayDate);
    pendingTodayCount = pendingEntries.where((e) => e.status == ScheduleEntryStatus.pending && !e.isSunday).length;

    for (final loan in loans) {
      if (loan.status == LoanStatus.active || loan.status == LoanStatus.overdue) {
        final overdueEntries = await _scheduleDao.getOverdueEntries(loan.id!, todayDate);
        for (final entry in overdueEntries) {
          if (entry.status == ScheduleEntryStatus.overdue) {
            missedCount++;
          }
        }
      }
    }

    if (overdueCount > 0) {
      alerts.add({
        'type': 'overdue',
        'title': 'Overdue Loans',
        'count': overdueCount,
        'color': 0xFFE53935,
        'icon': 'warning',
      });
    }

    if (missedCount > 0) {
      alerts.add({
        'type': 'missed',
        'title': 'Missed Collections',
        'count': missedCount,
        'color': 0xFFFF9800,
        'icon': 'error',
      });
    }

    if (pendingTodayCount > 0) {
      alerts.add({
        'type': 'pending_today',
        'title': 'Pending Today',
        'count': pendingTodayCount,
        'color': 0xFF2196F3,
        'icon': 'schedule',
      });
    }

    if (completedCount > 0) {
      alerts.add({
        'type': 'completed',
        'title': 'Completed Loans',
        'count': completedCount,
        'color': 0xFF4CAF50,
        'icon': 'check_circle',
      });
    }

    if (defaultedCount > 0) {
      alerts.add({
        'type': 'defaulted',
        'title': 'Defaulted Loans',
        'count': defaultedCount,
        'color': 0xFF9E9E9E,
        'icon': 'cancel',
      });
    }

    return alerts;
  }
}

extension on FlutterLocalNotificationsPlugin {
  Future<void> zonedScheduleDailyAtTimeFallback({
    required String title,
    required String body,
    required int hour,
    required int minute,
    required NotificationDetails details,
  }) async {
    final now = DateTime.now();
    var scheduled = DateTime(now.year, now.month, now.day, hour, minute);
    while (scheduled.isBefore(now)) {
      scheduled = scheduled.add(const Duration(days: 1));
    }
    final delay = scheduled.difference(now);
    await Future.delayed(delay);
    await show(0, title, body, details);
  }
}
