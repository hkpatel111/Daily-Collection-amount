import '../models/loan.dart';
import '../models/schedule_entry.dart';
import '../models/collection_entry.dart';
import '../models/transaction_log.dart';
import '../models/edit_history.dart';
import '../database/dao/loan_dao.dart';
import '../database/dao/schedule_dao.dart';
import '../database/dao/collection_dao.dart';
import '../database/dao/transaction_log_dao.dart';
import '../database/dao/edit_history_dao.dart';
import 'calculation_service.dart';

class ScheduleService {
  final LoanDao _loanDao = LoanDao();
  final ScheduleDao _scheduleDao = ScheduleDao();
  final CollectionDao _collectionDao = CollectionDao();
  final TransactionLogDao _logDao = TransactionLogDao();
  final EditHistoryDao _editHistoryDao = EditHistoryDao();

  Future<void> generateSchedule(Loan loan) async {
    final entries = <ScheduleEntry>[];
    DateTime currentDate = loan.startDate;
    int dayNum = 0;
    int addedDays = 0;

    while (addedDays < loan.totalDays) {
      final isSunday = currentDate.weekday == DateTime.sunday;
      double expectedAmount;

      if (addedDays == loan.totalDays - 1) {
        expectedAmount = CalculationService.calcLastDayAdjusted(
          loan.returnAmount, loan.dailyInstallment, loan.totalDays,
        );
      } else {
        expectedAmount = loan.dailyInstallment;
      }

      ScheduleEntryStatus status = ScheduleEntryStatus.pending;
      if (isSunday && loan.sundayHolidayEnabled) {
        status = ScheduleEntryStatus.holiday;
      }

      entries.add(ScheduleEntry(
        loanId: loan.id!,
        entryDate: DateTime(currentDate.year, currentDate.month, currentDate.day),
        expectedAmount: expectedAmount,
        status: status,
        dayNumber: dayNum + 1,
        isSunday: isSunday,
      ));

      currentDate = currentDate.add(const Duration(days: 1));
      addedDays++;
      dayNum++;
    }

    await _scheduleDao.batchInsert(entries);
  }

  Future<void> recordCollection({
    required ScheduleEntry entry,
    required double amount,
    required PaymentMode paymentMode,
    String? note,
    required int customerId,
  }) async {
    entry.collectedAmount = amount;
    
    if (amount >= entry.expectedAmount) {
      entry.status = ScheduleEntryStatus.paid;
    } else if (amount > 0) {
      entry.status = ScheduleEntryStatus.partial;
    }

    await _scheduleDao.update(entry);

    final collection = CollectionEntry(
      scheduleEntryId: entry.id!,
      loanId: entry.loanId,
      customerId: customerId,
      collectedDate: DateTime.now(),
      amount: amount,
      paymentMode: paymentMode,
      note: note,
    );
    await _collectionDao.insert(collection);

    await _logDao.insert(TransactionLog(
      customerId: customerId,
      loanId: entry.loanId,
      collectionEntryId: collection.id,
      action: 'COLLECTION',
      description: 'Rs. $amount collected for day ${entry.dayNumber}',
    ));

    // Check if loan is completed
    await _checkLoanCompletion(entry.loanId);
  }

  Future<void> editCollection({
    required CollectionEntry entry,
    required double newAmount,
    required PaymentMode newPaymentMode,
    String? newNote,
  }) async {
    final oldAmount = entry.amount;
    final oldMode = entry.paymentMode;

    // Record edit history
    if (oldAmount != newAmount) {
      await _editHistoryDao.insert(EditHistory(
        collectionEntryId: entry.id!,
        fieldName: 'amount',
        oldValue: oldAmount.toString(),
        newValue: newAmount.toString(),
      ));
    }
    if (oldMode != newPaymentMode) {
      await _editHistoryDao.insert(EditHistory(
        collectionEntryId: entry.id!,
        fieldName: 'payment_mode',
        oldValue: oldMode.name,
        newValue: newPaymentMode.name,
      ));
    }

    // Update collection entry
    entry.amount = newAmount;
    entry.paymentMode = newPaymentMode;
    entry.note = newNote;
    await _collectionDao.update(entry);

    // Update schedule entry
    final scheduleEntry = await _scheduleDao.getById(entry.scheduleEntryId);
    if (scheduleEntry != null) {
      scheduleEntry.collectedAmount = newAmount;
      if (newAmount >= scheduleEntry.expectedAmount) {
        scheduleEntry.status = ScheduleEntryStatus.paid;
      } else if (newAmount > 0) {
        scheduleEntry.status = ScheduleEntryStatus.partial;
      } else {
        scheduleEntry.status = ScheduleEntryStatus.pending;
      }
      await _scheduleDao.update(scheduleEntry);
    }

    await _logDao.insert(TransactionLog(
      customerId: entry.customerId,
      loanId: entry.loanId,
      collectionEntryId: entry.id,
      action: 'EDIT',
      description: 'Collection edited from Rs. $oldAmount to Rs. $newAmount',
    ));
  }

  Future<void> deleteCollection(CollectionEntry entry) async {
    final scheduleEntry = await _scheduleDao.getById(entry.scheduleEntryId);
    if (scheduleEntry != null) {
      scheduleEntry.collectedAmount = 0;
      scheduleEntry.status = ScheduleEntryStatus.pending;
      await _scheduleDao.update(scheduleEntry);
    }

    await _collectionDao.delete(entry.id!);

    await _logDao.insert(TransactionLog(
      customerId: entry.customerId,
      loanId: entry.loanId,
      action: 'DELETE',
      description: 'Collection of Rs. ${entry.amount} deleted',
    ));
  }

  Future<void> preCloseLoan(int loanId, double payableAmount, int customerId) async {
    final loan = await _loanDao.getById(loanId);
    if (loan == null) return;

    loan.status = LoanStatus.preClosed;
    await _loanDao.update(loan);

    await _logDao.insert(TransactionLog(
      customerId: customerId,
      loanId: loanId,
      action: 'PRE_CLOSE',
      description: 'Loan pre-closed with payable amount Rs. $payableAmount',
    ));
  }

  Future<void> cancelLoan(int loanId, int customerId) async {
    final loan = await _loanDao.getById(loanId);
    if (loan == null) return;

    loan.status = LoanStatus.cancelled;
    await _loanDao.update(loan);

    await _logDao.insert(TransactionLog(
      customerId: customerId,
      loanId: loanId,
      action: 'CANCEL',
      description: 'Loan cancelled',
    ));
  }

  Future<void> updateOverdueStatus(int loanId) async {
    final loan = await _loanDao.getById(loanId);
    if (loan == null) return;
    if (loan.status != LoanStatus.active && loan.status != LoanStatus.overdue) return;

    final now = DateTime.now();
    final overdueEntries = await _scheduleDao.getOverdueEntries(loanId, now);

    for (final entry in overdueEntries) {
      if (entry.status == ScheduleEntryStatus.pending) {
        entry.status = ScheduleEntryStatus.overdue;
        await _scheduleDao.update(entry);
      }
    }

    if (overdueEntries.isNotEmpty) {
      loan.status = LoanStatus.overdue;
    } else {
      loan.status = LoanStatus.active;
    }
    await _loanDao.update(loan);
  }

  Future<void> _checkLoanCompletion(int loanId) async {
    final loan = await _loanDao.getById(loanId);
    if (loan == null) return;
    if (loan.status != LoanStatus.active && loan.status != LoanStatus.overdue) return;

    final entries = await _scheduleDao.getByLoan(loanId);
    final nonHolidayEntries = entries.where((e) => !e.isHoliday).toList();
    final allPaid = nonHolidayEntries.every((e) => e.isPaid);

    if (allPaid) {
      loan.status = LoanStatus.completed;
      await _loanDao.update(loan);

      await _logDao.insert(TransactionLog(
        loanId: loanId,
        action: 'COMPLETE',
        description: 'Loan completed successfully',
      ));
    }
  }

  List<ScheduleEntry> sortEntries(List<ScheduleEntry> entries, ScheduleSortOrder order) {
    final sorted = List<ScheduleEntry>.from(entries);
    switch (order) {
      case ScheduleSortOrder.newToOld:
        sorted.sort((a, b) => b.entryDate.compareTo(a.entryDate));
        break;
      case ScheduleSortOrder.oldToNew:
        sorted.sort((a, b) => a.entryDate.compareTo(b.entryDate));
        break;
      case ScheduleSortOrder.paidFirst:
        sorted.sort((a, b) {
          if (a.isPaid && !b.isPaid) return -1;
          if (!a.isPaid && b.isPaid) return 1;
          return a.entryDate.compareTo(b.entryDate);
        });
        break;
      case ScheduleSortOrder.unpaidFirst:
        sorted.sort((a, b) {
          if (!a.isPaid && b.isPaid) return -1;
          if (a.isPaid && !b.isPaid) return 1;
          return a.entryDate.compareTo(b.entryDate);
        });
        break;
      case ScheduleSortOrder.pendingFirst:
        sorted.sort((a, b) {
          final aPending = a.status == ScheduleEntryStatus.pending;
          final bPending = b.status == ScheduleEntryStatus.pending;
          if (aPending && !bPending) return -1;
          if (!aPending && bPending) return 1;
          return a.entryDate.compareTo(b.entryDate);
        });
        break;
      case ScheduleSortOrder.missedFirst:
        sorted.sort((a, b) {
          final aMissed = a.isMissed;
          final bMissed = b.isMissed;
          if (aMissed && !bMissed) return -1;
          if (!aMissed && bMissed) return 1;
          return a.entryDate.compareTo(b.entryDate);
        });
        break;
    }
    return sorted;
  }

  // ===== LOAN RENEWAL =====
  Future<int> renewLoan({
    required int oldLoanId,
    required double newPrincipal,
    required double newReturnAmount,
    required double newDailyInstallment,
    required DateTime newStartDate,
    required int newTotalDays,
    double? newMonthlyRate,
    InterestMode? newInterestMode,
  }) async {
    final oldLoan = await _loanDao.getById(oldLoanId);
    if (oldLoan == null) return 0;

    // Mark old loan as completed if not already
    if (oldLoan.status == LoanStatus.active || oldLoan.status == LoanStatus.overdue) {
      oldLoan.status = LoanStatus.completed;
      await _loanDao.update(oldLoan);
    }

    // Create new loan as renewal
    final newLoan = Loan(
      customerId: oldLoan.customerId,
      accountName: oldLoan.accountName,
      tag: oldLoan.tag,
      principal: newPrincipal,
      returnAmount: newReturnAmount,
      dailyInstallment: newDailyInstallment,
      startDate: newStartDate,
      totalDays: newTotalDays,
      monthlyInterestRate: newMonthlyRate ?? oldLoan.monthlyInterestRate,
      interestMode: newInterestMode ?? oldLoan.interestMode,
      gracePeriod: oldLoan.gracePeriod,
      sundayHolidayEnabled: oldLoan.sundayHolidayEnabled,
      lateFeePerDay: oldLoan.lateFeePerDay,
      lateFeeEnabled: oldLoan.lateFeeEnabled,
      excessPaymentMode: oldLoan.excessPaymentMode,
      renewedFromLoanId: oldLoanId,
    );

    final newLoanId = await _loanDao.insert(newLoan);
    newLoan.id = newLoanId;
    await generateSchedule(newLoan);

    await _logDao.insert(TransactionLog(
      customerId: oldLoan.customerId,
      loanId: newLoanId,
      action: 'RENEW',
      description: 'Loan renewed from loan #$oldLoanId',
    ));

    return newLoanId;
  }

  // Bulk mark all paid for today
  Future<void> bulkMarkPaidForDate(int loanId, int customerId, DateTime date, PaymentMode mode) async {
    final entries = await _scheduleDao.getByLoan(loanId);
    final dateOnly = DateTime(date.year, date.month, date.day);

    for (final entry in entries) {
      final entryDateOnly = DateTime(entry.entryDate.year, entry.entryDate.month, entry.entryDate.day);
      if (entryDateOnly == dateOnly && entry.status != ScheduleEntryStatus.paid && entry.status != ScheduleEntryStatus.holiday) {
        await recordCollection(
          entry: entry,
          amount: entry.expectedAmount,
          paymentMode: mode,
          customerId: customerId,
        );
      }
    }
  }
}
