import 'package:flutter/material.dart';
import 'database/dao/settings_dao.dart';
import 'models/settings.dart';
import 'utils/constants.dart';
import 'screens/dashboard_screen.dart';
import 'screens/app_lock_screen.dart';

class DailyCollectionApp extends StatefulWidget {
  const DailyCollectionApp({super.key});

  @override
  State<DailyCollectionApp> createState() => _DailyCollectionAppState();
}

class _DailyCollectionAppState extends State<DailyCollectionApp> {
  final SettingsDao _settingsDao = SettingsDao();
  AppSettings? _settings;
  bool _unlocked = false;

  @override
  void initState() {
    super.initState();
    _loadSettings();
  }

  Future<void> _loadSettings() async {
    final settings = await _settingsDao.getSettings();
    setState(() {
      _settings = settings;
      _unlocked = !settings.appLockEnabled;
    });
  }

  void _onUnlock() {
    setState(() => _unlocked = true);
  }

  @override
  Widget build(BuildContext context) {
    if (_settings == null) {
      return const MaterialApp(home: Scaffold(body: Center(child: CircularProgressIndicator())));
    }

    final themeColor = ThemeColors.getColor(_settings!.themeColorIndex);
    final isDark = _settings!.isDarkMode;

    return MaterialApp(
      title: AppConstants.appName,
      debugShowCheckedModeBanner: false,
      theme: ThemeData(
        colorScheme: ColorScheme.fromSeed(seedColor: themeColor),
        useMaterial3: true,
        brightness: Brightness.light,
        cardTheme: CardThemeData(
          elevation: 2,
          shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(12)),
        ),
        appBarTheme: AppBarTheme(
          backgroundColor: themeColor,
          foregroundColor: Colors.white,
          elevation: 0,
        ),
      ),
      darkTheme: ThemeData(
        colorScheme: ColorScheme.fromSeed(seedColor: themeColor, brightness: Brightness.dark),
        useMaterial3: true,
        brightness: Brightness.dark,
        cardTheme: CardThemeData(
          elevation: 2,
          shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(12)),
        ),
      ),
      themeMode: isDark ? ThemeMode.dark : ThemeMode.light,
      home: _unlocked
          ? const DashboardScreen()
          : AppLockScreen(onUnlock: _onUnlock),
    );
  }
}
