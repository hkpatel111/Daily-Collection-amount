import 'package:flutter/material.dart';
import 'app.dart';
import 'services/notification_service.dart';

void main() {
  WidgetsFlutterBinding.ensureInitialized();
  runApp(const DailyCollectionApp());
  NotificationService().init();
}
