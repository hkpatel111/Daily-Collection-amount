import 'package:flutter/material.dart';
import '../models/customer.dart';
import '../models/loan.dart';
import '../models/settings.dart';
import '../database/dao/customer_dao.dart';
import '../database/dao/loan_dao.dart';
import '../database/dao/settings_dao.dart';
import '../services/calculation_service.dart';
import '../services/schedule_service.dart';
import '../utils/constants.dart';
import '../utils/validators.dart';

class AddCustomerScreen extends StatefulWidget {
  const AddCustomerScreen({super.key});

  @override
  State<AddCustomerScreen> createState() => _AddCustomerScreenState();
}

class _AddCustomerScreenState extends State<AddCustomerScreen> {
  final _formKey = GlobalKey<FormState>();
  final CustomerDao _customerDao = CustomerDao();
  final LoanDao _loanDao = LoanDao();
  final SettingsDao _settingsDao = SettingsDao();
  final ScheduleService _scheduleService = ScheduleService();

  final _nameController = TextEditingController();
  final _mobileController = TextEditingController();
  final _nicknameController = TextEditingController();
  final _idNumberController = TextEditingController();
  final _accountNameController = TextEditingController();

  final _principalController = TextEditingController();
  final _returnAmountController = TextEditingController();
  final _dailyInstallmentController = TextEditingController();
  final _monthlyRateController = TextEditingController();
  final _totalDaysController = TextEditingController();

  DateTime _startDate = DateTime.now();
  InterestMode _interestMode = InterestMode.fixedReturn;
  int _gracePeriod = 0;
  bool _sundayHoliday = false;
  double _lateFeePerDay = 0;
  bool _lateFeeEnabled = false;
  bool _createLoan = false;
  bool _isLoading = false;

  // Live calculated values
  double _principal = 0;
  double _returnAmount = 0;
  double _dailyInstallment = 0;
  double _monthlyRate = 0;
  int _totalDays = 0;
  double _profit = 0;
  double _calcMonthlyRate = 0;
  double _calcYearlyRate = 0;

  void _recalculate({String? changedField}) {
    setState(() {
      _principal = double.tryParse(_principalController.text) ?? 0;
      _returnAmount = double.tryParse(_returnAmountController.text) ?? 0;
      _dailyInstallment = double.tryParse(_dailyInstallmentController.text) ?? 0;
      _monthlyRate = double.tryParse(_monthlyRateController.text) ?? 0;
      _totalDays = int.tryParse(_totalDaysController.text) ?? 0;

      if (_interestMode == InterestMode.flatMonthly) {
        // Flat monthly: returnAmount = principal + principal * rate% * months
        if (_principal > 0 && _monthlyRate > 0 && _totalDays > 0) {
          final months = (_totalDays / 30).ceil();
          _returnAmount = CalculationService.calcFlatReturnAmount(_principal, _monthlyRate, months);
          _dailyInstallment = _returnAmount / _totalDays;
          _returnAmountController.text = _returnAmount.toStringAsFixed(0);
          _dailyInstallmentController.text = _dailyInstallment.toStringAsFixed(0);
        } else if (_principal > 0 && _returnAmount > 0 && _totalDays > 0) {
          final months = (_totalDays / 30).ceil();
          _monthlyRate = ((_returnAmount - _principal) / (_principal * months)) * 100;
          _dailyInstallment = _returnAmount / _totalDays;
          _monthlyRateController.text = _monthlyRate.toStringAsFixed(2);
          _dailyInstallmentController.text = _dailyInstallment.toStringAsFixed(0);
        } else if (_principal > 0 && _monthlyRate > 0 && _returnAmount > 0) {
          final interest = _returnAmount - _principal;
          _totalDays = ((interest / (_principal * _monthlyRate / 100)) * 30).round();
          _dailyInstallment = _returnAmount / _totalDays;
          _totalDaysController.text = '$_totalDays';
          _dailyInstallmentController.text = _dailyInstallment.toStringAsFixed(0);
        }
      } else if (_interestMode == InterestMode.reducingBalance) {
        // Reducing balance (EMI style)
        if (_principal > 0 && _monthlyRate > 0 && _totalDays > 0) {
          final months = (_totalDays / 30).ceil();
          _dailyInstallment = CalculationService.calcEMI(_principal, _monthlyRate, months);
          _returnAmount = _dailyInstallment * _totalDays;
          _dailyInstallmentController.text = _dailyInstallment.toStringAsFixed(0);
          _returnAmountController.text = _returnAmount.toStringAsFixed(0);
        }
      } else {
        // Fixed return mode
        if (_returnAmount > 0 && _dailyInstallment > 0) {
          _totalDays = (_returnAmount / _dailyInstallment).ceil();
          _totalDaysController.text = '$_totalDays';
        } else if (_returnAmount > 0 && _totalDays > 0) {
          _dailyInstallment = _returnAmount / _totalDays;
          _dailyInstallmentController.text = _dailyInstallment.toStringAsFixed(0);
        }
        if (_principal > 0 && _returnAmount > 0 && _totalDays > 0) {
          _monthlyRate = CalculationService.calcMonthlyRate(
            CalculationService.calcDailyInterestRate(_returnAmount - _principal, _principal, _totalDays)
          );
          _monthlyRateController.text = _monthlyRate.toStringAsFixed(2);
        }
      }

      _profit = _returnAmount - _principal;
      if (_totalDays > 0 && _profit > 0 && _principal > 0) {
        final dailyRate = CalculationService.calcDailyInterestRate(_profit, _principal, _totalDays);
        _calcMonthlyRate = CalculationService.calcMonthlyRate(dailyRate);
        _calcYearlyRate = CalculationService.calcYearlyRate(dailyRate);
      }
    });
  }

  Future<void> _save() async {
    if (!_formKey.currentState!.validate()) return;

    setState(() => _isLoading = true);

    try {
      final customer = Customer(
        name: _nameController.text.trim(),
        mobile: _mobileController.text.trim(),
        nickname: _nicknameController.text.trim().isEmpty ? null : _nicknameController.text.trim(),
        idNumber: _idNumberController.text.trim().isEmpty ? null : _idNumberController.text.trim(),
      );
      final customerId = await _customerDao.insert(customer);

      if (_createLoan && _principal > 0 && _returnAmount > 0) {
        final settings = await _settingsDao.getSettings();
        final loan = Loan(
          customerId: customerId,
          accountName: _accountNameController.text.trim(),
          principal: _principal,
          returnAmount: _returnAmount,
          dailyInstallment: _dailyInstallment > 0 ? _dailyInstallment : (_returnAmount / _totalDays),
          startDate: _startDate,
          totalDays: _totalDays > 0 ? _totalDays : CalculationService.calcTotalDays(_returnAmount, _dailyInstallment),
          monthlyInterestRate: _monthlyRate,
          interestMode: _interestMode,
          gracePeriod: _gracePeriod,
          sundayHolidayEnabled: _sundayHoliday,
          lateFeePerDay: _lateFeePerDay,
          lateFeeEnabled: _lateFeeEnabled,
          excessPaymentMode: 'separateEntry',
        );
        final loanId = await _loanDao.insert(loan);
        loan.id = loanId;
        await _scheduleService.generateSchedule(loan);
      }

      if (mounted) Navigator.pop(context, true);
    } catch (e) {
      if (mounted) {
        ScaffoldMessenger.of(context).showSnackBar(SnackBar(content: Text('Error: $e')));
      }
    }
    setState(() => _isLoading = false);
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: const Text('Add Customer')),
      body: Form(
        key: _formKey,
        child: ListView(
          padding: const EdgeInsets.all(16),
          children: [
            // Customer details
            const Text('Customer Details', style: TextStyle(fontSize: 18, fontWeight: FontWeight.bold)),
            const SizedBox(height: 8),
            TextFormField(
              controller: _nameController,
              decoration: const InputDecoration(labelText: 'Name *', border: OutlineInputBorder()),
              validator: Validators.validateName,
            ),
            const SizedBox(height: 12),
            TextFormField(
              controller: _mobileController,
              decoration: const InputDecoration(labelText: 'Mobile *', border: OutlineInputBorder()),
              keyboardType: TextInputType.phone,
              validator: Validators.validateMobile,
            ),
            const SizedBox(height: 12),
            TextFormField(
              controller: _nicknameController,
              decoration: const InputDecoration(labelText: 'Nickname (optional)', border: OutlineInputBorder()),
            ),
            const SizedBox(height: 12),
            TextFormField(
              controller: _idNumberController,
              decoration: const InputDecoration(labelText: 'ID Number (optional)', border: OutlineInputBorder()),
            ),
            const SizedBox(height: 16),

            // Loan toggle
            SwitchListTile(
              title: const Text('Create Loan Now'),
              value: _createLoan,
              onChanged: (v) => setState(() => _createLoan = v),
            ),

            if (_createLoan) ...[
              const Divider(),
              const SizedBox(height: 8),
              const Text('Loan Details', style: TextStyle(fontSize: 18, fontWeight: FontWeight.bold)),
              const SizedBox(height: 8),
              TextFormField(
                controller: _accountNameController,
                decoration: const InputDecoration(labelText: 'Account Name/Tag (optional)', border: OutlineInputBorder()),
              ),
              const SizedBox(height: 12),

              // Interest Mode Selector
              DropdownButtonFormField<InterestMode>(
                value: _interestMode,
                decoration: const InputDecoration(labelText: 'Interest Mode', border: OutlineInputBorder()),
                items: const [
                  DropdownMenuItem(value: InterestMode.fixedReturn, child: Text('Fixed Return')),
                  DropdownMenuItem(value: InterestMode.flatMonthly, child: Text('Flat Monthly %')),
                  DropdownMenuItem(value: InterestMode.reducingBalance, child: Text('Reducing Balance (EMI)')),
                ],
                onChanged: (v) { setState(() => _interestMode = v!); _recalculate(); },
              ),
              const SizedBox(height: 12),

              // Principal
              TextFormField(
                controller: _principalController,
                decoration: const InputDecoration(labelText: 'Principal Amount *', border: OutlineInputBorder()),
                keyboardType: TextInputType.number,
                onChanged: (_) => _recalculate(),
                validator: Validators.validateAmount,
              ),
              const SizedBox(height: 12),

              // Monthly Rate
              TextFormField(
                controller: _monthlyRateController,
                decoration: InputDecoration(
                  labelText: _interestMode == InterestMode.fixedReturn ? 'Monthly Rate (auto)' : 'Monthly Interest Rate % *',
                  border: const OutlineInputBorder(),
                ),
                keyboardType: TextInputType.number,
                onChanged: (_) => _recalculate(),
                readOnly: _interestMode == InterestMode.fixedReturn,
              ),
              const SizedBox(height: 12),

              // Return Amount
              TextFormField(
                controller: _returnAmountController,
                decoration: const InputDecoration(labelText: 'Return Amount', border: OutlineInputBorder()),
                keyboardType: TextInputType.number,
                onChanged: (_) => _recalculate(),
              ),
              const SizedBox(height: 12),

              // Daily Installment
              TextFormField(
                controller: _dailyInstallmentController,
                decoration: const InputDecoration(labelText: 'Daily Installment', border: OutlineInputBorder()),
                keyboardType: TextInputType.number,
                onChanged: (_) => _recalculate(),
              ),
              const SizedBox(height: 12),

              // Total Days
              TextFormField(
                controller: _totalDaysController,
                decoration: const InputDecoration(labelText: 'Total Days / Tenure', border: OutlineInputBorder()),
                keyboardType: TextInputType.number,
                onChanged: (_) => _recalculate(),
              ),
              const SizedBox(height: 12),

              // Start Date
              ListTile(
                contentPadding: EdgeInsets.zero,
                title: const Text('Start Date'),
                subtitle: Text(CalculationService.formatDate(_startDate)),
                trailing: const Icon(Icons.calendar_today),
                onTap: () async {
                  final date = await showDatePicker(context: context, initialDate: _startDate, firstDate: DateTime(2020), lastDate: DateTime(2030));
                  if (date != null) setState(() => _startDate = date);
                },
              ),
              const SizedBox(height: 8),

              // Grace Period
              Row(
                children: [
                  const Text('Grace Period (days): '),
                  Expanded(
                    child: Slider(
                      value: _gracePeriod.toDouble(),
                      min: 0, max: 30,
                      divisions: 30,
                      label: '$_gracePeriod',
                      onChanged: (v) => setState(() => _gracePeriod = v.round()),
                    ),
                  ),
                  Text('$_gracePeriod'),
                ],
              ),

              // Sunday Holiday toggle
              SwitchListTile(
                title: const Text('Skip Sundays'),
                value: _sundayHoliday,
                onChanged: (v) => setState(() => _sundayHoliday = v),
              ),

              // Late Fee
              SwitchListTile(
                title: const Text('Late Fee Enabled'),
                value: _lateFeeEnabled,
                onChanged: (v) => setState(() => _lateFeeEnabled = v),
              ),
              if (_lateFeeEnabled)
                Padding(
                  padding: const EdgeInsets.only(left: 16, right: 16),
                  child: TextFormField(
                    decoration: const InputDecoration(labelText: 'Late Fee Per Day', border: OutlineInputBorder()),
                    keyboardType: TextInputType.number,
                    onChanged: (v) => _lateFeePerDay = double.tryParse(v) ?? 0,
                  ),
                ),

              const SizedBox(height: 16),

              // Live Preview
              if (_principal > 0) ...[
                Card(
                  color: Colors.blue.shade50,
                  child: Padding(
                    padding: const EdgeInsets.all(12),
                    child: Column(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: [
                        const Text('Live Preview', style: TextStyle(fontSize: 16, fontWeight: FontWeight.bold)),
                        const Divider(),
                        _previewRow('Principal', CalculationService.formatCurrency(_principal)),
                        _previewRow('Return Amount', CalculationService.formatCurrency(_returnAmount)),
                        _previewRow('Profit', CalculationService.formatCurrency(_profit)),
                        _previewRow('Daily Installment', CalculationService.formatCurrency(_dailyInstallment)),
                        _previewRow('Total Days', '$_totalDays'),
                        _previewRow('Monthly Rate', '${_calcMonthlyRate.toStringAsFixed(2)}%'),
                        _previewRow('Yearly Rate', '${_calcYearlyRate.toStringAsFixed(2)}%'),
                        _previewRow('Last Day Amount', CalculationService.formatCurrency(
                          _totalDays > 1 ? _returnAmount - (_dailyInstallment * (_totalDays - 1)) : _returnAmount,
                        )),
                      ],
                    ),
                  ),
                ),
              ],

              const SizedBox(height: 8),
              Text(
                'Tip: Change any field - all others update automatically!',
                style: TextStyle(fontSize: 11, color: Colors.grey[600], fontStyle: FontStyle.italic),
              ),
            ],

            const SizedBox(height: 24),

            // Save button
            FilledButton(
              onPressed: _isLoading ? null : _save,
              child: _isLoading
                ? const SizedBox(height: 20, width: 20, child: CircularProgressIndicator(color: Colors.white, strokeWidth: 2))
                : const Text('Save', style: TextStyle(fontSize: 16)),
            ),
          ],
        ),
      ),
    );
  }

  Widget _previewRow(String label, String value) {
    return Padding(
      padding: const EdgeInsets.symmetric(vertical: 2),
      child: Row(
        mainAxisAlignment: MainAxisAlignment.spaceBetween,
        children: [
          Text(label, style: TextStyle(fontSize: 13, color: Colors.grey[700])),
          Text(value, style: const TextStyle(fontSize: 13, fontWeight: FontWeight.w600)),
        ],
      ),
    );
  }
}
