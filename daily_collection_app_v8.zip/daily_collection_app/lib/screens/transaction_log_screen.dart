import 'package:flutter/material.dart';
import '../database/dao/transaction_log_dao.dart';
import '../services/calculation_service.dart';
import '../services/backup_service.dart';

class TransactionLogScreen extends StatefulWidget {
  const TransactionLogScreen({super.key});

  @override
  State<TransactionLogScreen> createState() => _TransactionLogScreenState();
}

class _TransactionLogScreenState extends State<TransactionLogScreen> {
  final TransactionLogDao _logDao = TransactionLogDao();
  final BackupService _backupService = BackupService();
  List<Map<String, dynamic>> _logs = [];
  String _searchQuery = '';

  @override
  void initState() {
    super.initState();
    _loadLogs();
  }

  Future<void> _loadLogs() async {
    final logs = _searchQuery.isNotEmpty ? await _logDao.search(_searchQuery) : await _logDao.getAll();
    setState(() => _logs = logs);
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text('Transaction Log'),
        actions: [
          IconButton(
            icon: const Icon(Icons.share),
            onPressed: () => _backupService.sharePdfTransactionLog(_logs),
          ),
        ],
      ),
      body: Column(
        children: [
          Padding(
            padding: const EdgeInsets.all(8),
            child: TextField(
              decoration: const InputDecoration(hintText: 'Search logs...', prefixIcon: Icon(Icons.search), border: OutlineInputBorder()),
              onChanged: (v) { _searchQuery = v; _loadLogs(); },
            ),
          ),
          Expanded(
            child: _logs.isEmpty
                ? const Center(child: Text('No transactions yet'))
                : ListView.builder(
                    itemCount: _logs.length,
                    itemBuilder: (context, index) {
                      final log = _logs[index];
                      return Card(
                        margin: const EdgeInsets.symmetric(horizontal: 8, vertical: 2),
                        child: ListTile(
                          leading: _getIcon(log['action'] as String),
                          title: Text(log['description'] as String),
                          subtitle: Text('${log['customer_name'] ?? '-'} - ${CalculationService.formatDateTime(DateTime.parse(log['timestamp'] as String))}'),
                          trailing: Text(log['action'] as String, style: const TextStyle(fontSize: 10)),
                        ),
                      );
                    },
                  ),
          ),
        ],
      ),
    );
  }

  Icon _getIcon(String action) {
    switch (action) {
      case 'COLLECTION': return const Icon(Icons.payment, color: Colors.green);
      case 'EDIT': return const Icon(Icons.edit, color: Colors.orange);
      case 'DELETE': return const Icon(Icons.delete, color: Colors.red);
      case 'PRE_CLOSE': return const Icon(Icons.check, color: Colors.purple);
      case 'CANCEL': return const Icon(Icons.cancel, color: Colors.grey);
      case 'COMPLETE': return const Icon(Icons.check_circle, color: Colors.green);
      case 'RENEW': return const Icon(Icons.refresh, color: Colors.teal);
      default: return const Icon(Icons.info, color: Colors.blue);
    }
  }
}
