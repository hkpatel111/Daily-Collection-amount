import 'package:flutter/material.dart';
import '../database/dao/customer_dao.dart';
import '../database/dao/loan_dao.dart';
import '../models/customer.dart';
import '../models/loan.dart';
import '../services/calculation_service.dart';
import 'customer_detail_screen.dart';
import 'loan_detail_screen.dart';

class SearchScreen extends StatefulWidget {
  const SearchScreen({super.key});

  @override
  State<SearchScreen> createState() => _SearchScreenState();
}

class _SearchScreenState extends State<SearchScreen> {
  final CustomerDao _customerDao = CustomerDao();
  final LoanDao _loanDao = LoanDao();
  List<Customer> _customers = [];
  List<Loan> _loans = [];
  bool _searched = false;

  void _search(String query) async {
    if (query.isEmpty) {
      setState(() { _customers = []; _loans = []; _searched = false; });
      return;
    }
    final customers = await _customerDao.search(query);
    final loans = await _loanDao.search(query);
    setState(() { _customers = customers; _loans = loans; _searched = true; });
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: const Text('Search')),
      body: Column(
        children: [
          Padding(
            padding: const EdgeInsets.all(8),
            child: TextField(
              autofocus: true,
              decoration: const InputDecoration(hintText: 'Search name, mobile, loan ID, amount...', prefixIcon: Icon(Icons.search), border: OutlineInputBorder()),
              onChanged: _search,
            ),
          ),
          Expanded(
            child: !_searched
                ? const Center(child: Text('Start typing to search...'))
                : ListView(
                    children: [
                      if (_customers.isNotEmpty) ...[
                        const Padding(padding: EdgeInsets.all(8), child: Text('Customers', style: TextStyle(fontSize: 16, fontWeight: FontWeight.bold))),
                        ..._customers.map((c) => Card(child: ListTile(
                          leading: const Icon(Icons.person),
                          title: Text(c.name),
                          subtitle: Text(c.mobile),
                          onTap: () => Navigator.push(context, MaterialPageRoute(builder: (_) => CustomerDetailScreen(customerId: c.id!))),
                        ))),
                      ],
                      if (_loans.isNotEmpty) ...[
                        const Padding(padding: EdgeInsets.all(8), child: Text('Loans', style: TextStyle(fontSize: 16, fontWeight: FontWeight.bold))),
                        ..._loans.map((l) => Card(child: ListTile(
                          leading: const Icon(Icons.account_balance),
                          title: Text('Loan #${l.id} - ${CalculationService.formatCurrency(l.principal)}'),
                          subtitle: Text('Return: ${CalculationService.formatCurrency(l.returnAmount)}'),
                          onTap: () => Navigator.push(context, MaterialPageRoute(builder: (_) => LoanDetailScreen(loanId: l.id!))),
                        ))),
                      ],
                      if (_customers.isEmpty && _loans.isEmpty)
                        const Center(child: Padding(padding: EdgeInsets.all(20), child: Text('No results found'))),
                    ],
                  ),
          ),
        ],
      ),
    );
  }
}
