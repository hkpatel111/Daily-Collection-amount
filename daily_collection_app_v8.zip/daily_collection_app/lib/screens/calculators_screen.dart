import 'package:flutter/material.dart';
import '../services/calculation_service.dart';

class CalculatorsScreen extends StatefulWidget {
  const CalculatorsScreen({super.key});

  @override
  State<CalculatorsScreen> createState() => _CalculatorsScreenState();
}

class _CalculatorsScreenState extends State<CalculatorsScreen> {
  int _selectedIndex = 0;

  final _calculators = [
    'Daily Collection', 'EMI', 'SIP', 'Future Value', 'Rate of Return',
    'Home Loan', 'Simple Interest', 'Compound Interest', 'Profit Margin', 'Loan Comparison',
  ];

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: Text(_calculators[_selectedIndex])),
      body: Column(
        children: [
          SizedBox(
            height: 50,
            child: ListView.builder(
              scrollDirection: Axis.horizontal,
              itemCount: _calculators.length,
              itemBuilder: (context, index) {
                return Padding(
                  padding: const EdgeInsets.symmetric(horizontal: 4, vertical: 8),
                  child: ChoiceChip(
                    label: Text(_calculators[index], style: TextStyle(fontSize: 12)),
                    selected: _selectedIndex == index,
                    onSelected: (_) => setState(() => _selectedIndex = index),
                  ),
                );
              },
            ),
          ),
          Expanded(child: _getCalculator()),
        ],
      ),
    );
  }

  Widget _getCalculator() {
    switch (_selectedIndex) {
      case 0: return const _DailyCollectionCalc();
      case 1: return const _EMICalc();
      case 2: return const _SIPCalc();
      case 3: return const _FutureValueCalc();
      case 4: return const _RateOfReturnCalc();
      case 5: return const _HomeLoanCalc();
      case 6: return const _SimpleInterestCalc();
      case 7: return const _CompoundInterestCalc();
      case 8: return const _ProfitMarginCalc();
      case 9: return const _LoanComparisonCalc();
      default: return const Center(child: Text('Coming soon'));
    }
  }
}

// ===== Helper Widget for Live Calculator =====
class _LiveResult extends StatelessWidget {
  final String label;
  final String value;
  const _LiveResult({required this.label, required this.value});

  @override
  Widget build(BuildContext context) {
    return Padding(
      padding: const EdgeInsets.symmetric(vertical: 4),
      child: Row(
        mainAxisAlignment: MainAxisAlignment.spaceBetween,
        children: [
          Text(label, style: TextStyle(color: Colors.grey[600])),
          Text(value, style: const TextStyle(fontWeight: FontWeight.bold)),
        ],
      ),
    );
  }
}

Widget _buildInput(TextEditingController controller, String label, {String suffix = ''}) {
  return Padding(
    padding: const EdgeInsets.only(bottom: 12),
    child: TextField(
      controller: controller,
      decoration: InputDecoration(
        labelText: label,
        border: const OutlineInputBorder(),
        suffixText: suffix,
      ),
      keyboardType: TextInputType.number,
    ),
  );
}

Widget _buildRateToggle(bool isMonthly, ValueChanged<bool> onChanged) {
  return Row(
    children: [
      const Text('Rate: '),
      const SizedBox(width: 8),
      ChoiceChip(label: const Text('Monthly %'), selected: isMonthly, onSelected: (_) => onChanged(true)),
      const SizedBox(width: 4),
      ChoiceChip(label: const Text('Yearly %'), selected: !isMonthly, onSelected: (_) => onChanged(false)),
    ],
  );
}

Widget _buildResultCard(List<Widget> children) {
  return Card(
    color: Colors.blue.shade50,
    child: Padding(
      padding: const EdgeInsets.all(12),
      child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: children),
    ),
  );
}

// 1. Daily Collection Calculator
class _DailyCollectionCalc extends StatefulWidget {
  const _DailyCollectionCalc();
  @override
  State<_DailyCollectionCalc> createState() => _DailyCollectionCalcState();
}

class _DailyCollectionCalcState extends State<_DailyCollectionCalc> {
  final _principal = TextEditingController(text: '5000');
  final _daily = TextEditingController(text: '50');
  final _days = TextEditingController(text: '120');
  final _monthlyRate = TextEditingController();
  bool _useMonthly = false;

  @override
  Widget build(BuildContext context) {
    final principal = double.tryParse(_principal.text) ?? 0;
    final daily = double.tryParse(_daily.text) ?? 0;
    final days = int.tryParse(_days.text) ?? 0;
    final monthlyRate = double.tryParse(_monthlyRate.text) ?? 0;

    final result = CalculationService.calcDailyCollection(
      principal: principal,
      dailyInstallment: daily,
      days: days,
      monthlyRate: _useMonthly && monthlyRate > 0 ? monthlyRate : null,
    );

    return ListView(
      padding: const EdgeInsets.all(16),
      children: [
        _buildInput(_principal, 'Principal Amount', suffix: '\u20B9'),
        SwitchListTile(title: const Text('Use Monthly %'), value: _useMonthly, onChanged: (v) => setState(() => _useMonthly = v)),
        if (_useMonthly) _buildInput(_monthlyRate, 'Monthly Interest Rate', suffix: '%'),
        if (!_useMonthly) _buildInput(_daily, 'Daily Installment', suffix: '\u20B9'),
        _buildInput(_days, 'Total Days'),
        const SizedBox(height: 8),
        _buildResultCard([
          const Text('Results (Live)', style: TextStyle(fontSize: 16, fontWeight: FontWeight.bold)),
          const Divider(),
          _LiveResult(label: 'Return Amount', value: CalculationService.formatCurrency(result['returnAmount'])),
          _LiveResult(label: 'Profit', value: CalculationService.formatCurrency(result['profit'])),
          if (!_useMonthly) _LiveResult(label: 'Daily Installment', value: CalculationService.formatCurrency(result['dailyInstallment'])),
          _LiveResult(label: 'Monthly Rate', value: '${(result['monthlyRate'] as double).toStringAsFixed(2)}%'),
          _LiveResult(label: 'Yearly Rate', value: '${(result['yearlyRate'] as double).toStringAsFixed(2)}%'),
        ]),
      ],
    );
  }
}

// 2. EMI Calculator
class _EMICalc extends StatefulWidget {
  const _EMICalc();
  @override
  State<_EMICalc> createState() => _EMICalcState();
}

class _EMICalcState extends State<_EMICalc> {
  final _principal = TextEditingController(text: '100000');
  final _rate = TextEditingController(text: '12');
  final _tenure = TextEditingController(text: '60');
  bool _isMonthly = false;

  @override
  Widget build(BuildContext context) {
    final principal = double.tryParse(_principal.text) ?? 0;
    final rate = double.tryParse(_rate.text) ?? 0;
    final tenure = int.tryParse(_tenure.text) ?? 0;

    final result = CalculationService.calcEMICalculator(principal: principal, annualRate: rate, tenureMonths: tenure, isMonthlyRate: _isMonthly);

    return ListView(
      padding: const EdgeInsets.all(16),
      children: [
        _buildInput(_principal, 'Principal', suffix: '\u20B9'),
        _buildRateToggle(_isMonthly, (v) => setState(() => _isMonthly = v)),
        _buildInput(_rate, 'Interest Rate', suffix: '%'),
        _buildInput(_tenure, 'Tenure (months)'),
        const SizedBox(height: 8),
        _buildResultCard([
          const Text('Results (Live)', style: TextStyle(fontSize: 16, fontWeight: FontWeight.bold)),
          const Divider(),
          _LiveResult(label: 'Monthly EMI', value: CalculationService.formatCurrency(result['emi'])),
          _LiveResult(label: 'Total Payment', value: CalculationService.formatCurrency(result['totalPayment'])),
          _LiveResult(label: 'Total Interest', value: CalculationService.formatCurrency(result['totalInterest'])),
          _LiveResult(label: 'Yearly Rate', value: '${(result['yearlyRate'] as double).toStringAsFixed(2)}%'),
        ]),
      ],
    );
  }
}

// 3. SIP Calculator
class _SIPCalc extends StatefulWidget {
  const _SIPCalc();
  @override
  State<_SIPCalc> createState() => _SIPCalcState();
}

class _SIPCalcState extends State<_SIPCalc> {
  final _monthly = TextEditingController(text: '5000');
  final _rate = TextEditingController(text: '12');
  final _years = TextEditingController(text: '10');
  bool _isMonthly = false;

  @override
  Widget build(BuildContext context) {
    final monthly = double.tryParse(_monthly.text) ?? 0;
    final rate = double.tryParse(_rate.text) ?? 0;
    final years = int.tryParse(_years.text) ?? 0;

    final result = CalculationService.calcSIP(monthlyInvestment: monthly, annualRate: rate, years: years, isMonthlyRate: _isMonthly);

    return ListView(
      padding: const EdgeInsets.all(16),
      children: [
        _buildInput(_monthly, 'Monthly Investment', suffix: '\u20B9'),
        _buildRateToggle(_isMonthly, (v) => setState(() => _isMonthly = v)),
        _buildInput(_rate, 'Expected Return Rate', suffix: '%'),
        _buildInput(_years, 'Investment Period (years)'),
        const SizedBox(height: 8),
        _buildResultCard([
          const Text('Results (Live)', style: TextStyle(fontSize: 16, fontWeight: FontWeight.bold)),
          const Divider(),
          _LiveResult(label: 'Maturity Value', value: CalculationService.formatCurrency(result['maturity'])),
          _LiveResult(label: 'Total Invested', value: CalculationService.formatCurrency(result['totalInvested'])),
          _LiveResult(label: 'Total Gain', value: CalculationService.formatCurrency(result['totalGain'])),
        ]),
      ],
    );
  }
}

// 4. Future Value Calculator
class _FutureValueCalc extends StatefulWidget {
  const _FutureValueCalc();
  @override
  State<_FutureValueCalc> createState() => _FutureValueCalcState();
}

class _FutureValueCalcState extends State<_FutureValueCalc> {
  final _present = TextEditingController(text: '10000');
  final _rate = TextEditingController(text: '8');
  final _years = TextEditingController(text: '5');
  bool _isMonthly = false;

  @override
  Widget build(BuildContext context) {
    final present = double.tryParse(_present.text) ?? 0;
    final rate = double.tryParse(_rate.text) ?? 0;
    final years = int.tryParse(_years.text) ?? 0;

    final result = CalculationService.calcFutureValue(presentValue: present, annualRate: rate, years: years, isMonthlyRate: _isMonthly);

    return ListView(
      padding: const EdgeInsets.all(16),
      children: [
        _buildInput(_present, 'Present Value', suffix: '\u20B9'),
        _buildRateToggle(_isMonthly, (v) => setState(() => _isMonthly = v)),
        _buildInput(_rate, 'Interest Rate', suffix: '%'),
        _buildInput(_years, 'Time Period (years)'),
        const SizedBox(height: 8),
        _buildResultCard([
          const Text('Results (Live)', style: TextStyle(fontSize: 16, fontWeight: FontWeight.bold)),
          const Divider(),
          _LiveResult(label: 'Future Value', value: CalculationService.formatCurrency(result['futureValue'])),
          _LiveResult(label: 'Total Gain', value: CalculationService.formatCurrency(result['totalGain'])),
        ]),
      ],
    );
  }
}

// 5. Rate of Return Calculator
class _RateOfReturnCalc extends StatefulWidget {
  const _RateOfReturnCalc();
  @override
  State<_RateOfReturnCalc> createState() => _RateOfReturnCalcState();
}

class _RateOfReturnCalcState extends State<_RateOfReturnCalc> {
  final _present = TextEditingController(text: '10000');
  final _future = TextEditingController(text: '15000');
  final _years = TextEditingController(text: '3');

  @override
  Widget build(BuildContext context) {
    final present = double.tryParse(_present.text) ?? 0;
    final future = double.tryParse(_future.text) ?? 0;
    final years = int.tryParse(_years.text) ?? 0;

    final result = CalculationService.calcRateOfReturn(presentValue: present, futureValue: future, years: years);

    return ListView(
      padding: const EdgeInsets.all(16),
      children: [
        _buildInput(_present, 'Present Value', suffix: '\u20B9'),
        _buildInput(_future, 'Future Value', suffix: '\u20B9'),
        _buildInput(_years, 'Time Period (years)'),
        const SizedBox(height: 8),
        _buildResultCard([
          const Text('Results (Live)', style: TextStyle(fontSize: 16, fontWeight: FontWeight.bold)),
          const Divider(),
          _LiveResult(label: 'Yearly Rate of Return', value: '${(result['rate'] as double).toStringAsFixed(2)}%'),
          _LiveResult(label: 'Monthly Rate', value: '${(result['monthlyRate'] as double).toStringAsFixed(2)}%'),
        ]),
      ],
    );
  }
}

// 6. Home Loan Calculator
class _HomeLoanCalc extends StatefulWidget {
  const _HomeLoanCalc();
  @override
  State<_HomeLoanCalc> createState() => _HomeLoanCalcState();
}

class _HomeLoanCalcState extends State<_HomeLoanCalc> {
  final _principal = TextEditingController(text: '2000000');
  final _rate = TextEditingController(text: '8.5');
  final _years = TextEditingController(text: '20');
  bool _isMonthly = false;

  @override
  Widget build(BuildContext context) {
    final principal = double.tryParse(_principal.text) ?? 0;
    final rate = double.tryParse(_rate.text) ?? 0;
    final years = int.tryParse(_years.text) ?? 0;

    final result = CalculationService.calcHomeLoan(principal: principal, annualRate: rate, tenureYears: years, isMonthlyRate: _isMonthly);

    return ListView(
      padding: const EdgeInsets.all(16),
      children: [
        _buildInput(_principal, 'Loan Amount', suffix: '\u20B9'),
        _buildRateToggle(_isMonthly, (v) => setState(() => _isMonthly = v)),
        _buildInput(_rate, 'Interest Rate', suffix: '%'),
        _buildInput(_years, 'Tenure (years)'),
        const SizedBox(height: 8),
        _buildResultCard([
          const Text('Results (Live)', style: TextStyle(fontSize: 16, fontWeight: FontWeight.bold)),
          const Divider(),
          _LiveResult(label: 'Monthly EMI', value: CalculationService.formatCurrency(result['emi'])),
          _LiveResult(label: 'Total Payment', value: CalculationService.formatCurrency(result['totalPayment'])),
          _LiveResult(label: 'Total Interest', value: CalculationService.formatCurrency(result['totalInterest'])),
        ]),
      ],
    );
  }
}

// 7. Simple Interest Calculator
class _SimpleInterestCalc extends StatefulWidget {
  const _SimpleInterestCalc();
  @override
  State<_SimpleInterestCalc> createState() => _SimpleInterestCalcState();
}

class _SimpleInterestCalcState extends State<_SimpleInterestCalc> {
  final _principal = TextEditingController(text: '10000');
  final _rate = TextEditingController(text: '10');
  final _time = TextEditingController(text: '2');
  bool _isMonthly = false;
  bool _isMonths = false;

  @override
  Widget build(BuildContext context) {
    final principal = double.tryParse(_principal.text) ?? 0;
    final rate = double.tryParse(_rate.text) ?? 0;
    final time = int.tryParse(_time.text) ?? 0;

    final result = CalculationService.calcSimpleInterest(principal: principal, rate: rate, time: time, isMonthlyRate: _isMonthly, isMonths: _isMonths);

    return ListView(
      padding: const EdgeInsets.all(16),
      children: [
        _buildInput(_principal, 'Principal', suffix: '\u20B9'),
        _buildRateToggle(_isMonthly, (v) => setState(() => _isMonthly = v)),
        _buildInput(_rate, 'Interest Rate', suffix: '%'),
        Row(
          children: [
            const Text('Period: '),
            ChoiceChip(label: const Text('Years'), selected: !_isMonths, onSelected: (_) => setState(() => _isMonths = false)),
            const SizedBox(width: 4),
            ChoiceChip(label: const Text('Months'), selected: _isMonths, onSelected: (_) => setState(() => _isMonths = true)),
          ],
        ),
        _buildInput(_time, _isMonths ? 'Time (months)' : 'Time (years)'),
        const SizedBox(height: 8),
        _buildResultCard([
          const Text('Results (Live)', style: TextStyle(fontSize: 16, fontWeight: FontWeight.bold)),
          const Divider(),
          _LiveResult(label: 'Interest', value: CalculationService.formatCurrency(result['interest'])),
          _LiveResult(label: 'Total Amount', value: CalculationService.formatCurrency(result['totalAmount'])),
          _LiveResult(label: 'Monthly Rate', value: '${(result['monthlyRate'] as double).toStringAsFixed(2)}%'),
          _LiveResult(label: 'Yearly Rate', value: '${(result['yearlyRate'] as double).toStringAsFixed(2)}%'),
        ]),
      ],
    );
  }
}

// 8. Compound Interest Calculator
class _CompoundInterestCalc extends StatefulWidget {
  const _CompoundInterestCalc();
  @override
  State<_CompoundInterestCalc> createState() => _CompoundInterestCalcState();
}

class _CompoundInterestCalcState extends State<_CompoundInterestCalc> {
  final _principal = TextEditingController(text: '10000');
  final _rate = TextEditingController(text: '10');
  final _time = TextEditingController(text: '5');
  bool _isMonthly = false;
  bool _isMonths = false;

  @override
  Widget build(BuildContext context) {
    final principal = double.tryParse(_principal.text) ?? 0;
    final rate = double.tryParse(_rate.text) ?? 0;
    final time = int.tryParse(_time.text) ?? 0;

    final result = CalculationService.calcCompoundInterest(principal: principal, rate: rate, time: time, isMonthlyRate: _isMonthly, isMonths: _isMonths);

    return ListView(
      padding: const EdgeInsets.all(16),
      children: [
        _buildInput(_principal, 'Principal', suffix: '\u20B9'),
        _buildRateToggle(_isMonthly, (v) => setState(() => _isMonthly = v)),
        _buildInput(_rate, 'Interest Rate', suffix: '%'),
        Row(
          children: [
            const Text('Period: '),
            ChoiceChip(label: const Text('Years'), selected: !_isMonths, onSelected: (_) => setState(() => _isMonths = false)),
            const SizedBox(width: 4),
            ChoiceChip(label: const Text('Months'), selected: _isMonths, onSelected: (_) => setState(() => _isMonths = true)),
          ],
        ),
        _buildInput(_time, _isMonths ? 'Time (months)' : 'Time (years)'),
        const SizedBox(height: 8),
        _buildResultCard([
          const Text('Results (Live)', style: TextStyle(fontSize: 16, fontWeight: FontWeight.bold)),
          const Divider(),
          _LiveResult(label: 'Amount', value: CalculationService.formatCurrency(result['amount'])),
          _LiveResult(label: 'Interest', value: CalculationService.formatCurrency(result['interest'])),
          _LiveResult(label: 'Monthly Rate', value: '${(result['monthlyRate'] as double).toStringAsFixed(2)}%'),
        ]),
      ],
    );
  }
}

// 9. Profit Margin Calculator
class _ProfitMarginCalc extends StatefulWidget {
  const _ProfitMarginCalc();
  @override
  State<_ProfitMarginCalc> createState() => _ProfitMarginCalcState();
}

class _ProfitMarginCalcState extends State<_ProfitMarginCalc> {
  final _revenue = TextEditingController(text: '50000');
  final _cost = TextEditingController(text: '35000');

  @override
  Widget build(BuildContext context) {
    final revenue = double.tryParse(_revenue.text) ?? 0;
    final cost = double.tryParse(_cost.text) ?? 0;

    final result = CalculationService.calcProfitMargin(revenue: revenue, cost: cost);

    return ListView(
      padding: const EdgeInsets.all(16),
      children: [
        _buildInput(_revenue, 'Revenue / Selling Price', suffix: '\u20B9'),
        _buildInput(_cost, 'Cost Price', suffix: '\u20B9'),
        const SizedBox(height: 8),
        _buildResultCard([
          const Text('Results (Live)', style: TextStyle(fontSize: 16, fontWeight: FontWeight.bold)),
          const Divider(),
          _LiveResult(label: 'Profit', value: CalculationService.formatCurrency(result['profit'])),
          _LiveResult(label: 'Profit Margin %', value: '${(result['marginPercent'] as double).toStringAsFixed(2)}%'),
          _LiveResult(label: 'Markup %', value: '${(result['markupPercent'] as double).toStringAsFixed(2)}%'),
        ]),
      ],
    );
  }
}

// 10. Loan Comparison Calculator
class _LoanComparisonCalc extends StatefulWidget {
  const _LoanComparisonCalc();
  @override
  State<_LoanComparisonCalc> createState() => _LoanComparisonCalcState();
}

class _LoanComparisonCalcState extends State<_LoanComparisonCalc> {
  final _principal = TextEditingController(text: '100000');
  final _rate1 = TextEditingController(text: '10');
  final _rate2 = TextEditingController(text: '12');
  final _rate3 = TextEditingController(text: '8');
  final _tenure1 = TextEditingController(text: '12');
  final _tenure2 = TextEditingController(text: '24');
  final _tenure3 = TextEditingController(text: '36');
  bool _isMonthly = false;

  @override
  Widget build(BuildContext context) {
    final principal = double.tryParse(_principal.text) ?? 0;
    final rates = [double.tryParse(_rate1.text) ?? 0, double.tryParse(_rate2.text) ?? 0, double.tryParse(_rate3.text) ?? 0];
    final tenures = [int.tryParse(_tenure1.text) ?? 0, int.tryParse(_tenure2.text) ?? 0, int.tryParse(_tenure3.text) ?? 0];

    final results = CalculationService.calcLoanComparison(principal: principal, rates: rates, tenures: tenures, isMonthlyRate: _isMonthly);

    return ListView(
      padding: const EdgeInsets.all(16),
      children: [
        _buildInput(_principal, 'Principal', suffix: '\u20B9'),
        _buildRateToggle(_isMonthly, (v) => setState(() => _isMonthly = v)),
        const SizedBox(height: 8),
        Row(
          children: [
            Expanded(child: _buildInput(_rate1, 'Rate 1', suffix: '%')),
            const SizedBox(width: 8),
            Expanded(child: _buildInput(_tenure1, 'Months 1')),
          ],
        ),
        Row(
          children: [
            Expanded(child: _buildInput(_rate2, 'Rate 2', suffix: '%')),
            const SizedBox(width: 8),
            Expanded(child: _buildInput(_tenure2, 'Months 2')),
          ],
        ),
        Row(
          children: [
            Expanded(child: _buildInput(_rate3, 'Rate 3', suffix: '%')),
            const SizedBox(width: 8),
            Expanded(child: _buildInput(_tenure3, 'Months 3')),
          ],
        ),
        const SizedBox(height: 8),
        ...results.map((r) => _buildResultCard([
          Text('Option ${r['option']}: ${r['rate']}% x ${r['tenure']} months', style: const TextStyle(fontWeight: FontWeight.bold)),
          const Divider(),
          _LiveResult(label: 'EMI', value: CalculationService.formatCurrency(r['emi'])),
          _LiveResult(label: 'Total Payment', value: CalculationService.formatCurrency(r['totalPayment'])),
          _LiveResult(label: 'Total Interest', value: CalculationService.formatCurrency(r['totalInterest'])),
        ])),
      ],
    );
  }
}
