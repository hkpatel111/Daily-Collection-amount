import 'package:flutter/material.dart';
import '../database/dao/edit_history_dao.dart';
import '../services/calculation_service.dart';

class EditHistoryScreen extends StatefulWidget {
  final int collectionEntryId;

  const EditHistoryScreen({super.key, required this.collectionEntryId});

  @override
  State<EditHistoryScreen> createState() => _EditHistoryScreenState();
}

class _EditHistoryScreenState extends State<EditHistoryScreen> {
  final EditHistoryDao _editHistoryDao = EditHistoryDao();
  List<dynamic> _history = [];

  @override
  void initState() {
    super.initState();
    _loadHistory();
  }

  Future<void> _loadHistory() async {
    final history = await _editHistoryDao.getByCollectionEntry(widget.collectionEntryId);
    setState(() => _history = history);
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: const Text('Edit History')),
      body: _history.isEmpty
          ? const Center(child: Text('No edit history'))
          : ListView.builder(
              itemCount: _history.length,
              itemBuilder: (context, index) {
                final h = _history[index];
                return Card(
                  margin: const EdgeInsets.symmetric(horizontal: 8, vertical: 3),
                  child: ListTile(
                    leading: const Icon(Icons.edit, color: Colors.orange),
                    title: Text('${h.fieldName}: ${h.oldValue} -> ${h.newValue}'),
                    subtitle: Text(CalculationService.formatDateTime(h.editedAt)),
                  ),
                );
              },
            ),
    );
  }
}
