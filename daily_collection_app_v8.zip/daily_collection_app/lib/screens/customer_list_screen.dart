import 'package:flutter/material.dart';
import '../database/dao/customer_dao.dart';
import '../models/customer.dart';
import 'add_customer_screen.dart';
import 'customer_detail_screen.dart';

class CustomerListScreen extends StatefulWidget {
  const CustomerListScreen({super.key});

  @override
  State<CustomerListScreen> createState() => _CustomerListScreenState();
}

class _CustomerListScreenState extends State<CustomerListScreen> {
  final CustomerDao _customerDao = CustomerDao();
  List<Customer> _customers = [];
  bool _showArchived = false;
  String _searchQuery = '';

  @override
  void initState() {
    super.initState();
    _loadCustomers();
  }

  Future<void> _loadCustomers() async {
    final customers = _showArchived
        ? await _customerDao.getAll()
        : await _customerDao.getAll(activeOnly: true);
    setState(() {
      if (_searchQuery.isNotEmpty) {
        _customers = customers.where((c) =>
          c.name.toLowerCase().contains(_searchQuery.toLowerCase()) ||
          c.mobile.contains(_searchQuery) ||
          (c.nickname ?? '').toLowerCase().contains(_searchQuery.toLowerCase())
        ).toList();
      } else {
        _customers = customers;
      }
    });
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text('Customers'),
        actions: [
          IconButton(
            icon: Icon(_showArchived ? Icons.archive : Icons.unarchive),
            onPressed: () { setState(() => _showArchived = !_showArchived); _loadCustomers(); },
          ),
        ],
      ),
      body: Column(
        children: [
          Padding(
            padding: const EdgeInsets.all(8),
            child: TextField(
              decoration: const InputDecoration(
                hintText: 'Search by name, mobile, nickname...',
                prefixIcon: Icon(Icons.search),
                border: OutlineInputBorder(),
              ),
              onChanged: (val) { _searchQuery = val; _loadCustomers(); },
            ),
          ),
          Expanded(
            child: _customers.isEmpty
                ? const Center(child: Text('No customers found'))
                : ListView.builder(
                    itemCount: _customers.length,
                    itemBuilder: (context, index) {
                      final customer = _customers[index];
                      return Card(
                        margin: const EdgeInsets.symmetric(horizontal: 8, vertical: 3),
                        child: ListTile(
                          leading: CircleAvatar(
                            child: Text(customer.name[0].toUpperCase()),
                          ),
                          title: Text(customer.name),
                          subtitle: Text(customer.mobile),
                          trailing: !customer.isActive
                              ? const Icon(Icons.archive, color: Colors.grey)
                              : null,
                          onTap: () async {
                            await Navigator.push(context, MaterialPageRoute(builder: (_) => CustomerDetailScreen(customerId: customer.id!)));
                            _loadCustomers();
                          },
                        ),
                      );
                    },
                  ),
          ),
        ],
      ),
      floatingActionButton: FloatingActionButton(
        onPressed: () async {
          await Navigator.push(context, MaterialPageRoute(builder: (_) => const AddCustomerScreen()));
          _loadCustomers();
        },
        child: const Icon(Icons.person_add),
      ),
    );
  }
}
