import 'package:flutter/material.dart';
import '../database/dao/collection_dao.dart';
import '../models/collection_entry.dart';
import '../services/calculation_service.dart';
import '../services/schedule_service.dart';
import 'edit_history_screen.dart';

class CollectionListScreen extends StatefulWidget {
  final int loanId;

  const CollectionListScreen({super.key, required this.loanId});

  @override
  State<CollectionListScreen> createState() => _CollectionListScreenState();
}

class _CollectionListScreenState extends State<CollectionListScreen> {
  final CollectionDao _collectionDao = CollectionDao();
  final ScheduleService _scheduleService = ScheduleService();
  List<Map<String, dynamic>> _collections = [];

  @override
  void initState() {
    super.initState();
    _loadData();
  }

  Future<void> _loadData() async {
    final collections = await _collectionDao.getByLoanWithDetails(widget.loanId);
    setState(() => _collections = collections);
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: const Text('Collections')),
      body: _collections.isEmpty
          ? const Center(child: Text('No collections yet'))
          : ListView.builder(
              itemCount: _collections.length,
              itemBuilder: (context, index) {
                final c = _collections[index];
                final entry = CollectionEntry.fromMap(c);
                return Card(
                  margin: const EdgeInsets.symmetric(horizontal: 8, vertical: 3),
                  child: ListTile(
                    leading: CircleAvatar(child: Text('${c['day_number'] ?? index + 1}')),
                    title: Text(CalculationService.formatCurrency(entry.amount)),
                    subtitle: Text('${CalculationService.formatDateTime(entry.collectedDate)} - ${entry.paymentMode.name}'),
                    trailing: PopupMenuButton(
                      itemBuilder: (context) => [
                        const PopupMenuItem(value: 'edit', child: Text('Edit')),
                        const PopupMenuItem(value: 'history', child: Text('Edit History')),
                        const PopupMenuItem(value: 'delete', child: Text('Delete')),
                      ],
                      onSelected: (value) async {
                        if (value == 'edit') {
                          _showEditDialog(entry);
                        } else if (value == 'history') {
                          Navigator.push(context, MaterialPageRoute(builder: (_) => EditHistoryScreen(collectionEntryId: entry.id!)));
                        } else if (value == 'delete') {
                          await _scheduleService.deleteCollection(entry);
                          _loadData();
                        }
                      },
                    ),
                  ),
                );
              },
            ),
    );
  }

  void _showEditDialog(CollectionEntry entry) {
    final amountController = TextEditingController(text: entry.amount.toStringAsFixed(0));
    PaymentMode selectedMode = entry.paymentMode;

    showDialog(
      context: context,
      builder: (ctx) => AlertDialog(
        title: const Text('Edit Collection'),
        content: Column(
          mainAxisSize: MainAxisSize.min,
          children: [
            TextField(controller: amountController, decoration: const InputDecoration(labelText: 'Amount', border: OutlineInputBorder()), keyboardType: TextInputType.number),
            const SizedBox(height: 12),
            DropdownButtonFormField<PaymentMode>(
              value: selectedMode,
              decoration: const InputDecoration(labelText: 'Payment Mode', border: OutlineInputBorder()),
              items: PaymentMode.values.map((m) => DropdownMenuItem(value: m, child: Text(m.name))).toList(),
              onChanged: (v) => selectedMode = v!,
            ),
          ],
        ),
        actions: [
          TextButton(onPressed: () => Navigator.pop(ctx), child: const Text('Cancel')),
          FilledButton(
            onPressed: () async {
              await _scheduleService.editCollection(entry: entry, newAmount: double.tryParse(amountController.text) ?? 0, newPaymentMode: selectedMode);
              if (mounted) Navigator.pop(ctx);
              _loadData();
            },
            child: const Text('Update'),
          ),
        ],
      ),
    );
  }
}
