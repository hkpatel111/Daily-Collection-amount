import 'package:flutter/material.dart';
import '../database/dao/loan_dao.dart';
import '../database/dao/customer_dao.dart';
import '../database/dao/schedule_dao.dart';
import '../database/dao/collection_dao.dart';
import '../models/loan.dart';
import '../models/customer.dart';
import '../models/schedule_entry.dart';
import '../models/collection_entry.dart';
import '../services/calculation_service.dart';
import '../services/schedule_service.dart';
import '../services/sms_service.dart';
import '../services/backup_service.dart';
import '../utils/constants.dart';
import '../widgets/schedule_entry_tile.dart';
import 'collection_list_screen.dart';
import 'pre_close_screen.dart';
import 'calendar_screen.dart';
import 'sms_history_screen.dart';
import 'edit_history_screen.dart';

class LoanDetailScreen extends StatefulWidget {
  final int loanId;

  const LoanDetailScreen({super.key, required this.loanId});

  @override
  State<LoanDetailScreen> createState() => _LoanDetailScreenState();
}

class _LoanDetailScreenState extends State<LoanDetailScreen> {
  final LoanDao _loanDao = LoanDao();
  final CustomerDao _customerDao = CustomerDao();
  final ScheduleDao _scheduleDao = ScheduleDao();
  final CollectionDao _collectionDao = CollectionDao();
  final ScheduleService _scheduleService = ScheduleService();
  final SmsService _smsService = SmsService();
  final BackupService _backupService = BackupService();

  Loan? _loan;
  Customer? _customer;
  List<ScheduleEntry> _schedule = [];
  double _totalCollected = 0;
  int _paidDays = 0;
  ScheduleSortOrder _sortOrder = ScheduleSortOrder.oldToNew;

  @override
  void initState() {
    super.initState();
    _loadData();
  }

  Future<void> _loadData() async {
    final loan = await _loanDao.getById(widget.loanId);
    final customer = _loan != null ? await _customerDao.getById(_loan!.customerId) : (loan != null ? await _customerDao.getById(loan.customerId) : null);
    final schedule = loan != null ? await _scheduleDao.getByLoan(loan.id!) : <ScheduleEntry>[];
    final totalCollected = loan != null ? await _collectionDao.getTotalCollected(loan.id!) : 0.0;

    final paidDays = schedule.where((e) => e.isPaid).length;

    // Update overdue status
    if (loan != null && (loan.status == LoanStatus.active || loan.status == LoanStatus.overdue)) {
      await _scheduleService.updateOverdueStatus(loan.id!);
    }

    final updatedSchedule = loan != null ? await _scheduleDao.getByLoan(loan.id!) : <ScheduleEntry>[];
    final updatedLoan = loan != null ? await _loanDao.getById(loan.id!) : null;

    setState(() {
      _loan = updatedLoan ?? loan;
      _customer = customer;
      _schedule = _scheduleService.sortEntries(updatedSchedule, _sortOrder);
      _totalCollected = totalCollected;
      _paidDays = paidDays;
    });
  }

  @override
  Widget build(BuildContext context) {
    if (_loan == null) {
      return Scaffold(appBar: AppBar(), body: const Center(child: CircularProgressIndicator()));
    }

    final loan = _loan!;
    final remaining = loan.returnAmount - _totalCollected;
    final dailyRate = CalculationService.calcDailyInterestRate(loan.profit, loan.principal, loan.totalDays);
    final monthlyRate = CalculationService.calcMonthlyRate(dailyRate);
    final yearlyRate = CalculationService.calcYearlyRate(dailyRate);

    return Scaffold(
      appBar: AppBar(
        title: Text('Loan #${loan.id}'),
        actions: [
          PopupMenuButton(
            itemBuilder: (context) => [
              const PopupMenuItem(value: 'calendar', child: Text('Calendar View')),
              const PopupMenuItem(value: 'collections', child: Text('All Collections')),
              const PopupMenuItem(value: 'sms_history', child: Text('SMS History')),
              const PopupMenuItem(value: 'summary_pdf', child: Text('Share Summary PDF')),
              const PopupMenuItem(value: 'summary_whatsapp', child: Text('Send WhatsApp Summary')),
              const PopupMenuItem(value: 'outstanding', child: Text('Outstanding Snapshot')),
              const PopupMenuItem(value: 'renew', child: Text('Renew Loan')),
              const PopupMenuItem(value: 'pre_close', child: Text('Pre-Close Loan')),
              const PopupMenuItem(value: 'cancel', child: Text('Cancel Loan')),
              const PopupMenuItem(value: 'delete', child: Text('Delete Loan')),
            ],
            onSelected: (value) => _handleMenuAction(value.toString()),
          ),
        ],
      ),
      body: Column(
        children: [
          // Loan Info Card
          Card(
            margin: const EdgeInsets.all(8),
            child: Padding(
              padding: const EdgeInsets.all(12),
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Row(
                    children: [
                      if (_customer != null) ...[
                        Expanded(child: Text(_customer!.name, style: const TextStyle(fontSize: 18, fontWeight: FontWeight.bold))),
                        Text(_customer!.mobile, style: TextStyle(color: Colors.grey[600])),
                      ],
                    ],
                  ),
                  if (loan.accountName.isNotEmpty)
                    Text('Account: ${loan.accountName}', style: TextStyle(color: Colors.grey[600])),
                  if (loan.isRenewed)
                    Text('Renewed from Loan #${loan.renewedFromLoanId}', style: TextStyle(color: Colors.green[700], fontSize: 12)),
                  const Divider(),
                  _infoRow('Principal', CalculationService.formatCurrency(loan.principal)),
                  _infoRow('Return Amount', CalculationService.formatCurrency(loan.returnAmount)),
                  _infoRow('Profit', CalculationService.formatCurrency(loan.profit)),
                  _infoRow('Daily Installment', CalculationService.formatCurrency(loan.dailyInstallment)),
                  _infoRow('Start Date', CalculationService.formatDate(loan.startDate)),
                  _infoRow('Total Days', '${loan.totalDays}'),
                  _infoRow('Mode', AppConstants.interestModeNames[loan.interestMode.index]),
                  const Divider(),
                  // Monthly rate prominent, yearly optional
                  Row(
                    children: [
                      Expanded(
                        child: Container(
                          padding: const EdgeInsets.all(8),
                          decoration: BoxDecoration(color: Colors.blue.withAlpha(20), borderRadius: BorderRadius.circular(8)),
                          child: Column(
                            children: [
                              const Text('Monthly Rate', style: TextStyle(fontSize: 11, color: Colors.grey)),
                              Text('${monthlyRate.toStringAsFixed(2)}%', style: const TextStyle(fontSize: 18, fontWeight: FontWeight.bold, color: Colors.blue)),
                            ],
                          ),
                        ),
                      ),
                      const SizedBox(width: 8),
                      Expanded(
                        child: Container(
                          padding: const EdgeInsets.all(8),
                          decoration: BoxDecoration(color: Colors.purple.withAlpha(20), borderRadius: BorderRadius.circular(8)),
                          child: Column(
                            children: [
                              const Text('Yearly Rate', style: TextStyle(fontSize: 11, color: Colors.grey)),
                              Text('${yearlyRate.toStringAsFixed(2)}%', style: const TextStyle(fontSize: 16, fontWeight: FontWeight.bold, color: Colors.purple)),
                            ],
                          ),
                        ),
                      ),
                    ],
                  ),
                  const SizedBox(height: 8),
                  LinearProgressIndicator(
                    value: loan.totalDays > 0 ? _paidDays / loan.totalDays : 0,
                    minHeight: 8,
                    borderRadius: BorderRadius.circular(4),
                  ),
                  const SizedBox(height: 4),
                  _infoRow('Collected', CalculationService.formatCurrency(_totalCollected)),
                  _infoRow('Remaining', CalculationService.formatCurrency(remaining)),
                  _infoRow('Progress', '${(_paidDays / loan.totalDays * 100).toStringAsFixed(1)}% ($_paidDays/${loan.totalDays} days)'),
                ],
              ),
            ),
          ),

          // Sort dropdown
          Padding(
            padding: const EdgeInsets.symmetric(horizontal: 8),
            child: Row(
              children: [
                const Text('Sort: '),
                Expanded(
                  child: DropdownButton<ScheduleSortOrder>(
                    value: _sortOrder,
                    isExpanded: true,
                    items: ScheduleSortOrder.values.map((s) => DropdownMenuItem(value: s, child: Text(AppConstants.sortOrderNames[s.index]))).toList(),
                    onChanged: (v) { setState(() { _sortOrder = v!; _schedule = _scheduleService.sortEntries(_schedule, _sortOrder); }); },
                  ),
                ),
              ],
            ),
          ),

          // Schedule list
          Expanded(
            child: ListView.builder(
              itemCount: _schedule.length,
              itemBuilder: (context, index) {
                final entry = _schedule[index];
                return ScheduleEntryTile(
                  entry: entry,
                  onTap: () => _showCollectDialog(entry),
                );
              },
            ),
          ),
        ],
      ),
      floatingActionButton: FloatingActionButton.extended(
        onPressed: () => _showCollectDialog(_schedule.where((e) => e.isPending || e.isPartial).firstOrNull ?? _schedule.first),
        icon: const Icon(Icons.payment),
        label: const Text('Collect'),
      ),
    );
  }

  Widget _infoRow(String label, String value) {
    return Padding(
      padding: const EdgeInsets.symmetric(vertical: 2),
      child: Row(
        mainAxisAlignment: MainAxisAlignment.spaceBetween,
        children: [
          Text(label, style: TextStyle(fontSize: 13, color: Colors.grey[600])),
          Text(value, style: const TextStyle(fontSize: 13, fontWeight: FontWeight.w600)),
        ],
      ),
    );
  }

  void _showCollectDialog(ScheduleEntry entry) {
    final amountController = TextEditingController(text: entry.expectedAmount.toStringAsFixed(0));
    PaymentMode selectedMode = PaymentMode.cash;

    showDialog(
      context: context,
      builder: (ctx) => AlertDialog(
        title: Text('Day ${entry.dayNumber} - ${CalculationService.formatDate(entry.entryDate)}'),
        content: Column(
          mainAxisSize: MainAxisSize.min,
          children: [
            Text('Expected: ${CalculationService.formatCurrency(entry.expectedAmount)}'),
            if (entry.isPartial) Text('Already Paid: ${CalculationService.formatCurrency(entry.collectedAmount)}'),
            const SizedBox(height: 12),
            TextField(
              controller: amountController,
              decoration: const InputDecoration(labelText: 'Amount', border: OutlineInputBorder()),
              keyboardType: TextInputType.number,
            ),
            const SizedBox(height: 12),
            DropdownButtonFormField<PaymentMode>(
              value: selectedMode,
              decoration: const InputDecoration(labelText: 'Payment Mode', border: OutlineInputBorder()),
              items: PaymentMode.values.map((m) => DropdownMenuItem(value: m, child: Text(AppConstants.paymentModes[m.index]))).toList(),
              onChanged: (v) => selectedMode = v!,
            ),
          ],
        ),
        actions: [
          TextButton(onPressed: () => Navigator.pop(ctx), child: const Text('Cancel')),
          FilledButton(
            onPressed: () async {
              final amount = double.tryParse(amountController.text) ?? 0;
              if (amount > 0) {
                await _scheduleService.recordCollection(
                  entry: entry,
                  amount: amount,
                  paymentMode: selectedMode,
                  customerId: _loan!.customerId,
                );

                // Show receipt options
                if (mounted) {
                  Navigator.pop(ctx);
                  _showReceiptDialog(entry, amount, selectedMode);
                }
              }
            },
            child: const Text('Collect'),
          ),
        ],
      ),
    );
  }

  void _showReceiptDialog(ScheduleEntry entry, double amount, PaymentMode mode) async {
    final totalCollected = await _collectionDao.getTotalCollected(_loan!.id!);
    final remaining = _loan!.returnAmount - totalCollected;

    showDialog(
      context: context,
      builder: (ctx) => AlertDialog(
        title: const Text('Payment Receipt'),
        content: Column(
          mainAxisSize: MainAxisSize.min,
          children: [
            Text('Amount: ${CalculationService.formatCurrency(amount)}'),
            Text('Day: ${entry.dayNumber}/${_loan!.totalDays}'),
            Text('Total Collected: ${CalculationService.formatCurrency(totalCollected)}'),
            Text('Remaining: ${CalculationService.formatCurrency(remaining)}'),
          ],
        ),
        actions: [
          TextButton(onPressed: () => Navigator.pop(ctx), child: const Text('Close')),
          TextButton(
            onPressed: () async {
              await _backupService.sharePdfReceipt(
                customer: _customer!,
                loan: _loan!,
                amount: amount,
                dayNumber: entry.dayNumber,
                totalCollected: totalCollected,
                remaining: remaining,
                paymentMode: mode.name,
              );
            },
            child: const Text('Share PDF'),
          ),
          TextButton(
            onPressed: () async {
              final message = _smsService.buildPaymentReceipt(
                customer: _customer!,
                loan: _loan!,
                collection: CollectionEntry(
                  scheduleEntryId: entry.id!,
                  loanId: _loan!.id!,
                  customerId: _loan!.customerId,
                  collectedDate: DateTime.now(),
                  amount: amount,
                  paymentMode: mode,
                ),
                dayNumber: entry.dayNumber,
                totalCollected: totalCollected,
                remaining: remaining,
              );
              await _smsService.sendSms(to: _customer!.mobile, message: message, loanId: _loan!.id, customerId: _customer!.id);
              if (mounted) Navigator.pop(ctx);
            },
            child: const Text('SMS'),
          ),
          TextButton(
            onPressed: () async {
              final message = _smsService.buildPaymentReceipt(
                customer: _customer!,
                loan: _loan!,
                collection: CollectionEntry(
                  scheduleEntryId: entry.id!,
                  loanId: _loan!.id!,
                  customerId: _loan!.customerId,
                  collectedDate: DateTime.now(),
                  amount: amount,
                  paymentMode: mode,
                ),
                dayNumber: entry.dayNumber,
                totalCollected: totalCollected,
                remaining: remaining,
              );
              await _backupService.shareToWhatsApp(message);
            },
            child: const Text('WhatsApp'),
          ),
        ],
      ),
    );
    _loadData();
  }

  void _handleMenuAction(String action) async {
    switch (action) {
      case 'calendar':
        Navigator.push(context, MaterialPageRoute(builder: (_) => CalendarScreen(loanId: _loan!.id!)));
        break;
      case 'collections':
        Navigator.push(context, MaterialPageRoute(builder: (_) => CollectionListScreen(loanId: _loan!.id!)));
        break;
      case 'sms_history':
        Navigator.push(context, MaterialPageRoute(builder: (_) => SmsHistoryScreen(loanId: _loan!.id!)));
        break;
      case 'summary_pdf':
        await _backupService.sharePdfLoanSummary(
          customer: _customer!,
          loan: _loan!,
          totalCollected: _totalCollected,
          paidDays: _paidDays,
        );
        break;
      case 'summary_whatsapp':
        final message = _smsService.buildSummary(
          customer: _customer!,
          loan: _loan!,
          totalCollected: _totalCollected,
          remaining: _loan!.returnAmount - _totalCollected,
          paidDays: _paidDays,
        );
        await _backupService.shareToWhatsApp(message);
        break;
      case 'outstanding':
        final outstanding = CalculationService.calcOutstandingAtDate(_loan!, _totalCollected, DateTime.now());
        final outstandingWithInterest = CalculationService.calcOutstandingWithInterest(_loan!, _totalCollected, DateTime.now());
        await _backupService.sharePdfOutstandingSnapshot(
          customer: _customer!,
          loan: _loan!,
          totalCollected: _totalCollected,
          outstanding: outstanding,
          outstandingWithInterest: outstandingWithInterest,
          asOfDate: DateTime.now(),
        );
        break;
      case 'renew':
        _showRenewDialog();
        break;
      case 'pre_close':
        Navigator.push(context, MaterialPageRoute(builder: (_) => PreCloseScreen(loanId: _loan!.id!))).then((_) => _loadData());
        break;
      case 'cancel':
        final confirm = await showDialog<bool>(
          context: context,
          builder: (ctx) => AlertDialog(
            title: const Text('Cancel Loan'),
            content: const Text('Are you sure you want to cancel this loan?'),
            actions: [TextButton(onPressed: () => Navigator.pop(ctx, false), child: const Text('No')), TextButton(onPressed: () => Navigator.pop(ctx, true), child: const Text('Yes'))],
          ),
        );
        if (confirm == true) {
          await _scheduleService.cancelLoan(_loan!.id!, _loan!.customerId);
          _loadData();
        }
        break;
      case 'delete':
        final confirm = await showDialog<bool>(
          context: context,
          builder: (ctx) => AlertDialog(
            title: const Text('Delete Loan'),
            content: const Text('This will permanently delete the loan and all related data.'),
            actions: [TextButton(onPressed: () => Navigator.pop(ctx, false), child: const Text('Cancel')), TextButton(onPressed: () => Navigator.pop(ctx, true), child: const Text('Delete', style: TextStyle(color: Colors.red)))],
          ),
        );
        if (confirm == true) {
          await _loanDao.delete(_loan!.id!);
          if (mounted) Navigator.pop(context);
        }
        break;
    }
  }

  void _showRenewDialog() {
    final newPrincipalController = TextEditingController(text: _loan!.principal.toStringAsFixed(0));
    final newReturnController = TextEditingController(text: _loan!.returnAmount.toStringAsFixed(0));
    final newDailyController = TextEditingController(text: _loan!.dailyInstallment.toStringAsFixed(0));

    showDialog(
      context: context,
      builder: (ctx) => AlertDialog(
        title: const Text('Renew Loan'),
        content: Column(
          mainAxisSize: MainAxisSize.min,
          children: [
            Text('Renew from Loan #${_loan!.id}', style: TextStyle(color: Colors.grey[600])),
            const SizedBox(height: 12),
            TextField(controller: newPrincipalController, decoration: const InputDecoration(labelText: 'New Principal', border: OutlineInputBorder()), keyboardType: TextInputType.number),
            const SizedBox(height: 8),
            TextField(controller: newReturnController, decoration: const InputDecoration(labelText: 'New Return Amount', border: OutlineInputBorder()), keyboardType: TextInputType.number),
            const SizedBox(height: 8),
            TextField(controller: newDailyController, decoration: const InputDecoration(labelText: 'New Daily Installment', border: OutlineInputBorder()), keyboardType: TextInputType.number),
          ],
        ),
        actions: [
          TextButton(onPressed: () => Navigator.pop(ctx), child: const Text('Cancel')),
          FilledButton(
            onPressed: () async {
              final p = double.tryParse(newPrincipalController.text) ?? 0;
              final r = double.tryParse(newReturnController.text) ?? 0;
              final d = double.tryParse(newDailyController.text) ?? 0;
              if (p > 0 && r > 0 && d > 0) {
                final days = (r / d).ceil();
                await _scheduleService.renewLoan(
                  oldLoanId: _loan!.id!,
                  newPrincipal: p,
                  newReturnAmount: r,
                  newDailyInstallment: d,
                  newStartDate: DateTime.now(),
                  newTotalDays: days,
                );
                if (mounted) Navigator.pop(ctx);
                _loadData();
              }
            },
            child: const Text('Renew'),
          ),
        ],
      ),
    );
  }
}
