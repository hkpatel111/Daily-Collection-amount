import 'package:flutter/material.dart';
import '../database/dao/schedule_dao.dart';
import '../database/dao/loan_dao.dart';
import '../database/dao/collection_dao.dart';
import '../models/schedule_entry.dart';
import '../models/loan.dart';
import '../models/collection_entry.dart';
import '../services/calculation_service.dart';
import '../services/schedule_service.dart';
import '../services/backup_service.dart';
import '../utils/constants.dart';

class DailyCollectionScreen extends StatefulWidget {
  const DailyCollectionScreen({super.key});

  @override
  State<DailyCollectionScreen> createState() => _DailyCollectionScreenState();
}

class _DailyCollectionScreenState extends State<DailyCollectionScreen> {
  final ScheduleDao _scheduleDao = ScheduleDao();
  final LoanDao _loanDao = LoanDao();
  final CollectionDao _collectionDao = CollectionDao();
  final ScheduleService _scheduleService = ScheduleService();
  final BackupService _backupService = BackupService();

  List<ScheduleEntry> _pending = [];
  List<Loan> _loans = [];
  double _todayCollected = 0;

  @override
  void initState() {
    super.initState();
    _loadData();
  }

  Future<void> _loadData() async {
    final today = DateTime.now();
    final pending = await _scheduleDao.getPendingForDate(DateTime(today.year, today.month, today.day));
    final loans = await _loanDao.getAll(statusFilter: LoanStatus.active);
    final todayCollected = await _collectionDao.getTotalCollectedByDate(today);

    final loanIds = loans.map((l) => l.id).toSet();
    final filtered = pending.where((e) => loanIds.contains(e.loanId) && !e.isSunday).toList();

    setState(() {
      _pending = filtered;
      _loans = loans;
      _todayCollected = todayCollected;
    });
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text('Daily Collection'),
        actions: [
          IconButton(
            icon: const Icon(Icons.share),
            onPressed: () async {
              final collections = await _collectionDao.getByDateWithDetails(DateTime.now());
              await _backupService.sharePdfDailySummary(
                date: DateTime.now(),
                totalCollected: _todayCollected,
                collections: collections,
              );
            },
          ),
        ],
      ),
      body: Column(
        children: [
          Card(
            margin: const EdgeInsets.all(8),
            child: Padding(
              padding: const EdgeInsets.all(12),
              child: Row(
                mainAxisAlignment: MainAxisAlignment.spaceAround,
                children: [
                  Column(
                    children: [
                      Text(CalculationService.formatDate(DateTime.now()), style: const TextStyle(fontSize: 12, color: Colors.grey)),
                      const Text('Today', style: TextStyle(fontSize: 16, fontWeight: FontWeight.bold)),
                      Text(CalculationService.formatCurrency(_todayCollected), style: const TextStyle(fontSize: 18, fontWeight: FontWeight.bold, color: Colors.green)),
                    ],
                  ),
                  Column(
                    children: [
                      Text('${_pending.length}', style: const TextStyle(fontSize: 24, fontWeight: FontWeight.bold, color: Colors.orange)),
                      const Text('Pending', style: TextStyle(fontSize: 12, color: Colors.grey)),
                    ],
                  ),
                ],
              ),
            ),
          ),
          Expanded(
            child: _pending.isEmpty
                ? const Center(child: Text('All collections done for today!', style: TextStyle(fontSize: 16)))
                : ListView.builder(
                    itemCount: _pending.length,
                    itemBuilder: (context, index) {
                      final entry = _pending[index];
                      final loan = _loans.where((l) => l.id == entry.loanId).firstOrNull;
                      return Card(
                        margin: const EdgeInsets.symmetric(horizontal: 8, vertical: 3),
                        child: ListTile(
                          leading: CircleAvatar(backgroundColor: Colors.orange.withAlpha(30), child: const Icon(Icons.pending_actions, color: Colors.orange)),
                          title: Text(loan != null ? 'Loan #${loan.id} - Day ${entry.dayNumber}' : 'Day ${entry.dayNumber}'),
                          subtitle: Text('${CalculationService.formatCurrency(entry.expectedAmount)} - ${CalculationService.formatDate(entry.entryDate)}'),
                          trailing: Row(
                            mainAxisSize: MainAxisSize.min,
                            children: [
                              if (entry.isPartial) Text('Paid: ${CalculationService.formatCurrencyShort(entry.collectedAmount)}', style: TextStyle(fontSize: 11, color: Colors.orange[700])),
                              IconButton(
                                icon: const Icon(Icons.check_circle, color: Colors.green),
                                onPressed: () => _markPaid(entry, loan),
                              ),
                            ],
                          ),
                          onTap: () => _markPaid(entry, loan),
                        ),
                      );
                    },
                  ),
          ),
        ],
      ),
      floatingActionButton: FloatingActionButton.extended(
        onPressed: _bulkMarkAll,
        icon: const Icon(Icons.done_all),
        label: const Text('Mark All Paid'),
      ),
    );
  }

  Future<void> _markPaid(ScheduleEntry entry, Loan? loan) async {
    if (loan == null) return;
    await _scheduleService.recordCollection(
      entry: entry,
      amount: entry.expectedAmount,
      paymentMode: PaymentMode.cash,
      customerId: loan.customerId,
    );
    _loadData();
  }

  Future<void> _bulkMarkAll() async {
    for (final entry in _pending) {
      final loan = _loans.where((l) => l.id == entry.loanId).firstOrNull;
      if (loan != null) {
        await _scheduleService.bulkMarkPaidForDate(entry.loanId, loan.customerId, DateTime.now(), PaymentMode.cash);
      }
    }
    _loadData();
  }
}
