import 'package:flutter/material.dart';
import '../database/dao/schedule_dao.dart';
import '../models/schedule_entry.dart';
import '../services/calculation_service.dart';

class CalendarScreen extends StatefulWidget {
  final int loanId;

  const CalendarScreen({super.key, required this.loanId});

  @override
  State<CalendarScreen> createState() => _CalendarScreenState();
}

class _CalendarScreenState extends State<CalendarScreen> {
  final ScheduleDao _scheduleDao = ScheduleDao();
  List<ScheduleEntry> _entries = [];
  DateTime _selectedMonth = DateTime.now();

  @override
  void initState() {
    super.initState();
    _loadData();
  }

  Future<void> _loadData() async {
    final entries = await _scheduleDao.getByLoan(widget.loanId);
    setState(() => _entries = entries);
  }

  @override
  Widget build(BuildContext context) {
    final monthEntries = _entries.where((e) => e.entryDate.month == _selectedMonth.month && e.entryDate.year == _selectedMonth.year).toList();

    return Scaffold(
      appBar: AppBar(
        title: Text('${_selectedMonth.year}-${_selectedMonth.month.toString().padLeft(2, '0')}'),
        actions: [
          IconButton(icon: const Icon(Icons.chevron_left), onPressed: () => setState(() => _selectedMonth = DateTime(_selectedMonth.year, _selectedMonth.month - 1))),
          IconButton(icon: const Icon(Icons.chevron_right), onPressed: () => setState(() => _selectedMonth = DateTime(_selectedMonth.year, _selectedMonth.month + 1))),
        ],
      ),
      body: GridView.builder(
        padding: const EdgeInsets.all(8),
        gridDelegate: const SliverGridDelegateWithFixedCrossAxisCount(crossAxisCount: 7, childAspectRatio: 0.8),
        itemCount: _getDaysInMonth(_selectedMonth.year, _selectedMonth.month) + _getFirstWeekday(_selectedMonth),
        itemBuilder: (context, index) {
          final firstWeekday = _getFirstWeekday(_selectedMonth);
          if (index < firstWeekday) return const SizedBox();

          final day = index - firstWeekday + 1;
          final date = DateTime(_selectedMonth.year, _selectedMonth.month, day);
          final entry = monthEntries.where((e) => e.entryDate.day == day).firstOrNull;

          Color bgColor = Colors.grey.shade100;
          if (entry != null) {
            switch (entry.status) {
              case ScheduleEntryStatus.paid: bgColor = Colors.green.shade100; break;
              case ScheduleEntryStatus.pending: bgColor = Colors.blue.shade100; break;
              case ScheduleEntryStatus.missed: bgColor = Colors.red.shade100; break;
              case ScheduleEntryStatus.partial: bgColor = Colors.orange.shade100; break;
              case ScheduleEntryStatus.holiday: bgColor = Colors.purple.shade100; break;
              case ScheduleEntryStatus.overdue: bgColor = Colors.red.shade200; break;
            }
          }

          return Container(
            margin: const EdgeInsets.all(2),
            decoration: BoxDecoration(color: bgColor, borderRadius: BorderRadius.circular(4)),
            child: Column(
              mainAxisAlignment: MainAxisAlignment.center,
              children: [
                Text('$day', style: const TextStyle(fontSize: 10)),
                if (entry != null)
                  Text(CalculationService.formatCurrencyShort(entry.expectedAmount), style: const TextStyle(fontSize: 8)),
              ],
            ),
          );
        },
      ),
    );
  }

  int _getDaysInMonth(int year, int month) => DateTime(year, month + 1, 0).day;
  int _getFirstWeekday(DateTime date) => DateTime(date.year, date.month, 1).weekday - 1;
}
