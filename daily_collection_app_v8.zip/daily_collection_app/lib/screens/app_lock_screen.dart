import 'package:flutter/material.dart';
import '../database/dao/settings_dao.dart';
import '../utils/constants.dart';

class AppLockScreen extends StatefulWidget {
  final VoidCallback onUnlock;

  const AppLockScreen({super.key, required this.onUnlock});

  @override
  State<AppLockScreen> createState() => _AppLockScreenState();
}

class _AppLockScreenState extends State<AppLockScreen> {
  final SettingsDao _settingsDao = SettingsDao();
  String _enteredPin = '';
  String? _error;
  int _attempts = 0;

  void _addDigit(String digit) {
    if (_enteredPin.length < 4) {
      setState(() {
        _enteredPin += digit;
        _error = null;
      });
      if (_enteredPin.length == 4) {
        _verifyPin();
      }
    }
  }

  void _removeDigit() {
    if (_enteredPin.isNotEmpty) {
      setState(() {
        _enteredPin = _enteredPin.substring(0, _enteredPin.length - 1);
        _error = null;
      });
    }
  }

  Future<void> _verifyPin() async {
    final settings = await _settingsDao.getSettings();
    if (_enteredPin == settings.appPin) {
      widget.onUnlock();
    } else {
      setState(() {
        _attempts++;
        _enteredPin = '';
        _error = 'Wrong PIN. ${5 - _attempts} attempts left.';
      });
      if (_attempts >= 5) {
        _showRecoveryDialog(settings.securityQuestion, settings.securityAnswer);
      }
    }
  }

  void _showRecoveryDialog(String? question, String? answer) {
    final answerController = TextEditingController();

    showDialog(
      context: context,
      barrierDismissible: false,
      builder: (ctx) => AlertDialog(
        title: const Text('PIN Recovery'),
        content: Column(
          mainAxisSize: MainAxisSize.min,
          children: [
            Text(question ?? 'No security question set. Please reinstall app and restore from backup.'),
            if (question != null) ...[
              const SizedBox(height: 12),
              TextField(
                controller: answerController,
                decoration: const InputDecoration(labelText: 'Answer', border: OutlineInputBorder()),
              ),
            ],
          ],
        ),
        actions: [
          if (question == null)
            TextButton(onPressed: () => Navigator.pop(ctx), child: const Text('OK')),
          if (question != null) ...[
            TextButton(
              onPressed: () {
                Navigator.pop(ctx);
                setState(() {
                  _attempts = 0;
                  _enteredPin = '';
                  _error = 'Please try your PIN again.';
                });
              },
              child: const Text('Try Again'),
            ),
            FilledButton(
              onPressed: () {
                if (answer != null && answerController.text.trim().toLowerCase() == answer.trim().toLowerCase()) {
                  Navigator.pop(ctx);
                  widget.onUnlock();
                } else {
                  ScaffoldMessenger.of(ctx).showSnackBar(const SnackBar(content: Text('Wrong answer')));
                }
              },
              child: const Text('Verify'),
            ),
          ],
        ],
      ),
    );
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: SafeArea(
        child: Center(
          child: Column(
            mainAxisAlignment: MainAxisAlignment.center,
            children: [
              const Icon(Icons.lock, size: 64, color: Colors.blue),
              const SizedBox(height: 16),
              const Text('Daily Collection App', style: TextStyle(fontSize: 20, fontWeight: FontWeight.bold)),
              const SizedBox(height: 8),
              const Text('Enter PIN to unlock', style: TextStyle(color: Colors.grey)),
              const SizedBox(height: 24),

              // PIN dots
              Row(
                mainAxisAlignment: MainAxisAlignment.center,
                children: List.generate(4, (index) {
                  final filled = index < _enteredPin.length;
                  return Container(
                    margin: const EdgeInsets.symmetric(horizontal: 8),
                    width: 20,
                    height: 20,
                    decoration: BoxDecoration(
                      shape: BoxShape.circle,
                      color: filled ? Colors.blue : Colors.transparent,
                      border: Border.all(color: Colors.blue, width: 2),
                    ),
                  );
                }),
              ),

              if (_error != null) ...[
                const SizedBox(height: 16),
                Text(_error!, style: const TextStyle(color: Colors.red, fontSize: 13)),
              ],

              const SizedBox(height: 24),

              // Number pad
              SizedBox(
                width: 240,
                child: GridView.count(
                  shrinkWrap: true,
                  crossAxisCount: 3,
                  mainAxisSpacing: 12,
                  crossAxisSpacing: 12,
                  childAspectRatio: 1.5,
                  children: [
                    for (int i = 1; i <= 9; i++)
                      _buildKey('$i'),
                    _buildKey('', enabled: false),
                    _buildKey('0'),
                    _buildKey('back', isBack: true),
                  ],
                ),
              ),

              if (_attempts >= 3)
                TextButton(
                  onPressed: () async {
                    final settings = await _settingsDao.getSettings();
                    _showRecoveryDialog(settings.securityQuestion, settings.securityAnswer);
                  },
                  child: const Text('Forgot PIN?'),
                ),

              const SizedBox(height: 20),
              Text(AppConstants.createdBy, style: TextStyle(fontSize: 11, color: Colors.grey[400])),
            ],
          ),
        ),
      ),
    );
  }

  Widget _buildKey(String digit, {bool enabled = true, bool isBack = false}) {
    return InkWell(
      onTap: enabled ? (isBack ? _removeDigit : () => _addDigit(digit)) : null,
      borderRadius: BorderRadius.circular(40),
      child: Container(
        decoration: BoxDecoration(
          shape: BoxShape.circle,
          border: Border.all(color: Colors.grey.shade300),
        ),
        child: Center(
          child: isBack
              ? const Icon(Icons.backspace, color: Colors.grey)
              : Text(digit, style: const TextStyle(fontSize: 24, fontWeight: FontWeight.w500)),
        ),
      ),
    );
  }
}
