import 'package:flutter/material.dart';
import '../database/dao/sms_log_dao.dart';
import '../services/sms_service.dart';
import '../services/calculation_service.dart';
import '../models/sms_log.dart';

class SmsHistoryScreen extends StatefulWidget {
  final int? loanId;

  const SmsHistoryScreen({super.key, this.loanId});

  @override
  State<SmsHistoryScreen> createState() => _SmsHistoryScreenState();
}

class _SmsHistoryScreenState extends State<SmsHistoryScreen> {
  final SmsLogDao _smsLogDao = SmsLogDao();
  final SmsService _smsService = SmsService();
  List<Map<String, dynamic>> _logs = [];

  @override
  void initState() {
    super.initState();
    _loadLogs();
  }

  Future<void> _loadLogs() async {
    final logs = widget.loanId != null ? await _smsLogDao.getByLoan(widget.loanId!) : await _smsLogDao.getAll();
    setState(() => _logs = logs);
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: const Text('SMS History')),
      body: _logs.isEmpty
          ? const Center(child: Text('No SMS sent yet'))
          : ListView.builder(
              itemCount: _logs.length,
              itemBuilder: (context, index) {
                final log = _logs[index];
                final status = SmsStatus.values[log['status'] as int];
                return Card(
                  margin: const EdgeInsets.symmetric(horizontal: 8, vertical: 3),
                  child: ListTile(
                    leading: Icon(status == SmsStatus.sent ? Icons.check_circle : Icons.error, color: status == SmsStatus.sent ? Colors.green : Colors.red),
                    title: Text(log['recipient'] as String, style: const TextStyle(fontWeight: FontWeight.w600)),
                    subtitle: Column(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: [
                        Text(log['message'] as String, maxLines: 2, overflow: TextOverflow.ellipsis, style: const TextStyle(fontSize: 12)),
                        Text(CalculationService.formatDateTime(DateTime.parse(log['sent_at'] as String)), style: const TextStyle(fontSize: 10, color: Colors.grey)),
                      ],
                    ),
                    trailing: status == SmsStatus.failed
                        ? TextButton(onPressed: () async {
                            await _smsService.sendSms(to: log['recipient'] as String, message: log['message'] as String);
                            _loadLogs();
                          }, child: const Text('Resend'))
                        : null,
                  ),
                );
              },
            ),
    );
  }
}
