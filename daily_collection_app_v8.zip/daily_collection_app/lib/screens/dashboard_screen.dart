import 'package:flutter/material.dart';
import '../database/dao/loan_dao.dart';
import '../database/dao/customer_dao.dart';
import '../database/dao/collection_dao.dart';
import '../database/dao/settings_dao.dart';
import '../services/calculation_service.dart';
import '../services/notification_service.dart';
import '../utils/constants.dart';
import '../widgets/stat_card.dart';
import 'customer_list_screen.dart';
import 'loan_list_screen.dart';
import 'daily_collection_screen.dart';
import 'search_screen.dart';
import 'calculators_screen.dart';
import 'transaction_log_screen.dart';
import 'settings_screen.dart';

class DashboardScreen extends StatefulWidget {
  const DashboardScreen({super.key});

  @override
  State<DashboardScreen> createState() => _DashboardScreenState();
}

class _DashboardScreenState extends State<DashboardScreen> {
  final LoanDao _loanDao = LoanDao();
  final CustomerDao _customerDao = CustomerDao();
  final CollectionDao _collectionDao = CollectionDao();
  final SettingsDao _settingsDao = SettingsDao();
  final NotificationService _notifService = NotificationService();

  Map<String, double> _aggregates = {};
  int _customerCount = 0;
  double _todayCollected = 0;
  List<Map<String, dynamic>> _alerts = [];

  @override
  void initState() {
    super.initState();
    _loadData();
  }

  Future<void> _loadData() async {
    final aggregates = await _loanDao.getAggregates();
    final customerCount = await _customerDao.count();
    final todayCollected = await _collectionDao.getTotalCollectedByDate(DateTime.now());
    final alerts = await _notifService.getDashboardAlerts();

    setState(() {
      _aggregates = aggregates;
      _customerCount = customerCount;
      _todayCollected = todayCollected;
      _alerts = alerts;
    });
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text(AppConstants.appName),
        actions: [
          IconButton(icon: const Icon(Icons.search), onPressed: () => Navigator.push(context, MaterialPageRoute(builder: (_) => const SearchScreen()))),
          IconButton(icon: const Icon(Icons.settings), onPressed: () => Navigator.push(context, MaterialPageRoute(builder: (_) => const SettingsScreen())).then((_) => _loadData())),
        ],
      ),
      body: RefreshIndicator(
        onRefresh: _loadData,
        child: ListView(
          padding: const EdgeInsets.all(8),
          children: [
            // Stats Grid
            GridView.count(
              shrinkWrap: true,
              physics: const NeverScrollableScrollPhysics(),
              crossAxisCount: 3,
              childAspectRatio: 0.8,
              mainAxisSpacing: 4,
              crossAxisSpacing: 4,
              children: [
                StatCard(
                  title: 'Total Loans',
                  value: '${_aggregates['activeCount']?.toInt() ?? 0}',
                  icon: Icons.account_balance,
                  color: Colors.blue,
                  onTap: () => Navigator.push(context, MaterialPageRoute(builder: (_) => const LoanListScreen())),
                ),
                StatCard(
                  title: 'Customers',
                  value: '$_customerCount',
                  icon: Icons.people,
                  color: Colors.green,
                  onTap: () => Navigator.push(context, MaterialPageRoute(builder: (_) => const CustomerListScreen())),
                ),
                StatCard(
                  title: 'Invested',
                  value: CalculationService.formatCurrencyShort(_aggregates['totalPrincipal'] ?? 0),
                  icon: Icons.currency_rupee,
                  color: Colors.purple,
                ),
                StatCard(
                  title: 'Total Return',
                  value: CalculationService.formatCurrencyShort(_aggregates['totalReturn'] ?? 0),
                  icon: Icons.trending_up,
                  color: Colors.teal,
                ),
                StatCard(
                  title: 'Overdue',
                  value: '${_aggregates['overdueCount']?.toInt() ?? 0}',
                  icon: Icons.warning,
                  color: Colors.red,
                  onTap: () => Navigator.push(context, MaterialPageRoute(builder: (_) => const LoanListScreen())),
                ),
                StatCard(
                  title: 'Today',
                  value: CalculationService.formatCurrencyShort(_todayCollected),
                  icon: Icons.today,
                  color: Colors.orange,
                  onTap: () => Navigator.push(context, MaterialPageRoute(builder: (_) => const DailyCollectionScreen())),
                ),
              ],
            ),
            const SizedBox(height: 12),

            // Alerts
            if (_alerts.isNotEmpty) ...[
              const Padding(
                padding: EdgeInsets.symmetric(horizontal: 8, vertical: 4),
                child: Text('Alerts', style: TextStyle(fontSize: 18, fontWeight: FontWeight.bold)),
              ),
              ..._alerts.map((alert) => Card(
                child: ListTile(
                  leading: Icon(_getAlertIcon(alert['type']), color: Color(alert['color'] as int)),
                  title: Text(alert['title'] as String),
                  trailing: CircleAvatar(
                    backgroundColor: Color(alert['color'] as int).withAlpha(30),
                    child: Text('${alert['count']}', style: TextStyle(color: Color(alert['color'] as int), fontWeight: FontWeight.bold)),
                  ),
                  onTap: () => _navigateToAlert(alert['type'] as String),
                ),
              )),
              const SizedBox(height: 12),
            ],

            // Quick Actions
            const Padding(
              padding: EdgeInsets.symmetric(horizontal: 8, vertical: 4),
              child: Text('Quick Actions', style: TextStyle(fontSize: 18, fontWeight: FontWeight.bold)),
            ),
            Wrap(
              spacing: 8,
              runSpacing: 8,
              children: [
                ActionChip(label: const Text('Daily Collection'), avatar: const Icon(Icons.today), onPressed: () => Navigator.push(context, MaterialPageRoute(builder: (_) => const DailyCollectionScreen()))),
                ActionChip(label: const Text('Customers'), avatar: const Icon(Icons.people), onPressed: () => Navigator.push(context, MaterialPageRoute(builder: (_) => const CustomerListScreen()))),
                ActionChip(label: const Text('Loans'), avatar: const Icon(Icons.account_balance), onPressed: () => Navigator.push(context, MaterialPageRoute(builder: (_) => const LoanListScreen()))),
                ActionChip(label: const Text('Calculators'), avatar: const Icon(Icons.calculate), onPressed: () => Navigator.push(context, MaterialPageRoute(builder: (_) => const CalculatorsScreen()))),
                ActionChip(label: const Text('Transaction Log'), avatar: const Icon(Icons.history), onPressed: () => Navigator.push(context, MaterialPageRoute(builder: (_) => const TransactionLogScreen()))),
                ActionChip(label: const Text('Search'), avatar: const Icon(Icons.search), onPressed: () => Navigator.push(context, MaterialPageRoute(builder: (_) => const SearchScreen()))),
              ],
            ),
            const SizedBox(height: 20),
            Center(
              child: Text(
                AppConstants.createdBy,
                style: TextStyle(fontSize: 12, color: Colors.grey[500]),
              ),
            ),
            const SizedBox(height: 8),
          ],
        ),
      ),
    );
  }

  IconData _getAlertIcon(String type) {
    switch (type) {
      case 'overdue': return Icons.warning;
      case 'missed': return Icons.error;
      case 'pending_today': return Icons.schedule;
      case 'completed': return Icons.check_circle;
      case 'defaulted': return Icons.cancel;
      default: return Icons.info;
    }
  }

  void _navigateToAlert(String type) {
    switch (type) {
      case 'overdue':
      case 'defaulted':
        Navigator.push(context, MaterialPageRoute(builder: (_) => const LoanListScreen()));
        break;
      case 'pending_today':
      case 'missed':
        Navigator.push(context, MaterialPageRoute(builder: (_) => const DailyCollectionScreen()));
        break;
      case 'completed':
        Navigator.push(context, MaterialPageRoute(builder: (_) => const LoanListScreen()));
        break;
    }
  }
}
