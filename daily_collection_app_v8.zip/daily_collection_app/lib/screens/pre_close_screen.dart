import 'package:flutter/material.dart';
import '../database/dao/loan_dao.dart';
import '../database/dao/collection_dao.dart';
import '../models/loan.dart';
import '../services/calculation_service.dart';
import '../services/schedule_service.dart';
import '../services/sms_service.dart';
import '../database/dao/customer_dao.dart';

class PreCloseScreen extends StatefulWidget {
  final int loanId;

  const PreCloseScreen({super.key, required this.loanId});

  @override
  State<PreCloseScreen> createState() => _PreCloseScreenState();
}

class _PreCloseScreenState extends State<PreCloseScreen> {
  final LoanDao _loanDao = LoanDao();
  final CollectionDao _collectionDao = CollectionDao();
  final ScheduleService _scheduleService = ScheduleService();
  final SmsService _smsService = SmsService();
  final CustomerDao _customerDao = CustomerDao();

  Loan? _loan;
  double _totalCollected = 0;
  double _payable = 0;

  @override
  void initState() {
    super.initState();
    _loadData();
  }

  Future<void> _loadData() async {
    final loan = await _loanDao.getById(widget.loanId);
    final collected = await _collectionDao.getTotalCollected(widget.loanId);

    // Payable = remaining expected - collected
    final remaining = loan!.returnAmount - collected;
    final outstanding = CalculationService.calcOutstandingWithInterest(loan, collected, DateTime.now());

    setState(() {
      _loan = loan;
      _totalCollected = collected;
      _payable = outstanding;
    });
  }

  @override
  Widget build(BuildContext context) {
    if (_loan == null) return Scaffold(appBar: AppBar(), body: const Center(child: CircularProgressIndicator()));

    return Scaffold(
      appBar: AppBar(title: const Text('Pre-Close Loan')),
      body: Padding(
        padding: const EdgeInsets.all(16),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Card(
              child: Padding(
                padding: const EdgeInsets.all(16),
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    const Text('Pre-Closure Summary', style: TextStyle(fontSize: 18, fontWeight: FontWeight.bold)),
                    const Divider(),
                    _row('Principal', CalculationService.formatCurrency(_loan!.principal)),
                    _row('Return Amount', CalculationService.formatCurrency(_loan!.returnAmount)),
                    _row('Total Collected', CalculationService.formatCurrency(_totalCollected)),
                    _row('Remaining', CalculationService.formatCurrency(_loan!.returnAmount - _totalCollected)),
                    const Divider(),
                    Text('Payable Amount: ${CalculationService.formatCurrency(_payable)}', style: const TextStyle(fontSize: 20, fontWeight: FontWeight.bold, color: Colors.red)),
                  ],
                ),
              ),
            ),
            const Spacer(),
            Row(
              children: [
                Expanded(
                  child: OutlinedButton(
                    onPressed: () async {
                      final customer = await _customerDao.getById(_loan!.customerId);
                      if (customer != null) {
                        await _smsService.sendSms(
                          to: customer.mobile,
                          message: _smsService.buildPreClosureMessage(customer: customer, loan: _loan!, payableAmount: _payable),
                          loanId: _loan!.id,
                          customerId: customer.id,
                        );
                      }
                    },
                    child: const Text('Send SMS'),
                  ),
                ),
                const SizedBox(width: 8),
                Expanded(
                  child: FilledButton(
                    onPressed: () async {
                      await _scheduleService.preCloseLoan(_loan!.id!, _payable, _loan!.customerId);
                      if (mounted) Navigator.pop(context, true);
                    },
                    child: const Text('Confirm Pre-Close'),
                  ),
                ),
              ],
            ),
          ],
        ),
      ),
    );
  }

  Widget _row(String label, String value) {
    return Padding(
      padding: const EdgeInsets.symmetric(vertical: 4),
      child: Row(mainAxisAlignment: MainAxisAlignment.spaceBetween, children: [Text(label), Text(value, style: const TextStyle(fontWeight: FontWeight.w600))]),
    );
  }
}
