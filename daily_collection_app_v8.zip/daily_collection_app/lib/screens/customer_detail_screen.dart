import 'package:flutter/material.dart';
import '../database/dao/customer_dao.dart';
import '../database/dao/loan_dao.dart';
import '../database/dao/collection_dao.dart';
import '../models/customer.dart';
import '../models/loan.dart';
import '../services/calculation_service.dart';
import '../services/backup_service.dart';
import 'loan_detail_screen.dart';

class CustomerDetailScreen extends StatefulWidget {
  final int customerId;

  const CustomerDetailScreen({super.key, required this.customerId});

  @override
  State<CustomerDetailScreen> createState() => _CustomerDetailScreenState();
}

class _CustomerDetailScreenState extends State<CustomerDetailScreen> {
  final CustomerDao _customerDao = CustomerDao();
  final LoanDao _loanDao = LoanDao();
  final CollectionDao _collectionDao = CollectionDao();
  final BackupService _backupService = BackupService();

  Customer? _customer;
  List<Loan> _loans = [];
  double _totalCollected = 0;

  @override
  void initState() {
    super.initState();
    _loadData();
  }

  Future<void> _loadData() async {
    final customer = await _customerDao.getById(widget.customerId);
    final loans = await _loanDao.getByCustomer(widget.customerId);
    double total = 0;
    for (final loan in loans) {
      total += await _collectionDao.getTotalCollected(loan.id!);
    }
    setState(() {
      _customer = customer;
      _loans = loans;
      _totalCollected = total;
    });
  }

  @override
  Widget build(BuildContext context) {
    if (_customer == null) {
      return Scaffold(appBar: AppBar(), body: const Center(child: CircularProgressIndicator()));
    }

    final activeLoans = _loans.where((l) => l.status == LoanStatus.active || l.status == LoanStatus.overdue).toList();
    final pastLoans = _loans.where((l) => l.status != LoanStatus.active && l.status != LoanStatus.overdue).toList();

    return Scaffold(
      appBar: AppBar(
        title: Text(_customer!.name),
        actions: [
          PopupMenuButton(
            itemBuilder: (context) => [
              const PopupMenuItem(value: 'edit', child: Text('Edit Customer')),
              const PopupMenuItem(value: 'archive', child: Text('Archive')),
              const PopupMenuItem(value: 'summary_pdf', child: Text('Export Summary PDF')),
              const PopupMenuItem(value: 'summary_excel', child: Text('Export Excel')),
              const PopupMenuItem(value: 'delete', child: Text('Delete Permanently')),
            ],
            onSelected: (value) => _handleMenuAction(value.toString()),
          ),
        ],
      ),
      body: ListView(
        padding: const EdgeInsets.all(16),
        children: [
          Card(
            child: Padding(
              padding: const EdgeInsets.all(16),
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Row(
                    children: [
                      CircleAvatar(radius: 30, child: Text(_customer!.name[0].toUpperCase(), style: const TextStyle(fontSize: 24))),
                      const SizedBox(width: 16),
                      Expanded(
                        child: Column(
                          crossAxisAlignment: CrossAxisAlignment.start,
                          children: [
                            Text(_customer!.name, style: const TextStyle(fontSize: 20, fontWeight: FontWeight.bold)),
                            if (_customer!.nickname != null) Text('Nick: ${_customer!.nickname}'),
                            Text(_customer!.mobile, style: TextStyle(color: Colors.grey[600])),
                            if (_customer!.idNumber != null) Text('ID: ${_customer!.idNumber}', style: TextStyle(fontSize: 12, color: Colors.grey[500])),
                          ],
                        ),
                      ),
                    ],
                  ),
                  const Divider(),
                  _infoRow('Total Loans', '${_loans.length}'),
                  _infoRow('Active Loans', '${activeLoans.length}'),
                  _infoRow('Total Collected', CalculationService.formatCurrency(_totalCollected)),
                ],
              ),
            ),
          ),
          const SizedBox(height: 16),
          if (activeLoans.isNotEmpty) ...[
            const Text('Active Loans', style: TextStyle(fontSize: 18, fontWeight: FontWeight.bold)),
            ...activeLoans.map((loan) => _loanCard(loan)),
            const SizedBox(height: 16),
          ],
          if (pastLoans.isNotEmpty) ...[
            const Text('Past Loans', style: TextStyle(fontSize: 18, fontWeight: FontWeight.bold)),
            ...pastLoans.map((loan) => _loanCard(loan)),
          ],
        ],
      ),
    );
  }

  Widget _loanCard(Loan loan) {
    return Card(
      margin: const EdgeInsets.symmetric(vertical: 4),
      child: ListTile(
        title: Text('Loan #${loan.id} ${loan.accountName.isNotEmpty ? '- ${loan.accountName}' : ''}'),
        subtitle: Text('${CalculationService.formatCurrency(loan.principal)} / ${CalculationService.formatCurrency(loan.returnAmount)}'),
        trailing: loan.isRenewed
          ? Container(padding: const EdgeInsets.symmetric(horizontal: 8, vertical: 4), decoration: BoxDecoration(color: Colors.green.withAlpha(30), borderRadius: BorderRadius.circular(8)), child: const Text('Renewed', style: TextStyle(fontSize: 10, color: Colors.green)))
          : null,
        onTap: () async {
          await Navigator.push(context, MaterialPageRoute(builder: (_) => LoanDetailScreen(loanId: loan.id!)));
          _loadData();
        },
      ),
    );
  }

  Widget _infoRow(String label, String value) {
    return Padding(
      padding: const EdgeInsets.symmetric(vertical: 2),
      child: Row(
        mainAxisAlignment: MainAxisAlignment.spaceBetween,
        children: [
          Text(label, style: TextStyle(color: Colors.grey[600])),
          Text(value, style: const TextStyle(fontWeight: FontWeight.w600)),
        ],
      ),
    );
  }

  void _handleMenuAction(String action) async {
    switch (action) {
      case 'edit':
        // Open edit dialog
        break;
      case 'archive':
        await _customerDao.softDelete(widget.customerId);
        if (mounted) Navigator.pop(context);
        break;
      case 'summary_pdf':
        // Export customer summary as PDF
        break;
      case 'summary_excel':
        // Export as Excel
        break;
      case 'delete':
        final confirm = await showDialog<bool>(
          context: context,
          builder: (ctx) => AlertDialog(
            title: const Text('Delete Permanently'),
            content: const Text('This will delete the customer and all related data. Are you sure?'),
            actions: [TextButton(onPressed: () => Navigator.pop(ctx, false), child: const Text('Cancel')), TextButton(onPressed: () => Navigator.pop(ctx, true), child: const Text('Delete', style: TextStyle(color: Colors.red)))],
          ),
        );
        if (confirm == true) {
          await _customerDao.permanentDelete(widget.customerId);
          if (mounted) Navigator.pop(context);
        }
        break;
    }
  }
}
