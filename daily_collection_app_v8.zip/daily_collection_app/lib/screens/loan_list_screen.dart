import 'package:flutter/material.dart';
import '../database/dao/loan_dao.dart';
import '../models/loan.dart';
import '../services/calculation_service.dart';
import '../widgets/stat_card.dart';
import '../utils/constants.dart';
import 'loan_detail_screen.dart';

class LoanListScreen extends StatefulWidget {
  const LoanListScreen({super.key});

  @override
  State<LoanListScreen> createState() => _LoanListScreenState();
}

class _LoanListScreenState extends State<LoanListScreen> {
  final LoanDao _loanDao = LoanDao();
  List<Map<String, dynamic>> _loans = [];
  LoanStatus? _filterStatus;
  String _searchQuery = '';

  @override
  void initState() {
    super.initState();
    _loadLoans();
  }

  Future<void> _loadLoans() async {
    List<Map<String, dynamic>> loans;
    if (_filterStatus != null) {
      loans = await _loanDao.getByStatusWithCustomer(_filterStatus!.index);
    } else {
      loans = await _loanDao.getAllWithCustomer();
    }
    if (_searchQuery.isNotEmpty) {
      loans = loans.where((l) =>
        (l['customer_name'] as String).toLowerCase().contains(_searchQuery.toLowerCase()) ||
        (l['account_name'] as String? ?? '').toLowerCase().contains(_searchQuery.toLowerCase()) ||
        l['id'].toString().contains(_searchQuery)
      ).toList();
    }
    setState(() => _loans = loans);
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: const Text('Loans')),
      body: Column(
        children: [
          Padding(
            padding: const EdgeInsets.all(8),
            child: TextField(
              decoration: const InputDecoration(hintText: 'Search loans...', prefixIcon: Icon(Icons.search), border: OutlineInputBorder()),
              onChanged: (v) { _searchQuery = v; _loadLoans(); },
            ),
          ),
          SizedBox(
            height: 50,
            child: ListView(
              scrollDirection: Axis.horizontal,
              children: [
                FilterChip(label: const Text('All'), selected: _filterStatus == null, onSelected: (_) { setState(() => _filterStatus = null); _loadLoans(); }),
                ...LoanStatus.values.map((s) => Padding(
                  padding: const EdgeInsets.only(left: 4),
                  child: FilterChip(label: Text(AppConstants.loanStatusNames[s.index]), selected: _filterStatus == s, onSelected: (_) { setState(() => _filterStatus = s); _loadLoans(); }),
                )),
              ],
            ),
          ),
          Expanded(
            child: _loans.isEmpty
                ? const Center(child: Text('No loans found'))
                : ListView.builder(
                    itemCount: _loans.length,
                    itemBuilder: (context, index) {
                      final l = _loans[index];
                      final loan = Loan.fromMap(l);
                      return Card(
                        margin: const EdgeInsets.symmetric(horizontal: 8, vertical: 3),
                        child: ListTile(
                          title: Text('${l['customer_name']} - Loan #${loan.id}'),
                          subtitle: Text('${CalculationService.formatCurrency(loan.principal)} -> ${CalculationService.formatCurrency(loan.returnAmount)}'),
                          trailing: Container(
                            padding: const EdgeInsets.symmetric(horizontal: 8, vertical: 4),
                            decoration: BoxDecoration(color: _statusColor(loan.status).withAlpha(30), borderRadius: BorderRadius.circular(8)),
                            child: Text(loan.status.name, style: TextStyle(color: _statusColor(loan.status), fontSize: 11)),
                          ),
                          onTap: () async {
                            await Navigator.push(context, MaterialPageRoute(builder: (_) => LoanDetailScreen(loanId: loan.id!)));
                            _loadLoans();
                          },
                        ),
                      );
                    },
                  ),
          ),
        ],
      ),
    );
  }

  Color _statusColor(LoanStatus status) {
    switch (status) {
      case LoanStatus.active: return Colors.blue;
      case LoanStatus.overdue: return Colors.red;
      case LoanStatus.preClosed: return Colors.purple;
      case LoanStatus.completed: return Colors.green;
      case LoanStatus.defaulted: return Colors.grey;
      case LoanStatus.cancelled: return Colors.orange;
    }
  }
}
