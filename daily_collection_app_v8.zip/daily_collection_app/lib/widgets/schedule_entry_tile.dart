import 'package:flutter/material.dart';
import '../models/schedule_entry.dart';
import '../services/calculation_service.dart';

class ScheduleEntryTile extends StatelessWidget {
  final ScheduleEntry entry;
  final VoidCallback? onTap;

  const ScheduleEntryTile({
    super.key,
    required this.entry,
    this.onTap,
  });

  @override
  Widget build(BuildContext context) {
    IconData icon;
    Color iconColor;
    String statusText;

    switch (entry.status) {
      case ScheduleEntryStatus.paid:
        icon = Icons.check_circle;
        iconColor = Colors.green;
        statusText = 'Paid';
        break;
      case ScheduleEntryStatus.pending:
        icon = Icons.radio_button_unchecked;
        iconColor = Colors.blue;
        statusText = 'Pending';
        break;
      case ScheduleEntryStatus.missed:
        icon = Icons.cancel;
        iconColor = Colors.red;
        statusText = 'Missed';
        break;
      case ScheduleEntryStatus.partial:
        icon = Icons.remove_circle;
        iconColor = Colors.orange;
        statusText = 'Partial';
        break;
      case ScheduleEntryStatus.holiday:
        icon = Icons.beach_access;
        iconColor = Colors.purple;
        statusText = 'Holiday';
        break;
      case ScheduleEntryStatus.overdue:
        icon = Icons.warning;
        iconColor = Colors.red;
        statusText = 'Overdue';
        break;
    }

    return Card(
      margin: const EdgeInsets.symmetric(horizontal: 8, vertical: 2),
      child: ListTile(
        leading: Icon(icon, color: iconColor, size: 32),
        title: Row(
          children: [
            Text('Day ${entry.dayNumber}', style: const TextStyle(fontWeight: FontWeight.w600)),
            const SizedBox(width: 8),
            Text(
              CalculationService.formatDate(entry.entryDate),
              style: TextStyle(fontSize: 12, color: Colors.grey[600]),
            ),
          ],
        ),
        subtitle: Row(
          children: [
            if (entry.isSunday)
              Padding(
                padding: const EdgeInsets.only(right: 4),
                child: Icon(Icons.wb_sunny, size: 12, color: Colors.orange[300]),
              ),
            Text(
              '${CalculationService.formatCurrency(entry.expectedAmount)}',
              style: const TextStyle(fontSize: 13),
            ),
            if (entry.isPartial) ...[
              const SizedBox(width: 8),
              Text(
                '(Paid: ${CalculationService.formatCurrency(entry.collectedAmount)})',
                style: TextStyle(fontSize: 12, color: Colors.orange[700]),
              ),
            ],
            const SizedBox(width: 8),
            Container(
              padding: const EdgeInsets.symmetric(horizontal: 6, vertical: 1),
              decoration: BoxDecoration(
                color: iconColor.withAlpha(30),
                borderRadius: BorderRadius.circular(8),
              ),
              child: Text(statusText, style: TextStyle(fontSize: 10, color: iconColor)),
            ),
          ],
        ),
        onTap: onTap,
        trailing: entry.isPending || entry.isPartial || entry.isOverdue
            ? const Icon(Icons.touch_app, size: 18, color: Colors.blue)
            : null,
      ),
    );
  }
}
