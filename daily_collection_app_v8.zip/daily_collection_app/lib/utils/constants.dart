import 'package:flutter/material.dart';

class AppColors {
  static const Color primary = Color(0xFF1565C0);
  static const Color primaryLight = Color(0xFF42A5F5);
  static const Color primaryDark = Color(0xFF0D47A1);
  static const Color secondary = Color(0xFF26A69A);
  static const Color background = Color(0xFFF5F5F5);
  static const Color surface = Colors.white;
  static const Color error = Color(0xFFE53935);
  static const Color success = Color(0xFF4CAF50);
  static const Color warning = Color(0xFFFF9800);
  static const Color textPrimary = Color(0xFF212121);
  static const Color textSecondary = Color(0xFF757575);
}

class DarkColors {
  static const Color primary = Color(0xFF42A5F5);
  static const Color background = Color(0xFF121212);
  static const Color surface = Color(0xFF1E1E1E);
  static const Color textPrimary = Colors.white;
  static const Color textSecondary = Color(0xFFB0B0B0);
}

class ThemeColors {
  static const List<Color> colors = [
    Color(0xFF1565C0), // blue
    Color(0xFF2E7D32), // green
    Color(0xFF6A1B9A), // purple
    Color(0xFFE65100), // orange
    Color(0xFF00897B), // teal
  ];

  static const List<String> colorNames = ['Blue', 'Green', 'Purple', 'Orange', 'Teal'];

  static Color getColor(int index) => colors[index % colors.length];
}

class AppConstants {
  static const String appName = 'Daily Collection';
  static const String appVersion = '3.0.0';
  static const String createdBy = 'Created by Harish';
  static const String developerName = 'Harish K Patidar';

  static const List<String> paymentModes = ['Cash', 'UPI', 'Bank', 'Other'];
  static const List<String> loanStatusNames = [
    'Active', 'Overdue', 'Pre-Closed', 'Completed', 'Defaulted', 'Cancelled'
  ];

  static const List<String> interestModeNames = [
    'Fixed Return', 'Flat Monthly %', 'Reducing Balance'
  ];

  static const List<String> excessPaymentModes = [
    'Next Installment', 'Principal Adjust', 'Separate Entry'
  ];

  static const List<String> sortOrderNames = [
    'New to Old', 'Old to New', 'Paid First', 'Unpaid First', 'Pending First', 'Missed First'
  ];

  static const List<String> securityQuestions = [
    'What is your pet name?',
    'What is your mother maiden name?',
    'What is your birth city?',
    'What is your favorite movie?',
  ];
}
