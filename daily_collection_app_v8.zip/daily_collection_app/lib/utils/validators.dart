class Validators {
  static String? validateName(String? value) {
    if (value == null || value.trim().isEmpty) {
      return 'Name is required';
    }
    if (value.trim().length < 2) {
      return 'Name too short';
    }
    return null;
  }

  static String? validateMobile(String? value) {
    if (value == null || value.trim().isEmpty) {
      return 'Mobile is required';
    }
    final cleaned = value.replaceAll(RegExp(r'[^0-9]'), '');
    if (cleaned.length != 10) {
      return 'Enter valid 10-digit mobile';
    }
    return null;
  }

  static String? validateAmount(String? value) {
    if (value == null || value.trim().isEmpty) {
      return 'Amount is required';
    }
    final amount = double.tryParse(value);
    if (amount == null || amount <= 0) {
      return 'Enter valid amount';
    }
    return null;
  }

  static String? validateReturnAmount(String? value, String? principalStr) {
    if (value == null || value.trim().isEmpty) {
      return 'Return amount is required';
    }
    final returnAmount = double.tryParse(value);
    if (returnAmount == null || returnAmount <= 0) {
      return 'Enter valid amount';
    }
    final principal = double.tryParse(principalStr ?? '0') ?? 0;
    if (returnAmount < principal) {
      return 'Return amount must be >= principal';
    }
    return null;
  }

  static String? validateDailyInstallment(String? value) {
    if (value == null || value.trim().isEmpty) {
      return 'Daily installment is required';
    }
    final amount = double.tryParse(value);
    if (amount == null || amount <= 0) {
      return 'Enter valid amount';
    }
    return null;
  }

  static String? validatePin(String? value) {
    if (value == null || value.trim().isEmpty) {
      return 'PIN is required';
    }
    if (value.length != 4) {
      return 'PIN must be 4 digits';
    }
    if (int.tryParse(value) == null) {
      return 'PIN must be numeric';
    }
    return null;
  }

  static String? validateMonthlyRate(String? value) {
    if (value == null || value.trim().isEmpty) {
      return 'Monthly rate is required';
    }
    final rate = double.tryParse(value);
    if (rate == null || rate < 0) {
      return 'Enter valid rate';
    }
    return null;
  }

  static String? validateMonths(String? value) {
    if (value == null || value.trim().isEmpty) {
      return 'Tenure is required';
    }
    final months = int.tryParse(value);
    if (months == null || months <= 0) {
      return 'Enter valid months';
    }
    return null;
  }

  static String? validateSecurityAnswer(String? value) {
    if (value == null || value.trim().isEmpty) {
      return 'Answer is required';
    }
    return null;
  }
}
