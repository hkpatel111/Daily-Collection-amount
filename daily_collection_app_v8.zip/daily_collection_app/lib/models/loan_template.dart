import '../models/loan.dart';

class LoanTemplate {
  final int? id;
  String name;
  double principal;
  double returnAmount;
  double dailyInstallment;
  int totalDays;
  double monthlyInterestRate;
  InterestMode interestMode;
  int gracePeriod;
  bool sundayHolidayEnabled;
  double lateFeePerDay;
  bool lateFeeEnabled;
  String excessPaymentMode;

  LoanTemplate({
    this.id,
    required this.name,
    required this.principal,
    required this.returnAmount,
    required this.dailyInstallment,
    required this.totalDays,
    this.monthlyInterestRate = 0,
    this.interestMode = InterestMode.fixedReturn,
    this.gracePeriod = 0,
    this.sundayHolidayEnabled = false,
    this.lateFeePerDay = 0,
    this.lateFeeEnabled = false,
    this.excessPaymentMode = 'separateEntry',
  });

  Map<String, dynamic> toMap() {
    return {
      'id': id,
      'name': name,
      'principal': principal,
      'return_amount': returnAmount,
      'daily_installment': dailyInstallment,
      'total_days': totalDays,
      'monthly_interest_rate': monthlyInterestRate,
      'interest_mode': interestMode.index,
      'grace_period': gracePeriod,
      'sunday_holiday_enabled': sundayHolidayEnabled ? 1 : 0,
      'late_fee_per_day': lateFeePerDay,
      'late_fee_enabled': lateFeeEnabled ? 1 : 0,
      'excess_payment_mode': excessPaymentMode,
    };
  }

  factory LoanTemplate.fromMap(Map<String, dynamic> map) {
    return LoanTemplate(
      id: map['id'] as int?,
      name: map['name'] as String,
      principal: (map['principal'] as num).toDouble(),
      returnAmount: (map['return_amount'] as num).toDouble(),
      dailyInstallment: (map['daily_installment'] as num).toDouble(),
      totalDays: map['total_days'] as int,
      monthlyInterestRate: (map['monthly_interest_rate'] as num?)?.toDouble() ?? 0,
      interestMode: InterestMode.values[(map['interest_mode'] as int?) ?? 0],
      gracePeriod: (map['grace_period'] as int?) ?? 0,
      sundayHolidayEnabled: ((map['sunday_holiday_enabled'] as int?) ?? 0) == 1,
      lateFeePerDay: (map['late_fee_per_day'] as num?)?.toDouble() ?? 0,
      lateFeeEnabled: ((map['late_fee_enabled'] as int?) ?? 0) == 1,
      excessPaymentMode: (map['excess_payment_mode'] as String?) ?? 'separateEntry',
    );
  }
}
