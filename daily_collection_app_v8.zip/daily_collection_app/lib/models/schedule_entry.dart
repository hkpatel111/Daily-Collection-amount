enum ScheduleEntryStatus { pending, paid, missed, partial, holiday, overdue }

enum ScheduleSortOrder { newToOld, oldToNew, paidFirst, unpaidFirst, pendingFirst, missedFirst }

class ScheduleEntry {
  final int? id;
  int loanId;
  DateTime entryDate;
  double expectedAmount;
  double collectedAmount;
  ScheduleEntryStatus status;
  int dayNumber;
  bool isSunday;

  ScheduleEntry({
    this.id,
    required this.loanId,
    required this.entryDate,
    required this.expectedAmount,
    this.collectedAmount = 0,
    this.status = ScheduleEntryStatus.pending,
    required this.dayNumber,
    this.isSunday = false,
  });

  bool get isPaid => status == ScheduleEntryStatus.paid;
  bool get isPartial => status == ScheduleEntryStatus.partial;
  bool get isPending => status == ScheduleEntryStatus.pending;
  bool get isMissed => status == ScheduleEntryStatus.missed;
  bool get isHoliday => status == ScheduleEntryStatus.holiday;
  double get remainingAmount => expectedAmount - collectedAmount;

  Map<String, dynamic> toMap() {
    return {
      'id': id,
      'loan_id': loanId,
      'entry_date': entryDate.toIso8601String(),
      'expected_amount': expectedAmount,
      'collected_amount': collectedAmount,
      'status': status.index,
      'day_number': dayNumber,
      'is_sunday': isSunday ? 1 : 0,
    };
  }

  factory ScheduleEntry.fromMap(Map<String, dynamic> map) {
    return ScheduleEntry(
      id: map['id'] as int?,
      loanId: map['loan_id'] as int,
      entryDate: DateTime.parse(map['entry_date'] as String),
      expectedAmount: (map['expected_amount'] as num).toDouble(),
      collectedAmount: (map['collected_amount'] as num?)?.toDouble() ?? 0,
      status: ScheduleEntryStatus.values[map['status'] as int],
      dayNumber: map['day_number'] as int,
      isSunday: ((map['is_sunday'] as int?) ?? 0) == 1,
    );
  }

  ScheduleEntry copyWith({
    int? id,
    int? loanId,
    DateTime? entryDate,
    double? expectedAmount,
    double? collectedAmount,
    ScheduleEntryStatus? status,
    int? dayNumber,
    bool? isSunday,
  }) {
    return ScheduleEntry(
      id: id ?? this.id,
      loanId: loanId ?? this.loanId,
      entryDate: entryDate ?? this.entryDate,
      expectedAmount: expectedAmount ?? this.expectedAmount,
      collectedAmount: collectedAmount ?? this.collectedAmount,
      status: status ?? this.status,
      dayNumber: dayNumber ?? this.dayNumber,
      isSunday: isSunday ?? this.isSunday,
    );
  }
}
