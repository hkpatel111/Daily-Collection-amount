enum LoanStatus { active, overdue, preClosed, completed, defaulted, cancelled }

enum InterestMode { fixedReturn, flatMonthly, reducingBalance }

class Loan {
  final int? id;
  int customerId;
  String accountName;
  String? tag;
  double principal;
  double returnAmount;
  double dailyInstallment;
  DateTime startDate;
  int totalDays;
  double monthlyInterestRate;
  InterestMode interestMode;
  int gracePeriod;
  bool sundayHolidayEnabled;
  double lateFeePerDay;
  bool lateFeeEnabled;
  String? excessPaymentMode; // nextInstallment, principalAdjust, separateEntry
  LoanStatus status;
  int? renewedFromLoanId;
  DateTime createdAt;
  DateTime updatedAt;

  Loan({
    this.id,
    required this.customerId,
    this.accountName = '',
    this.tag,
    required this.principal,
    required this.returnAmount,
    required this.dailyInstallment,
    required this.startDate,
    required this.totalDays,
    this.monthlyInterestRate = 0,
    this.interestMode = InterestMode.fixedReturn,
    this.gracePeriod = 0,
    this.sundayHolidayEnabled = false,
    this.lateFeePerDay = 0,
    this.lateFeeEnabled = false,
    this.excessPaymentMode = 'separateEntry',
    this.status = LoanStatus.active,
    this.renewedFromLoanId,
    DateTime? createdAt,
    DateTime? updatedAt,
  })  : createdAt = createdAt ?? DateTime.now(),
        updatedAt = updatedAt ?? DateTime.now();

  double get profit => returnAmount - principal;
  bool get isRenewed => renewedFromLoanId != null;

  Map<String, dynamic> toMap() {
    return {
      'id': id,
      'customer_id': customerId,
      'account_name': accountName,
      'tag': tag,
      'principal': principal,
      'return_amount': returnAmount,
      'daily_installment': dailyInstallment,
      'start_date': startDate.toIso8601String(),
      'total_days': totalDays,
      'monthly_interest_rate': monthlyInterestRate,
      'interest_mode': interestMode.index,
      'grace_period': gracePeriod,
      'sunday_holiday_enabled': sundayHolidayEnabled ? 1 : 0,
      'late_fee_per_day': lateFeePerDay,
      'late_fee_enabled': lateFeeEnabled ? 1 : 0,
      'excess_payment_mode': excessPaymentMode,
      'status': status.index,
      'renewed_from_loan_id': renewedFromLoanId,
      'created_at': createdAt.toIso8601String(),
      'updated_at': updatedAt.toIso8601String(),
    };
  }

  factory Loan.fromMap(Map<String, dynamic> map) {
    return Loan(
      id: map['id'] as int?,
      customerId: map['customer_id'] as int,
      accountName: (map['account_name'] as String?) ?? '',
      tag: map['tag'] as String?,
      principal: (map['principal'] as num).toDouble(),
      returnAmount: (map['return_amount'] as num).toDouble(),
      dailyInstallment: (map['daily_installment'] as num).toDouble(),
      startDate: DateTime.parse(map['start_date'] as String),
      totalDays: map['total_days'] as int,
      monthlyInterestRate: (map['monthly_interest_rate'] as num?)?.toDouble() ?? 0,
      interestMode: InterestMode.values[(map['interest_mode'] as int?) ?? 0],
      gracePeriod: (map['grace_period'] as int?) ?? 0,
      sundayHolidayEnabled: ((map['sunday_holiday_enabled'] as int?) ?? 0) == 1,
      lateFeePerDay: (map['late_fee_per_day'] as num?)?.toDouble() ?? 0,
      lateFeeEnabled: ((map['late_fee_enabled'] as int?) ?? 0) == 1,
      excessPaymentMode: (map['excess_payment_mode'] as String?) ?? 'separateEntry',
      status: LoanStatus.values[map['status'] as int],
      renewedFromLoanId: map['renewed_from_loan_id'] as int?,
      createdAt: DateTime.parse(map['created_at'] as String),
      updatedAt: DateTime.parse(map['updated_at'] as String),
    );
  }

  Loan copyWith({
    int? id,
    int? customerId,
    String? accountName,
    String? tag,
    double? principal,
    double? returnAmount,
    double? dailyInstallment,
    DateTime? startDate,
    int? totalDays,
    double? monthlyInterestRate,
    InterestMode? interestMode,
    int? gracePeriod,
    bool? sundayHolidayEnabled,
    double? lateFeePerDay,
    bool? lateFeeEnabled,
    String? excessPaymentMode,
    LoanStatus? status,
    int? renewedFromLoanId,
    DateTime? createdAt,
    DateTime? updatedAt,
  }) {
    return Loan(
      id: id ?? this.id,
      customerId: customerId ?? this.customerId,
      accountName: accountName ?? this.accountName,
      tag: tag ?? this.tag,
      principal: principal ?? this.principal,
      returnAmount: returnAmount ?? this.returnAmount,
      dailyInstallment: dailyInstallment ?? this.dailyInstallment,
      startDate: startDate ?? this.startDate,
      totalDays: totalDays ?? this.totalDays,
      monthlyInterestRate: monthlyInterestRate ?? this.monthlyInterestRate,
      interestMode: interestMode ?? this.interestMode,
      gracePeriod: gracePeriod ?? this.gracePeriod,
      sundayHolidayEnabled: sundayHolidayEnabled ?? this.sundayHolidayEnabled,
      lateFeePerDay: lateFeePerDay ?? this.lateFeePerDay,
      lateFeeEnabled: lateFeeEnabled ?? this.lateFeeEnabled,
      excessPaymentMode: excessPaymentMode ?? this.excessPaymentMode,
      status: status ?? this.status,
      renewedFromLoanId: renewedFromLoanId ?? this.renewedFromLoanId,
      createdAt: createdAt ?? this.createdAt,
      updatedAt: updatedAt ?? this.updatedAt,
    );
  }
}
