class Customer {
  final int? id;
  String name;
  String mobile;
  String? nickname;
  bool isActive;
  String? photoPath;
  String? idNumber;
  DateTime createdAt;
  DateTime updatedAt;

  Customer({
    this.id,
    required this.name,
    required this.mobile,
    this.nickname,
    this.isActive = true,
    this.photoPath,
    this.idNumber,
    DateTime? createdAt,
    DateTime? updatedAt,
  })  : createdAt = createdAt ?? DateTime.now(),
        updatedAt = updatedAt ?? DateTime.now();

  String get displayName => nickname?.isNotEmpty == true ? '$nickname ($name)' : name;

  Map<String, dynamic> toMap() {
    return {
      'id': id,
      'name': name,
      'mobile': mobile,
      'nickname': nickname,
      'photo_path': photoPath,
      'id_number': idNumber,
      'is_active': isActive ? 1 : 0,
      'created_at': createdAt.toIso8601String(),
      'updated_at': updatedAt.toIso8601String(),
    };
  }

  factory Customer.fromMap(Map<String, dynamic> map) {
    return Customer(
      id: map['id'] as int?,
      name: map['name'] as String,
      mobile: map['mobile'] as String,
      nickname: map['nickname'] as String?,
      photoPath: map['photo_path'] as String?,
      idNumber: map['id_number'] as String?,
      isActive: (map['is_active'] as int) == 1,
      createdAt: DateTime.parse(map['created_at'] as String),
      updatedAt: DateTime.parse(map['updated_at'] as String),
    );
  }

  Customer copyWith({
    int? id,
    String? name,
    String? mobile,
    String? nickname,
    bool? isActive,
    String? photoPath,
    String? idNumber,
    DateTime? createdAt,
    DateTime? updatedAt,
  }) {
    return Customer(
      id: id ?? this.id,
      name: name ?? this.name,
      mobile: mobile ?? this.mobile,
      nickname: nickname ?? this.nickname,
      isActive: isActive ?? this.isActive,
      photoPath: photoPath ?? this.photoPath,
      idNumber: idNumber ?? this.idNumber,
      createdAt: createdAt ?? this.createdAt,
      updatedAt: updatedAt ?? this.updatedAt,
    );
  }
}
