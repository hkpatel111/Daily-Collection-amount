enum SmsStatus { sent, failed }

class SmsLog {
  final int? id;
  int? loanId;
  int? customerId;
  String recipient;
  String message;
  SmsStatus status;
  DateTime sentAt;

  SmsLog({
    this.id,
    this.loanId,
    this.customerId,
    required this.recipient,
    required this.message,
    this.status = SmsStatus.sent,
    DateTime? sentAt,
  }) : sentAt = sentAt ?? DateTime.now();

  Map<String, dynamic> toMap() {
    return {
      'id': id,
      'loan_id': loanId,
      'customer_id': customerId,
      'recipient': recipient,
      'message': message,
      'status': status.index,
      'sent_at': sentAt.toIso8601String(),
    };
  }

  factory SmsLog.fromMap(Map<String, dynamic> map) {
    return SmsLog(
      id: map['id'] as int?,
      loanId: map['loan_id'] as int?,
      customerId: map['customer_id'] as int?,
      recipient: map['recipient'] as String,
      message: map['message'] as String,
      status: SmsStatus.values[map['status'] as int],
      sentAt: DateTime.parse(map['sent_at'] as String),
    );
  }
}
