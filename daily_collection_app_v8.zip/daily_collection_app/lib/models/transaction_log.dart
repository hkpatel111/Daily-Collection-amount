class TransactionLog {
  final int? id;
  int? customerId;
  int? loanId;
  int? collectionEntryId;
  String action;
  String description;
  DateTime timestamp;

  TransactionLog({
    this.id,
    this.customerId,
    this.loanId,
    this.collectionEntryId,
    required this.action,
    required this.description,
    DateTime? timestamp,
  }) : timestamp = timestamp ?? DateTime.now();

  Map<String, dynamic> toMap() {
    return {
      'id': id,
      'customer_id': customerId,
      'loan_id': loanId,
      'collection_entry_id': collectionEntryId,
      'action': action,
      'description': description,
      'timestamp': timestamp.toIso8601String(),
    };
  }

  factory TransactionLog.fromMap(Map<String, dynamic> map) {
    return TransactionLog(
      id: map['id'] as int?,
      customerId: map['customer_id'] as int?,
      loanId: map['loan_id'] as int?,
      collectionEntryId: map['collection_entry_id'] as int?,
      action: map['action'] as String,
      description: map['description'] as String,
      timestamp: DateTime.parse(map['timestamp'] as String),
    );
  }
}
