class EditHistory {
  final int? id;
  int collectionEntryId;
  String fieldName;
  String oldValue;
  String newValue;
  DateTime editedAt;

  EditHistory({
    this.id,
    required this.collectionEntryId,
    required this.fieldName,
    required this.oldValue,
    required this.newValue,
    DateTime? editedAt,
  }) : editedAt = editedAt ?? DateTime.now();

  Map<String, dynamic> toMap() {
    return {
      'id': id,
      'collection_entry_id': collectionEntryId,
      'field_name': fieldName,
      'old_value': oldValue,
      'new_value': newValue,
      'edited_at': editedAt.toIso8601String(),
    };
  }

  factory EditHistory.fromMap(Map<String, dynamic> map) {
    return EditHistory(
      id: map['id'] as int?,
      collectionEntryId: map['collection_entry_id'] as int,
      fieldName: map['field_name'] as String,
      oldValue: map['old_value'] as String,
      newValue: map['new_value'] as String,
      editedAt: DateTime.parse(map['edited_at'] as String),
    );
  }
}
