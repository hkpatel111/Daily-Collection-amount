enum PaymentMode { cash, upi, bank, other }

class CollectionEntry {
  final int? id;
  int scheduleEntryId;
  int loanId;
  int customerId;
  DateTime collectedDate;
  double amount;
  PaymentMode paymentMode;
  String? note;

  CollectionEntry({
    this.id,
    required this.scheduleEntryId,
    required this.loanId,
    required this.customerId,
    required this.collectedDate,
    required this.amount,
    this.paymentMode = PaymentMode.cash,
    this.note,
  });

  Map<String, dynamic> toMap() {
    return {
      'id': id,
      'schedule_entry_id': scheduleEntryId,
      'loan_id': loanId,
      'customer_id': customerId,
      'collected_date': collectedDate.toIso8601String(),
      'amount': amount,
      'payment_mode': paymentMode.index,
      'note': note,
    };
  }

  factory CollectionEntry.fromMap(Map<String, dynamic> map) {
    return CollectionEntry(
      id: map['id'] as int?,
      scheduleEntryId: map['schedule_entry_id'] as int,
      loanId: map['loan_id'] as int,
      customerId: map['customer_id'] as int,
      collectedDate: DateTime.parse(map['collected_date'] as String),
      amount: (map['amount'] as num).toDouble(),
      paymentMode: PaymentMode.values[map['payment_mode'] as int],
      note: map['note'] as String?,
    );
  }

  CollectionEntry copyWith({
    int? id,
    int? scheduleEntryId,
    int? loanId,
    int? customerId,
    DateTime? collectedDate,
    double? amount,
    PaymentMode? paymentMode,
    String? note,
  }) {
    return CollectionEntry(
      id: id ?? this.id,
      scheduleEntryId: scheduleEntryId ?? this.scheduleEntryId,
      loanId: loanId ?? this.loanId,
      customerId: customerId ?? this.customerId,
      collectedDate: collectedDate ?? this.collectedDate,
      amount: amount ?? this.amount,
      paymentMode: paymentMode ?? this.paymentMode,
      note: note ?? this.note,
    );
  }
}
