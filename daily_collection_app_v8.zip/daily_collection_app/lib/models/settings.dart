class AppSettings {
  bool isDarkMode;
  int themeColorIndex;
  bool appLockEnabled;
  String? appPin;
  String? securityQuestion;
  String? securityAnswer;
  bool autoBackupEnabled;
  int autoBackupIntervalDays;
  String? backupPath;
  bool notificationEnabled;
  String notificationTime;
  bool reminderSmsEnabled;
  int reminderSmsDays;
  bool sundayHolidayDefault;
  int defaultGracePeriod;
  double defaultLateFeePerDay;
  bool defaultLateFeeEnabled;
  InterestDisplayMode interestDisplayMode;
  String currencySymbol;
  bool driveBackupEnabled;

  AppSettings({
    this.isDarkMode = false,
    this.themeColorIndex = 0,
    this.appLockEnabled = false,
    this.appPin,
    this.securityQuestion,
    this.securityAnswer,
    this.autoBackupEnabled = false,
    this.autoBackupIntervalDays = 7,
    this.backupPath,
    this.notificationEnabled = false,
    this.notificationTime = '09:00',
    this.reminderSmsEnabled = false,
    this.reminderSmsDays = 1,
    this.sundayHolidayDefault = false,
    this.defaultGracePeriod = 0,
    this.defaultLateFeePerDay = 0,
    this.defaultLateFeeEnabled = false,
    this.interestDisplayMode = InterestDisplayMode.monthly,
    this.currencySymbol = '\u20B9',
    this.driveBackupEnabled = false,
  });

  Map<String, dynamic> toMap() {
    return {
      'id': 1,
      'is_dark_mode': isDarkMode ? 1 : 0,
      'theme_color_index': themeColorIndex,
      'app_lock_enabled': appLockEnabled ? 1 : 0,
      'app_pin': appPin,
      'security_question': securityQuestion,
      'security_answer': securityAnswer,
      'auto_backup_enabled': autoBackupEnabled ? 1 : 0,
      'auto_backup_interval_days': autoBackupIntervalDays,
      'backup_path': backupPath,
      'notification_enabled': notificationEnabled ? 1 : 0,
      'notification_time': notificationTime,
      'reminder_sms_enabled': reminderSmsEnabled ? 1 : 0,
      'reminder_sms_days': reminderSmsDays,
      'sunday_holiday_default': sundayHolidayDefault ? 1 : 0,
      'default_grace_period': defaultGracePeriod,
      'default_late_fee_per_day': defaultLateFeePerDay,
      'default_late_fee_enabled': defaultLateFeeEnabled ? 1 : 0,
      'interest_display_mode': interestDisplayMode.index,
      'currency_symbol': currencySymbol,
      'drive_backup_enabled': driveBackupEnabled ? 1 : 0,
    };
  }

  factory AppSettings.fromMap(Map<String, dynamic> map) {
    return AppSettings(
      isDarkMode: ((map['is_dark_mode'] as int?) ?? 0) == 1,
      themeColorIndex: (map['theme_color_index'] as int?) ?? 0,
      appLockEnabled: ((map['app_lock_enabled'] as int?) ?? 0) == 1,
      appPin: map['app_pin'] as String?,
      securityQuestion: map['security_question'] as String?,
      securityAnswer: map['security_answer'] as String?,
      autoBackupEnabled: ((map['auto_backup_enabled'] as int?) ?? 0) == 1,
      autoBackupIntervalDays: (map['auto_backup_interval_days'] as int?) ?? 7,
      backupPath: map['backup_path'] as String?,
      notificationEnabled: ((map['notification_enabled'] as int?) ?? 0) == 1,
      notificationTime: (map['notification_time'] as String?) ?? '09:00',
      reminderSmsEnabled: ((map['reminder_sms_enabled'] as int?) ?? 0) == 1,
      reminderSmsDays: (map['reminder_sms_days'] as int?) ?? 1,
      sundayHolidayDefault: ((map['sunday_holiday_default'] as int?) ?? 0) == 1,
      defaultGracePeriod: (map['default_grace_period'] as int?) ?? 0,
      defaultLateFeePerDay: (map['default_late_fee_per_day'] as num?)?.toDouble() ?? 0,
      defaultLateFeeEnabled: ((map['default_late_fee_enabled'] as int?) ?? 0) == 1,
      interestDisplayMode: InterestDisplayMode.values[(map['interest_display_mode'] as int?) ?? 1],
      currencySymbol: (map['currency_symbol'] as String?) ?? '\u20B9',
      driveBackupEnabled: ((map['drive_backup_enabled'] as int?) ?? 0) == 1,
    );
  }

  AppSettings copyWith({
    bool? isDarkMode,
    int? themeColorIndex,
    bool? appLockEnabled,
    String? appPin,
    String? securityQuestion,
    String? securityAnswer,
    bool? autoBackupEnabled,
    int? autoBackupIntervalDays,
    String? backupPath,
    bool? notificationEnabled,
    String? notificationTime,
    bool? reminderSmsEnabled,
    int? reminderSmsDays,
    bool? sundayHolidayDefault,
    int? defaultGracePeriod,
    double? defaultLateFeePerDay,
    bool? defaultLateFeeEnabled,
    InterestDisplayMode? interestDisplayMode,
    String? currencySymbol,
    bool? driveBackupEnabled,
  }) {
    return AppSettings(
      isDarkMode: isDarkMode ?? this.isDarkMode,
      themeColorIndex: themeColorIndex ?? this.themeColorIndex,
      appLockEnabled: appLockEnabled ?? this.appLockEnabled,
      appPin: appPin ?? this.appPin,
      securityQuestion: securityQuestion ?? this.securityQuestion,
      securityAnswer: securityAnswer ?? this.securityAnswer,
      autoBackupEnabled: autoBackupEnabled ?? this.autoBackupEnabled,
      autoBackupIntervalDays: autoBackupIntervalDays ?? this.autoBackupIntervalDays,
      backupPath: backupPath ?? this.backupPath,
      notificationEnabled: notificationEnabled ?? this.notificationEnabled,
      notificationTime: notificationTime ?? this.notificationTime,
      reminderSmsEnabled: reminderSmsEnabled ?? this.reminderSmsEnabled,
      reminderSmsDays: reminderSmsDays ?? this.reminderSmsDays,
      sundayHolidayDefault: sundayHolidayDefault ?? this.sundayHolidayDefault,
      defaultGracePeriod: defaultGracePeriod ?? this.defaultGracePeriod,
      defaultLateFeePerDay: defaultLateFeePerDay ?? this.defaultLateFeePerDay,
      defaultLateFeeEnabled: defaultLateFeeEnabled ?? this.defaultLateFeeEnabled,
      interestDisplayMode: interestDisplayMode ?? this.interestDisplayMode,
      currencySymbol: currencySymbol ?? this.currencySymbol,
      driveBackupEnabled: driveBackupEnabled ?? this.driveBackupEnabled,
    );
  }
}

enum InterestDisplayMode { daily, monthly, yearly }
