# Daily Collection App v3.0

Daily Collection Loan Tracking App for Android.

## Features
- Fixed Return, Flat Monthly %, and Reducing Balance (EMI) loan modes
- Live interchangeable calculations during loan creation
- Monthly interest rate display (default) with yearly option
- PDF receipts, loan summaries, and outstanding snapshots
- Excel export/import with round-trip restore
- Custom-path auto-backup with restore on reinstall
- Daily notification reminders
- 10 live calculators with monthly/yearly rate toggle
- Loan renewal without losing history
- WhatsApp integration for PDF receipts and summaries
- PIN-based app lock with security question recovery
- SQLite database with 9 tables
- Theme customization (dark mode + 5 colors)
- Created by Harish

## Build
Upload ZIP to GitHub repo, add workflow file to .github/workflows/, trigger build.

## Developer
Harish K Patidar
